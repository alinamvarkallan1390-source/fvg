"""Compatibility patch for Balethon 1.1.0 type handling on Python 3.14."""
import types
import typing


def install():
    import balethon.objects.object as module
    from balethon.enums import NameEnum
    from balethon.objects.list import List as BalethonList

    def convert(expected, value):
        if value is None:
            return None
        origin = typing.get_origin(expected)
        args = typing.get_args(expected)
        if origin in (typing.Union, types.UnionType):
            candidates = [arg for arg in args if arg is not type(None)]
            # Preserve already matching primitive values (important for int | str).
            for candidate in candidates:
                if isinstance(candidate, type) and isinstance(value, candidate):
                    return value
            for candidate in candidates:
                if isinstance(candidate, type) and issubclass(candidate, module.Object) and isinstance(value, dict):
                    return candidate.wrap(value)
                if typing.get_origin(candidate) is list and isinstance(value, list):
                    return convert(candidate, value)
            return value
        if origin is list:
            if not isinstance(value, list):
                return value
            item_type = args[0] if args else typing.Any
            return BalethonList([convert(item_type, item) for item in value])
        if not isinstance(expected, type):
            return value
        if issubclass(expected, NameEnum):
            try:
                return expected(value)
            except (ValueError, TypeError):
                return value
        if issubclass(expected, module.Object) and not isinstance(value, expected) and isinstance(value, dict):
            return expected.wrap(value)
        return value

    def validate_types(cls, raw_object):
        expected_types = cls.expected_types()
        for key, value in raw_object.items():
            if key in expected_types:
                raw_object[key] = convert(expected_types[key], value)
        return raw_object

    module.Object.validate_types = classmethod(validate_types)
    # client.py imports wrap directly, so replace both references.
    module.wrap = convert
    import balethon.objects as objects
    objects.wrap = convert
    import balethon.client.client as client_module
    client_module.wrap = convert
