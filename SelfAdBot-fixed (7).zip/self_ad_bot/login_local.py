# -*- coding: utf-8 -*-
"""Interactive, local session creation using aiobale's own login flow.

Run this only on a trusted computer/terminal. The resulting file is equivalent
in sensitivity to account access; upload it only to a bot/server you trust.
"""
import asyncio
import os
import sys
from pathlib import Path

async def main():
    from aiobale import Client
    from aiobale.client.auth_cli import PhoneLoginCLI

    if not sys.stdin.isatty():
        print('این ابزار به ترمینال تعاملی نیاز دارد؛ ورودی غیرتعاملی پشتیبانی نمی‌شود.')
        return 1
    folder = Path('local_sessions')
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    name = input('نام فایل سشن (مثلاً my_account، بدون اطلاعات حساس): ').strip()
    if not name or len(name) > 60 or not all(c.isalnum() or c in '-_' for c in name):
        print('نام نامعتبر است؛ فقط حروف، عدد، خط تیره و زیرخط مجاز است.')
        return 1
    path = folder / (name + '.bale')
    if path.exists():
        print('این فایل از قبل وجود دارد؛ برای جلوگیری از جایگزینی نام دیگری انتخاب کنید.')
        return 1
    client = Client(session_file=path)
    try:
        print('شماره و کد را فقط در همین ترمینال وارد کنید، نه در چت یا پشتیبانی.')
        await PhoneLoginCLI(client).start()
        if not path.is_file() or not path.stat().st_size:
            print('ورود کامل نشد؛ فایل سشن معتبر ساخته نشده است.')
            return 1
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        print(f'سشن ذخیره شد: {path.resolve()}')
        print('فایل به اکانت شما دسترسی می‌دهد. فقط به ربات و سروری که به آن اعتماد دارید بفرستید.')
        return 0
    except KeyboardInterrupt:
        print('\nعملیات لغو شد.')
        return 1
    finally:
        await client.stop()

if __name__ == '__main__':
    sys.exit(asyncio.run(main()))
