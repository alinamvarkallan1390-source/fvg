# -*- coding: utf-8 -*-
# =====================================================================
# سورس جداگانه: «سلف تبلیغ گر اکانت» (Self Advertiser)
# برگرفته از main-3_2.py ریپوی اول (کامیت 3837569) — خط به خط بازبینی و
# تمام باگهای شناختهشدهاش رفع شد؛ فقط و فقط ادمین اصلی ربات به آن دسترسی دارد.
#
#  • ورود به اکانت (سشن) و انتخاب گروه هدف از پنل مدیریت
#  • ۱) تبلیغ در گروه هدف   ۲) هر پیام در گروه ⇒ افزودن به مخاطبین + بنر پیوی
#  • ارسال پاکت / تنظیم بنر / ارسال بنر / تنظیم تایم ارسال (۱ دقیقه)
# =====================================================================
from __future__ import annotations

import asyncio
import gc
import hashlib
from urllib.parse import unquote
import json
import os
import shutil
import sys
import time
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

import config
from core import (SelfAdEngine, parse_command, parse_int, parse_minutes,
                  to_english_numbers, valid_phone)

BASE = Path(__file__).resolve().parent

MAIN_KEYBOARD = [
    ["🎯 انتخاب گروه هدف", "📋 لیست گروهها"],
    ["➕ افزودن گروه", "➖ حذف گروه"],
    ["📝 تنظیم بنر", "📢 ارسال تبلیغ به گروه"],
    ["⏱ تنظیم تایم ارسال", "🎁 ارسال پاکت"],
    ["▶️ شروع تبلیغات", "⏹ توقف تبلیغات"],
    ["💻 مدیریت سشن", "🔍 بررسی سشنها"],
    ["📊 آمار", "📦 دریافت بکاپ"],
    ["📚 راهنما"],
]
SESSION_KEYBOARD = [
    ["✨ ساخت سشن", "🔐 دریافت کد ورود"],
    ["📥 افزودن سشن (فایل)", "📋 لیست سشنها"],
    ["🔙 بازگشت"],
]

HELP_TEXT = """📚 **راهنمای سلف تبلیغگر** (پنل شخصی شما)

🔹 **دستورات دقیق:**
• `تنظیم بنر (بنر)` یا `تنظیم بنر متن تبلیغ` → ذخیره بنر
• `ارسال بنر (بنر)` → ارسال همان بنر به گروه هدف
• `ارسال پاکت (مبلغ)` → پاکت هدیه با مبلغ (ریال)
• `تنظیم تایم ارسال (1 دقیقه)` → ارسال دورهای هر ۱ دقیقه

🔸 **گروه هدف:** «➕ افزودن گروه» ← لینک دعوت یا آیدی عددی بفرست؛
سپس «🎯 انتخاب گروه هدف» و انتخاب از لیست.

🔹 **رفتار خودکار:** به محض اینکه «هرکسی» در گروه هدف پیام داد،
سلف او را به مخاطبین اضافه کرده و بنر را در پیویش ارسال میکند
(کولداون ۶ ساعت + سقف ساعتی برای جلوگیری از بن شدن).

🔸 **سشن:** «✨ ساخت سشن» ← شماره (مثلاً 989123456789) ← کد ← در صورت
نیاز رمز دو مرحلهای. فایلهای `.bale` و `.zip` هم پذیرفته میشوند.

⚠️ هیچ پیام ناشناخته/پیشفرض پاسخ داده نمیشود."""

WELCOME = ("✨ **پنل مدیریت سلف تبلیغگر اکانت**\n\n"
           "🔐 پنل و سشن‌های هر کاربر جداگانه است\n"
           "🎯 اول گروه هدف را انتخاب کن، بعد بنر و تایم ارسال را تنظیم کن.\n"
           "📚 «راهنما» دستورات دقیق را نشان میدهد.")


class UserConfig:
    """Paths are derived only from the authenticated numeric user ID."""
    def __init__(self, user_id):
        self.MAIN_ADMIN_ID = int(user_id)
        if self.MAIN_ADMIN_ID <= 0:
            raise ValueError("invalid user id")
        root = config.BASE_DIR / "users" / str(self.MAIN_ADMIN_ID)
        self.SESSIONS_DIR = root / "sessions"
        self.CHECK_DIR = root / "check"
        self.DATA_DIR = root / "data"
        self.PANEL_FILE = self.DATA_DIR / "panel.json"
        self.LOG_FILE = root / "self_ad.log"

    def __getattr__(self, name):
        return getattr(config, name)

    def ensure_dirs(self):
        for directory in (self.SESSIONS_DIR, self.CHECK_DIR, self.DATA_DIR):
            directory.mkdir(parents=True, exist_ok=True, mode=0o700)


class SelfAdApp:
    def __init__(self, sdk, user_config=None):
        self.cfg = user_config or config
        # sdk = (Bc, private_condition, ReplyKeyboard, Client, Dispatcher, ChatType, AuthErrors)
        (self.Bc, self.private, self.ReplyKeyboard, self.AiobaleClient,
         self.Dispatcher, self.ChatType, self.AuthErrors) = sdk
        self.cfg.ensure_dirs()
        self.engine = SelfAdEngine(self.cfg.PANEL_FILE, chat_type=self.ChatType,
                                   banner_default=self.cfg.DEFAULT_BANNER)
        if not self.engine.data.get("admin_id"):
            self.engine.data["admin_id"] = self.cfg.MAIN_ADMIN_ID
        if not self.engine.data.get("delay"):
            self.engine.data["delay"] = self.cfg.DEFAULT_DELAY
        self.engine.save()
        self.bot = None
        self.user_state = {}          # FSM ادمین
        self.clients = {}             # session_key -> client
        self.dispatchers = {}
        self.tasks = []
        self.self_ids = set()
        self._scheduler_task = None
        self._start_lock = asyncio.Lock()
        self._startup_task = None

    # ---------------- ابزارهای ارسال امن ----------------
    async def reply(self, message, text, keyboard=None):
        if keyboard:
            try:
                return await message.reply(text, self.ReplyKeyboard(*keyboard))
            except Exception:
                pass
        try:
            return await message.reply(text)
        except Exception:
            return None

    async def notify(self, text):
        if self.bot and self.cfg.MAIN_ADMIN_ID:
            try:
                await self.bot.send_message(self.cfg.MAIN_ADMIN_ID, text)
            except Exception:
                pass

    async def send_document(self, message, path: Path, caption=""):
        """رفع باگ reply_document تاییدنشده سورس اصلی."""
        try:
            if hasattr(message, "reply_document"):
                return await message.reply_document(str(path), caption)
        except Exception:
            pass
        try:
            if hasattr(message, "reply"):
                return await message.reply("❌ ارسال فایل بکاپ ناموفق بود؛ دسترسی ارسال فایل و اتصال را بررسی کنید.")
        except Exception:
            pass
        return None

    # ---------------- سشنها ----------------
    def session_files(self):
        self.cfg.ensure_dirs()
        return sorted(f.name for f in self.cfg.SESSIONS_DIR.glob("*" + self.cfg.SESSION_EXTENSION))

    def make_client(self, session_name: str, dispatcher=None):
        dp = dispatcher or self.Dispatcher()
        path = self.cfg.SESSIONS_DIR / session_name
        # رفع باگ: همیشه session_file= (کلمهدار) و همان پسوند .bale
        return dp, self.AiobaleClient(dp, session_file=str(path))

    async def start_sessions(self):
        """Validate each session before registering and starting its listener."""
        async with self._start_lock:
            for name in self.session_files():
                if name in self.clients:
                    continue
                client = None
                try:
                    dp = self.Dispatcher()
                    @dp.message()
                    async def _on_message(msg, _key=name):
                        try:
                            cli = self.clients.get(_key) or getattr(msg, "client", None)
                            await self.engine.on_group_message(cli, msg, _key, self.self_ids)
                        except Exception as e:
                            self.log(f"on_group_message: {type(e).__name__}")
                    dp, client = self.make_client(name, dp)
                    me = await asyncio.wait_for(client.get_me(), timeout=20)
                    if not getattr(me, "id", None):
                        raise ValueError("account id missing")
                    self.self_ids.add(int(me.id))
                    self.dispatchers[name] = dp
                    self.clients[name] = client
                    task = asyncio.create_task(client.start(signal_handling=False))
                    self.tasks.append(task)
                    def on_done(task, key=name, instance=client):
                        if self.clients.get(key) is instance:
                            self.clients.pop(key, None)
                            self.dispatchers.pop(key, None)
                        if not task.cancelled():
                            error = task.exception()
                            if error:
                                self.log(f"session listener {key}: {type(error).__name__}")
                    task.add_done_callback(on_done)
                except Exception as e:
                    self.log(f"start session {name}: {type(e).__name__}")
                    if client:
                        try:
                            await client.stop()
                        except Exception:
                            pass
            if self._scheduler_task is None or self._scheduler_task.done():
                self.restart_scheduler()
            return len(self.clients)

    def restart_scheduler(self):
        if self._scheduler_task:
            try:
                self._scheduler_task.cancel()
            except Exception:
                pass
        try:
            self._scheduler_task = asyncio.create_task(
                self.engine.scheduler_loop(lambda: list(self.clients.items())))
            self.tasks.append(self._scheduler_task)
        except RuntimeError:
            pass   # خارج از event loop (تستها)

    def log(self, msg):
        try:
            with open(self.cfg.LOG_FILE, "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().isoformat()} {msg}\n")
        except Exception:
            pass

    # ---------------- گروه هدف ----------------
    async def join_group_sessions(self, link, details=None):
        """Follow original bot: join each session, then inspect the group."""
        joined = failed = 0
        for key, cli in list(self.clients.items()):
            try:
                response = await asyncio.wait_for(cli.join_chat(link), timeout=30)
                joined += 1
                if details is not None:
                    group = getattr(response, "group", None)
                    if group is not None:
                        details.append(group)
            except Exception as e:
                # Already joined can be confirmed by a preview rather than counted as failure.
                try:
                    preview = await asyncio.wait_for(cli.get_group_preview(link), timeout=20)
                    if getattr(preview, "is_joined", False):
                        joined += 1
                        if details is not None:
                            details.append(preview)
                        continue
                except Exception:
                    pass
                failed += 1
                self.log(f"join session {key}: {type(e).__name__}")
        return joined, failed

    async def add_group_from_link(self, message, raw):
        raw = to_english_numbers((raw or "").strip())
        if raw.lstrip("-").isdigit():
            self.engine.add_group(raw, "", f"گروه {raw}")
            await self.reply(message, "✅ گروه ثبت شد؛ برای عضویت خودکار لینک دعوت لازم است.")
            return
        if not ("/" in raw or "@" in raw):
            await self.reply(message, "❌ لینک دعوت خصوصی گروه را بفرستید.")
            return
        await self.start_sessions()
        if not self.clients:
            await self.reply(message, "❌ هیچ سشن قابل استفاده‌ای پیدا نشد. سشن و اتصال را بررسی کنید.")
            return
        await self.reply(message, f"⏳ در حال تلاش برای عضویت {len(self.clients)} سشن در گروه...")
        details = []
        joined, failed = await self.join_group_sessions(raw, details)
        # The original implementation joined first; do not block joining on preview failure.
        gid = title = None
        for key, cli in list(self.clients.items()):
            try:
                details.append(await asyncio.wait_for(cli.get_group_preview(raw), timeout=20))
                break
            except Exception as e:
                self.log(f"group preview {key}: {type(e).__name__}")
        for group in details:
            try:
                value = group.get("id") if isinstance(group, dict) else getattr(group, "id", None)
                if value is None:
                    continue
                gid = int(value)
                title = (group.get("title") if isinstance(group, dict) else getattr(group, "title", None)) or str(gid)
                break
            except (ValueError, TypeError):
                continue
        if gid is None:
            await self.reply(message, f"⚠️ نتیجه عضویت: {joined} موفق | {failed} ناموفق. شناسه گروه از پاسخ بله به دست نیامد، پس گروه هدف ثبت نشد. لینک و نوع خطا را بررسی کنید.")
            return
        self.engine.add_group(gid, raw, title)
        await self.reply(message, f"✅ گروه هدف ثبت شد: {title}\n🆔 {gid}\n📥 عضو یا عضوِ قبلی: {joined} | ناموفق: {failed}", MAIN_KEYBOARD)

    def groups_keyboard(self):
        rows = [[f"🎯 {g.get('title') or g.get('id')} | {str(g.get('id'))}"]
                for g in self.engine.data.get("groups", [])]
        rows.append(["🔙 بازگشت"])
        return rows

    # ---------------- هندلر اصلی پنل ----------------
    async def handle(self, message):
        # 🚪 دروازه امنیتی: «فقط فقط برای ادمین ربات اصلی»
        try:
            uid = int(message.author.id)
        except Exception:
            return
        if uid != self.cfg.MAIN_ADMIN_ID:
            return
        text = (getattr(message, "text", None) or "").strip()
        state = self.user_state.get(uid)

        # Navigation must not be consumed as an answer to a pending question.
        if text in ("/start", "🔙 بازگشت", "بازگشت") and state:
            self.user_state.pop(uid, None)
            cli = state.get("auth_client")
            if cli:
                try:
                    await cli.stop()
                except Exception:
                    pass
            state = None
        # ---------- FSM ----------
        if text in ("/cancel", "❌ انصراف"):
            self.user_state.pop(uid, None)
            cli = (state or {}).get("auth_client")
            if cli:
                try:
                    await cli.stop()
                except Exception:
                    pass
            await self.reply(message, "❌ عملیات لغو شد.", MAIN_KEYBOARD)
            return
        doc = getattr(message, "document", None)
        if doc is not None:
            if state:
                await self.reply(message, "ابتدا عملیات جاری را با /cancel لغو کنید، سپس فایل سشن را بفرستید.")
            else:
                await self.handle_document(message, doc)
            return
        if state:
            handled = await self.handle_state(message, uid, state, text)
            if handled:
                return

        # ---------- دستورات دقیق (هیچ پاسخ پیشفرض وجود ندارد) ----------
        if text in ("/start", "🔙 بازگشت", "بازگشت"):
            await self.reply(message, WELCOME, MAIN_KEYBOARD)
            if self.engine.data.get("enabled") and not self.clients:
                if self._startup_task is None or self._startup_task.done():
                    self._startup_task = asyncio.create_task(self.start_sessions())
            return
        if text == "📚 راهنما":
            await self.reply(message, HELP_TEXT, MAIN_KEYBOARD)
            return
        if text == "📊 آمار":
            await self.reply(message, self.engine.stats_text(), MAIN_KEYBOARD)
            return
        if text == "📋 لیست گروهها":
            gs = self.engine.data.get("groups", [])
            txt = "📋 **گروههای ذخیرهشده**\n\n" + (
                "\n".join(f"• {g.get('title')} — `{g.get('id')}`"
                          f"{' ✅ هدف' if str(g.get('id')) == str(self.engine.data.get('active_group')) else ''}"
                          for g in gs) if gs else "هنوز گروهی اضافه نشده.")
            await self.reply(message, txt, MAIN_KEYBOARD)
            return
        if text == "🎯 انتخاب گروه هدف":
            if not self.engine.data.get("groups"):
                await self.reply(message, "⚠️ اول «➕ افزودن گروه» را بزن.", MAIN_KEYBOARD)
                return
            await self.reply(message, "گروه هدف تبلیغ را انتخاب کن:", self.groups_keyboard())
            return
        if text.startswith("🎯 "):
            gid = text.split("|")[-1].strip()
            if self.engine.set_active_group(gid):
                await self.reply(message, f"✅ گروه هدف تنظیم شد: `{gid}`", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ گروه یافت نشد.", MAIN_KEYBOARD)
            return
        if text == "➕ افزودن گروه":
            self.user_state[uid] = {"step": "await_group"}
            await self.reply(message, "🔗 لینک دعوت گروه یا آیدی عددی آن را بفرست:\n(لغو: /cancel)")
            return
        if text == "➖ حذف گروه":
            self.user_state[uid] = {"step": "await_remove_group"}
            await self.reply(message, "🆔 آیدی گروهی که باید حذف شود را بفرست:")
            return
        if text == "📝 تنظیم بنر":
            self.user_state[uid] = {"step": "await_banner"}
            await self.reply(message, "📝 متن بنر را بفرست (یا `تنظیم بنر (متن)`):")
            return
        if text == "⏱ تنظیم تایم ارسال":
            self.user_state[uid] = {"step": "await_interval"}
            await self.reply(message, "⏱ دوره ارسال را بفرست، مثال: `1 دقیقه` / `5 دقیقه` / `1 ساعت`")
            return
        if text == "🎁 ارسال پاکت":
            self.user_state[uid] = {"step": "await_packet"}
            await self.reply(message, "💰 مبلغ پاکت (ریال) را بفرست، مثال: `ارسال پاکت (۵۰۰۰)`")
            return
        if text == "📢 ارسال تبلیغ به گروه":
            n = await self.advertise_now()
            await self.reply(message, f"📢 بنر به {n} گروه هدف ارسال شد.", MAIN_KEYBOARD)
            return
        if text == "▶️ شروع تبلیغات":
            self.engine.set_enabled(True)
            await self.start_sessions()
            groups = self.engine.target_groups()
            link = groups[0].get("link") if groups else None
            if link and self.clients:
                joined, failed = await self.join_group_sessions(link)
                detail = f"\n📥 نتیجه عضویت: {joined} موفق، {failed} ناموفق."
            else:
                detail = "\n⚠️ برای جوین خودکار سشن و لینک دعوت گروه لازم است."
            await self.reply(message, "🟢 سلف فعال شد." + detail, MAIN_KEYBOARD)
            return
        if text == "⏹ توقف تبلیغات":
            self.engine.set_enabled(False)
            await self.reply(message, "🔴 سلف متوقف شد (هیچ پیام خودکاری ارسال نمیشود).", MAIN_KEYBOARD)
            return
        if text == "💻 مدیریت سشن":
            await self.reply(message, "💻 **مدیریت سشنها**", SESSION_KEYBOARD)
            return
        if text == "📋 لیست سشنها":
            files = self.session_files()
            await self.reply(message, "📋 سشنها:\n" + ("\n".join("• " + f for f in files) if files else "— خالی —"),
                             SESSION_KEYBOARD)
            return
        if text == "✨ ساخت سشن":
            self.user_state[uid] = {"step": "await_phone"}
            await self.reply(message, "📱 شماره اکانت را بفرست (مثلاً 989123456789):\nلغو: /cancel")
            return
        if text == "🔐 دریافت کد ورود":
            self.user_state[uid] = {"step": "await_session_name"}
            await self.reply(message, "📄 نام فایل سشن را بفرست (مثلاً 98912….bale):")
            return
        if text == "📥 افزودن سشن (فایل)":
            await self.reply(message, "📥 فایل `.bale` یا فایل `.zip` حاوی سشنها را ارسال کنید.")
            return
        if text == "🔍 بررسی سشنها":
            report = await self.check_sessions()
            await self.reply(message, report, SESSION_KEYBOARD)
            return
        if text == "📦 دریافت بکاپ":
            await self.backup(message)
            return
        if text == "🧹 پاکسازی گروهها":
            n = await self.cleanup_groups()
            await self.reply(message, f"🧹 {n} گروه پاکسازی شد.", MAIN_KEYBOARD)
            return

        # --- دستورات متنی با پارامتر (پرانتز دار/بدون پرانتز) ---
        rest = parse_command(text, "تنظیم بنر")
        if rest is not None:
            if self.engine.set_banner(rest):
                await self.reply(message, f"✅ بنر ذخیره شد:\n\n{self.engine.banner[:500]}", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ بنر خالی یا خیلی طولانی است.")
            return
        rest = parse_command(text, "ارسال بنر")
        if rest is not None:
            banner = rest or self.engine.banner
            n = await self.advertise_now(banner)
            await self.reply(message, f"📢 ارسال بنر به {n} گروه انجام شد.", MAIN_KEYBOARD)
            return
        rest = parse_command(text, "ارسال پاکت")
        if rest is not None:
            amount = parse_int(rest)
            if not amount or "-" in rest or "−" in rest:
                await self.reply(message, "❌ مبلغ نامعتبر. مثال: `ارسال پاکت (۵۰۰۰)`")
                return
            ok, info = await self.send_packet(amount)
            await self.reply(message, ("🎁 " if ok else "❌ ") + info, MAIN_KEYBOARD)
            return
        rest = parse_command(text, "تنظیم تایم ارسال")
        if rest is not None:
            minutes = parse_minutes(rest)
            if not minutes:
                await self.reply(message, "❌ فرمت نامعتبر. مثال: `تنظیم تایم ارسال (1 دقیقه)`")
                return
            minutes = self.engine.set_interval(minutes)
            self.engine.set_enabled(True)
            self.restart_scheduler()
            await self.reply(message,
                f"⏱ ارسال دورهای هر **{minutes} دقیقه** تنظیم و فعال شد.\n"
                "سشنها بهصورت خودکار استارت میشوند.", MAIN_KEYBOARD)
            await self.start_sessions()
            return
        if text.startswith("عضو شو"):
            await self.bulk_join(message, text)
            return

        # 🚫 قانون: فقط دستورات تنظیمشده پاسخ میگیرند — هیچ پیام «نامعتبر» ارسال نمیشود

    async def validate_auth(self, cli, method, value, transaction_hash):
        """Decode gRPC status text before SDK matching; never log credentials."""
        session = getattr(cli, "session", None)
        if session is None or not callable(getattr(session, "post", None)):
            return await getattr(cli, method)(value, transaction_hash), None
        original_post = session.post
        captured = []
        async def post(*args, **kwargs):
            result = await original_post(*args, **kwargs)
            if isinstance(result, str):
                result = unquote(result).strip()
                captured.append(result)
                normalized = result.lower().replace("_", " ").strip()
                if normalized in {"password needed for login", "password needed", "password required", "session password needed"}:
                    return "password needed for login"
                if normalized in {"phone code invalid", "invalid code", "code invalid", "invalid phone code"}:
                    return "PHONE_CODE_INVALID"
                if normalized in {"phone number unoccupied", "phone number not registered"}:
                    return "PHONE_NUMBER_UNOCCUPIED"
                if normalized in {"wrong password", "password invalid", "invalid password"}:
                    return "wrong password"
            return result
        session.post = post
        try:
            result = await getattr(cli, method)(value, transaction_hash)
        finally:
            session.post = original_post
        raw = captured[-1] if captured else None
        # Only known error labels are displayed; an opaque fingerprint helps correlate
        # unknown errors without revealing codes, passwords, tokens or phone numbers.
        known = {"PHONE_CODE_EXPIRED", "PHONE_CODE_INVALID", "PHONE_NUMBER_UNOCCUPIED", "AUTH_KEY_UNREGISTERED", "FLOOD_WAIT", "AUTH_LIMIT"}
        if raw:
            upper = raw.upper().replace(" ", "_")
            detail = upper if upper in known else "REF-" + hashlib.sha256(raw.encode()).hexdigest()[:10]
        else:
            detail = None
        return result, detail

    # ---------------- FSM ----------------
    async def handle_state(self, message, uid, state, text):
        step = state.get("step")
        if step == "await_group":
            self.user_state.pop(uid, None)
            await self.add_group_from_link(message, text)
            return True
        if step == "await_remove_group":
            self.user_state.pop(uid, None)
            self.engine.remove_group(to_english_numbers(text).strip())
            await self.reply(message, "🗑 گروه حذف شد.", MAIN_KEYBOARD)
            return True
        if step == "await_banner":
            self.user_state.pop(uid, None)
            if self.engine.set_banner(text):
                await self.reply(message, "✅ بنر ذخیره شد.", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ متن نامعتبر.")
            return True
        if step == "await_interval":
            self.user_state.pop(uid, None)
            minutes = parse_minutes(text)
            if minutes:
                self.engine.set_interval(minutes)
                self.engine.set_enabled(True)
                self.restart_scheduler()
                await self.start_sessions()
                await self.reply(message, f"⏱ هر {self.engine.data['interval_minutes']} دقیقه ارسال میشود.", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ مثال: `1 دقیقه`")
            return True
        if step == "await_packet":
            self.user_state.pop(uid, None)
            amount = parse_int(text)
            if amount and "-" not in text and "−" not in text:
                ok, info = await self.send_packet(amount)
                await self.reply(message, ("🎁 " if ok else "❌ ") + info, MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ مبلغ نامعتبر.")
            return True
        if step == "await_phone":
            phone = valid_phone(text)
            if not phone:
                await self.reply(message, "❌ شماره نامعتبر. مثال: 989123456789")
                return True
            # Send Iranian numbers in international format to the API.
            if len(phone) == 10 and phone.startswith("9"):
                phone = "98" + phone
            name = phone + self.cfg.SESSION_EXTENSION
            if (self.cfg.SESSIONS_DIR / name).exists():
                self.user_state.pop(uid, None)
                await self.reply(message, "✅ این سشن از قبل وجود دارد.", SESSION_KEYBOARD)
                return True
            try:
                dp, cli = self.make_client(name)
                t = await asyncio.wait_for(cli.start_phone_auth(phone_number=int(phone)), timeout=30)
                if not hasattr(t, "transaction_hash"):
                    error_name = getattr(t, "name", "UNKNOWN")
                    await self.reply(message, f"⚠️ درخواست کد ناموفق بود ({error_name}). شماره، محدودیت حساب و اتصال را بررسی کنید.")
                    try:
                        await cli.stop()
                    except Exception:
                        pass
                    return True
                expiry = getattr(t, "code_expiration_date", None)
                expiry = getattr(expiry, "value", expiry)
                try:
                    expiry = float(expiry)
                    if expiry > 10_000_000_000:
                        expiry /= 1000
                    if expiry < time.time() - 10 or expiry > time.time() + 86400:
                        expiry = time.time() + 120
                except (ValueError, TypeError):
                    expiry = time.time() + 120
                self.user_state[uid] = {
                    "expires_at": expiry,
                    "step": "await_code", "phone": phone,
                    "transaction_hash": t.transaction_hash, "auth_client": cli,
                    "send_time": datetime.now(), "code_attempts": 0,
                    "password_attempts": 0,
                }
                await self.reply(message, "📨 درخواست کد پذیرفته شد. کد دریافتی را بفرستید؛ اگر نیامد، بعداً دوباره تلاش کنید.")
            except Exception as e:
                self.user_state.pop(uid, None)
                self.log(f"phone auth: {type(e).__name__}")
                await self.reply(message, f"❌ درخواست کد ناموفق بود ({type(e).__name__}). اتصال و محدودیت حساب را بررسی کنید.")
            return True
        if step in ("await_code", "await_password"):
            name = state["phone"] + self.cfg.SESSION_EXTENSION
            try:
                cli = state.get("auth_client")
                if cli is None:
                    _, cli = self.make_client(name)
                if step == "await_code":
                    code = to_english_numbers(text).strip().replace(" ", "").replace("-", "")
                    if not code.isdigit() or len(code) < 4:
                        await self.reply(message, "🔢 فقط عدد بفرست.")
                        return True
                    t, auth_detail = await asyncio.wait_for(
                        self.validate_auth(cli, "validate_code", code, state["transaction_hash"]), timeout=30)
                    if t == self.AuthErrors.WRONG_CODE:
                        state["code_attempts"] += 1
                        if state["code_attempts"] >= 2:
                            self.user_state.pop(uid, None)
                            await self.reply(message, "🚫 کد اشتباه؛ تلاشها تمام شد.")
                        else:
                            await self.reply(message, "❌ کد اشتباه، یک بار دیگر بفرست.")
                        return True
                    if t == self.AuthErrors.PASSWORD_NEEDED:
                        state["step"] = "await_password"
                        await self.reply(message, "🔐 رمز دو مرحلهای را بفرست:")
                        return True
                    if t == self.AuthErrors.UNKNOWN:
                        self.user_state.pop(uid, None)
                        if auth_detail == "PHONE_CODE_EXPIRED":
                            try:
                                await cli.stop()
                            except Exception:
                                pass
                            await self.reply(message, "❌ بله این کد را منقضی اعلام کرد. یک‌بار /cancel بزنید، بعد فقط یک درخواست کد جدید بدهید و آخرین کد دریافتی را وارد کنید. اگر تکرار شد، ورود از داخل ربات برای این حساب قابل تأیید نیست.", SESSION_KEYBOARD)
                            return True
                        await self.reply(message, "❌ خطای شناسایی‌نشده در ورود. " +
                            (f"شناسه خطا: {auth_detail}. " if auth_detail else "") +
                            "کد ورود یا رمز را برای کسی نفرستید؛ فقط شناسه خطا را گزارش کنید.")
                        return True
                else:
                    t, auth_detail = await asyncio.wait_for(
                        self.validate_auth(cli, "validate_password", text, state["transaction_hash"]), timeout=30)
                    if t == self.AuthErrors.WRONG_PASSWORD:
                        state["password_attempts"] += 1
                        if state["password_attempts"] >= 2:
                            self.user_state.pop(uid, None)
                            await self.reply(message, "🚫 رمز اشتباه؛ تلاشها تمام شد.")
                        else:
                            await self.reply(message, "❌ رمز اشتباه، دوباره بفرست.")
                        return True
                    if t == self.AuthErrors.UNKNOWN:
                        self.user_state.pop(uid, None)
                        await self.reply(message, "❌ خطای شناسایی‌نشده در ورود. " +
                            (f"شناسه خطا: {auth_detail}. " if auth_detail else "") +
                            "کد ورود یا رمز را برای کسی نفرستید؛ فقط شناسه خطا را گزارش کنید.")
                        return True
                if isinstance(t, self.AuthErrors):
                    self.user_state.pop(uid, None)
                    await self.reply(message, f"❌ ورود ناموفق: {t}")
                    return True
                self.user_state.pop(uid, None)
                try:
                    await cli.stop()
                except Exception:
                    pass
                if not (self.cfg.SESSIONS_DIR / name).is_file():
                    await self.reply(message, "❌ پاسخ ورود دریافت شد اما فایل سشن ذخیره نشد.", SESSION_KEYBOARD)
                    return True
                await self.reply(message, "🎉 لاگین موفق؛ سشن ذخیره شد.", SESSION_KEYBOARD)
                await self.start_sessions()
            except Exception as e:
                self.log(f"code validation: {type(e).__name__}")
                await self.reply(message, f"⚠️ اعتبارسنجی ناموفق بود ({type(e).__name__}). دوباره تلاش کنید.")
            return True
        if step == "await_session_name":
            self.user_state.pop(uid, None)
            name = os.path.basename((text or "").strip())
            path = self.cfg.SESSIONS_DIR / name
            if not path.exists() or not name.endswith(self.cfg.SESSION_EXTENSION):
                await self.reply(message, "❌ فایل پیدا نشد.", SESSION_KEYBOARD)
                return True
            await self.reply(message, "⏳ تا ۶۰ ثانیه پیامهای حاوی کد برایتان فوروارد میشود.")
            asyncio.create_task(self.forward_codes(name))
            return True
        return False

    async def forward_codes(self, session_name):
        """نسخه امن get_coder سورس اصلی (client همیشه تعریفشده + cancel امن)."""
        client = None
        task = None
        try:
            dp = self.Dispatcher()

            @dp.message()
            async def _code(msg):
                txt = getattr(msg, "text", "") or ""
                if "Code" in txt or "کد" in txt:
                    await self.notify(f"🔐 کد از {session_name}:\n{txt}")

            dp, client = self.make_client(session_name, dp)
            task = asyncio.create_task(client.start(signal_handling=False))
            await asyncio.sleep(60)
        except Exception as e:
            self.log(f"forward_codes: {e}")
        finally:
            if task:
                task.cancel()
            if client:
                try:
                    await client.stop()
                except Exception:
                    pass
            await self.notify("⏱ دریافت کد به پایان رسید.")

    # ---------------- عملیات ----------------
    async def advertise_now(self, banner=None):
        await self.start_sessions()
        n = 0
        for key, cli in list(self.clients.items()):
            if cli is None:
                continue
            try:
                n += await self.engine.advertise(cli, banner)
            except Exception as e:
                self.log(f"advertise {key}: {e}")
        self.engine.save()
        return n

    async def send_packet(self, amount):
        if not self.clients:
            await self.start_sessions()
        for cli in list(self.clients.values()):
            if cli is None:
                continue
            return await self.engine.send_packet(cli, amount)
        return False, "هیچ سشن فعالی وجود ندارد"

    async def bulk_join(self, message, text):
        """`عضو شو\\n[تعداد]\\n[لینک]` — نسخه بدون except خالی/متغیر تعریفنشده."""
        parts = [p.strip() for p in text.split("\n") if p.strip()]
        if len(parts) < 3:
            await self.reply(message, "فرمت: `عضو شو` \\n تعداد \\n لینک")
            return
        count = parse_int(parts[1]) or 0
        link = parts[2]
        if count <= 0:
            await self.reply(message, "❌ تعداد نامعتبر.")
            return
        if not self.clients:
            await self.start_sessions()
        done = 0
        for key, cli in list(self.clients.items())[:count]:
            try:
                await cli.join_chat(link)
                done += 1
            except Exception as e:
                self.log(f"join {key}: {e}")
            await asyncio.sleep(float(self.engine.data.get("delay") or 2))
        await self.reply(message, f"✅ {done} سشن به گروه جوین شدند. برای انتخاب هدف، لینک را در بخش افزودن گروه ثبت کنید.", MAIN_KEYBOARD)

    async def check_sessions(self):
        ok = bad = 0
        seen = set()
        for name in self.session_files():
            client = None
            try:
                dp, client = self.make_client(name)
                me = await client.get_me()
                mid = int(getattr(me, "id", 0) or 0)
                if mid and mid in seen:
                    bad += 1
                    continue
                seen.add(mid)
                ok += 1
            except Exception as e:
                self.log(f"check session {name}: {e}")
                bad += 1
            finally:
                if client is not None:
                    try:
                        await client.stop()
                    except Exception:
                        pass
        return f"🔍 بررسی سشنها\n✅ سالم: {ok}\n⚠️ ناموفق/تکراری (حذف نشده): {bad}"

    async def cleanup_groups(self):
        n = 0
        for g in list(self.engine.data.get("groups", [])):
            gid = await self._resolve_id(g)
            for cli in list(self.clients.values()):
                try:
                    await cli.leave_group(gid)
                except Exception:
                    pass
            self.engine.remove_group(g.get("id"))
            n += 1
        return n

    async def _resolve_id(self, g):
        for cli in list(self.clients.values()):
            try:
                v = await self.engine.resolve_group_id(cli, g)
                if v is not None:
                    return v
            except Exception:
                pass
        try:
            return int(str(g.get("id")))
        except Exception:
            return 0

    async def handle_document(self, message, doc):
        name = os.path.basename(str(getattr(doc, "name", "") or ""))
        if not (name.endswith(".bale") or name.endswith(".zip")):
            return
        if getattr(doc, "size", 0) and doc.size > 20 * 1024 * 1024:
            await self.reply(message, "❌ فایل از محدودیت ۲۰ مگابایت بزرگتر است.")
            return
        try:
            metadata = await self.bot.get_file(doc.id)
            file_path = getattr(metadata, "path", None)
            if not file_path:
                raise ValueError("getFile did not return a file path")
            raw = await self.bot.download(file_path)
            if len(raw) > 20 * 1024 * 1024:
                raise ValueError("فایل از محدودیت ۲۰ مگابایت بزرگتر است")
        except Exception as e:
            await self.reply(message, f"❌ دانلود فایل ناموفق: {e}")
            return
        self.cfg.ensure_dirs()
        tmp = self.cfg.CHECK_DIR / name
        tmp.write_bytes(raw)
        if name.endswith(".zip"):
            good = bad = 0
            try:
                zf = zipfile.ZipFile(tmp, "r")
                if len(zf.infolist()) > 100 or sum(x.file_size for x in zf.infolist()) > 50 * 1024 * 1024:
                    zf.close()
                    raise ValueError("archive too large")
            except (zipfile.BadZipFile, ValueError):
                tmp.unlink(missing_ok=True)
                await self.reply(message, "❌ فایل ZIP خراب یا بیش از حد بزرگ است.")
                return
            with zf:
                for member in zf.namelist():
                    if not member.endswith(self.cfg.SESSION_EXTENSION):
                        continue
                    target = self.cfg.SESSIONS_DIR / os.path.basename(member)
                    client = None
                    try:
                        info = zf.getinfo(member)
                        if target.exists() or info.file_size > 10 * 1024 * 1024:
                            bad += 1
                            continue
                        target.write_bytes(zf.read(member))
                        dp, client = self.make_client(target.name)
                        await client.get_me()
                        good += 1
                    except Exception:
                        target.unlink(missing_ok=True)
                        bad += 1
                    finally:
                        if client:
                            try:
                                await client.stop()
                            except Exception:
                                pass
            await self.reply(message, f"📦 سشنهای سالم: {good} | خراب: {bad}", SESSION_KEYBOARD)
        else:
            client = None
            try:
                target = self.cfg.SESSIONS_DIR / name
                if target.exists():
                    await self.reply(message, "❌ سشنی با این نام از قبل وجود دارد؛ جایگزین نشد.")
                    tmp.unlink(missing_ok=True)
                    return
                target.write_bytes(raw)
                dp, client = self.make_client(name)
                await client.get_me()
                await self.reply(message, "✅ فایل سشن تایید و ذخیره شد.", SESSION_KEYBOARD)
            except Exception:
                target.unlink(missing_ok=True)
                await self.reply(message, "❌ اعتبارسنجی سشن ناموفق بود؛ اتصال و فایل را بررسی کنید.")
            finally:
                if client:
                    try:
                        await client.stop()
                    except Exception:
                        pass
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        gc.collect()

    async def backup(self, message):
        out = self.cfg.CHECK_DIR / "sessions_backup"
        shutil.make_archive(str(out), "zip", str(self.cfg.SESSIONS_DIR))
        zip_path = Path(str(out) + ".zip")
        await self.send_document(message, zip_path,
                                 "📦 بکاپ سشنها — " + datetime.now().strftime("%Y/%m/%d %H:%M"))
        try:
            zip_path.unlink(missing_ok=True)
        except Exception:
            pass

    # ---------------- register ----------------
    def register(self, bot):
        self.bot = bot
        cond = self.private

        @bot.on_message(cond)
        async def _handler(message):
            try:
                await self.handle(message)
            except Exception as e:
                self.log(f"handler: {e}")
                try:
                    await self.reply(message, f"⚠️ خطای کنترلشده: {e}")
                except Exception:
                    pass
        return bot


class MultiUserRouter:
    def __init__(self, sdk):
        self.sdk = sdk
        self.apps = {}
        self.bot = None
        self._user_locks = {}

    def app_for(self, user_id):
        uid = int(user_id)
        if uid <= 0:
            raise ValueError("invalid user id")
        if uid not in self.apps:
            # Preserve legacy admin's existing sessions and settings.
            user_config = config if uid == config.MAIN_ADMIN_ID else UserConfig(uid)
            app = SelfAdApp(self.sdk, user_config)
            app.bot = self.bot
            self.apps[uid] = app
        return self.apps[uid]

    def register(self, bot):
        self.bot = bot
        @bot.on_message(self.sdk[1])
        async def handler(message):
            try:
                uid = int(message.author.id)
                app = self.app_for(uid)
                lock = self._user_locks.setdefault(uid, asyncio.Lock())
                async with lock:
                    await app.handle(message)
            except Exception:
                # Avoid leaking session credentials or local paths to users.
                try:
                    await message.reply("⚠️ خطایی رخ داد؛ دوباره تلاش کنید.")
                except Exception:
                    pass
        return bot


def load_sdk():
    """واردات تنبل — امکان اجرای تستهای آفلاین بدون نصب SDK."""
    # Balethon captures the current loop at import time. Python 3.14 no
    # longer creates one implicitly in the main thread.
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError("event loop is closed")
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())
    from balethon_compat import install as install_balethon_compat
    install_balethon_compat()
    from balethon import Client as Bc
    from balethon.conditions import private
    from balethon.objects import ReplyKeyboard
    from aiobale import Client, Dispatcher
    from aiobale.enums import ChatType, AuthErrors
    return Bc, private, ReplyKeyboard, Client, Dispatcher, ChatType, AuthErrors


def run():
    if not config.BOT_TOKEN:
        print("❌ خطا: متغیر محیطی BOT_TOKEN تنظیم نشده است.", file=sys.stderr)
        return 1
    sdk = load_sdk()
    app = MultiUserRouter(sdk)
    bot = sdk[0](config.BOT_TOKEN)
    app.register(bot)
    bot.run()
    return 0


if __name__ == "__main__":
    sys.exit(run())
