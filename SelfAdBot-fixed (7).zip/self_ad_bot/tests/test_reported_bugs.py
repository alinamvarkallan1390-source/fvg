import asyncio
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from enum import Enum
import config
import main

class Keyboard:
    def __init__(self, *a): pass
class ChatType:
    GROUP = 2
    PRIVATE = 1
class Errors(Enum):
    UNKNOWN=0; WRONG_CODE=1; PASSWORD_NEEDED=2; WRONG_PASSWORD=3
class Message:
    def __init__(self): self.sent=[]
    async def reply(self, text, *args): self.sent.append(text)
class GroupClient:
    def __init__(self, fail=False): self.joined=[]; self.fail=fail
    async def get_group_preview(self, link): return SimpleNamespace(id=125, title='گروه')
    async def join_chat(self, link):
        self.joined.append(link)
        if self.fail: raise ValueError('failed')
class AuthClient:
    def __init__(self): self.phone=None; self.codes=[]
    async def start_phone_auth(self, phone_number):
        self.phone=phone_number
        return SimpleNamespace(transaction_hash='test')
    async def validate_code(self, code, transaction_hash):
        self.codes.append((code, transaction_hash)); return Errors.UNKNOWN

class BugTests(unittest.TestCase):
    def test_join_all_sessions_and_no_numeric_needed(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config, 'BASE_DIR', Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,Errors), main.UserConfig(44))
                clients=[GroupClient(),GroupClient(),GroupClient(),GroupClient(True)]
                app.clients = {str(i): client for i,client in enumerate(clients)}
                msg=Message()
                await app.add_group_from_link(msg, 'https://ble.ir/join/private')
                self.assertEqual(app.engine.target_groups()[0]['id'], '125')
                self.assertTrue(all(c.joined for c in clients))
                self.assertIn('قبلی: 3',msg.sent[-1]); self.assertIn('ناموفق: 1',msg.sent[-1])
        asyncio.run(run())

    def test_auth_reuses_client_and_prefix(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config, 'BASE_DIR', Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,Errors), main.UserConfig(44))
                cli=AuthClient(); app.make_client=lambda *args: (None,cli)
                msg=Message()
                await app.handle_state(msg,44,{'step':'await_phone'},'۰۹۱۲۳۴۵۶۷۸۹')
                self.assertEqual(cli.phone, 989123456789)
                state=app.user_state[44]
                self.assertIs(state['auth_client'],cli)
                await app.handle_state(msg,44,state,'12345')
                self.assertEqual(cli.codes,[('12345','test')])
                self.assertIn('خطای شناسایی',msg.sent[-1])
        asyncio.run(run())

class ReferenceAuthTests(unittest.TestCase):
    def test_code_uses_original_client_and_transaction(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config, 'BASE_DIR', Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,Errors),main.UserConfig(44))
                cli=AuthClient(); app.make_client=lambda *args:(None,cli)
                msg=Message()
                await app.handle_state(msg,44,{'step':'await_phone'},'09123456789')
                state=app.user_state[44]
                state['expires_at']=0  # Let server decide whether code expired.
                await app.handle_state(msg,44,state,'۱۲- ۳۴۵')
                self.assertEqual(cli.codes,[('12345','test')])
                self.assertFalse(any('لاگین موفق' in text for text in msg.sent))
        asyncio.run(run())

class GroupJoinFirstTests(unittest.TestCase):
    def test_join_even_if_preview_fails(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config, 'BASE_DIR', Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,Errors),main.UserConfig(44))
                class Client:
                    def __init__(self): self.did_join=False
                    async def join_chat(self, link):
                        self.did_join=True
                        return SimpleNamespace(group=SimpleNamespace(id=678, title='target'))
                    async def get_group_preview(self, link):
                        raise RuntimeError('preview not available')
                client=Client()
                app.clients={'s':client}
                msg=Message()
                await app.add_group_from_link(msg, 'https://ble.ir/join/ABCDEFG')
                self.assertTrue(client.did_join)
                self.assertEqual(app.engine.target_groups()[0]['id'], '678')
                self.assertIn('قبلی: 1',msg.sent[-1])
        asyncio.run(run())
