import unittest
from typing import List, Optional, Union

try:
    from balethon_compat import install
    install()
    from balethon.objects import User, Message
    from balethon.objects.object import wrap
    AVAILABLE = True
except ImportError:
    AVAILABLE = False


@unittest.skipUnless(AVAILABLE, 'Balethon is not installed')
class CompatTests(unittest.TestCase):
    def test_get_me_payload(self):
        user = User.wrap({'id': 123, 'first_name': 'Test', 'is_bot': True})
        self.assertEqual(user.id, 123)
        self.assertEqual(user.first_name, 'Test')

    def test_nested_types(self):
        self.assertEqual(wrap(Optional[int], 42), 42)
        self.assertEqual(wrap(Union[int, str], 'abc'), 'abc')
        users = wrap(List[User], [{'id': 12}])
        self.assertIsInstance(users[0], User)
        self.assertEqual(users[0].id, 12)

@unittest.skipUnless(AVAILABLE, 'Balethon is not installed')
class IntegrationObjects(unittest.TestCase):
    def test_real_private_message_conversion(self):
        message = Message.wrap({'message_id': 10, 'from': {'id': 123, 'first_name': 'A'},
                                'chat': {'id': 123, 'type': 'private'},
                                'date': 1700000000, 'text': '/start'})
        self.assertEqual(message.author.id, 123)
        self.assertEqual(message.chat.id, 123)
        self.assertEqual(message.text, '/start')
