import asyncio
import tempfile
import unittest
from pathlib import Path
from core import SelfAdEngine, parse_minutes, valid_phone

class ChatType:
    PRIVATE = 1
    GROUP = 2

class Client:
    def __init__(self): self.messages = []
    async def add_contact(self, user_id): await asyncio.sleep(0.01)
    async def send_message(self, **kwargs): self.messages.append(kwargs)

class FixTests(unittest.TestCase):
    def test_phone_and_seconds(self):
        self.assertIsNone(valid_phone("1234567890"))
        self.assertEqual(parse_minutes("61 ثانیه"), 2)
        self.assertEqual(parse_minutes("0 ثانیه"), 0)

    def test_link_duplicate_and_removal(self):
        with tempfile.TemporaryDirectory() as tmp:
            e = SelfAdEngine(Path(tmp)/"panel.json", ChatType)
            e.add_group(12, "link")
            e.add_group(99, "link")
            self.assertEqual(e.data["active_group"], "12")
            e.remove_group(12)
            self.assertEqual(e.data["group"], [])

    def test_concurrent_cooldown(self):
        async def run():
            e = SelfAdEngine(chat_type=ChatType, banner_default="x")
            cli = Client()
            results = await asyncio.gather(*(e.add_contact_and_send_pv(cli, 42, "s") for _ in range(5)))
            self.assertEqual(sum(results), 1)
            self.assertEqual(len(cli.messages), 1)
        asyncio.run(run())
