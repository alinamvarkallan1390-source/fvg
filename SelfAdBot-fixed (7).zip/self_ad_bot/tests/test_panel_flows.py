import asyncio
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import config
import main

class Keyboard:
    def __init__(self,*rows): self.rows=rows
class ChatType:
    GROUP=2
    PRIVATE=1
class Msg:
    def __init__(self,text='',document=None):
        self.author=type('Author',(),{'id':123})()
        self.text=text; self.document=document; self.sent=[]
    async def reply(self,text,*args): self.sent.append((text,args))
    async def reply_document(self,*args): self.sent.append(('document',args))

class PanelFlows(unittest.TestCase):
    def test_all_visible_buttons_reply(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config,'BASE_DIR',Path(tmp)):
                sdk=(object,None,Keyboard,object,object,ChatType,object)
                app=main.SelfAdApp(sdk,main.UserConfig(123))
                async def start(): return 0
                async def report(): return 'checked'
                app.start_sessions=start
                app.check_sessions=report
                for button in sum(main.MAIN_KEYBOARD+main.SESSION_KEYBOARD,[]):
                    app.user_state.clear()
                    msg=Msg(button)
                    await app.handle(msg)
                    self.assertTrue(msg.sent, button)
        asyncio.run(run())

    def test_back_cancels_and_upload_not_misinterpreted(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config,'BASE_DIR',Path(tmp)):
                sdk=(object,None,Keyboard,object,object,ChatType,object)
                app=main.SelfAdApp(sdk,main.UserConfig(123))
                await app.handle(Msg('➕ افزودن گروه'))
                msg=Msg('',object()); await app.handle(msg)
                self.assertIn('/cancel',msg.sent[0][0])
                msg=Msg('🔙 بازگشت'); await app.handle(msg)
                self.assertNotIn(123,app.user_state)
                self.assertIn('پنل',msg.sent[0][0])
        asyncio.run(run())

    def test_negative_amount_not_sent(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config,'BASE_DIR',Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,object),main.UserConfig(123))
                msg=Msg('ارسال پاکت (-5000)'); await app.handle(msg)
                self.assertIn('نامعتبر',msg.sent[0][0])
        asyncio.run(run())

class UploadFlow(unittest.TestCase):
    def test_download_uses_get_file_path(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config,'BASE_DIR',Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,object),main.UserConfig(123))
                class Bot:
                    async def get_file(self, file_id):
                        assert file_id == 'file-id'
                        return type('File',(),{'path':'files/session.bale'})()
                    async def download(self, path):
                        assert path == 'files/session.bale'
                        return b'session data'
                class Client:
                    async def get_me(self): return object()
                    async def stop(self): pass
                app.bot=Bot()
                app.make_client=lambda *args: (None,Client())
                msg=Msg()
                doc=type('Doc',(),{'name':'s.bale','id':'file-id','size':12})()
                await app.handle_document(msg,doc)
                self.assertEqual((app.cfg.SESSIONS_DIR/'s.bale').read_bytes(),b'session data')
                self.assertIn('ذخیره شد',msg.sent[-1][0])
        asyncio.run(run())

class RegressionTests(unittest.TestCase):
    def test_start_does_not_wait_for_sessions(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config,'BASE_DIR',Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,object),main.UserConfig(123))
                app.engine.set_enabled(True)
                gate=asyncio.Event()
                async def slow(): await gate.wait()
                app.start_sessions=slow
                msg=Msg('/start')
                await asyncio.wait_for(app.handle(msg), 0.2)
                self.assertTrue(msg.sent)
                gate.set()
                await app._startup_task
        asyncio.run(run())

    def test_grpc_error_normalized_without_code_leak(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp, patch.object(config,'BASE_DIR',Path(tmp)):
                app=main.SelfAdApp((object,None,Keyboard,object,object,ChatType,object),main.UserConfig(123))
                class Session:
                    async def post(self, *a, **kw): return 'password%20needed%20for%20login'
                class Client:
                    def __init__(self): self.session=Session()
                    async def validate_code(self, code, transaction_hash):
                        return await self.session.post()
                cli=Client()
                result,detail=await app.validate_auth(cli,'validate_code','123456','SECRET')
                self.assertEqual(result, 'password needed for login')
                self.assertNotIn('123456',detail)
                self.assertNotIn('SECRET',detail)
                self.assertEqual(await cli.session.post(), 'password%20needed%20for%20login')
        asyncio.run(run())
