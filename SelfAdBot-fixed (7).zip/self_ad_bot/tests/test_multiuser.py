import asyncio
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import config
import main

class Keyboard:
    def __init__(self, *rows): pass
class ChatType:
    GROUP = 1
    PRIVATE = 2
class Message:
    def __init__(self, uid, text):
        self.author = type('User', (), {'id': uid})()
        self.text = text
        self.document = None
        self.sent = []
    async def reply(self, text, *args):
        self.sent.append(text)

class MultiUserTests(unittest.TestCase):
    def test_independent_panels_and_guard(self):
        async def run(root):
            sdk = (object, None, Keyboard, object, object, ChatType, object)
            router = main.MultiUserRouter(sdk)
            a, b = router.app_for(101), router.app_for(202)
            for app, uid, banner in [(a, 101, 'بنر اول'), (b, 202, 'بنر دوم')]:
                message = Message(uid, 'تنظیم بنر (' + banner + ')')
                await app.handle(message)
                self.assertTrue(message.sent)
            self.assertEqual(a.engine.banner, 'بنر اول')
            self.assertEqual(b.engine.banner, 'بنر دوم')
            self.assertNotEqual(a.cfg.PANEL_FILE, b.cfg.PANEL_FILE)
            (a.cfg.SESSIONS_DIR / 'test.bale').write_text('secret')
            self.assertEqual(a.session_files(), ['test.bale'])
            self.assertEqual(b.session_files(), [])
            b.engine.add_group(2020)
            self.assertFalse(a.engine.is_target(2020))
            forged = Message(202, 'تنظیم بنر (تغییر غیرمجاز)')
            await a.handle(forged)
            self.assertEqual(forged.sent, [])
            self.assertEqual(a.engine.banner, 'بنر اول')
            restored = main.MultiUserRouter(sdk)
            self.assertEqual(restored.app_for(101).engine.banner, 'بنر اول')
            self.assertEqual(restored.app_for(202).engine.banner, 'بنر دوم')
        with tempfile.TemporaryDirectory() as tmp, patch.object(config, 'BASE_DIR', Path(tmp)):
            asyncio.run(run(tmp))

    def test_invalid_id(self):
        with self.assertRaises(ValueError):
            main.UserConfig(-1)

class RouterRaceTests(unittest.TestCase):
    def test_messages_for_one_user_are_serialized(self):
        async def run():
            class Bot:
                def on_message(self, condition):
                    def register(fn): self.handler=fn; return fn
                    return register
            sdk=(object,None,Keyboard,object,object,ChatType,object)
            router=main.MultiUserRouter(sdk)
            bot=Bot(); router.register(bot)
            order=[]
            first_started=asyncio.Event()
            release=asyncio.Event()
            class App:
                async def handle(self, msg):
                    order.append('start-'+msg.text)
                    if msg.text=='first':
                        first_started.set(); await release.wait()
                    order.append('end-'+msg.text)
            app=App()
            router.app_for=lambda uid: app
            first=asyncio.create_task(bot.handler(Message(101,'first')))
            await first_started.wait()
            second=asyncio.create_task(bot.handler(Message(101,'second')))
            await asyncio.sleep(0)
            self.assertEqual(order, ['start-first'])
            release.set()
            await asyncio.gather(first,second)
            self.assertEqual(order,['start-first','end-first','start-second','end-second'])
        asyncio.run(run())
