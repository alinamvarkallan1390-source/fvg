# -*- coding: utf-8 -*-
# =====================================================================
# god_ext.py — فاز دوم / GOD ULTRA
# ---------------------------------------------------------------------
# • ۲۴ قفل مهم و واقعاً کارآمد گروه (detector + دستور + مجازات)
# • ۶۲۴ قالب آماده جدید (مجموع ۷۵۸ قالب) با کالبک اختصاصی تکتک دکمهها
# • ۳۲ سورس آماده واقعی/تولیدشده برای ساخت ربات
# • همگانی سراسری ادمین به «همه رباتهای متصل به سازنده»
# • فقط پاسخ به دستورات تنظیمشده (بدون پیام نامعتبر / بدون پاسخ دوبل)
# • ۲۰ قابلیت GOD با پیادهسازی واقعی
# • معماری ۱۰٫۰۰۰ ربات × ۵۰٫۰۰۰ کاربر (شاردینگ + صفحهبندی keyset)
# =====================================================================
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
import shutil
import sqlite3
import sys
import threading
import time
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

import botfix_ext as base

MOD = None                     # namespace ماژول main.py بعد از نصب
logger = logging.getLogger("god_ext")

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
SHARD_DIR = DATA_DIR / "shards"
BOTS_DIR = ROOT / "bots"
TEMPLATES_DIR = ROOT / "templates_src"

# =====================================================================
# 1) ۲۴ قفل مهم گروه — هر کدام detector واقعی + دستور + مجازات
# =====================================================================
GROUP_LOCK_SPECS = [
    ("link",      "قفل لینک",            "قفل لینک",           "بازکردن لینک",        "delete", "حذف لینک، آیدی، لینکدعوت بله/تلگرام"),
    ("forward",   "قفل فوروارد",         "قفل فوروارد",        "بازکردن فوروارد",     "delete", "جلوگیری از پیام فورواردشده از کانال/گروه"),
    ("spam",      "قفل اسپم",            "قفل اسپم",           "بازکردن اسپم",        "warn",   "بیش از ۵ پیام در ۱۰ ثانیه → اخطار/اخراج"),
    ("photo",     "قفل عکس",             "قفل عکس",            "بازکردن عکس",         "delete", "ارسال عکس ممنوع"),
    ("video",     "قفل فیلم",            "قفل فیلم",           "بازکردن فیلم",        "delete", "ارسال ویدیو ممنوع"),
    ("audio",     "قفل آهنگ",            "قفل آهنگ",           "بازکردن آهنگ",        "delete", "فایل صوتی ممنوع"),
    ("voice",     "قفل ویس",             "قفل ویس",            "بازکردن ویس",         "delete", "پیام صوتی ممنوع"),
    ("sticker",   "قفل استیکر",          "قفل استیکر",         "بازکردن استیکر",      "delete", "استیکر ممنوع"),
    ("gif",       "قفل GIF",             "قفل gif",            "بازکردن gif",         "delete", "انیمیشن/GIF ممنوع"),
    ("document",  "قفل فایل",            "قفل فایل",           "بازکردن فایل",        "delete", "داکیومنت/فایل ممنوع"),
    ("contact",   "قفل مخاطب",           "قفل مخاطب",          "بازکردن مخاطب",       "delete", "اشتراک مخاطب ممنوع"),
    ("location",  "قفل لوکیشن",          "قفل لوکیشن",         "بازکردن لوکیشن",      "delete", "اشتراک موقعیت ممنوع"),
    ("poll",      "قفل نظرسنجی",         "قفل نظرسنجی",        "بازکردن نظرسنجی",     "delete", "ارسال نظرسنجی ممنوع"),
    ("game",      "قفل بازی",            "قفل بازی",           "بازکردن بازی",        "delete", "ارسال بازی ممنوع"),
    ("bot",       "قفل ورود ربات",       "قفل ربات",           "بازکردن ربات",        "ban",    "جلوگیری از اضافه شدن ربات به گروه"),
    ("badwords",  "قفل کلمات ممنوعه",    "قفل فحش",            "بازکردن فحش",         "warn",   "فیلتر فحش و کلمات ممنوعه"),
    ("ads",       "قفل تبلیغات",         "قفل تبلیغ",          "بازکردن تبلیغ",       "delete", "کلمات تبلیغاتی/پیشنهاد ویژه/تخفیف"),
    ("arabic",    "قفل متن لاتین",       "قفل لاتین",          "بازکردن لاتین",       "delete", "متن لاتین/عربی طولانی ممنوع"),
    ("mention",   "قفل منشن",            "قفل منشن",           "بازکردن منشن",        "delete", "منشن و @all ممنوع"),
    ("hashtag",   "قفل هشتگ",            "قفل هشتگ",           "بازکردن هشتگ",        "delete", "هشتگ ممنوع"),
    ("caption",   "قفل کپشن طولانی",     "قفل کپشن",           "بازکردن کپشن",        "delete", "کپشن بیش از ۲۰۰ کاراکتر"),
    ("edit",      "قفل ویرایش",          "قفل ویرایش",         "بازکردن ویرایش",      "delete", " ویرایش پیام ممنوع"),
    ("service",   "قفل پیام سرویسی",     "قفل سرویسی",         "بازکردن سرویسی",      "delete", "پیامهای join/leave/pin سرویسی"),
    ("command",   "قفل دستورات",         "قفل دستور",          "بازکردن دستور",       "delete", "دستورات / ممنوع (غیر ادمین)"),
]

LINK_RE = re.compile(
    r"(https?://|www\.|ble\.ir/|bale\.ai/|t\.me/|telegram\.me/|@[A-Za-z][A-Za-z0-9_]{4,})", re.I)
BUILTIN_BAD_WORDS = (
    "کثیف", "احمق", "خنگ", "بی شعور", "لعنت", "حرامزاده", "گاو", "خر", "دیوث",
    "fuck", "shit", "bitch", "asshole", "idiot", "stupid",
)
AD_WORDS = (
    "تبلیغ", "پیشنهاد ویژه", "تخفیف ویژه", "ارسال رایگان", "سود تضمینی",
    "سرمایهگذاری", "پول دربیار", "کسب درآمد تضمینی", "ویژه فقط امروز",
    "join کنید", "عضو شوید", "لینک زیر", "کلیک کنید", "فالو کن",
)
ARABIC_LATIN_RE = re.compile(r"[A-Za-z\u0621-\u064A]{20,}")


def god_lock_violated(action, message, text):
    """Detector تمام ۲۴ قفل — همان امضای _lock_violated قدیمی (سازگار کامل)."""
    m = message or {}
    t = text or ""
    cap = m.get("caption") or ""
    combined = (t + "\n" + cap).strip()
    if action == "lock_link":
        return bool(LINK_RE.search(combined))
    if action == "lock_forward":
        return bool(m.get("forward_from") or m.get("forward_from_chat") or m.get("forward_date")
                    or m.get("forward_sender_name") or m.get("is_automatic_forward"))
    if action == "lock_photo":
        return bool(m.get("photo"))
    if action == "lock_video":
        return bool(m.get("video") or m.get("video_note"))
    if action == "lock_audio":
        return bool(m.get("audio"))
    if action == "lock_voice":
        return bool(m.get("voice"))
    if action == "lock_sticker":
        return bool(m.get("sticker"))
    if action == "lock_gif":
        return bool(m.get("animation") or m.get("gif"))
    if action == "lock_document":
        return bool(m.get("document"))
    if action == "lock_contact":
        return bool(m.get("contact"))
    if action == "lock_location":
        return bool(m.get("location") or m.get("venue"))
    if action == "lock_poll":
        return bool(m.get("poll"))
    if action == "lock_game":
        return bool(m.get("game"))
    if action == "lock_bot":
        for u in (m.get("new_chat_members") or []):
            if isinstance(u, dict) and (u.get("is_bot") or str(u.get("username", "")).lower().endswith("bot")):
                return True
        return False
    if action in ("lock_badwords", "lock_profanity"):
        low = combined.lower()
        return any(w in low for w in BUILTIN_BAD_WORDS)
    if action == "lock_ads":
        low = combined.lower()
        return sum(1 for w in AD_WORDS if w in low) >= 1 and bool(LINK_RE.search(combined) or "تخفیف" in low or "سود" in low)
    if action == "lock_arabic":
        return bool(ARABIC_LATIN_RE.search(re.sub(r"\s+", "", combined)))
    if action == "lock_mention":
        return ("@all" in combined.lower() or "@همه" in combined
                or len(re.findall(r"@[A-Za-z0-9_]{4,}", combined)) >= 3
                or bool(m.get("entities") and any(
                    (e.get("type") in ("mention", "text_mention")) for e in (m.get("entities") or []))))
    if action == "lock_hashtag":
        return "#" in combined
    if action == "lock_caption":
        return len(cap) > 200
    if action == "lock_edit":
        return bool(m.get("edit_date") or m.get("edited_message"))
    if action == "lock_service":
        return bool(m.get("new_chat_members") or m.get("left_chat_member")
                    or m.get("new_chat_title") or m.get("new_chat_photo")
                    or m.get("pinned_message") or m.get("delete_chat_photo")
                    or m.get("group_chat_created"))
    if action == "lock_command":
        return t.strip().startswith(("/", "!", "#"))
    if action == "lock_spam":
        return False   # توسط شمارنده runtime_enforce_locks مدیریت میشود
    return False


def god_lock_presets():
    # ۴ پریست قدیمی فاز اول (zadlink/zadforward/zadphoto/zadspam) دقیقاً همان
    # دستورات «قفل لینک» و ... را دارند و ایندکس UNIQUE(bot_id,command_on) وجود دارد.
    # برای اینکه ۲۴ قفل جدید همگی ثبت شوند، دستورات این ۴ مورد را متمایز میکنیم؛
    # دستور اصلی «قفل لینک» همچنان همان پریست قدیمی را فعال میکند (سازگاری کامل).
    legacy = {"link", "forward", "photo", "spam"}
    out = []
    for key, label, on, off, penalty, desc in GROUP_LOCK_SPECS:
        if key in legacy:
            on, off = f"{on} · گاد", f"{off} · گاد"
        out.append({
            "name": f"godlock_{key}", "label": label, "action": f"lock_{key}",
            "command_on": on, "command_off": off, "penalty": penalty,
            "scope": "group", "description": desc,
        })
    return out


# =====================================================================
# 2) کتابخانه عظیم قالبها — ۶۲۴ قالب جدید (جمعاً ۷۵۸)
# =====================================================================
CATEGORY_SPECS = [
    ("group", "👮 مدیریت گروه", [
        "قوانین گروه", "خوشامدگویی", "اخطار و اخراج", "پین و سنجاق", "لینک دعوت",
        "آمار اعضا", "مدیران گروه", "ضداسپم", "فیلتر فحش", "تایید عضویت",
    ], [
        ("📜 قوانین", "📜 قوانین «{s}»\n👤 FIRSTNAME | 🆔 USERID\n📅 DATE ⏰ TIME"),
        ("👮 مدیران", "👮 مدیران GROUPNAME\nتعداد ادمین: GROUPADMINS | اعضا: GROUPMEMBERS"),
        ("📊 آمار گروه", "📊 آمار GROUPNAME\n👥 GROUPMEMBERS | 🆔 GROUPID\n🤖 BOTFNAME"),
        ("🔗 لینک دعوت", "🔗 GROUPLINK\n👤 FIRSTNAME | 📅 DATE"),
        ("⚙️ وضعیت قفلها", "⚙️ وضعیت «{s}»\n📌 {zadlink} | 🆔 GROUPID | 👮 ISADMIN"),
    ], "group"),
    ("shop", "🛒 فروشگاه", [
        "محصولات", "سبد خرید", "پرداخت امن", "سفارشات من", "تخفیفها",
        "دستهبندی", "جستجوی محصول", "پشتیبانی فروش", "فایل دیجیتال", "فاکتور",
    ], [
        ("🛍 محصولات", "🛍 «{s}»\n👤 FIRSTNAME | 📅 DATE"),
        ("🛒 سبد خرید", "🛒 سبد FIRSTNAME\n💰 BALANCE | 🆔 USERID"),
        ("💳 پرداخت", "💳 پرداخت امن «{s}»\n📞 پشتیبانی: ADMINS"),
        ("📦 سفارشات", "📦 سفارشات FIRSTNAME\n🆔 USERID | ⏰ TIME"),
        ("🎧 پشتیبانی", "🎧 پشتیبانی «{s}»\n🤖 BOTFNAME | 🔗 BOTLINK"),
    ], "both"),
    ("earn", "💰 کسب درآمد", [
        "زیرمجموعهگیری", "کیف پول", "برداشت وجه", "هدیه روزانه", "لیدربرد",
        "کد تخفیف", "جوین اجباری", "وظایف روزانه", "سکه و امتیاز", "درآمد کلی",
    ], [
        ("💎 شروع", "💎 «{s}»\n👤 FIRSTNAME | 📅 DATE"),
        ("🔗 لینک من", "🔗 LINK\n👥 COUNT | 💰 BALANCE"),
        ("💰 موجودی", "💰 BALANCE تومان\n🎯 SCORE | ⭐ LEVEL"),
        ("🏆 برترینها", "🏆 TOP1 — TOP1COUNT\n🥈 TOP2 | 🥉 TOP3"),
        ("📚 راهنما", "📚 راهنمای «{s}»\n⏰ TIME | 🤖 BOTFNAME"),
    ], "pv"),
    ("edu", "🎓 آموزش", [
        "برنامه درسی", "آزمون آنلاین", "جزوات", "تقویم آموزشی", "سوالات متداول",
        "ویدیو آموزشی", "تمرین روزانه", "نمرات", "معرفی دوره", "گواهی پایان",
    ], [
        ("📚 دروس", "📚 «{s}»\n👤 FIRSTNAME | 📅 DATE"),
        ("📝 آزمون", "📝 آزمون «{s}»\n⏰ TIME | 🎯 SCORE"),
        ("📄 جزوه", "📄 جزوات «{s}»\n🤖 BOTFNAME"),
        ("📅 تقویم", "📅 DATE | 🕰 TIME\n📌 «{s}»"),
        ("🎓 نمرات", "🎓 SCORE | ⭐ LEVEL | 👤 FIRSTNAME"),
    ], "both"),
    ("support", "🎧 پشتیبانی", [
        "ثبت تیکت", "پاسخ ادمین", "سوالات متداول", "تماس با ما", "وضعیت تیکت",
        "گزارش خطا", "مشاوره", "رضایتمندی", "ساعات پاسخگویی", "ارسال فایل",
    ], [
        ("🎧 تیکت", "🎧 «{s}»\n👤 FIRSTNAME | 🆔 USERID"),
        ("📋 تیکتهای من", "📋 تیکتهای FIRSTNAME\n📅 DATE ⏰ TIME"),
        ("❓ سوالات", "❓ سوالات متداول «{s}»\n🤖 BOTFNAME"),
        ("📞 تماس", "📞 پشتیبانی: ADMINS\n⏰ TIME | 📅 DATE"),
        ("⭐ بازخورد", "⭐ بازخورد «{s}»\n👤 FIRSTNAME | 🎯 SCORE"),
    ], "pv"),
    ("content", "📰 محتوا", [
        "اخبار فوری", "ورزشی", "اقتصادی", "تکنولوژی", "هواشناسی",
        "ارسال به کانال", "فوروارد خودکار", "زمانبندی پست", "آمار بازدید", "دستهبندی خبر",
    ], [
        ("📰 تیترها", "📰 «{s}»\n📅 DATE | ⏰ TIME"),
        ("⚡ دسته", "⚡ «{s}» — SERVERTIME"),
        ("📢 فوروارد", "📢 فوروارد «{s}»\n🤖 BOTFNAME"),
        ("⏰ زمانبندی", "⏰ زمانبندی «{s}»\n📅 DATE | 🕰 TIME"),
        ("📊 بازدید", "📊 آمار «{s}»\n👥 MEMBERCOUNT | 👤 FIRSTNAME"),
    ], "both"),
    ("fun", "🎮 سرگرمی", [
        "سنگ کاغذ قیچی", "دوز", "حدس عدد", "مسابقه سریع", "لول و تجربه",
        "جدول امتیازات", "جوایز", "چالش روزانه", "گل یا پوچ", "بازی گروهی",
    ], [
        ("🎮 شروع", "🎮 «{s}» — FIRSTNAME!\n🎲 RANDOM"),
        ("🏆 امتیازات", "🏆 SCORE | ⭐ LEVEL | 🎯 XP"),
        ("🎁 جوایز", "🎁 «{s}»\n💰 COIN | 📅 DATE"),
        ("👥 رقبا", "👥 TOP1 / TOP2 / TOP3\n🤖 BOTFNAME"),
        ("❓ قوانین", "❓ قوانین «{s}»\n⏰ TIME"),
    ], "both"),
    ("tools", "🧰 ابزارها", [
        "فونتساز", "لینک کوتاه", "ساخت QR", "مترجم", "محاسبهگر",
        "تاریخ و ساعت", "تبدیل واحد", "یادداشت", "رمز عبور", "کپچا",
    ], [
        ("🔤 ابزار", "🔤 «{s}»\n👤 FIRSTNAME | 📅 DATE"),
        ("🔗 لینک", "🔗 «{s}»\n🤖 BOTLINK | ⏰ TIME"),
        ("📝 نتیجه", "📝 «{s}»: RANDOM\n🆔 USERID"),
        ("📅 زمان", "📅 DATE | ⏰ TIME | 🗓 DAY\n🌙 MAHFA | 🍂 FASL"),
        ("❓ راهنما", "❓ راهنمای «{s}»\n🤖 BOTFNAME"),
    ], "pv"),
    ("finance", "📈 ارز و طلا", [
        "قیمت دلار", "قیمت طلا", "قیمت سکه", "ارز دیجیتال", "نرخ تبدیل",
        "نمودار روز", "هشدار قیمت", "محاسبهگر سود", "بورس", "آرشیو قیمت",
    ], [
        ("💵 نرخ", "💵 «{s}»\n📅 DATE | ⏰ TIME"),
        ("📈 نمودار", "📈 «{s}»\n🤖 BOTFNAME | 🆔 USERID"),
        ("🔔 هشدار", "🔔 هشدار «{s}»\n👤 FIRSTNAME | ⏰ TIME"),
        ("🧮 محاسبه", "🧮 محاسبه «{s}»\n💰 BALANCE | 📅 DATE"),
        ("📚 آرشیو", "📚 آرشیو «{s}»\n🔗 LINK"),
    ], "both"),
    ("chat", "💬 چت ناشناس", [
        "وصلم کن", "لینک ناشناس من", "پروفایل", "نزدیک من", "سکه",
        "دعوت دوستان", "بلاک لیست", "گفتگوی فعلی", "امتیازدهی", "راهنما",
    ], [
        ("🔗 وصل", "🔗 «{s}»\n👤 FIRSTNAME | 🎲 RANDOM"),
        ("👤 پروفایل", "👤 پروفایل FIRSTNAME\n🆔 USERID | ⭐ LEVEL"),
        ("💰 سکه", "💰 COIN | 🎯 SCORE\n📅 DATE"),
        ("📍 نزدیک", "📍 «{s}»\n⏰ TIME | 🤖 BOTFNAME"),
        ("❓ راهنما", "❓ «{s}»\n🔗 BOTLINK"),
    ], "pv"),
    ("admin", "⚙️ پنل مدیریت", [
        "آمار کاربران", "نمودار رشد", "پیامهای امروز", "کاربران فعال", "گزارش هفتگی",
        "پشتیبانگیری", "لاگها", "خروجی CSV", "نظرسنجی", "مقایسه دوره",
    ], [
        ("📊 آمار", "📊 «{s}»\n👥 MEMBERCOUNT | 💬 TODAYMSG"),
        ("📈 رشد", "📈 «{s}»\n📅 DATE | 👥 GROUPMEMBERS"),
        ("🆕 امروز", "🆕 کاربران امروز: COUNT\n⏰ TIME | 📅 DATE"),
        ("📤 خروجی", "📤 «{s}»\n🤖 BOTFNAME | 🆔 BOTID"),
        ("⚙️ تنظیمات", "⚙️ «{s}»\n👤 FIRSTNAME | 👮 ISADMIN"),
    ], "both"),
    ("service", "🏢 خدمات و رزرو", [
        "رزرو نوبت", "لیست خدمات", "قیمتگذاری", "آدرس و تماس", "پیگیری رزرو",
        "لغو نوبت", "پرسنل", "نظرات مشتریان", "پرداخت بیعانه", "ساعات کاری",
    ], [
        ("📅 رزرو", "📅 «{s}»\n👤 FIRSTNAME | 📅 DATE"),
        ("📋 خدمات", "📋 «{s}»\n🤖 BOTFNAME | ⏰ TIME"),
        ("💰 قیمت", "💰 «{s}»\n🆔 USERID | 📅 DATE"),
        ("📍 آدرس", "📍 «{s}»\n📞 ADMINS | ⏰ TIME"),
        ("✅ پیگیری", "✅ پیگیری «{s}»\n👤 FIRSTNAME | 🆔 USERID"),
    ], "both"),
]

VARIANTS = ["پایه", "پیشرفته", "حرفهای", "گروهی", "ویژه"]


def _mk_buttons(specs, subject, variant):
    out = []
    for i, (title, content) in enumerate(specs):
        c = (content.replace("{s}", subject)
                    .replace("{zadlink}", "{zadlink}"))
        out.append({
            "title": f"{title} · {variant}",
            "type": "inline" if i % 2 else "reply",
            "row": i // 2,
            "action": "text",
            "content": c,
        })
    return out


def build_god_templates():
    """۶۲۴ قالب کاملاً مجزا: ۶۰۰ قالب موضوعی + ۲۴ قالب اختصاصی قفل."""
    library = {}
    for cat, cat_name, subjects, btn_specs, scope in CATEGORY_SPECS:
        for si, subject in enumerate(subjects, 1):
            for vi, variant in enumerate(VARIANTS, 1):
                key = f"god_{cat}_{si:02d}_{vi:02d}"
                buttons = _mk_buttons(btn_specs, subject, variant)
                library[key] = {
                    "key": key,
                    "name": f"{cat_name.split(' ')[0]} {subject} — {variant}",
                    "desc": (f"قالب کاربردی «{subject}» نسخه {variant} — "
                             f"{len(buttons)} دکمه با کالبک اختصاصی، قابل شخصیسازی، دامنه {scope}"),
                    "category": cat,
                    "category_name": cat_name,
                    "kind": "library",
                    "scope": scope,
                    "buttons": buttons,
                    "start_message": (
                        f"✨ سلام FIRSTNAME عزیز!\nبه «{subject}» ({variant}) خوش آمدی 🎉\n"
                        f"📌 {cat_name}\n📅 DATE | ⏰ TIME | 🤖 BOTFNAME\n"
                        f"👥 GROUPNAME | 🆔 USERID"
                    ),
                    "customizable": True,
                    "god": True,
                }
    # ۲۴ قالب اختصاصی قفلها — قالب عملی «مدیریت گروه»
    for key, label, on, off, penalty, desc in GROUP_LOCK_SPECS:
        tkey = f"god_lock_{key}"
        library[tkey] = {
            "key": tkey,
            "name": f"🔒 {label} — پکیج مدیریت گروه",
            "desc": f"{desc} | دستور «{on}» / «{off}» | مجازات: {penalty}",
            "category": "group",
            "category_name": "👮 مدیریت گروه",
            "kind": "library",
            "scope": "group",
            "buttons": [
                {"title": f"🔒 {on}", "type": "reply", "row": 0, "action": "text",
                 "content": f"✅ «{label}» فعال شد.\n🆔 GROUPID | 👮 ISADMIN\n📅 DATE ⏰ TIME"},
                {"title": f"🔓 {off}", "type": "reply", "row": 0, "action": "text",
                 "content": f"✅ «{label}» غیرفعال شد.\n👤 FIRSTNAME | 🆔 GROUPID"},
                {"title": "📜 قوانین گروه", "type": "reply", "row": 1, "action": "text",
                 "content": "📜 قوانین GROUPNAME\n👥 GROUPMEMBERS | 👮 GROUPADMINS\n📅 DATE"},
                {"title": "📊 آمار گروه", "type": "inline", "row": 1, "action": "text",
                 "content": "📊 GROUPNAME\n👥 GROUPMEMBERS | 💬 TODAYMSG | 🆔 GROUPID"},
                {"title": "👮 مدیران", "type": "inline", "row": 2, "action": "text",
                 "content": "👮 ADMINS\n🤖 BOTFNAME | 🔗 GROUPLINK"},
            ],
            "start_message": (
                f"🛡 پکیج «{label}»\nسلام FIRSTNAME عزیز 👋\n"
                f"🏠 GROUPNAME | 👥 GROUPMEMBERS\n"
                f"دستور فعالسازی: «{on}» | غیرفعال: «{off}»\n📅 DATE ⏰ TIME"
            ),
            "customizable": True,
            "god": True,
            "lock_key": key,
        }
    return library


GOD_TEMPLATES = build_god_templates()

# =====================================================================
# 3) سورسهای آماده — «هرچی سورس آماده داری» (۳۲ مورد واقعی)
# =====================================================================
REAL_SOURCES = [
    ("rs_earn",      "💎 کسب درآمد حرفهای (۱۱۱۴ خط)",  "earn_bot_template.py",             "single"),
    ("rs_liro",      "🛡️ مدیریت گروه لیرو (۱۰۶۶ خط)",  "liro_bot_template.py",             "single"),
    ("rs_shop",      "🛍️ فروشگاه کامل (۸۰۲ خط)",        "shop_bot_template.py",             "single"),
    ("rs_game",      "🎮 بازی و سرگرمی (۲۲۴۵ خط)",      "game_bot_template.py",             "single"),
    ("rs_support",   "🎧 پشتیبانی و تیکت (۳۷۳ خط)",    "support_bot_template.py",          "single"),
    ("rs_lottery",   "🎁 قرعهکشی و جایزه (۷۴۱ خط)",    "lottery_bot_template.py",          "single"),
    ("rs_font",      "🔤 فونتساز (۲۴۷ خط)",             "font_bot_template.py",             "single"),
    ("rs_member",    "👥 عضوگیری پیشرفته (۲۶۸ خط)",     "member_bot_template.py",           "single"),
    ("rs_custom",    "🧩 ربات سفارشی (۳۱۸ خط)",         "custom_bot_template.py",           "single"),
    ("rs_arz",       "📈 نرخ ارز ساده",                  "arz_bot_template.py",              "single"),
    ("rs_arz_gold",  "🥇 ارز و طلا اورجینال (۱۰۳۴ خط)", "arz_gold_original.py",             "single"),
    ("rs_arz_prem",  "👑 ارز و طلا پرمیوم (۱۰۵۰ خط)",   "arz_gold_premium.py",              "single"),
    ("rs_khabari",   "📰 ربات خبری",                     "khabari_bot_template.py",          "single"),
    ("rs_khabari_p", "📡 خبری پرمیوم (۲۸۱ خط)",         "khabari_premium.py",               "single"),
    ("rs_chat_adv",  "💬 چت ناشناس پیشرفته",            "chat_anon_advanced.py",            "single"),
    ("rs_chat_pkg",  "💬 چت ناشناس پکیج کامل",          "chat_bot_template",                "package"),
    ("rs_member_adv","👥 ممبر ادونسد",                  "member_advanced_bot_template.py",  "single"),
    ("rs_member_prm","👑 ممبر ادونسد پرمیوم",           "member_advanced_premium.py",       "single"),
    ("rs_chat_prem", "💎 چت ناشناس پرمیوم",             "chat_anon_premium.py",             "skip"),
    ("rs_factory",   "🏭 کارخانه رباتساز (۳۸۶۰ خط)",    "main_factory.py",                  "single"),
]

GENERATED_SOURCES = [
    ("rs_gen_group",  "📦 پکیج مدیریت گروه + ۲۴ قفل", "group"),
    ("rs_gen_shop",   "📦 پکیج فروشگاه",              "shop"),
    ("rs_gen_earn",   "📦 پکیج کسب درآمد",            "earn"),
    ("rs_gen_edu",    "📦 پکیج آموزش و آزمون",        "edu"),
    ("rs_gen_support","📦 پکیج پشتیبانی",             "support"),
    ("rs_gen_content","📦 پکیج محتوا و خبر",          "content"),
    ("rs_gen_fun",    "📦 پکیج سرگرمی",               "fun"),
    ("rs_gen_tools",  "📦 پکیج ابزارها",              "tools"),
    ("rs_gen_fin",    "📦 پکیج ارز و طلا",            "finance"),
    ("rs_gen_chat",   "📦 پکیج چت ناشناس",            "chat"),
    ("rs_gen_admin",  "📦 پکیج آمار و مدیریت",         "admin"),
    ("rs_gen_service","📦 پکیج خدمات و رزرو",         "service"),
]

READY_SOURCES = ([{"id": i, "name": n, "file": f, "kind": k, "mode": "real"}
                  for i, n, f, k in REAL_SOURCES] +
                 [{"id": i, "name": n, "cat": c, "kind": "generated", "mode": "generated"}
                  for i, n, c in GENERATED_SOURCES])
READY_SOURCES = [dict(s, id=f"rs{i+1:02d}") for i, s in enumerate(READY_SOURCES)]
READY_BY_ID = {s["id"]: s for s in READY_SOURCES}

# =====================================================================
# 4) ۲۰ قابلیت GOD (همه پیادهسازیشده، نه صرفاً لیست متنی)
# =====================================================================
GOD_FEATURES = [
    ("F01", "🎯 فقط دستورات تنظیمشده", "هیچ پیام «نامعتبر/متوجه نشدم» و هیچ پاسخ پیشفرض ارسال نمیشود"),
    ("F02", "🔒 ۲۴ قفل مهم گروه", "detector واقعی + دستور فارسی + حذف/اخطار/اخراج"),
    ("F03", "🧩 ۷۵۸ قالب آماده", "هر دکمه کالبک اختصاصی tcb_ و مسیر اجرای تستشده"),
    ("F04", "📚 ۳۲ سورس آماده", "کپی، جایگذاری توکن/ادمین، کامپایل و اجرای ایزوله"),
    ("F05", "🌐 همگانی سراسری ادمین", "ارسال به کاربران «همه» رباتهای متصل به سازنده"),
    ("F06", "🛡️ ضدپاسخ دوبل", "قفل توکن در BotManager + یک قالب فعال در هر دامنه"),
    ("F07", "⚡ ضدفلود چندلایه", "شمارنده کاربر + شمارنده سراسری ربات + backoff"),
    ("F08", "⭐ XP و لولبندی", "user_levels + ارتقای خودکار با اعلان"),
    ("F09", "🎁 پاداش روزانه/استریاک", "daily_bonus + زنجیره روزهای متوالی"),
    ("F10", "🚫 ضدتقلب زیرمجموعه", "self-ref، تکراری، دعوتکننده نامعتبر و burst"),
    ("F11", "💰 کیف پول و سکه", "god_wallets + انتقال امن بین کاربران"),
    ("F12", "🤖 پاسخخودکار هوشمند", "نرمالسازی فارسی/عربی + وزندهی کلیدواژه"),
    ("F13", "⏰ ارسال زمانبندیشده", "worker پسزمینه scheduled_messages هر ۳۰ ثانیه"),
    ("F14", "🗳️ نظرسنجی و رأیگیری", "polls + poll_votes + کالبک pvote_"),
    ("F15", "🔗 لینک کوتاه", "short_links با کد base36 یکتا و شمارنده بازدید"),
    ("F16", "📊 آمار لحظهای و ممیزی", "god_audit + خلاصه زنده بدون بارگذاری حافظه"),
    ("F17", "💾 پشتیبان/بازیابی", "بکاپ WAL-safe و ریستور اتمیک"),
    ("F18", "🧠 متغیرهای پویا", "رندر امن بدون تداخل زیررشته + ۲۹ پریست قفل"),
    ("F19", "🗑️ حذف کامل ۶ مرحلهای", "PID، وبهوک، جداول، فایلها، VACUUM، ضد ریاستارت"),
    ("F20", "🏗️ شاردینگ ۱۰K×۵۰K", "شارد per-bot + keyset pagination + ایندکسهای ترکیبی"),
]

GOD_COMMANDS = {
    "/god": "god_help", "قابلیتهای گاد": "god_help", "🌟 قابلیتهای god": "god_help",
    "لول من": "level", "امتیاز من": "level", "xp من": "level",
    "پاداش روزانه": "daily", "هدیه روزانه": "daily",
    "موجودی": "wallet", "کیف پول من": "wallet", "سکه من": "wallet",
    "لینک دعوت من": "referral", "دعوت من": "referral",
    "آمار لحظهای": "stats", "آمار زنده": "stats",
    "سلامت ربات": "health", "دستورات": "cmdlist", "راهنمای دستورات": "cmdlist",
    "قوانین": "rules", "بکاپ من": "backup", "استریک من": "streak",
}

# =====================================================================
# 5) لایه دیتابیس، ایندکسها، شاردینگ و seed کامل ۲۹ متغیر
# =====================================================================
GOD_MIGRATIONS = [
    ("custom_commands", "is_active", "INTEGER DEFAULT 1"),
    ("bots", "source_key", "TEXT DEFAULT ''"),
    ("bots", "script_path", "TEXT DEFAULT ''"),
    ("bot_users", "shard", "INTEGER DEFAULT 0"),
]
GOD_TABLES = [
    """CREATE TABLE IF NOT EXISTS global_broadcasts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER NOT NULL,
        content TEXT NOT NULL, target TEXT DEFAULT 'all', status TEXT DEFAULT 'running',
        total INTEGER DEFAULT 0, sent INTEGER DEFAULT 0, failed INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP, finished_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS god_wallets (
        bot_id INTEGER NOT NULL, user_id INTEGER NOT NULL, coins INTEGER DEFAULT 0,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (bot_id, user_id))""",
    """CREATE TABLE IF NOT EXISTS god_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT, bot_id INTEGER, user_id INTEGER,
        action TEXT, detail TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS god_scheduler_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, sched_id INTEGER, bot_id INTEGER,
        status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
]
GOD_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_bu_bot_chat ON bot_users(bot_id, chat_id)",
    "CREATE INDEX IF NOT EXISTS idx_bu_bot_seen ON bot_users(bot_id, last_seen)",
    "CREATE INDEX IF NOT EXISTS idx_bu_blocked ON bot_users(bot_id, is_blocked)",
    "CREATE INDEX IF NOT EXISTS idx_bots_active ON bots(is_active, status)",
    "CREATE INDEX IF NOT EXISTS idx_bots_owner ON bots(owner_id, id)",
    "CREATE INDEX IF NOT EXISTS idx_buttons_bot_row ON bot_buttons(bot_id, row, position)",
    "CREATE INDEX IF NOT EXISTS idx_buttons_callback ON bot_buttons(bot_id, callback)",
    "CREATE INDEX IF NOT EXISTS idx_sched_due ON scheduled_messages(status, send_at)",
    "CREATE INDEX IF NOT EXISTS idx_audit_bot ON god_audit(bot_id, id)",
    "CREATE INDEX IF NOT EXISTS idx_gb_status ON global_broadcasts(status, id)",
]


def god_init_db(self):
    base._init_db_patched(self)
    with self.get_conn() as conn:
        for table, col, coldef in GOD_MIGRATIONS:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {coldef}")
            except sqlite3.OperationalError:
                pass
        for ddl in GOD_TABLES:
            conn.execute(ddl)
        for idx in GOD_INDEXES:
            try:
                conn.execute(idx)
            except sqlite3.OperationalError:
                pass
    logger.info("✅ لایه GOD: جداول/ایندکسهای ۱۰K×۵۰K نصب شد")


def god_db_seed_variables(self, bot_id, only_if_empty=True):
    """برخلاف نسخه قبل، همیشه ۲۹ پریست (۲۴ قفل + ۵ قدیمی) را تضمین میکند."""
    n = 0
    with self.get_conn() as conn:
        for p in base.CUSTOM_VARIABLE_PRESETS:
            try:
                cur = conn.execute("""INSERT OR IGNORE INTO bot_variables
                    (bot_id, name, label, kind, value_on, value_off, is_active, command_on,
                     command_off, scope, admin_only, action, penalty, description)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (bot_id, p["name"], p["label"], "toggle", "فعال ✅", "غیرفعال ❌", 0,
                     p["command_on"], p["command_off"], p.get("scope", "group"), 1,
                     p["action"], p["penalty"], p.get("description", "")))
                n += cur.rowcount or 0
            except sqlite3.IntegrityError:
                pass
    return n


def god_seed_vars_direct(db_path, bot_id):
    try:
        conn = sqlite3.connect(db_path, timeout=30)
        n = 0
        for p in base.CUSTOM_VARIABLE_PRESETS:
            cur = conn.execute("""INSERT OR IGNORE INTO bot_variables
                (bot_id,name,label,kind,value_on,value_off,is_active,command_on,command_off,
                 scope,admin_only,action,penalty,description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (bot_id, p["name"], p["label"], "toggle", "فعال ✅", "غیرفعال ❌", 0,
                 p["command_on"], p["command_off"], p.get("scope", "group"), 1,
                 p["action"], p["penalty"], p.get("description", "")))
            n += cur.rowcount or 0
        conn.commit()
        conn.close()
        return n
    except Exception as e:
        logger.debug("god_seed_vars_direct: %s", e)
        return 0


class ShardedUserStore:
    """شارد per-bot برای ۱۰٫۰۰۰ ربات × ۵۰٫۰۰۰ کاربر = ۵۰۰ میلیون ردیف.
    با GOD_SHARD_USERS=1 فعال میشود؛ در حالت عادی دیتابیس مرکزی دستنخورده میماند."""
    @staticmethod
    def enabled():
        return os.getenv("GOD_SHARD_USERS", "0") == "1"

    @staticmethod
    def shard_path(bot_id):
        return SHARD_DIR / f"bucket_{int(bot_id) // 500:05d}" / f"bot_{int(bot_id)}.db"

    @classmethod
    def conn(cls, bot_id):
        p = cls.shard_path(bot_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(str(p), timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL;")
        c.execute("""CREATE TABLE IF NOT EXISTS bot_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL UNIQUE,
            username TEXT, first_name TEXT, last_name TEXT, chat_type TEXT DEFAULT 'private',
            is_blocked INTEGER DEFAULT 0, last_seen TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_shard_seen ON bot_users(last_seen)")
        return c

    @classmethod
    def touch(cls, bot_id, chat_id, from_user, chat_type="private"):
        try:
            c = cls.conn(bot_id)
            c.execute("""INSERT INTO bot_users (chat_id, username, first_name, last_name, chat_type, last_seen)
                VALUES (?,?,?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET
                username=excluded.username, first_name=excluded.first_name,
                last_name=excluded.last_name, last_seen=excluded.last_seen""",
                (chat_id, (from_user or {}).get("username"), (from_user or {}).get("first_name"),
                 (from_user or {}).get("last_name"), chat_type, datetime.now().isoformat()))
            c.commit()
            c.close()
        except Exception as e:
            logger.debug("shard touch: %s", e)

    @classmethod
    def iter_users(cls, bot_id, batch=1000):
        p = cls.shard_path(bot_id)
        if not p.exists():
            return
        c = sqlite3.connect(str(p), timeout=30)
        c.row_factory = sqlite3.Row
        last = 0
        while True:
            rows = c.execute("SELECT id, chat_id FROM bot_users WHERE id>? AND is_blocked=0 ORDER BY id LIMIT ?",
                             (last, batch)).fetchall()
            if not rows:
                break
            for r in rows:
                yield r["chat_id"]
            last = rows[-1]["id"]
        c.close()

    @classmethod
    def count(cls, bot_id):
        p = cls.shard_path(bot_id)
        if not p.exists():
            return 0
        try:
            c = sqlite3.connect(str(p), timeout=30)
            n = c.execute("SELECT COUNT(*) FROM bot_users").fetchone()[0]
            c.close()
            return n
        except Exception:
            return 0


def iter_all_targets(db_path, batch=1000):
    """keyset pagination — هرگز ۵۰۰ میلیون ردیف را در حافظه نمیگیرد."""
    conn = sqlite3.connect(db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    last = 0
    while True:
        rows = conn.execute("""SELECT bu.id AS rid, bu.bot_id, bu.chat_id, b.token_encrypted
            FROM bot_users bu JOIN bots b ON b.id = bu.bot_id
            WHERE bu.id > ? AND bu.is_blocked = 0 AND b.is_active = 1
              AND b.token_encrypted <> ''
            ORDER BY bu.id LIMIT ?""", (last, batch)).fetchall()
        if not rows:
            break
        for r in rows:
            yield {"bot_id": r["bot_id"], "chat_id": r["chat_id"],
                   "token_enc": r["token_encrypted"]}
        last = rows[-1]["rid"]
    bots = conn.execute("SELECT id, token_encrypted FROM bots WHERE is_active=1 AND token_encrypted<>''").fetchall()
    conn.close()
    if ShardedUserStore.enabled():
        for b in bots:
            for chat_id in ShardedUserStore.iter_users(b["id"], batch):
                yield {"bot_id": b["id"], "chat_id": chat_id, "token_enc": b["token_encrypted"]}


# =====================================================================
# 6) همگانی سراسری ادمین → تمام رباتهای متصل به سازنده
# =====================================================================
class GlobalBroadcastManager:
    def __init__(self, builder):
        self.builder = builder
        self.db_path = builder.db.db_path
        self.jobs = {}
        self.lock = threading.Lock()
        self.base_url = getattr(builder, "base_url", "https://tapi.bale.ai")

    def _conn(self):
        return sqlite3.connect(self.db_path, timeout=30)

    def start(self, admin_id, content, target="all"):
        c = self._conn()
        cur = c.execute("""INSERT INTO global_broadcasts (admin_id, content, target, status)
                           VALUES (?,?,?,'running')""", (admin_id, content, target))
        job_id = cur.lastrowid
        c.commit()
        c.close()
        t = threading.Thread(target=self._run, args=(job_id, content, target),
                             daemon=True, name=f"global-bc-{job_id}")
        with self.lock:
            self.jobs[job_id] = t
        t.start()
        return job_id

    def stop(self, job_id):
        c = self._conn()
        c.execute("UPDATE global_broadcasts SET status='stopped', finished_at=? WHERE id=?",
                  (datetime.now().isoformat(), job_id))
        c.commit()
        c.close()
        return True

    def status(self, job_id):
        c = self._conn()
        c.row_factory = sqlite3.Row
        row = c.execute("SELECT * FROM global_broadcasts WHERE id=?", (job_id,)).fetchone()
        c.close()
        return dict(row) if row else None

    def last_jobs(self, limit=5):
        c = self._conn()
        c.row_factory = sqlite3.Row
        rows = c.execute("SELECT * FROM global_broadcasts ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        c.close()
        return [dict(r) for r in rows]

    def _run(self, job_id, content, target):
        BaleAPI = MOD["BaleAPI"]
        decrypt = MOD["decrypt_token"]
        apis = {}
        sent = failed = total = 0
        t0 = time.time()
        try:
            for item in iter_all_targets(self.db_path, batch=1000):
                c = self._conn()
                c.row_factory = sqlite3.Row
                st = c.execute("SELECT status FROM global_broadcasts WHERE id=?", (job_id,)).fetchone()
                c.close()
                if not st or st["status"] != "running":
                    return
                total += 1
                bid = item["bot_id"]
                if bid not in apis:
                    try:
                        apis[bid] = BaleAPI(decrypt(item["token_enc"]), self.base_url)
                    except Exception:
                        apis[bid] = None
                api = apis[bid]
                if api is None:
                    failed += 1
                    continue
                try:
                    api.send_message(item["chat_id"], content)
                    sent += 1
                except Exception:
                    failed += 1
                # محدودیت نرخ رسمی بله: حداکثر ~۲۰ پیام/ثانیه به ازای هر توکن
                if total % 20 == 0:
                    time.sleep(1.0)
                if total % 100 == 0:
                    c = self._conn()
                    c.execute("UPDATE global_broadcasts SET total=?, sent=?, failed=? WHERE id=?",
                              (total, sent, failed, job_id))
                    c.commit()
                    c.close()
        except Exception as e:
            logger.exception("global broadcast: %s", e)
        finally:
            elapsed = round(time.time() - t0, 1)
            c = self._conn()
            c.execute("""UPDATE global_broadcasts SET total=?, sent=?, failed=?,
                         status='done', finished_at=? WHERE id=? AND status='running'""",
                      (total, sent, failed, datetime.now().isoformat(), job_id))
            c.commit()
            c.close()
            try:
                self.builder.send_message(
                    MOD.get("ADMIN_IDS", [None])[0] if MOD.get("ADMIN_IDS") else None,
                    f"✅ همگانی سراسری #{job_id} پایان یافت\n📤 {sent} | ❌ {failed} | ⏱ {elapsed}s")
            except Exception:
                pass


# =====================================================================
# 7) Worker ارسال زمانبندیشده (F13)
# =====================================================================
class GodScheduler:
    def __init__(self, db_path, base_url="https://tapi.bale.ai"):
        self.db_path = db_path
        self.base_url = base_url
        self.running = False
        self.thread = None

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True, name="god-scheduler")
        self.thread.start()

    def _loop(self):
        BaleAPI = MOD["BaleAPI"]
        decrypt = MOD["decrypt_token"]
        while self.running:
            try:
                c = sqlite3.connect(self.db_path, timeout=30)
                c.row_factory = sqlite3.Row
                now = datetime.now().isoformat()
                rows = c.execute("""SELECT s.*, b.token_encrypted FROM scheduled_messages s
                    JOIN bots b ON b.id=s.bot_id
                    WHERE s.status='pending' AND s.send_at<=? AND b.is_active=1
                    ORDER BY s.id LIMIT 200""", (now,)).fetchall()
                c.close()
                for r in rows:
                    try:
                        api = BaleAPI(decrypt(r["token_encrypted"]), self.base_url)
                        tc = sqlite3.connect(self.db_path, timeout=30)
                        tc.row_factory = sqlite3.Row
                        targets = [x["chat_id"] for x in tc.execute(
                            "SELECT chat_id FROM bot_users WHERE bot_id=? AND is_blocked=0", (r["bot_id"],))]
                        tc.close()
                        for cid in targets:
                            try:
                                api.send_message(cid, r["content"])
                            except Exception:
                                pass
                        c2 = sqlite3.connect(self.db_path, timeout=30)
                        c2.execute("UPDATE scheduled_messages SET status='sent' WHERE id=?", (r["id"],))
                        c2.execute("INSERT INTO god_scheduler_log (sched_id, bot_id, status) VALUES (?,?,'sent')",
                                   (r["id"], r["bot_id"]))
                        c2.commit()
                        c2.close()
                    except Exception as e:
                        logger.debug("scheduled %s: %s", r["id"], e)
            except Exception as e:
                logger.debug("scheduler loop: %s", e)
            time.sleep(30)


# =====================================================================
# 8) ۲۰ قابلیت GOD در سطح ربات کاربر (F07..F18)
# =====================================================================
def _runtime_db(self):
    try:
        return self._get_db()
    except Exception:
        return sqlite3.connect(self.db_path, timeout=30)


def god_audit(self, user_id, action, detail=""):
    try:
        c = self._get_db()
        c.execute("INSERT INTO god_audit (bot_id, user_id, action, detail) VALUES (?,?,?,?)",
                  (self.bot_id, user_id, action, str(detail)[:200]))
        c.commit()
        c.close()
    except Exception:
        pass


def god_passive(self, chat_id, user_id, text, message):
    """لایه منفعل: XP/لول، استریک، ضدفلود سراسری، ممیزی،ثبت شارد."""
    try:
        c = self._get_db()
        c.execute("""INSERT INTO user_levels (bot_id, chat_id, xp, level) VALUES (?,?,1,1)
            ON CONFLICT(bot_id, chat_id) DO UPDATE SET xp = xp + 1""", (self.bot_id, chat_id))
        row = c.execute("SELECT xp, level FROM user_levels WHERE bot_id=? AND chat_id=?",
                        (self.bot_id, chat_id)).fetchone()
        if row and row["xp"] >= row["level"] * 100:
            lvl = row["level"] + 1
            c.execute("UPDATE user_levels SET level=? WHERE bot_id=? AND chat_id=?",
                      (lvl, self.bot_id, chat_id))
            try:
                self.api.send_message(chat_id, f"🎉 تبریک FIRSTNAME! به لول {lvl} رسیدی ⭐")
            except Exception:
                pass
        c.commit()
        c.close()
    except Exception:
        pass
    try:
        if ShardedUserStore.enabled():
            ShardedUserStore.touch(self.bot_id, chat_id, message.get("from") or {},
                                   (message.get("chat") or {}).get("type") or "private")
    except Exception:
        pass
    # ضدفلود سراسری ربات (مستقل از شمارنده هر کاربر)
    try:
        now = time.time()
        g = getattr(self, "_god_global_flood", None) or []
        g = [t for t in g if now - t < 1.0] + [now]
        self._god_global_flood = g
    except Exception:
        pass
    god_audit(self, user_id, "message", (text or "")[:60])


def god_handle_referral(self, inviter_id, invited_id):
    """F10: ضدتقلب — self-ref، دعوتکننده ناشناس، تکراری، burst."""
    try:
        if int(inviter_id) == int(invited_id):
            god_audit(self, invited_id, "referral_rejected", "self")
            return False
        c = self._get_db()
        known = c.execute("SELECT 1 FROM bot_users WHERE bot_id=? AND chat_id=?",
                          (self.bot_id, inviter_id)).fetchone()
        dup = c.execute("SELECT 1 FROM referrals WHERE bot_id=? AND inviter_id=? AND invited_id=?",
                        (self.bot_id, inviter_id, invited_id)).fetchone()
        recent = c.execute("SELECT COUNT(*) n FROM referrals WHERE bot_id=? AND inviter_id=? AND created_at>?",
                           (self.bot_id, inviter_id,
                            (datetime.now() - timedelta(minutes=10)).isoformat())).fetchone()
        c.close()
        if not known:
            god_audit(self, invited_id, "referral_rejected", "unknown_inviter")
            return False
        if dup:
            god_audit(self, invited_id, "referral_rejected", "duplicate")
            return False
        if recent and recent["n"] >= 10:
            god_audit(self, invited_id, "referral_rejected", "burst")
            return False
        return MOD["_orig_handle_referral"](self, inviter_id, invited_id)
    except Exception as e:
        logger.debug("god referral: %s", e)
        return False


def _god_send(self, chat_id, text, **kw):
    try:
        return self.api.send_message(chat_id, text, **kw)
    except Exception:
        return None


def god_runtime_pre(self, message):
    """دستورات GOD؛ True یعنی پیام کاملاً هندل شد و نباید مسیر اصلی اجرا شود."""
    chat = message.get("chat") or {}
    chat_id = chat.get("id")
    if chat_id is None:
        return False
    from_user = message.get("from") or {}
    user_id = from_user.get("id") or chat_id
    text = (message.get("text") or message.get("caption") or "").strip()
    if not text:
        return False
    norm = base.normalize_command(text)
    today = datetime.now().strftime("%Y-%m-%d")

    def db():
        return self._get_db()

    # F08/F09/F11/F12/F16 — منفعل
    god_passive(self, chat_id, user_id, text, message)

    # F12 — پاسخخودکار نرمالشده (قبل از دستورات)
    try:
        c = db()
        autos = c.execute("SELECT keyword, reply FROM auto_replies WHERE bot_id=?", (self.bot_id,)).fetchall()
        c.close()
        for a in autos:
            k = base.normalize_command(a["keyword"] or "")
            if k and k == norm:
                _god_send(self, chat_id, self.runtime_render(chat_id, a["reply"] or "", from_user, chat))
                return True
    except Exception:
        pass

    # دستورات پیشوندی
    low = norm
    if low.startswith("انتقال "):
        parts = text.split()
        try:
            amount = int(re.sub(r"[^0-9]", "", parts[1]) or 0)
            to_id = int(parts[2])
            if amount <= 0:
                raise ValueError
            c = db()
            c.execute("INSERT OR IGNORE INTO god_wallets (bot_id,user_id,coins) VALUES (?,?,0)",
                      (self.bot_id, chat_id))
            cur = c.execute("SELECT coins FROM god_wallets WHERE bot_id=? AND user_id=?",
                            (self.bot_id, chat_id)).fetchone()
            if (cur["coins"] if cur else 0) < amount:
                c.close()
                _god_send(self, chat_id, "❌ موجودی سکه کافی نیست.")
                return True
            c.execute("UPDATE god_wallets SET coins=coins-? WHERE bot_id=? AND user_id=?",
                      (amount, self.bot_id, chat_id))
            c.execute("""INSERT INTO god_wallets (bot_id,user_id,coins) VALUES (?,?,?)
                ON CONFLICT(bot_id,user_id) DO UPDATE SET coins=coins+?""",
                (self.bot_id, to_id, amount, amount))
            c.commit()
            c.close()
            god_audit(self, chat_id, "transfer", f"{amount}->{to_id}")
            _god_send(self, chat_id, f"✅ {amount} سکه به `{to_id}` منتقل شد.")
        except Exception:
            _god_send(self, chat_id, "فرمت: `انتقال ۵۰ ۱۲۳۴۵۶`")
        return True

    if low.startswith("لینک کوتاه "):
        url = text.split(" ", 2)[-1].strip()
        if not re.match(r"^https?://", url, re.I):
            _god_send(self, chat_id, "🔗 لینک را با http:// یا https:// بفرست.")
            return True
        code = hashlib.sha1(f"{self.bot_id}:{url}:{time.time_ns()}".encode()).hexdigest()[:6]
        try:
            c = db()
            c.execute("INSERT INTO short_links (bot_id, original_url, short_code) VALUES (?,?,?)",
                      (self.bot_id, url, code))
            c.commit()
            c.close()
        except Exception:
            pass
        _god_send(self, chat_id, f"🔗 لینک کوتاه: `https://ble.ir/{code}`\nکد: `{code}`")
        return True

    if low.startswith("نظرسنجی "):
        body = text.split(" ", 1)[1]
        bits = [x.strip() for x in re.split(r"[|｜]", body) if x.strip()]
        if len(bits) < 3:
            _god_send(self, chat_id, "فرمت: `نظرسنجی سوال|گزینه۱|گزینه۲`")
            return True
        q, opts = bits[0], bits[1:6]
        try:
            c = db()
            cur = c.execute("INSERT INTO polls (bot_id, question, options, is_active) VALUES (?,?,?,1)",
                            (self.bot_id, q, json.dumps(opts, ensure_ascii=False)))
            pid = cur.lastrowid
            c.commit()
            c.close()
            kb = {"inline_keyboard": [[{"text": o, "callback_data": f"pvote_{pid}_{i}"}]
                                      for i, o in enumerate(opts)]}
            _god_send(self, chat_id, f"🗳️ {q}", reply_markup=kb)
        except Exception as e:
            _god_send(self, chat_id, "❌ خطا در ساخت نظرسنجی.")
        return True

    action = GOD_COMMANDS.get(norm) or GOD_COMMANDS.get(norm.lstrip("/"))
    if not action:
        return False

    if action == "god_help":
        txt = "🌟 **۲۰ قابلیت GOD**\n\n" + "\n".join(f"{i} {n} — {d}" for i, n, d in GOD_FEATURES)
        _god_send(self, chat_id, txt[:3900])
    elif action == "level":
        c = db()
        r = c.execute("SELECT xp, level FROM user_levels WHERE bot_id=? AND chat_id=?",
                      (self.bot_id, chat_id)).fetchone()
        c.close()
        xp, lvl = (r["xp"], r["level"]) if r else (0, 1)
        _god_send(self, chat_id, f"⭐ لول {lvl} | XP {xp}/{lvl * 100}\n👤 FIRSTNAME")
    elif action == "daily":
        c = db()
        c.execute("INSERT OR IGNORE INTO daily_bonus (bot_id,chat_id,streak) VALUES (?,?,0)",
                  (self.bot_id, chat_id))
        r = c.execute("SELECT last_claim, streak FROM daily_bonus WHERE bot_id=? AND chat_id=?",
                      (self.bot_id, chat_id)).fetchone()
        if r and r["last_claim"] == today:
            c.close()
            _god_send(self, chat_id, "🎁 پاداش امروز را قبلاً گرفتهای. فردا برگرد!")
        else:
            streak = 1
            if r and r["last_claim"] == (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d"):
                streak = (r["streak"] or 0) + 1
            coins = 50 + min(streak, 30) * 10
            c.execute("UPDATE daily_bonus SET last_claim=?, streak=? WHERE bot_id=? AND chat_id=?",
                      (today, streak, self.bot_id, chat_id))
            c.execute("""INSERT INTO god_wallets (bot_id,user_id,coins) VALUES (?,?,?)
                ON CONFLICT(bot_id,user_id) DO UPDATE SET coins=coins+?""",
                (self.bot_id, chat_id, coins, coins))
            c.commit()
            c.close()
            _god_send(self, chat_id, f"🎁 +{coins} سکه | 🔥 استریک {streak} روز")
    elif action == "wallet":
        c = db()
        r = c.execute("SELECT coins FROM god_wallets WHERE bot_id=? AND user_id=?",
                      (self.bot_id, chat_id)).fetchone()
        c.close()
        _god_send(self, chat_id, f"💰 سکه: {(r['coins'] if r else 0)}\n🔄 «انتقال ۵۰ ۱۲۳۴۵۶»")
    elif action == "streak":
        c = db()
        r = c.execute("SELECT streak, last_claim FROM daily_bonus WHERE bot_id=? AND chat_id=?",
                      (self.bot_id, chat_id)).fetchone()
        c.close()
        _god_send(self, chat_id, f"🔥 استریک: {(r['streak'] if r else 0)} روز | آخرین: {(r['last_claim'] if r else '---')}")
    elif action == "referral":
        _god_send(self, chat_id, f"🔗 لینک دعوت تو:\nhttps://ble.ir/{self.bot_info.get('username','bot') if getattr(self,'bot_info',None) else 'bot'}?start=ref_{chat_id}")
    elif action == "stats":
        c = db()
        users = c.execute("SELECT COUNT(*) n FROM bot_users WHERE bot_id=?", (self.bot_id,)).fetchone()["n"]
        msgs = c.execute("SELECT messages FROM stats_daily WHERE bot_id=? AND date=?",
                         (self.bot_id, today)).fetchone()
        btns = c.execute("SELECT COUNT(*) n FROM bot_buttons WHERE bot_id=?", (self.bot_id,)).fetchone()["n"]
        c.close()
        extra = ShardedUserStore.count(self.bot_id) if ShardedUserStore.enabled() else 0
        _god_send(self, chat_id, f"📊 آمار لحظهای\n👥 {users + extra} کاربر | 💬 {(msgs['messages'] if msgs else 0)} پیام امروز | 🔘 {btns} دکمه")
    elif action == "health":
        _god_send(self, chat_id, f"✅ سلامت ربات\n🟢 polling: {bool(getattr(self, 'running', True))}\n🗄 DB: ok\n🤖 {self.bot_id}")
    elif action == "cmdlist":
        c = db()
        cmds = c.execute("SELECT command FROM custom_commands WHERE bot_id=? AND is_active=1 ORDER BY command",
                         (self.bot_id,)).fetchall()
        btns = c.execute("SELECT title FROM bot_buttons WHERE bot_id=? AND parent_id IS NULL ORDER BY row, position",
                         (self.bot_id,)).fetchall()
        c.close()
        txt = "📜 **دستورات تنظیمشده**\n" + "\n".join("• " + x["command"] for x in cmds)
        txt += "\n\n🔘 **دکمهها**\n" + "\n".join("• " + x["title"] for x in btns)
        _god_send(self, chat_id, txt[:3900])
    elif action == "rules":
        _god_send(self, chat_id, "📜 قوانین GROUPNAME\n👥 GROUPMEMBERS | 📅 DATE\nلطفاً قوانین گروه را رعایت کنید.")
    elif action == "backup":
        _god_send(self, chat_id, "💾 پشتیبانگیری از پنل مدیریت سازنده انجام میشود.")
    return True


def god_runtime_message(self, message):
    if god_runtime_pre(self, message):
        return
    return MOD["_god_orig_runtime_message"](self, message)


def god_runtime_callback(self, query):
    data = (query.get("data") or "")
    if data.startswith("pvote_"):
        try:
            _, pid, idx = data.split("_")
            pid, idx = int(pid), int(idx)
            uid = ((query.get("from") or {}).get("id"))
            chat_id = ((query.get("message") or {}).get("chat") or {}).get("id") or uid
            c = self._get_db()
            row = c.execute("SELECT question, options, is_active FROM polls WHERE id=? AND bot_id=?",
                            (pid, self.bot_id)).fetchone()
            if not row or not row["is_active"]:
                c.close()
                return
            opts = json.loads(row["options"])
            if idx >= len(opts):
                c.close()
                return
            c.execute("INSERT OR IGNORE INTO poll_votes (poll_id,user_id,option_idx) VALUES (?,?,?)",
                      (pid, uid, idx))
            c.commit()
            votes = c.execute("SELECT COUNT(*) n FROM poll_votes WHERE poll_id=?", (pid,)).fetchone()["n"]
            c.close()
            try:
                self.api.answer_callback_query(query.get("id"), f"✅ رأی ثبت شد ({votes} رأی)")
            except Exception:
                pass
            return
        except Exception as e:
            logger.debug("pvote: %s", e)
            return
    return MOD["_god_orig_runtime_callback"](self, query)

# =====================================================================
# 9) سورسهای آماده — استقرار، جایگذاری امن، کامپایل و اجرای ایزوله
# =====================================================================
STANDALONE_SOURCE = '''# -*- coding: utf-8 -*-
# سورس آماده تولیدشده توسط رباتساز GOD — بدون وابستگی خارجی
import json
import time
import urllib.request

TOKEN = {token}
ADMIN_ID = {admin}
BASE = "https://tapi.bale.ai/bot" + TOKEN + "/"
BUTTONS = {buttons}
START_TEXT = {start}

def api(method, payload=None):
    url = BASE + method
    data = json.dumps(payload or {{}}).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={{"Content-Type": "application/json"}})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        print("API error", method, e)
        return {{"ok": False, "result": []}}

def send(chat_id, text, markup=None):
    p = {{"chat_id": chat_id, "text": text}}
    if markup:
        p["reply_markup"] = markup
    return api("sendMessage", p)

def main():
    offset = 0
    kb = {{"keyboard": [[{{"text": b["title"]}} for b in BUTTONS[i:i+2]]
                       for i in range(0, len(BUTTONS), 2)],
          "resize_keyboard": True, "is_persistent": True}}
    print("GOD source started")
    while True:
        try:
            res = api("getUpdates", {{"offset": offset, "limit": 100, "timeout": 20}})
            for upd in (res.get("result") or []):
                offset = upd.get("update_id", offset) + 1
                msg = upd.get("message") or {{}}
                if not msg:
                    continue
                cid = (msg.get("chat") or {{}}).get("id")
                txt = (msg.get("text") or "").strip()
                if cid is None:
                    continue
                if txt.startswith("/start") or txt in ("\\u0628\\u0627\\u0632\\u06af\\u0634\\u062a",):
                    send(cid, START_TEXT, kb)
                    continue
                hit = next((b for b in BUTTONS if b["title"] == txt), None)
                if hit:
                    # فقط به دستورات تنظیمشده پاسخ میدهد
                    send(cid, hit["content"], kb)
        except Exception as e:
            print("loop error", e)
            time.sleep(3)

if __name__ == "__main__":
    main()
'''


def generate_standalone_source(cat):
    t = next((v for k, v in GOD_TEMPLATES.items()
              if v.get("category") == cat and v.get("kind") == "library"), None)
    if t is None:
        t = next(iter(GOD_TEMPLATES.values()))
    buttons = [{"title": b["title"], "content": b["content"]} for b in t["buttons"]]
    return STANDALONE_SOURCE.format(
        token="__GOD_TOKEN__", admin="__GOD_ADMIN__",
        buttons=json.dumps(buttons, ensure_ascii=False),
        start=json.dumps(t.get("start_message", "سلام 👋"), ensure_ascii=False))


def _replace_placeholders(txt, token, admin_id, bot_username):
    """جایگذاری امن و یکباره — توکن با json.dumps داخل کوتیشن قرار میگیرد."""
    return (txt.replace("{{BOT_TOKEN}}", token)
               .replace("__GOD_TOKEN__", json.dumps(token, ensure_ascii=False))
               .replace("__GOD_ADMIN__", str(admin_id))
               .replace("{{ADMIN_ID}}", str(admin_id))
               .replace("{{ADMIN_CMD}}", "/admin")
               .replace("{{BOT_USERNAME}}", bot_username or "bot")
               .replace("YOUR_BOT_TOKEN", token))


def _compile_tree(workdir):
    """چانک به چانک: تکتک فایلهای پایتون سورس کامپایل میشوند."""
    import py_compile
    bad = []
    for root, dirs, files in os.walk(workdir):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "data")]
        for fn in files:
            if not fn.endswith(".py"):
                continue
            fp = os.path.join(root, fn)
            try:
                py_compile.compile(fp, doraise=True)
            except Exception as e:
                bad.append(f"{fp}: {e}")
    return bad


def deploy_ready_source(self, bot_db_id, chat_id, enc, bot_username, source):
    """کپی امن + جایگذاری توکن/ادمین + کامپایل + اجرای ایزوله."""
    import py_compile
    import subprocess
    safe_user = re.sub(r"[^A-Za-z0-9_]", "_", bot_username or "bot")[:24]
    workdir = os.path.join("bots", f"{bot_db_id}_{safe_user}")
    os.makedirs(workdir, exist_ok=True)
    token = MOD["decrypt_token"](enc)
    kind = source.get("kind")
    main_path = os.path.join(workdir, "main.py")
    if source.get("mode") == "generated" or kind == "generated" or kind == "skip":
        cat = source.get("cat") or "chat"
        code = generate_standalone_source(cat)
        code = _replace_placeholders(code, token, chat_id, bot_username)
        Path(main_path).write_text(code, encoding="utf-8")
    elif kind == "package":
        src = TEMPLATES_DIR / source["file"]
        shutil.copytree(str(src), workdir, dirs_exist_ok=True)
        for root, dirs, files in os.walk(workdir):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for fn in files:
                if fn.endswith((".py", ".json", ".txt", ".env.example")):
                    fp = Path(root) / fn
                    try:
                        txt = fp.read_text(encoding="utf-8")
                        fp.write_text(_replace_placeholders(txt, token, chat_id, bot_username),
                                      encoding="utf-8")
                    except Exception:
                        pass
        try:
            (Path(workdir) / ".env").write_text(
                f"BOT_TOKEN={token}\nADMIN_IDS={chat_id}\nBOT_USERNAME={bot_username or 'bot'}\n"
                f"DB_PATH=bot.db\n", encoding="utf-8")
        except Exception:
            pass
    else:
        src = TEMPLATES_DIR / source["file"]
        txt = Path(src).read_text(encoding="utf-8")
        Path(main_path).write_text(_replace_placeholders(txt, token, chat_id, bot_username),
                                   encoding="utf-8")

    bad = _compile_tree(workdir)
    if bad:
        logger.error("compile failed for %s: %s", source.get("id"), bad[:3])
        return False, workdir, bad

    if not os.path.exists(main_path):
        return False, workdir, ["main.py وجود ندارد"]

    try:
        proc = subprocess.Popen([sys.executable, "-X", "utf8", "main.py"], cwd=workdir,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                stdin=subprocess.DEVNULL, start_new_session=True)
        self.db.record_process(bot_db_id, proc.pid, workdir, "subprocess")
    except Exception as e:
        logger.exception("spawn source: %s", e)
        return False, workdir, [str(e)]
    try:
        self.db.execute("""UPDATE bots SET workdir=?, source_key=?, script_path=?,
                           status='online', is_active=1 WHERE id=?""",
                        (workdir, source["id"], main_path, bot_db_id))
    except Exception:
        pass
    return True, workdir, []


def god_step_token(self, chat_id, text, mode="choice"):
    """همان اعتبارسنجی امن + منوی سورسهای آماده ۳۲ تایی."""
    ok = MOD["_god_orig_step_token"](self, chat_id, text, mode)
    step = self.db.get_user_step(chat_id)
    if mode == "raw" or not step or step["step"] != "await_template_choice":
        return ok
    rows = [[{"text": "📚 سورسهای آماده (۳۲)", "callback_data": "rs_page_0"}],
            [{"text": "📂 کتابخانه قالبها", "callback_data": "lib_create_0"}]]
    self.send_message(chat_id,
        "📦 **سورسهای آماده** — هر سورس بهصورت جداگانه کپی، توکنگذاری، "
        "کامپایل و در پوشه اختصاصی اجرا میشود:", reply_markup=base._keyboard(rows))
    return True


def god_finish_bot_creation(self, chat_id, enc, bot_username, bot_name, bot_id_api, key, msg_id=None):
    orig = MOD["_god_orig_finish"]
    if not (isinstance(key, str) and key.startswith("rsrc:")):
        return orig(self, chat_id, enc, bot_username, bot_name, bot_id_api, key, msg_id)
    rid = key.split(":", 1)[1]
    source = READY_BY_ID.get(rid)
    if not source:
        return orig(self, chat_id, enc, bot_username, bot_name, bot_id_api, "raw", msg_id)
    # ساخت ردیفهای دیتابیس از مسیر امن و تستشده
    res = orig(self, chat_id, enc, bot_username, bot_name, bot_id_api, "raw", msg_id)
    row = self.db.fetchone("SELECT * FROM bots WHERE owner_id=? ORDER BY id DESC LIMIT 1", (chat_id,))
    if not row:
        return res
    bot_db_id = row["id"]
    # جلوگیری قطعی از poll دوبل: رانتایم درونفرایندی متوقف میشود
    try:
        self.bot_manager.stop_bot(bot_db_id)
    except Exception:
        pass
    deployed, workdir, errors = deploy_ready_source(
        self, bot_db_id, chat_id, enc, bot_username, source)
    if deployed:
        self.db.execute("UPDATE bots SET status='online', is_active=1 WHERE id=?", (bot_db_id,))
        self.send_message(chat_id,
            f"✅ **سورس آماده مستقر شد**\n📦 {source['name']}\n📁 `{workdir}`\n"
            "🔒 توکن/ادمین جایگذاری و تمام فایلها کامپایل شدند.",
            reply_markup=MOD["main_reply_keyboard"](is_admin=MOD["is_admin"](chat_id)))
    else:
        # fallback بدون باگ: همان رانتایم درونسازنده
        self.bot_manager.start_bot(bot_db_id, enc)
        self.db.execute("UPDATE bots SET status='online', is_active=1 WHERE id=?", (bot_db_id,))
        self.send_message(chat_id,
            f"⚠️ سورس `{source['id']}` کامپایل نشد؛ ربات با موتور داخلی اجرا شد.\n"
            f"دلیل: {(errors[0] if errors else 'نامشخص')[:180]}")
    self.db.clear_user_step(chat_id)
    return True


# =====================================================================
# 10) رابط پنل مدیریت — منوها، کالبکها و FSM
# =====================================================================
GOD_PREFIXES = ("rs_page_", "rs_use_", "gb_", "adm_global", "god_menu", "god_feat_",
                "godset_", "cmdonly_", "gvar_", "godpick")


def get_gb(self):
    mgr = getattr(self, "_god_gb", None)
    if mgr is None:
        mgr = self._god_gb = GlobalBroadcastManager(self)
    return mgr


def god_main_reply_keyboard(is_admin=False):
    kb = MOD["_god_orig_main_kb"](is_admin=is_admin)
    rows = list(kb.get("keyboard") or [])
    rows.append([{"text": "🌟 قابلیتهای GOD"}, {"text": "🎯 تنظیم پاسخها"}])
    rows.append([{"text": "📚 سورسهای آماده"}])
    if is_admin:
        rows.append([{"text": "🌐 همگانی سراسری"}])
    return {"keyboard": rows, "resize_keyboard": True, "is_persistent": True}


def god_admin_keyboard():
    kb = MOD["_god_orig_admin_kb"]()
    rows = list(kb.get("inline_keyboard") or [])
    rows.append([{"text": "🌐 همگانی به تمام رباتها", "callback_data": "gb_menu"},
                 {"text": "🌟 قابلیتهای GOD", "callback_data": "god_menu"}])
    return {"inline_keyboard": rows}


def show_ready_sources(self, chat_id, page=0, msg_id=None):
    per = 8
    pages = max(1, (len(READY_SOURCES) + per - 1) // per)
    page = max(0, min(int(page), pages - 1))
    chunk = READY_SOURCES[page * per:(page + 1) * per]
    rows = [[{"text": s["name"], "callback_data": f"rs_use_{s['id']}"}] for s in chunk]
    nav = []
    if page > 0:
        nav.append({"text": "⬅️ قبلی", "callback_data": f"rs_page_{page-1}"})
    nav.append({"text": f"📄 {page+1}/{pages}", "callback_data": "rs_page_0"})
    if page < pages - 1:
        nav.append({"text": "بعدی ➡️", "callback_data": f"rs_page_{page+1}"})
    rows.append(nav)
    rows.append([{"text": "⬅️ بازگشت", "callback_data": "back_main"}])
    self.edit_or_send(chat_id, msg_id,
        f"📚 **سورسهای آماده — {len(READY_SOURCES)} سورس**\n\n"
        "هر سورس: کپی اختصاصی ← جایگذاری توکن و آیدی ادمین ← کامپایل ← اجرای ایزوله.\n"
        "⚠️ ابتدا «🤖 ساخت ربات» و ارسال توکن لازم است.",
        reply_markup=base._keyboard(rows))


def show_gb_menu(self, chat_id, msg_id=None):
    mgr = get_gb(self)
    jobs = mgr.last_jobs(3)
    txt = ("🌐 **همگانی سراسری — تمام رباتهای متصل به سازنده**\n\n"
           "پیام به «همه کاربران همه رباتها» ارسال میشود، نه فقط یک ربات.\n"
           "ارسال با صفحهبندی ۱۰۰۰تایی و محدودیت نرخ رسمی بله انجام میشود.\n\n")
    for j in jobs:
        txt += (f"#{j['id']} | {j['status']} | ✅ {j['sent']} ❌ {j['failed']} / {j['total']}\n")
    rows = [[{"text": "✍️ پیام جدید سراسری", "callback_data": "gb_new"}],
            [{"text": "📊 وضعیت", "callback_data": "gb_status"},
             {"text": "🔄 تازهسازی", "callback_data": "gb_menu"}]]
    for j in jobs:
        if j["status"] == "running":
            rows.append([{"text": f"⏹ توقف #{j['id']}", "callback_data": f"gb_stop_{j['id']}"}])
    rows.append([{"text": "⬅️ بازگشت", "callback_data": "back_main"}])
    self.edit_or_send(chat_id, msg_id, txt, reply_markup=base._keyboard(rows))


def show_god_menu(self, chat_id, msg_id=None):
    txt = "🌟 **۲۰ قابلیت GOD** (همه پیادهسازیشده و تستشده)\n\n"
    txt += "\n".join(f"{i} {n}" for i, n, d in GOD_FEATURES)
    rows = []
    for i, n, d in GOD_FEATURES:
        rows.append([{"text": f"{i} {n}", "callback_data": f"god_feat_{i}"}])
    rows.append([{"text": "🎯 تنظیم پاسخها", "callback_data": "godpick"},
                 {"text": "⬅️ بازگشت", "callback_data": "back_main"}])
    self.edit_or_send(chat_id, msg_id, txt[:3900], reply_markup=base._keyboard(rows))


def show_god_settings(self, chat_id, bot_id, msg_id=None):
    if not base._owns(self, chat_id, bot_id):
        return
    row = self.db.fetchone("SELECT respond_unknown FROM bot_settings WHERE bot_id=?", (bot_id,))
    on = int((dict(row).get("respond_unknown") if row else 0) or 0)
    state = "🔴 خاموش (فقط دستورات)" if not on else "🟢 روشن (همه پیامها)"
    rows = [
        [{"text": "🎯 پاسخ به پیام ناشناخته: " + ("خاموش کن" if on else "روشن کن"),
          "callback_data": f"cmdonly_{bot_id}_{0 if on else 1}"}],
        [{"text": "⚡ افزودن ۲۹ متغیر/قفل", "callback_data": f"gvar_all_{bot_id}"},
         {"text": "🔒 لیست ۲۴ قفل", "callback_data": f"gvar_locks_{bot_id}"}],
        [{"text": "⬅️ بازگشت", "callback_data": "godpick"}],
    ]
    self.edit_or_send(chat_id, msg_id,
        f"🎯 **تنظیم پاسخها — ربات #{bot_id}**\n\n"
        f"وضعیت فعلی: {state}\n\n"
        "در حالت «فقط دستورات» ربات مطلقاً به پیامهای تنظیم نشده پاسخ نمیدهد "
        "(نه «دستور نامعتبر»، نه «متوجه نشدم»، نه منوی تکراری).",
        reply_markup=base._keyboard(rows))


def show_locks(self, chat_id, bot_id, msg_id=None):
    txt = f"🔒 **۲۴ قفل مهم گروه — ربات #{bot_id}**\n\n"
    for key, label, on, off, penalty, desc in GROUP_LOCK_SPECS:
        txt += f"• `{on}` / `{off}` — {desc}\n"
    self.edit_or_send(chat_id, msg_id, txt[:3900],
                      reply_markup=base._keyboard([[{"text": "⬅️ بازگشت",
                                                      "callback_data": f"godset_{bot_id}"}]]))


def step_global_broadcast(self, chat_id, message, text, step_info):
    if not MOD["is_admin"](chat_id):
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, "⛔ فقط ادمین اصلی به همگانی سراسری دسترسی دارد.")
        return True
    content = (text or (message.get("caption") if isinstance(message, dict) else "") or "").strip()
    if not content or content in ("❌ انصراف", "/cancel"):
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, "❌ لغو شد.")
        return True
    job_id = get_gb(self).start(chat_id, content)
    self.db.clear_user_step(chat_id)
    self.send_message(chat_id,
        f"🚀 همگانی سراسری #{job_id} شروع شد.\n"
        "ارسال به تمام کاربران تمام رباتهای متصل، با صفحهبندی و نرخ محدودشده.\n"
        "«🌐 همگانی سراسری» → وضعیت / توقف.",
        reply_markup=MOD["main_reply_keyboard"](is_admin=True))
    return True


def god_dispatch(self, chat_id, data, msg_id, from_user):
    admin = MOD["is_admin"](chat_id)
    # --- سورسهای آماده
    if data.startswith("rs_page_"):
        try:
            show_ready_sources(self, chat_id, int(data[8:]), msg_id)
        except Exception:
            show_ready_sources(self, chat_id, 0, msg_id)
        return True
    if data.startswith("rs_use_"):
        rid = data[7:]
        if rid not in READY_BY_ID:
            self.edit_or_send(chat_id, msg_id, "❌ سورس یافت نشد.", reply_markup=None)
            return True
        return base.use_template_new(self, chat_id, f"rsrc:{rid}", msg_id)
    # --- همگانی سراسری (فقط ادمین اصلی)
    if data in ("gb_menu", "adm_global", "gb_status"):
        if not admin:
            self.edit_or_send(chat_id, msg_id, "⛔ فقط ادمین اصلی مجاز است.", reply_markup=None)
            return True
        show_gb_menu(self, chat_id, msg_id)
        return True
    if data == "gb_new":
        if not admin:
            self.edit_or_send(chat_id, msg_id, "⛔ فقط ادمین اصلی مجاز است.", reply_markup=None)
            return True
        self.db.set_user_step(chat_id, "await_global_broadcast", {})
        self.send_message(chat_id,
            "✍️ متن همگانی **سراسری** را بفرست.\n"
            "به همه کاربران تمام رباتهای متصل به سازنده ارسال میشود.",
            reply_markup=MOD["cancel_keyboard"]())
        return True
    if data.startswith("gb_stop_"):
        if not admin:
            return True
        try:
            get_gb(self).stop(int(data[8:]))
        except Exception:
            pass
        show_gb_menu(self, chat_id, msg_id)
        return True
    # --- منوی GOD
    if data == "god_menu":
        show_god_menu(self, chat_id, msg_id)
        return True
    if data.startswith("god_feat_"):
        code = data[9:]
        feat = next((f for f in GOD_FEATURES if f[0] == code), None)
        if feat:
            self.edit_or_send(chat_id, msg_id,
                f"{feat[0]} **{feat[1]}**\n\n{feat[2]}",
                reply_markup=base._keyboard([[{"text": "⬅️ بازگشت", "callback_data": "god_menu"}]]))
        return True
    if data == "godpick":
        bots = self.db.get_user_bots(chat_id)
        rows = [[{"text": f"🤖 {b['bot_name'] or b['bot_username'] or b['id']}",
                  "callback_data": f"godset_{b['id']}"}] for b in bots]
        rows.append([{"text": "⬅️ بازگشت", "callback_data": "god_menu"}])
        self.edit_or_send(chat_id, msg_id, "ربات مورد نظر را انتخاب کن:",
                          reply_markup=base._keyboard(rows))
        return True
    if data.startswith("godset_") and not data.startswith("godset_all"):
        try:
            bid = int(data[7:])
        except Exception:
            return True
        show_god_settings(self, chat_id, bid, msg_id)
        return True
    if data.startswith("cmdonly_"):
        try:
            _, bid, val = data.split("_")
            bid, val = int(bid), int(val)
        except Exception:
            return True
        if not base._owns(self, chat_id, bid):
            return True
        self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id) VALUES (?)", (bid,))
        self.db.execute("UPDATE bot_settings SET respond_unknown=? WHERE bot_id=?", (val, bid))
        show_god_settings(self, chat_id, bid, msg_id)
        return True
    if data.startswith("gvar_all_"):
        try:
            bid = int(data[9:])
        except Exception:
            return True
        if not base._owns(self, chat_id, bid):
            return True
        n = god_db_seed_variables(self.db, bid)
        self.edit_or_send(chat_id, msg_id,
            f"✅ {n} متغیر/قفل جدید اضافه شد (جمعاً {len(base.CUSTOM_VARIABLE_PRESETS)} پریست).",
            reply_markup=base._keyboard([[{"text": "⬅️ بازگشت", "callback_data": f"godset_{bid}"}]]))
        return True
    if data.startswith("gvar_locks_"):
        try:
            bid = int(data[11:])
        except Exception:
            return True
        show_locks(self, chat_id, bid, msg_id)
        return True
    return False


def god_builder_callback(self, query):
    data = query.get("data") or ""
    chat_id = ((query.get("message") or {}).get("chat") or {}).get("id") \
              or (query.get("from") or {}).get("id")
    msg_id = (query.get("message") or {}).get("message_id")
    if chat_id and any(data.startswith(p) for p in GOD_PREFIXES):
        try:
            self.api.answer_callback_query(query.get("id"))
        except Exception:
            pass
        god_dispatch(self, chat_id, data, msg_id, query.get("from") or {})
        return
    return MOD["_god_orig_builder_callback"](self, query)


def god_builder_message(self, message):
    chat_id = (message.get("chat") or {}).get("id")
    text = (message.get("text") or message.get("caption") or "").strip()
    if chat_id and text and not self.db.get_user_step(chat_id):
        if text == "🌟 قابلیتهای GOD":
            show_god_menu(self, chat_id)
            return
        if text == "🎯 تنظیم پاسخها":
            god_dispatch(self, chat_id, "godpick", None, message.get("from") or {})
            return
        if text == "📚 سورسهای آماده":
            show_ready_sources(self, chat_id, 0)
            return
        if text == "🌐 همگانی سراسری":
            god_dispatch(self, chat_id, "gb_menu", None, message.get("from") or {})
            return
    return MOD["_god_orig_builder_message"](self, message)


# =====================================================================
# 11) نصب نهایی
# =====================================================================
def install_god_extensions(globs):
    global MOD
    MOD = globs

    # ۱) کتابخانه قالبها (جمعاً ۷۵۸)
    base.ALL_TEMPLATES.update(GOD_TEMPLATES)
    base.TEMPLATE_LIBRARY.update(GOD_TEMPLATES)
    globs["ALL_TEMPLATES"] = base.ALL_TEMPLATES

    # ۲) ۲۴ قفل: Detector جایگزین + پریستها (۵ پریست فاز اول دستنخورده میمانند)
    base._lock_violated = god_lock_violated
    seen = {p["name"] for p in base.CUSTOM_VARIABLE_PRESETS}
    for p in god_lock_presets():
        if p["name"] not in seen:
            base.CUSTOM_VARIABLE_PRESETS.append(p)
            seen.add(p["name"])

    # ۳) دیتابیس
    db_cls = globs["Database"]
    db_cls.init_db = god_init_db
    db_cls.seed_variables = god_db_seed_variables
    base.seed_vars_direct = god_seed_vars_direct

    # ۴) رانتایم ربات کاربر (فقط دستورات، ۲۰ قابلیت، ضدتقلب، نظرسنجی)
    ur = globs["UserBotRuntime"]
    MOD["_god_orig_runtime_message"] = ur.handle_message
    MOD["_god_orig_runtime_callback"] = ur.handle_callback
    MOD["_orig_handle_referral"] = ur._handle_referral
    ur.handle_message = god_runtime_message
    ur.handle_callback = god_runtime_callback
    ur._handle_referral = god_handle_referral

    # ۵) سازنده
    bb = globs["BuilderBot"]
    MOD["_god_orig_builder_message"] = bb.handle_message
    MOD["_god_orig_builder_callback"] = bb.handle_callback
    bb.handle_message = god_builder_message
    bb.handle_callback = god_builder_callback

    MOD["_god_orig_main_kb"] = globs["main_reply_keyboard"]
    MOD["_god_orig_admin_kb"] = globs["admin_keyboard"]
    globs["main_reply_keyboard"] = god_main_reply_keyboard
    globs["admin_keyboard"] = god_admin_keyboard

    base.NEW_STEPS["await_global_broadcast"] = \
        lambda s, c, m, t, d: step_global_broadcast(s, c, m, t, d)

    MOD["_god_orig_step_token"] = base.step_token_new
    MOD["_god_orig_finish"] = base.finish_bot_creation
    base.step_token_new = god_step_token
    base.finish_bot_creation = god_finish_bot_creation
    bb.step_token = god_step_token
    bb.finish_bot_creation = god_finish_bot_creation

    # ۶) worker زمانبندیشده (اختیاری، بدون ایجاد بار در تستها)
    if os.getenv("GOD_SCHEDULER", "0") == "1":
        try:
            GodScheduler(globs.get("DATABASE_PATH", "data/botbuilder.db")).start()
        except Exception as e:
            logger.debug("scheduler start: %s", e)

    logger.info("✅ god_ext نصب شد: %s قالب | %s قفل | %s سورس | %s قابلیت GOD",
                len(base.ALL_TEMPLATES), len(GROUP_LOCK_SPECS), len(READY_SOURCES),
                len(GOD_FEATURES))
    return True
