#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ممیزی نهایی «خط به خط / حرف به حرف / چانک به چانک / فریم به فریم».

اجرا:  python3 audit_all.py
خروجی: AUDIT-GOD.md + audit-report.json  (گزارش فارسی + ماشینی)
بدون هیچ تماس شبکهای، بدون توکن واقعی، بدون اجرای ربات.
"""
import glob
import json
import os
import py_compile
import subprocess
import sys
import time
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import main  # noqa: E402
import botfix_ext as ext  # noqa: E402
import god_ext as god  # noqa: E402

report = {
    "generated_at": datetime.now().isoformat(),
    "python_files": 0, "compile_errors": [],
    "templates_total": len(ext.ALL_TEMPLATES),
    "templates_god": len(god.GOD_TEMPLATES),
    "templates_checked": 0, "buttons_checked": 0,
    "structural_errors": [], "lock_detectors": {},
    "ready_sources": len(god.READY_SOURCES), "ready_source_results": {},
    "locks": len(god.GROUP_LOCK_SPECS), "features": len(god.GOD_FEATURES),
    "tests": {}, "scale": {},
}

# ---------- ۱) کامپایل تکتک فایلها ----------
for f in glob.glob(os.path.join(HERE, "**", "*.py"), recursive=True):
    if "__pycache__" in f:
        continue
    report["python_files"] += 1
    try:
        py_compile.compile(f, doraise=True)
    except Exception as e:
        report["compile_errors"].append({"file": f, "error": str(e)[:300]})

# ---------- ۲) بررسی ساختار تکتک قالبها / تکتک دکمهها ----------
for key, t in ext.ALL_TEMPLATES.items():
    report["templates_checked"] += 1
    is_lib = t.get("kind") == "library"
    for field in ("name", "desc", "start_message"):
        if not t.get(field):
            report["structural_errors"].append(f"{key}: {field} خالی")
    if (t.get("scope") or "both") not in ("both", "group", "pv", "off"):
        report["structural_errors"].append(f"{key}: scope نامعتبر")
    if is_lib and not t.get("buttons"):
        report["structural_errors"].append(f"{key}: کتابخانه بدون دکمه")
    titles = set()
    for i, b in enumerate(t.get("buttons") or []):
        report["buttons_checked"] += 1
        if not b.get("title"):
            report["structural_errors"].append(f"{key}[{i}]: عنوان خالی")
        if b.get("title") in titles:
            report["structural_errors"].append(f"{key}[{i}]: عنوان تکراری")
        titles.add(b.get("title"))
        if not str(b.get("content") or "").strip():
            report["structural_errors"].append(f"{key}[{i}]: محتوای خالی")
        if b.get("type") not in ("reply", "inline"):
            report["structural_errors"].append(f"{key}[{i}]: type نامعتبر")
        # رندر امن متغیرها (حرف به حرف، بدون تداخل زیررشته)
        ext.render_variables(b.get("content") or "", {"FIRSTNAME": "علی", "zadlink": "فعال"})
    ext.render_variables(t.get("start_message") or "", {"FIRSTNAME": "علی"})

# ---------- ۳) تکتک detector های ۲۴ قفل ----------
VIOLATING = {
    "lock_link": {"text": "https://ble.ir/x"},
    "lock_forward": {"forward_from": {"id": 1}},
    "lock_photo": {"photo": [1]},
    "lock_video": {"video": 1},
    "lock_audio": {"audio": 1},
    "lock_voice": {"voice": 1},
    "lock_sticker": {"sticker": 1},
    "lock_gif": {"animation": 1},
    "lock_document": {"document": 1},
    "lock_contact": {"contact": 1},
    "lock_location": {"location": 1},
    "lock_poll": {"poll": 1},
    "lock_game": {"game": 1},
    "lock_bot": {"new_chat_members": [{"is_bot": True}]},
    "lock_badwords": {"text": "تو احمقی"},
    "lock_ads": {"text": "تخفیف ویژه فقط امروز، لینک زیر را کلیک کنید https://x.com"},
    "lock_arabic": {"text": "ThisIsAVeryLongLatinMessageForTest"},
    "lock_mention": {"text": "@all سلام"},
    "lock_hashtag": {"text": "سلام #تبلیغ"},
    "lock_caption": {"caption": "x" * 250},
    "lock_edit": {"edit_date": 1},
    "lock_service": {"new_chat_members": [{"id": 3}]},
    "lock_command": {"text": "/start"},
}
clean = {"text": "سلام دوستان، حالتون خوبه؟", "caption": ""}
for key, label, on, off, penalty, desc in god.GROUP_LOCK_SPECS:
    action = "lock_" + key
    if action == "lock_spam":
        report["lock_detectors"][action] = "runtime-counter"
        continue
    m = VIOLATING.get(action) or {}
    hit = god.god_lock_violated(action, m, m.get("text", ""))
    fp = god.god_lock_violated(action, clean, clean["text"])
    report["lock_detectors"][action] = "OK" if (hit and not fp) else f"FAIL hit={hit} fp={fp}"

# ---------- ۴) تکتک سورسهای آماده (کپی + جایگذاری + کامپایل) ----------
import shutil  # noqa: E402
import tempfile  # noqa: E402
from unittest.mock import patch  # noqa: E402

class _DummyDB:
    def record_process(self, *a, **kw):
        return True

    def execute(self, *a, **kw):
        return True

class _DummyBuilder:
    db = _DummyDB()


_tmp = tempfile.mkdtemp(prefix="god_audit_")
_cwd = os.getcwd()
try:
    os.chdir(_tmp)
    os.makedirs("bots", exist_ok=True)
    with patch("subprocess.Popen") as popen:
        popen.return_value.pid = 1
        for s in god.READY_SOURCES:
            try:
                ok, workdir, bad = god.deploy_ready_source(
                    _DummyBuilder(), 1, 1, "TESTTOKEN", "bot", s)
                leftovers = []
                mp = os.path.join(workdir, "main.py")
                if os.path.exists(mp):
                    txt = open(mp, encoding="utf-8").read()
                    leftovers = [p for p in ("{{BOT_TOKEN}}", "{{ADMIN_ID}}",
                                             "__GOD_TOKEN__", "__GOD_ADMIN__") if p in txt]
                report["ready_source_results"][s["id"]] = (
                    "OK" if ok and not leftovers and not bad
                    else f"FAIL {bad[:1]} leftovers={leftovers}")
                shutil.rmtree(workdir, ignore_errors=True)
            except Exception as e:
                report["ready_source_results"][s["id"]] = f"ERROR {e}"
finally:
    os.chdir(_cwd)
    shutil.rmtree(_tmp, ignore_errors=True)

# ---------- ۵) اجرای کامل سوئیت تستها (شامل ۳۷۰۰+ کالبک واقعی) ----------
t0 = time.time()
p = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"],
                   cwd=HERE, capture_output=True, text=True, timeout=600)
report["tests"] = {
    "returncode": p.returncode,
    "seconds": round(time.time() - t0, 1),
    "summary": (p.stderr or "").strip().splitlines()[-4:],
    "all_ok": p.returncode == 0,
}

# ---------- ۶) مقیاس ----------
report["scale"] = {
    "design_target": "10,000 bots × 50,000 users/bot",
    "strategy": "WAL + composite indexes + keyset pagination (batch=1000) + per-bot shard files",
    "shard_env": "GOD_SHARD_USERS=1",
    "scheduler_env": "GOD_SCHEDULER=1",
}

with open(os.path.join(HERE, "audit-report.json"), "w", encoding="utf-8") as f:
    json.dump(report, f, ensure_ascii=False, indent=2)

md = f"""# 🧾 گزارش ممیزی نهایی — GOD ULTRA (فاز دوم)

🗓 `{report['generated_at']}`

| بخش | نتیجه |
|---|---|
| فایلهای پایتون کامپایلشده | **{report['python_files']}** |
| خطای نحوی | **{len(report['compile_errors'])}** |
| قالبهای بررسیشده (چانکبهچانک) | **{report['templates_checked']}** |
| دکمههای بررسیشده (فریمبهفریم) | **{report['buttons_checked']}** |
| خطای ساختاری قالب | **{len(report['structural_errors'])}** |
| قفلهای مهم گروه | **{report['locks']}** |
| سورسهای آماده استقرار/کامپایلشده | **{report['ready_sources']}** |
| قابلیتهای GOD | **{report['features']}** |
| سوئیت تست آفلاین | **{'✅ OK' if report['tests']['all_ok'] else '❌ FAIL'}** (در {report['tests']['seconds']} ثانیه) |

## 🔒 Detector قفلها
```
{json.dumps(report['lock_detectors'], ensure_ascii=False, indent=2)}
```

## 📦 استقرار سورسها
```
{json.dumps(report['ready_source_results'], ensure_ascii=False, indent=2)}
```

## 🏗️ مقیاس
{json.dumps(report['scale'], ensure_ascii=False, indent=2)}

## خلاصه تستها
```
{chr(10).join(report['tests']['summary'])}
```

📄 نسخه ماشینی کامل: `audit-report.json`
"""
with open(os.path.join(HERE, "AUDIT-GOD.md"), "w", encoding="utf-8") as f:
    f.write(md)

print(md)
sys.exit(0 if not report["compile_errors"] and not report["structural_errors"]
         and report["tests"]["all_ok"] else 1)
