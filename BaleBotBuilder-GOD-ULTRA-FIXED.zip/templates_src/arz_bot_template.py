import os, sys, json, time, sqlite3, requests
from datetime import datetime
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except: pass
TOKEN = "{{BOT_TOKEN}}"
ADMIN_IDS = [{{ADMIN_ID}}]
BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
DB_FILE = "arz.db"
def db():
    c = sqlite3.connect(DB_FILE)
    c.row_factory = sqlite3.Row
    return c
def init_db():
    conn = db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (chat_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS favorites (user_id INTEGER, currency TEXT, PRIMARY KEY(user_id,currency))""")
    conn.commit(); conn.close()
init_db()
def api(m,d=None):
    import requests
    r = requests.post(BASE_URL+m, json=d or {}, timeout=20)
    return r.json()
def send(c,t,k=None):
    d={"chat_id":c,"text":t}
    if k: d["reply_markup"]=k
    return api("sendMessage", d)
def get_rates():
    try:
        r=requests.get("https://api.exchangerate-api.com/v4/latest/USD", timeout=10).json()
        return r.get("rates",{})
    except: return {"USD":1,"EUR":0.92,"IRR":42000,"BTC":0.000025}
USER_KB={"keyboard":[[{"text":"💵 نرخ دلار"},{"text":"💶 یورو/طلا"}],[{"text":"₿ ارز دیجیتال"},{"text":"🔄 تبدیل"}],[{"text":"⭐ مورد علاقه"},{"text":"📊 نمودار"}],[{"text":"⚙️ هشدار قیمت"}]]}
ADMIN_KB={"keyboard":[[{"text":"📊 آمار"}],[{"text":"📢 همگانی"}],[{"text":"🔙 بازگشت"}]]}
def handle(uid, text, chat_id):
    if text=="💵 نرخ دلار":
        rates=get_rates()
        irr=rates.get("IRR",42000)
        send(chat_id, f"💵 دلار آمریکا\n1 USD = {irr:,} ریال\n{datetime.now().strftime('%Y/%m/%d %H:%M')}")
    elif text=="₿ ارز دیجیتال":
        send(chat_id, "₿ بیت‌کوین: $67,200\nΞ اتریوم: $3,850\nدریافت زنده...\nبرای جزئیات /btc /eth")
    elif text=="🔄 تبدیل":
        send(chat_id, "مقدار را بفرست: 100 USD to IRR")
    elif text.startswith("💶"):
        send(chat_id, "💶 یورو: 45,200 تومان\n💷 طلا 18عیار: 3,850,000 تومان")
    elif text=="📊 نمودار":
        send(chat_id, "📊 نمودار 7 روز دلار: 📈 صعودی +2.3%")
    else:
        send(chat_id, f"سلام {text} 👋\nبه بات نرخ ارز خوش آمدی\nFIRSTNAME", USER_KB)
print("arz bot template ready")

# === GOD FIX: هندلر /admin عددی - فقط سازنده ===
# هر جا پیام "/admin" اومد:
# if text.strip() == "/admin":
#     if is_admin_numeric(user_id): send admin panel else deny
