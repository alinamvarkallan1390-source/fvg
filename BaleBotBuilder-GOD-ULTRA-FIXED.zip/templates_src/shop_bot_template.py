# ===================================================================
# 🛍️ فروشگاه سورس کد - پنل مدیریت داخل خود بله (بدون پنل وب)
# ===================================================================

import os
import sys

# محافظت در برابر کرش روی ویندوز موقع پرینت فارسی/ایموجی وقتی خروجی به فایل ریدایرکت می‌شه
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import time
import sqlite3
import json
import requests
from pathlib import Path
from datetime import datetime

# ===================================================================
# ⚙️ تنظیمات
# ===================================================================
MAIN_BOT_TOKEN = "{{BOT_TOKEN}}"  # ← توکن ربات
ADMIN_ID = {{ADMIN_ID}}  # ← آیدی عددی ادمین این بات
ADMIN_CMD = "{{ADMIN_CMD}}"  # دستوری که پنل مدیریت رو باز می‌کنه (پیش‌فرض: /admin)
BALE_API = "https://tapi.bale.ai/bot"
BALE_FILE_API = "https://tapi.bale.ai/file/bot"
SOURCES_DIR = "sources"
DB_NAME = "shop.db"
ALLOWED_EXTENSIONS = (".py", ".zip")

Path(SOURCES_DIR).mkdir(exist_ok=True)

# ===================================================================
# 🗄️ دیتابیس
# ===================================================================
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        username TEXT DEFAULT '',
        first_name TEXT DEFAULT '',
        balance INTEGER DEFAULT 0,
        is_banned INTEGER DEFAULT 0,
        has_started INTEGER DEFAULT 0,
        created_at TEXT DEFAULT '')''')

    c.execute('''CREATE TABLE IF NOT EXISTS sources (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, description TEXT, price INTEGER DEFAULT 0,
        filename TEXT, sample_username TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT '')''')

    c.execute('''CREATE TABLE IF NOT EXISTS purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, source_id INTEGER,
        created_at TEXT DEFAULT '')''')

    c.execute('''CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, amount INTEGER, type TEXT DEFAULT 'charge',
        created_at TEXT DEFAULT '')''')

    c.execute('''CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT)''')

    defaults = {
        'start_text': '👋 سلام {first_name} عزیز!\n\n🎉 به فروشگاه سورس کد خوش اومدی!\n\n💰 موجودی: {balance} تومان',
        'support_text': '📞 پشتیبانی: @Admin',
        'charge_single_text': '🎁 کاربر عزیز {first_name}!\n\n💎 مبلغ {amount} تومان از طرف مدیریت شارژ شد.\n\n💰 موجودی: {balance} تومان',
        'charge_bulk_text': '🎉 خبر خوب!\n\n💰 مبلغ {amount} تومان هدیه شارژ شد.\n\n💰 موجودی: {balance} تومان',
        'deduct_bulk_text': '📢 اطلاعیه\n\n⚠️ مبلغ {amount} تومان کسر شد.\n\n💰 موجودی: {balance} تومان',
    }
    for k, v in defaults.items():
        c.execute('INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)', (k, v))

    conn.commit()
    conn.close()

# ===================================================================
# 📊 توابع دیتابیس
# ===================================================================
def get_setting(key):
    conn = sqlite3.connect(DB_NAME)
    r = conn.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
    conn.close()
    return r[0] if r else ""

def update_setting(key, value):
    conn = sqlite3.connect(DB_NAME)
    conn.execute('UPDATE settings SET value=? WHERE key=?', (value, key))
    conn.commit()
    conn.close()

def get_all_settings():
    conn = sqlite3.connect(DB_NAME)
    return {r[0]: r[1] for r in conn.execute('SELECT * FROM settings').fetchall()}

def get_user(user_id):
    conn = sqlite3.connect(DB_NAME)
    r = conn.execute('SELECT * FROM users WHERE user_id=?', (user_id,)).fetchone()
    conn.close()
    return r

def ensure_user_exists(user_id):
    if not get_user(user_id):
        conn = sqlite3.connect(DB_NAME)
        conn.execute('INSERT OR IGNORE INTO users (user_id, has_started) VALUES (?,0)', (user_id,))
        conn.commit()
        conn.close()

def add_user(user_id, username, first_name):
    conn = sqlite3.connect(DB_NAME)
    now = datetime.now().isoformat()
    existing = conn.execute('SELECT id FROM users WHERE user_id=?', (user_id,)).fetchone()
    if existing:
        conn.execute('UPDATE users SET username=?, first_name=?, has_started=1 WHERE user_id=?', (username, first_name, user_id))
    else:
        conn.execute('INSERT INTO users (user_id, username, first_name, has_started, created_at) VALUES (?,?,?,1,?)', (user_id, username, first_name, now))
    conn.commit()
    conn.close()

def get_balance(user_id):
    u = get_user(user_id)
    return u[4] if u else 0

def update_balance(user_id, amount):
    ensure_user_exists(user_id)
    conn = sqlite3.connect(DB_NAME)
    conn.execute('UPDATE users SET balance=balance+? WHERE user_id=?', (amount, user_id))
    conn.commit()
    conn.close()

def get_all_users():
    conn = sqlite3.connect(DB_NAME)
    return conn.execute('SELECT * FROM users ORDER BY created_at DESC').fetchall()

def ban_toggle(user_id):
    ensure_user_exists(user_id)
    u = get_user(user_id)
    new_status = 0 if u[5] else 1
    conn = sqlite3.connect(DB_NAME)
    conn.execute('UPDATE users SET is_banned=? WHERE user_id=?', (new_status, user_id))
    conn.commit()
    conn.close()
    return new_status

def get_sources():
    return sqlite3.connect(DB_NAME).execute('SELECT * FROM sources WHERE is_active=1 ORDER BY id DESC').fetchall()

def get_all_sources():
    return sqlite3.connect(DB_NAME).execute('SELECT * FROM sources ORDER BY id DESC').fetchall()

def get_source(source_id):
    return sqlite3.connect(DB_NAME).execute('SELECT * FROM sources WHERE id=?', (source_id,)).fetchone()

def add_source(name, description, price, filename, sample_username=""):
    conn = sqlite3.connect(DB_NAME)
    conn.execute('INSERT INTO sources (name, description, price, filename, sample_username, created_at) VALUES (?,?,?,?,?,?)', (name, description, price, filename, sample_username, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def delete_source(source_id):
    src = get_source(source_id)
    if src:
        Path(SOURCES_DIR, src[4]).unlink(missing_ok=True)
        conn = sqlite3.connect(DB_NAME)
        conn.execute('DELETE FROM sources WHERE id=?', (source_id,))
        conn.commit()
        conn.close()

def update_source_price(source_id, price):
    conn = sqlite3.connect(DB_NAME)
    conn.execute('UPDATE sources SET price=? WHERE id=?', (price, source_id))
    conn.commit()
    conn.close()

def has_purchased(user_id, source_id):
    return sqlite3.connect(DB_NAME).execute('SELECT 1 FROM purchases WHERE user_id=? AND source_id=?', (user_id, source_id)).fetchone() is not None

def add_purchase(user_id, source_id):
    conn = sqlite3.connect(DB_NAME)
    conn.execute('INSERT INTO purchases (user_id, source_id, created_at) VALUES (?,?,?)', (user_id, source_id, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def add_payment(user_id, amount, pay_type='charge'):
    conn = sqlite3.connect(DB_NAME)
    conn.execute('INSERT INTO payments (user_id, amount, type, created_at) VALUES (?,?,?,?)', (user_id, amount, pay_type, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def get_user_purchases(user_id):
    return sqlite3.connect(DB_NAME).execute('''SELECT s.name, s.price, p.created_at FROM purchases p JOIN sources s ON p.source_id=s.id WHERE p.user_id=? ORDER BY p.created_at DESC''', (user_id,)).fetchall()

def get_all_purchases(limit=20):
    return sqlite3.connect(DB_NAME).execute('''SELECT p.id, p.user_id, u.first_name, u.username, s.name, s.price, p.created_at FROM purchases p JOIN users u ON p.user_id=u.user_id JOIN sources s ON p.source_id=s.id ORDER BY p.id DESC LIMIT ?''', (limit,)).fetchall()

def get_stats():
    conn = sqlite3.connect(DB_NAME)
    tu = conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]
    ts = conn.execute('SELECT COUNT(*) FROM sources').fetchone()[0]
    tp = conn.execute('SELECT COUNT(*) FROM purchases').fetchone()[0]
    tc = conn.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE type="charge"').fetchone()[0]
    tbuy = conn.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE type="buy"').fetchone()[0]
    conn.close()
    return {'total_users': tu, 'total_sources': ts, 'total_purchases': tp, 'total_charge': tc, 'total_buy': tbuy}

def financial_report():
    conn = sqlite3.connect(DB_NAME)
    today = datetime.now().strftime("%Y-%m-%d")
    month = datetime.now().strftime("%Y-%m")
    ts = conn.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE type='buy' AND created_at LIKE ?", (f"{today}%",)).fetchone()[0]
    tc = conn.execute("SELECT COUNT(*) FROM purchases WHERE created_at LIKE ?", (f"{today}%",)).fetchone()[0]
    tch = conn.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE type='charge' AND created_at LIKE ?", (f"{today}%",)).fetchone()[0]
    ms = conn.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE type='buy' AND created_at LIKE ?", (f"{month}%",)).fetchone()[0]
    mc = conn.execute("SELECT COUNT(*) FROM purchases WHERE created_at LIKE ?", (f"{month}%",)).fetchone()[0]
    mch = conn.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE type='charge' AND created_at LIKE ?", (f"{month}%",)).fetchone()[0]
    total_s = conn.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE type='buy'").fetchone()[0]
    total_c = conn.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE type='charge'").fetchone()[0]
    conn.close()
    return (
        "📈 گزارش مالی\n\n"
        f"📅 امروز: فروش {ts:,} | خرید {tc} عدد | شارژ {tch:,}\n"
        f"📆 این ماه: فروش {ms:,} | خرید {mc} عدد | شارژ {mch:,}\n\n"
        f"🏆 مجموع فروش: {total_s:,}\n💳 مجموع شارژ: {total_c:,}\n💰 موجودی کل کاربران: {total_c - total_s:,}"
    )

# ===================================================================
# 🤖 توابع ربات
# ===================================================================
processed_updates = set()

def send_message(chat_id, text, reply_markup=None):
    try:
        data = {"chat_id": chat_id, "text": text}
        if reply_markup:
            data["reply_markup"] = reply_markup
        requests.post(f"{BALE_API}{MAIN_BOT_TOKEN}/sendMessage", json=data, timeout=15)
    except Exception:
        pass

def answer_callback(callback_id, text="", show_alert=False):
    try:
        requests.post(f"{BALE_API}{MAIN_BOT_TOKEN}/answerCallbackQuery", json={"callback_query_id": callback_id, "text": text, "show_alert": show_alert}, timeout=10)
    except Exception:
        pass

def send_file(chat_id, file_path):
    try:
        with open(file_path, 'rb') as f:
            requests.post(f"{BALE_API}{MAIN_BOT_TOKEN}/sendDocument", files={"document": f}, data={"chat_id": chat_id}, timeout=60)
    except Exception:
        pass

def download_incoming_document(document, dest_name):
    """فایل document که کاربر فرستاده رو (زیپ یا py) از بله دانلود و ذخیره می‌کنه."""
    try:
        file_id = document["file_id"]
        r = requests.get(f"{BALE_API}{MAIN_BOT_TOKEN}/getFile", params={"file_id": file_id}, timeout=20).json()
        if not r.get("ok"):
            return False
        file_path = r["result"]["file_path"]
        file_bytes = requests.get(f"{BALE_FILE_API}{MAIN_BOT_TOKEN}/{file_path}", timeout=60).content
        with open(Path(SOURCES_DIR, dest_name), "wb") as f:
            f.write(file_bytes)
        return True
    except Exception:
        return False

def get_updates(offset=None):
    try:
        params = {"timeout": 30}
        if offset:
            params["offset"] = offset
        return requests.get(f"{BALE_API}{MAIN_BOT_TOKEN}/getUpdates", params=params, timeout=35).json().get("result", [])
    except Exception:
        return []

def is_admin(user_id):
    return int(user_id) == int(ADMIN_ID)

def main_menu(chat_id):
    u = get_user(chat_id)
    balance = u[4] if u else 0
    first_name = u[3] if u else "کاربر"
    text = get_setting('start_text').replace('{first_name}', first_name).replace('{balance}', f"{balance:,}")
    keyboard = {"inline_keyboard": [
        [{"text": "🛍️ خرید سورس", "callback_data": "shop"}],
        [{"text": "📦 خریدهای من", "callback_data": "purchases"}],
        [{"text": "💰 کیف پول", "callback_data": "wallet"}],
        [{"text": "👤 پشتیبانی", "callback_data": "support"}],
    ]}
    send_message(chat_id, text, keyboard)
    if is_admin(chat_id):
        send_message(chat_id, f"👑 شما ادمین این بات هستید.\nبرای پنل مدیریت دستور {ADMIN_CMD} رو بفرست.")

# ===================================================================
# 👑 پنل مدیریت داخل بله
# ===================================================================
waiting_for = {}  # user_id(str) -> {"type": ..., ...}
CANCEL_KB = {"keyboard": [[{"text": "❌ انصراف"}]], "resize_keyboard": True}

def kb_admin_root():
    rows = [
        [{"text": "📊 داشبورد"}],
        [{"text": "📦 مدیریت سورس‌ها"}],
        [{"text": "👥 کاربران"}, {"text": "🛒 آخرین خریدها"}],
        [{"text": "💰 شارژ/کسر همگانی"}, {"text": "📨 پیام همگانی"}],
        [{"text": "✉️ پیام به کاربر"}, {"text": "📈 گزارش مالی"}],
        [{"text": "⚙️ تنظیم متن‌ها"}],
        [{"text": "🔙 خروج از پنل"}],
    ]
    return {"keyboard": rows, "resize_keyboard": True}

def kb_sources():
    return {"keyboard": [
        [{"text": "➕ افزودن سورس جدید"}],
        [{"text": "📋 لیست سورس‌ها"}],
        [{"text": "✏️ تغییر قیمت سورس"}, {"text": "🗑 حذف سورس"}],
        [{"text": "🔙 بازگشت به پنل"}],
    ], "resize_keyboard": True}

def kb_users():
    return {"keyboard": [
        [{"text": "🔍 جستجوی کاربر"}],
        [{"text": "🚫 مسدود/رفع مسدود کاربر"}],
        [{"text": "💰 شارژ یا کسر یک کاربر"}],
        [{"text": "📋 لیست کاربران (۲۰ نفر آخر)"}],
        [{"text": "🔙 بازگشت به پنل"}],
    ], "resize_keyboard": True}

def kb_settings():
    rows = [[{"text": k}] for k in [
        "متن شروع", "متن پشتیبانی", "متن شارژ تکی", "متن شارژ همگانی", "متن کسر همگانی",
    ]]
    rows.append([{"text": "🔙 بازگشت به پنل"}])
    return {"keyboard": rows, "resize_keyboard": True}

SETTING_KEY_MAP = {
    "متن شروع": "start_text",
    "متن پشتیبانی": "support_text",
    "متن شارژ تکی": "charge_single_text",
    "متن شارژ همگانی": "charge_bulk_text",
    "متن کسر همگانی": "deduct_bulk_text",
}

def sources_list_text():
    rows = get_all_sources()
    if not rows:
        return "📭 هنوز سورسی اضافه نشده."
    out = "📋 لیست سورس‌ها:\n"
    for s in rows:
        out += f"\n#{s[0]} {s[1]} - {s[3]:,} تومان - فایل: {s[4]}"
    return out

def users_list_text():
    rows = get_all_users()[:20]
    if not rows:
        return "کاربری ثبت نشده."
    out = "📋 ۲۰ کاربر آخر:\n"
    for u in rows:
        out += f"\n🆔 {u[1]} | {u[3] or '-'} | 💰 {u[4]:,} | {'🚫 بن' if u[5] else '✅ آزاد'}"
    return out

def purchases_list_text():
    rows = get_all_purchases(20)
    if not rows:
        return "خریدی ثبت نشده."
    out = "🛒 ۲۰ خرید آخر:\n"
    for p in rows:
        out += f"\n#{p[0]} {p[4]} | {p[5]:,}T | کاربر {p[1]} ({p[2] or p[3] or '-'}) | {p[6][:16]}"
    return out


def handle_admin_flow(chat_id, text, msg):
    """اگه پیام مربوط به یکی از حالت‌های در انتظار پنل ادمین بود پردازشش می‌کنه و True برمی‌گردونه."""
    key = str(chat_id)
    wait = waiting_for.get(key)

    if text == "❌ انصراف" and wait:
        del waiting_for[key]
        send_message(chat_id, "لغو شد.", kb_admin_root())
        return True

    if not wait:
        return False
    wtype = wait["type"]

    if wtype == "add_source_name":
        wait["name"] = text
        wait["type"] = "add_source_desc"
        send_message(chat_id, "📝 توضیحات سورس رو بفرست:", CANCEL_KB)
        return True

    if wtype == "add_source_desc":
        wait["desc"] = text
        wait["type"] = "add_source_price"
        send_message(chat_id, "💵 قیمت رو به تومان بفرست (عدد):", CANCEL_KB)
        return True

    if wtype == "add_source_price":
        if not text.isdigit():
            send_message(chat_id, "❌ فقط عدد بفرست:", CANCEL_KB)
            return True
        wait["price"] = int(text)
        wait["type"] = "add_source_sample"
        send_message(chat_id, "📱 یوزرنیم نمونه (اختیاری، اگه نداری بفرست: -):", CANCEL_KB)
        return True

    if wtype == "add_source_sample":
        wait["sample"] = "" if text.strip() == "-" else text.strip().lstrip("@")
        wait["type"] = "add_source_file"
        send_message(chat_id, "📎 حالا فایل سورس رو بفرست (فایل .py تکی یا .zip):", CANCEL_KB)
        return True

    if wtype == "add_source_file":
        doc = msg.get("document")
        if not doc:
            send_message(chat_id, "❌ باید یه فایل (.py یا .zip) به‌صورت داکیومنت بفرستی، نه متن.", CANCEL_KB)
            return True
        orig_name = doc.get("file_name", "file")
        ext = Path(orig_name).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            send_message(chat_id, f"❌ فقط فایل با پسوند {' یا '.join(ALLOWED_EXTENSIONS)} قبول می‌شه.", CANCEL_KB)
            return True
        dest_name = f"{int(time.time())}_{orig_name}"
        ok = download_incoming_document(doc, dest_name)
        if not ok:
            send_message(chat_id, "❌ دانلود فایل ناموفق بود، دوباره امتحان کن:", CANCEL_KB)
            return True
        add_source(wait["name"], wait["desc"], wait["price"], dest_name, wait.get("sample", ""))
        del waiting_for[key]
        send_message(chat_id, f"✅ سورس «{wait['name']}» با موفقیت اضافه شد.", kb_sources())
        return True

    if wtype == "update_price_id":
        if not text.isdigit() or not get_source(int(text)):
            send_message(chat_id, "❌ شماره سورس معتبر نیست:", CANCEL_KB)
            return True
        wait["source_id"] = int(text)
        wait["type"] = "update_price_value"
        send_message(chat_id, "💵 قیمت جدید رو بفرست:", CANCEL_KB)
        return True

    if wtype == "update_price_value":
        if not text.isdigit():
            send_message(chat_id, "❌ فقط عدد بفرست:", CANCEL_KB)
            return True
        update_source_price(wait["source_id"], int(text))
        del waiting_for[key]
        send_message(chat_id, "✅ قیمت به‌روزرسانی شد.", kb_sources())
        return True

    if wtype == "delete_source_id":
        del waiting_for[key]
        if not text.isdigit() or not get_source(int(text)):
            send_message(chat_id, "❌ شماره سورس معتبر نیست.", kb_sources())
            return True
        delete_source(int(text))
        send_message(chat_id, "✅ سورس حذف شد.", kb_sources())
        return True

    if wtype == "search_user_id":
        del waiting_for[key]
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر نیست.", kb_users())
            return True
        u = get_user(int(text))
        if not u:
            send_message(chat_id, "❌ کاربری با این آیدی پیدا نشد.", kb_users())
            return True
        info = (
            f"👤 اطلاعات کاربر {u[1]}\n\n"
            f"نام: {u[3] or '-'}\nیوزرنیم: @{u[2]}\n" if u[2] else f"👤 اطلاعات کاربر {u[1]}\n\nنام: {u[3] or '-'}\n"
        )
        info += f"💰 موجودی: {u[4]:,} تومان\n🚫 وضعیت: {'مسدود' if u[5] else 'آزاد'}\n🗓 عضویت: {(u[7] or '-')[:10]}"
        send_message(chat_id, info, kb_users())
        return True

    if wtype == "ban_toggle_id":
        del waiting_for[key]
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر نیست.", kb_users())
            return True
        new_status = ban_toggle(int(text))
        send_message(chat_id, f"✅ کاربر {text} الان {'مسدوده 🚫' if new_status else 'آزاده ✅'}.", kb_users())
        return True

    if wtype == "charge_user_id":
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر نیست:", CANCEL_KB)
            return True
        wait["target_id"] = int(text)
        wait["type"] = "charge_user_amount"
        send_message(chat_id, "💰 مبلغ رو بفرست (منفی برای کسر، مثلاً -2000):", CANCEL_KB)
        return True

    if wtype == "charge_user_amount":
        if not text.lstrip("-").isdigit():
            send_message(chat_id, "❌ فقط عدد بفرست:", CANCEL_KB)
            return True
        amount = int(text)
        target = wait["target_id"]
        del waiting_for[key]
        update_balance(target, amount)
        add_payment(target, amount, 'charge' if amount >= 0 else 'deduct')
        send_message(chat_id, f"✅ موجودی کاربر {target} به‌اندازه {amount:,} تغییر کرد.\nموجودی جدید: {get_balance(target):,}", kb_users())
        u = get_user(target)
        if amount >= 0:
            txt = get_setting('charge_single_text').replace('{first_name}', u[3] or 'کاربر').replace('{amount}', f"{amount:,}").replace('{balance}', f"{get_balance(target):,}")
        else:
            txt = f"⚠️ مبلغ {abs(amount):,} تومان از موجودی شما کسر شد.\n💰 موجودی: {get_balance(target):,}"
        try:
            send_message(target, txt)
        except Exception:
            pass
        return True

    if wtype == "bulk_amount":
        if not text.lstrip("-").isdigit():
            send_message(chat_id, "❌ فقط عدد بفرست:", CANCEL_KB)
            return True
        amount = int(text)
        del waiting_for[key]
        users = [u for u in get_all_users() if u[6] == 1]
        for u in users:
            update_balance(u[1], amount)
            add_payment(u[1], amount, 'charge' if amount >= 0 else 'deduct')
            tmpl = get_setting('charge_bulk_text') if amount >= 0 else get_setting('deduct_bulk_text')
            txt = tmpl.replace('{first_name}', u[3] or 'کاربر').replace('{amount}', f"{abs(amount):,}").replace('{balance}', f"{get_balance(u[1]):,}")
            try:
                send_message(u[1], txt)
                time.sleep(0.1)
            except Exception:
                pass
        send_message(chat_id, f"✅ عملیات روی {len(users)} کاربر انجام شد.", kb_admin_root())
        return True

    if wtype == "broadcast_text":
        del waiting_for[key]
        users = [u for u in get_all_users() if u[6] == 1]
        count = 0
        for u in users:
            try:
                send_message(u[1], text)
                count += 1
                time.sleep(0.1)
            except Exception:
                pass
        send_message(chat_id, f"✅ پیام به {count} کاربر ارسال شد.", kb_admin_root())
        return True

    if wtype == "send_user_id":
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر نیست:", CANCEL_KB)
            return True
        wait["target_id"] = int(text)
        wait["type"] = "send_user_text"
        send_message(chat_id, "✏️ متن پیام رو بفرست:", CANCEL_KB)
        return True

    if wtype == "send_user_text":
        target = wait["target_id"]
        del waiting_for[key]
        send_message(target, text)
        send_message(chat_id, f"✅ پیام به کاربر {target} ارسال شد.", kb_admin_root())
        return True

    if wtype == "set_setting_value":
        update_setting(wait["setting_key"], text)
        del waiting_for[key]
        send_message(chat_id, "✅ ذخیره شد.", kb_settings())
        return True

    return False


def handle_admin_menu(chat_id, text):
    """دکمه‌های سطح پنل ادمین رو پردازش می‌کنه (خارج از حالت‌های در انتظار)."""
    key = str(chat_id)

    if text == ADMIN_CMD:
        send_message(chat_id, "👑 پنل مدیریت فروشگاه", kb_admin_root())
        return True

    if text == "🔙 خروج از پنل":
        send_message(chat_id, "از پنل خارج شدی.")
        main_menu(chat_id)
        return True

    if text == "🔙 بازگشت به پنل":
        send_message(chat_id, "👑 پنل مدیریت فروشگاه", kb_admin_root())
        return True

    if text == "📊 داشبورد":
        s = get_stats()
        send_message(chat_id, f"📊 داشبورد\n\n👥 کاربران: {s['total_users']}\n📦 سورس‌ها: {s['total_sources']}\n🛒 خریدها: {s['total_purchases']}\n💰 شارژ کل: {s['total_charge']:,}\n💸 فروش کل: {s['total_buy']:,}", kb_admin_root())
        return True

    if text == "📦 مدیریت سورس‌ها":
        send_message(chat_id, "📦 مدیریت سورس‌ها", kb_sources())
        return True

    if text == "➕ افزودن سورس جدید":
        waiting_for[key] = {"type": "add_source_name"}
        send_message(chat_id, "📝 نام سورس رو بفرست:", CANCEL_KB)
        return True

    if text == "📋 لیست سورس‌ها":
        send_message(chat_id, sources_list_text(), kb_sources())
        return True

    if text == "✏️ تغییر قیمت سورس":
        waiting_for[key] = {"type": "update_price_id"}
        send_message(chat_id, "شماره سورس (#) رو بفرست:\n\n" + sources_list_text(), CANCEL_KB)
        return True

    if text == "🗑 حذف سورس":
        waiting_for[key] = {"type": "delete_source_id"}
        send_message(chat_id, "شماره سورس (#) که می‌خوای حذفش کنی رو بفرست:\n\n" + sources_list_text(), CANCEL_KB)
        return True

    if text == "👥 کاربران":
        send_message(chat_id, "👥 مدیریت کاربران", kb_users())
        return True

    if text == "🔍 جستجوی کاربر":
        waiting_for[key] = {"type": "search_user_id"}
        send_message(chat_id, "آیدی عددی کاربر رو بفرست:", CANCEL_KB)
        return True

    if text == "🚫 مسدود/رفع مسدود کاربر":
        waiting_for[key] = {"type": "ban_toggle_id"}
        send_message(chat_id, "آیدی عددی کاربر رو بفرست:", CANCEL_KB)
        return True

    if text == "💰 شارژ یا کسر یک کاربر":
        waiting_for[key] = {"type": "charge_user_id"}
        send_message(chat_id, "آیدی عددی کاربر رو بفرست:", CANCEL_KB)
        return True

    if text == "📋 لیست کاربران (۲۰ نفر آخر)":
        send_message(chat_id, users_list_text(), kb_users())
        return True

    if text == "🛒 آخرین خریدها":
        send_message(chat_id, purchases_list_text(), kb_admin_root())
        return True

    if text == "💰 شارژ/کسر همگانی":
        waiting_for[key] = {"type": "bulk_amount"}
        send_message(chat_id, "مبلغ رو بفرست (مثبت برای شارژ، منفی برای کسر همه‌ی کاربران):", CANCEL_KB)
        return True

    if text == "📨 پیام همگانی":
        waiting_for[key] = {"type": "broadcast_text"}
        send_message(chat_id, "متن پیام همگانی رو بفرست:", CANCEL_KB)
        return True

    if text == "✉️ پیام به کاربر":
        waiting_for[key] = {"type": "send_user_id"}
        send_message(chat_id, "آیدی عددی کاربر رو بفرست:", CANCEL_KB)
        return True

    if text == "📈 گزارش مالی":
        send_message(chat_id, financial_report(), kb_admin_root())
        return True

    if text == "⚙️ تنظیم متن‌ها":
        send_message(chat_id, "⚙️ کدوم متن رو می‌خوای تغییر بدی؟", kb_settings())
        return True

    if text in SETTING_KEY_MAP:
        skey = SETTING_KEY_MAP[text]
        waiting_for[key] = {"type": "set_setting_value", "setting_key": skey}
        send_message(chat_id, f"متن فعلی:\n\n{get_setting(skey)}\n\nمتن جدید رو بفرست:", CANCEL_KB)
        return True

    return False

# ===================================================================
# 📨 پردازش آپدیت‌ها
# ===================================================================
def process_update(update):
    update_id = update["update_id"]
    if update_id in processed_updates:
        return
    processed_updates.add(update_id)
    if len(processed_updates) > 2000:
        processed_updates.clear()

    if "message" in update:
        msg = update["message"]
        chat_id = msg["chat"]["id"]
        text = msg.get("text", "") or ""
        add_user(chat_id, msg["chat"].get("username", ""), msg["chat"].get("first_name", "کاربر"))
        u = get_user(chat_id)
        if u and u[5] == 1 and not is_admin(chat_id):
            send_message(chat_id, "⛔ مسدود شده‌اید.")
            return

        # پنل ادمین (فقط برای ADMIN_ID)
        if is_admin(chat_id):
            if handle_admin_flow(chat_id, text, msg):
                return
            if handle_admin_menu(chat_id, text):
                return

        if text == "/start":
            main_menu(chat_id)
            return

        # هر پیام دیگه از کاربر عادی -> منوی اصلی
        if not is_admin(chat_id):
            main_menu(chat_id)

    elif "callback_query" in update:
        cb = update["callback_query"]
        chat_id = cb["message"]["chat"]["id"]
        data = cb["data"]
        cb_id = cb["id"]

        if data == "wallet":
            send_message(chat_id, f"💰 کیف پول\n\n💳 موجودی: {get_balance(chat_id):,} تومان", {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": "back"}]]})
        elif data == "support":
            send_message(chat_id, get_setting('support_text'), {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": "back"}]]})
        elif data == "purchases":
            purchases = get_user_purchases(chat_id)
            if not purchases:
                send_message(chat_id, "📭 خریدی نداشتی!", {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": "back"}]]})
            else:
                txt = "📦 خریدهای تو:\n\n" + "\n".join([f"{i+1}. {p[0]} | {p[1]:,}T | {p[2][:10]}" for i, p in enumerate(purchases)])
                send_message(chat_id, txt, {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": "back"}]]})
        elif data == "shop":
            sources = get_sources()
            if not sources:
                send_message(chat_id, "📭 سورسی نیست!", {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": "back"}]]})
                answer_callback(cb_id)
                return
            kb = [[{"text": f"📦 {s[1]} - {'✅' if has_purchased(chat_id, s[0]) else f'{s[3]:,}T'}", "callback_data": f"detail_{s[0]}"}] for s in sources]
            kb.append([{"text": "🔙 بازگشت", "callback_data": "back"}])
            send_message(chat_id, "🛍️ سورس‌ها:\n👇 برای جزئیات کلیک کن", {"inline_keyboard": kb})
        elif data.startswith("detail_"):
            src = get_source(int(data.replace("detail_", "")))
            if not src:
                answer_callback(cb_id, "❌ یافت نشد!", True)
                return
            purchased = has_purchased(chat_id, src[0])
            sample = f"\n\n📱 نمونه: @{src[5]}" if src[5] else ""
            txt = f"📦 {src[1]}\n\n💰 قیمت: {src[3]:,} تومان\n\n📝 توضیحات:\n{src[2]}{sample}\n\n{'✅ قبلاً خریدی' if purchased else '❓ مایل به خرید هستی؟'}"
            kb = [[{"text": "📥 دانلود" if purchased else "✅ بله، خرید", "callback_data": f"{'download' if purchased else 'buy'}_{src[0]}"}, {"text": "🔙 بازگشت", "callback_data": "shop"}]]
            send_message(chat_id, txt, {"inline_keyboard": kb})
        elif data.startswith("buy_"):
            src = get_source(int(data.replace("buy_", "")))
            if not src or has_purchased(chat_id, src[0]):
                answer_callback(cb_id, "❌", True)
                return
            if get_balance(chat_id) < src[3]:
                send_message(chat_id, f"⚠️ موجودی کافی نیست!\n💰 موجودی: {get_balance(chat_id):,}\n💵 قیمت: {src[3]:,}\n🔻 کمبود: {src[3]-get_balance(chat_id):,}", {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": f"detail_{src[0]}"}]]})
                answer_callback(cb_id, "موجودی ناکافی!", True)
                return
            update_balance(chat_id, -src[3])
            add_purchase(chat_id, src[0])
            add_payment(chat_id, src[3], 'buy')
            send_message(chat_id, f"✅ خرید موفق!\n📦 {src[1]}\n💰 موجودی: {get_balance(chat_id):,}", {"inline_keyboard": [[{"text": "🔙 فروشگاه", "callback_data": "shop"}]]})
            if Path(SOURCES_DIR, src[4]).exists():
                send_file(chat_id, str(Path(SOURCES_DIR, src[4])))
        elif data.startswith("download_"):
            src = get_source(int(data.replace("download_", "")))
            if src and has_purchased(chat_id, src[0]) and Path(SOURCES_DIR, src[4]).exists():
                send_file(chat_id, str(Path(SOURCES_DIR, src[4])))
                answer_callback(cb_id, "📥 ارسال شد")
        elif data == "back":
            main_menu(chat_id)
        answer_callback(cb_id)

# ===================================================================
# 🚀 اجرا
# ===================================================================
if __name__ == "__main__":
    init_db()
    print("=" * 50)
    print("🛍️ فروشگاه سورس کد (پنل مدیریت داخل بله)")
    print(f"👑 ادمین: {ADMIN_ID}")
    print("=" * 50)
    print("🤖 ربات در حال اجرا (Polling)...")
    offset = None
    while True:
        try:
            for update in get_updates(offset):
                process_update(update)
                offset = update["update_id"] + 1
        except Exception as e:
            print(f"خطا: {e}")
            time.sleep(1)
