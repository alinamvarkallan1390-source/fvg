import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import time
import sqlite3
import requests

TOKEN = "{{BOT_TOKEN}}"
BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
ADMIN_ID = {{ADMIN_ID}}
ADMIN_CMD = "{{ADMIN_CMD}}"
DB_NAME = "font_bot.db"

LOWER = "abcdefghijklmnopqrstuvwxyz"
UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DIGITS = "0123456789"


def make_map(upper_start, lower_start, digit_start=None, exceptions=None):
    m = {}
    for i, ch in enumerate(UPPER):
        m[ch] = chr(upper_start + i)
    for i, ch in enumerate(LOWER):
        m[ch] = chr(lower_start + i)
    if digit_start is not None:
        for i, ch in enumerate(DIGITS):
            m[ch] = chr(digit_start + i)
    if exceptions:
        m.update(exceptions)
    return m


# ==================== نگاشت فونت‌ها (بلوک استاندارد یونیکد Mathematical Alphanumeric) ====================
SUPERSCRIPT_MAP = {
    'a': 'ᵃ', 'b': 'ᵇ', 'c': 'ᶜ', 'd': 'ᵈ', 'e': 'ᵉ', 'f': 'ᶠ', 'g': 'ᵍ', 'h': 'ʰ', 'i': 'ⁱ', 'j': 'ʲ',
    'k': 'ᵏ', 'l': 'ˡ', 'm': 'ᵐ', 'n': 'ⁿ', 'o': 'ᵒ', 'p': 'ᵖ', 'q': 'q', 'r': 'ʳ', 's': 'ˢ', 't': 'ᵗ',
    'u': 'ᵘ', 'v': 'ᵛ', 'w': 'ʷ', 'x': 'ˣ', 'y': 'ʸ', 'z': 'ᶻ',
    'A': 'ᴬ', 'B': 'ᴮ', 'C': 'ᶜ', 'D': 'ᴰ', 'E': 'ᴱ', 'F': 'ᶠ', 'G': 'ᴳ', 'H': 'ᴴ', 'I': 'ᴵ', 'J': 'ᴶ',
    'K': 'ᴷ', 'L': 'ᴸ', 'M': 'ᴹ', 'N': 'ᴺ', 'O': 'ᴼ', 'P': 'ᴾ', 'Q': 'Q', 'R': 'ᴿ', 'S': 'ˢ', 'T': 'ᵀ',
    'U': 'ᵁ', 'V': 'ⱽ', 'W': 'ᵂ', 'X': 'ˣ', 'Y': 'ʸ', 'Z': 'ᶻ',
    '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
    '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
}

SUBSCRIPT_MAP = {
    'a': 'ₐ', 'e': 'ₑ', 'h': 'ₕ', 'i': 'ᵢ', 'j': 'ⱼ', 'k': 'ₖ', 'l': 'ₗ', 'm': 'ₘ', 'n': 'ₙ',
    'o': 'ₒ', 'p': 'ₚ', 'r': 'ᵣ', 's': 'ₛ', 't': 'ₜ', 'u': 'ᵤ', 'v': 'ᵥ', 'x': 'ₓ',
    '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉',
    '+': '₊', '-': '₋', '=': '₌', '(': '₍', ')': '₎',
}

BOLD_MAP = make_map(0x1D400, 0x1D41A, 0x1D7CE)
ITALIC_MAP = make_map(0x1D434, 0x1D44E, exceptions={'h': 'ℎ'})
BOLD_ITALIC_MAP = make_map(0x1D468, 0x1D482)
DOUBLE_STRUCK_MAP = make_map(0x1D538, 0x1D552, 0x1D7D8, exceptions={
    'C': 'ℂ', 'H': 'ℍ', 'N': 'ℕ', 'P': 'ℙ', 'Q': 'ℚ', 'R': 'ℝ', 'Z': 'ℤ',
})
SCRIPT_MAP = make_map(0x1D49C, 0x1D4B6, exceptions={
    'B': 'ℬ', 'E': 'ℰ', 'F': 'ℱ', 'H': 'ℋ', 'I': 'ℐ', 'L': 'ℒ', 'M': 'ℳ', 'R': 'ℛ',
    'e': 'ℯ', 'g': 'ℊ', 'o': 'ℴ',
})
FULLWIDTH_MAP = make_map(0xFF21, 0xFF41, 0xFF10)
CIRCLED_MAP = make_map(0x24B6, 0x24D0, exceptions={'0': '⓪', **{str(i): chr(0x2460 + i - 1) for i in range(1, 10)}})
SMALLCAPS_MAP = {
    'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ',
    'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴘ', 'q': 'q', 'r': 'ʀ', 's': 's', 't': 'ᴛ',
    'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ',
}

FONT_STYLES = {
    "🔡 بالانویس": SUPERSCRIPT_MAP,
    "🔢 زیرنویس": SUBSCRIPT_MAP,
    "𝗕𝗼𝗹𝗱 (درشت)": BOLD_MAP,
    "𝘐𝘵𝘢𝘭𝘪𝘤 (کج)": ITALIC_MAP,
    "𝙄𝙩𝙖𝙡𝙞𝙘 𝘽𝙤𝙡𝙙": BOLD_ITALIC_MAP,
    "𝕯𝖔𝖚𝖇𝖑𝖊 𝕾𝖙𝖗𝖚𝖈𝖐": DOUBLE_STRUCK_MAP,
    "𝓢𝓬𝓻𝓲𝓹𝓽": SCRIPT_MAP,
    "Ｆｕｌｌｗｉｄｔｈ": FULLWIDTH_MAP,
    "Ⓒⓘⓡⓒⓛⓔⓓ": CIRCLED_MAP,
    "ꜱᴍᴀʟʟ ᴄᴀᴘꜱ": SMALLCAPS_MAP,
}


def convert(text, style_map):
    return ''.join(style_map.get(ch, ch) for ch in text)


# ==================== دیتابیس (تنظیمات ساده) ====================
def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('welcome_text', "
                 "'✨ به بات تبدیل فونت خوش اومدی!\\n\\nاول یه استایل رو از کیبورد انتخاب کن، بعد هر متنی بفرستی به همون فونت تبدیل می‌شه.')")
    conn.commit()
    conn.close()

def get_setting(key, default=""):
    r = db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r and r["value"] else default

def set_setting(key, value):
    conn = db()
    conn.execute("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    conn.commit()
    conn.close()


# ==================== API بله ====================
def api_request(method, data=None, max_retries=3):
    for attempt in range(max_retries):
        try:
            r = requests.post(BASE_URL + method, json=data, timeout=20) if data else requests.get(BASE_URL + method, timeout=20)
            return r.json()
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(2)
    return {"ok": False}

def send_message(chat_id, text, keyboard=None):
    data = {"chat_id": chat_id, "text": text}
    if keyboard:
        data["reply_markup"] = keyboard
    return api_request("sendMessage", data)


def is_admin(user_id):
    return int(user_id) == int(ADMIN_ID)

def styles_keyboard():
    rows, row = [], []
    for name in FONT_STYLES:
        row.append({"text": name})
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([{"text": "🔙 راهنما"}])
    return {"keyboard": rows, "resize_keyboard": True}


user_style = {}  # user_id(str) -> نام استایل انتخاب‌شده
waiting_for = {}
CANCEL_KB = {"keyboard": [[{"text": "❌ انصراف"}]], "resize_keyboard": True}


def handle_admin(chat_id, text):
    key = str(chat_id)
    if waiting_for.get(key) == "set_welcome":
        if text == "❌ انصراف":
            del waiting_for[key]
            send_message(chat_id, "لغو شد.", styles_keyboard())
            return True
        set_setting("welcome_text", text)
        del waiting_for[key]
        send_message(chat_id, "✅ پیام خوش‌آمد ذخیره شد.", styles_keyboard())
        return True

    if text == ADMIN_CMD:
        send_message(chat_id, "👑 پنل مدیریت بات فونت‌ساز", {"keyboard": [
            [{"text": "✏️ تنظیم پیام خوش‌آمد"}], [{"text": "🔙 بازگشت"}],
        ], "resize_keyboard": True})
        return True
    if text == "✏️ تنظیم پیام خوش‌آمد":
        waiting_for[key] = "set_welcome"
        send_message(chat_id, f"متن فعلی:\n\n{get_setting('welcome_text')}\n\nمتن جدید رو بفرست:", CANCEL_KB)
        return True
    if text == "🔙 بازگشت":
        send_message(chat_id, "برگشتی.", styles_keyboard())
        return True
    return False


def handle_message(msg):
    chat_id = msg["chat"]["id"]
    text = msg.get("text", "") or ""
    key = str(chat_id)

    if is_admin(chat_id) and handle_admin(chat_id, text):
        return

    if text == "/start":
        send_message(chat_id, get_setting("welcome_text"), styles_keyboard())
        if is_admin(chat_id):
            send_message(chat_id, f"👑 برای پنل مدیریت دستور {ADMIN_CMD} رو بفرست.")
        return

    if text == "🔙 راهنما":
        send_message(chat_id, get_setting("welcome_text"), styles_keyboard())
        return

    if text in FONT_STYLES:
        user_style[key] = text
        send_message(chat_id, f"✅ استایل «{text}» انتخاب شد.\nحالا هر متنی بفرستی، به این فونت تبدیل می‌شه:")
        return

    style_name = user_style.get(key)
    if style_name:
        result = convert(text, FONT_STYLES[style_name])
        send_message(chat_id, result)
        return

    send_message(chat_id, "اول یه استایل رو از کیبورد پایین انتخاب کن 👇", styles_keyboard())


def run():
    last_update_id = 0
    while True:
        try:
            updates = api_request("getUpdates", {"offset": last_update_id + 1, "timeout": 30})
            if updates.get("ok"):
                for update in updates.get("result", []):
                    last_update_id = update["update_id"]
                    try:
                        if "message" in update:
                            handle_message(update["message"])
                    except Exception as e:
                        print(f"⚠️ خطا: {e}")
            time.sleep(0.3)
        except KeyboardInterrupt:
            print("\n🛑 بات متوقف شد")
            break
        except Exception as e:
            print(f"⚠️ خطا: {e}")
            time.sleep(2)


if __name__ == "__main__":
    init_db()
    print("🚀 بات فونت‌ساز آماده شد")
    run()

# === GOD FIX: هندلر /admin عددی - فقط سازنده ===
# هر جا پیام "/admin" اومد:
# if text.strip() == "/admin":
#     if is_admin_numeric(user_id): send admin panel else deny
