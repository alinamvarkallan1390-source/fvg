import requests
import time
import os
import sys
import re
import json

# محافظت در برابر کرش روی ویندوز موقع پرینت فارسی/ایموجی وقتی خروجی به فایل ریدایرکت می‌شه
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# ==================== تنظیمات ====================
TOKEN = "{{BOT_TOKEN}}"
BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
ADMIN_ID = {{ADMIN_ID}}
ADMIN_CMD = "{{ADMIN_CMD}}"  # دستوری که پنل مدیریت رو باز می‌کنه (پیش‌فرض: /admin)

FILES_DEFAULTS = {
    "done.txt": "✅ پیام شما با موفقیت ارسال شد!",
    "start.txt": "به ربات پشتیبانی خوش آمدید 🌹",
    "member.txt": "",
    "banlist.txt": "",
}


def check_and_create_files():
    for fname, default in FILES_DEFAULTS.items():
        if not os.path.exists(fname):
            with open(fname, "w", encoding="utf-8") as f:
                f.write(default)


def read_text_file(fname):
    try:
        with open(fname, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""


def write_file(fname, content):
    with open(fname, "w", encoding="utf-8") as f:
        f.write(content)


def append_file(fname, content):
    with open(fname, "a", encoding="utf-8") as f:
        f.write(content)


def api_request(method, data=None, max_retries=3):
    for attempt in range(max_retries):
        try:
            url = BASE_URL + method
            if data:
                r = requests.post(url, json=data, timeout=20)
            else:
                r = requests.get(url, timeout=20)
            return r.json()
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(2)
    return {"ok": False}


def send_message(chat_id, text, keyboard=None):
    data = {"chat_id": chat_id, "text": text}
    if keyboard:
        data["reply_markup"] = keyboard
    return api_request("sendMessage", data)


def forward_message(to_chat, from_chat, message_id):
    return api_request(
        "forwardMessage",
        {"chat_id": to_chat, "from_chat_id": from_chat, "message_id": message_id},
    )


ADMIN_KEYBOARD = {
    "keyboard": [
        [{"text": "📊 آمار اعضا"}, {"text": "🚫 لیست بلاک"}],
        [{"text": "📨 ارسال همگانی"}, {"text": "🗑 پاک کردن بلاک لیست"}],
        [{"text": "📋 پروفایل کاربر"}, {"text": "📤 ارسال به کاربر"}],
        [{"text": "⚙️ تنظیمات"}, {"text": "🔙 خروج از پنل"}],
    ],
    "resize_keyboard": True,
}

USER_KEYBOARD = {
    "keyboard": [
        [{"text": "👤 پروفایل من"}],
        [{"text": "📤 ارسال پیام به پشتیبانی"}],
    ],
    "resize_keyboard": True,
}

CANCEL_KEYBOARD = {"keyboard": [[{"text": "❌ انصراف"}]], "resize_keyboard": True}

# حالت هر کاربر (per-user، نه فایل مشترک) - جلوگیری از قاطی‌شدن پیام کاربرهای مختلف
waiting_for = {}  # str(user_id) -> "sendtoadmin" | "getprofile" | "sendtouser" | "sendall"


def is_admin(user_id):
    return str(user_id) == str(ADMIN_ID)


def handle_update(update):
    if "message" not in update:
        return
    msg = update["message"]
    chat_id = msg["chat"]["id"]
    from_id = msg.get("from", {}).get("id", chat_id)
    text = msg.get("text", "") or ""
    msg_id = msg["message_id"]
    first_name = msg.get("from", {}).get("first_name", "ناشناس")
    last_name = msg.get("from", {}).get("last_name", "")
    username = msg.get("from", {}).get("username", "")

    key = str(from_id)
    done = read_text_file("done.txt")
    start_text = read_text_file("start.txt")
    banlist = read_text_file("banlist.txt")
    state = waiting_for.get(key)

    # ========== انصراف عمومی ==========
    if text == "❌ انصراف" and state:
        waiting_for.pop(key, None)
        send_message(chat_id, "لغو شد.", ADMIN_KEYBOARD if is_admin(from_id) else USER_KEYBOARD)
        return

    # ========== باز کردن پنل مدیریت با دستور اختصاصی ==========
    if text == ADMIN_CMD and is_admin(from_id):
        send_message(chat_id, "👑 پنل مدیریت پشتیبانی\n\nخوش آمدید! 🌹", ADMIN_KEYBOARD)
        return

    if text == "🔙 خروج از پنل" and is_admin(from_id):
        waiting_for.pop(key, None)
        send_message(chat_id, "از پنل خارج شدی.", USER_KEYBOARD)
        return

    # ========== START ==========
    if text == "/start":
        if is_admin(from_id):
            send_message(chat_id, f"👋 خوش اومدی ادمین!\n\nبرای ورود به پنل مدیریت دستور {ADMIN_CMD} رو بفرست.")
        else:
            members = read_text_file("member.txt")
            if f"{chat_id}|" not in members:
                full_name = first_name + (f" {last_name}" if last_name else "")
                member_info = f"{chat_id}|{full_name}|{username}|{time.strftime('%Y/%m/%d %H:%M')}\n"
                append_file("member.txt", member_info)
            send_message(chat_id, start_text, USER_KEYBOARD)
        return

    # ========== پروفایل کاربر ==========
    if text == "👤 پروفایل من":
        profile = "👤 پروفایل شما\n\n"
        profile += f"📛 نام: {first_name}"
        if last_name:
            profile += f" {last_name}"
        profile += "\n"
        profile += f"🆔 آیدی عددی: {from_id}\n"
        profile += f"📎 یوزرنیم: @{username}\n" if username else "📎 یوزرنیم: ندارد\n"
        profile += f"📅 تاریخ: {time.strftime('%Y/%m/%d')}\n"
        send_message(chat_id, profile)
        return

    # ========== ارسال پیام به پشتیبانی (شروع صریح) ==========
    if text == "📤 ارسال پیام به پشتیبانی":
        waiting_for[key] = "sendtoadmin"
        send_message(chat_id, "📝 پیام خود را بنویسید تا برای پشتیبانی ارسال شود.\n\nمتن، عکس، ویس، فیلم و... را ارسال کنید.", CANCEL_KEYBOARD)
        return

    # ========== ارسال پیام کاربر به ادمین (فقط وقتی صریحاً درخواست داده) ==========
    if state == "sendtoadmin" and not is_admin(from_id):
        waiting_for.pop(key, None)
        if str(from_id) in banlist:
            send_message(chat_id, "🚫 شما بلاک شده‌اید!", USER_KEYBOARD)
            return
        user_info = "📨 پیام جدید\n\n"
        user_info += f"👤 نام: {first_name}"
        if last_name:
            user_info += f" {last_name}"
        user_info += "\n"
        user_info += f"🆔 آیدی: {from_id}\n"
        if username:
            user_info += f"📎 یوزرنیم: @{username}\n"
        user_info += f"📅 {time.strftime('%Y/%m/%d %H:%M')}"

        forward_message(ADMIN_ID, chat_id, msg_id)
        send_message(ADMIN_ID, user_info)
        send_message(chat_id, done, USER_KEYBOARD)
        return

    # ========== منوی ادمین ==========
    if text == "📊 آمار اعضا" and is_admin(from_id):
        members = read_text_file("member.txt")
        member_list = [m for m in members.strip().split("\n") if m]
        count = len(member_list)

        out = "📊 آمار اعضا\n\n"
        out += f"👥 تعداد کل: {count} عضو\n\n"
        out += "📋 ۱۰ عضو آخر:\n\n"
        for m in member_list[-10:]:
            parts = m.split("|")
            if len(parts) >= 4:
                out += f"👤 {parts[1]}\n🆔 {parts[0]}\n"
                if parts[2]:
                    out += f"📎 @{parts[2]}\n"
                out += "➖➖➖➖➖➖\n"
        send_message(chat_id, out, ADMIN_KEYBOARD)
        return

    if text == "📋 پروفایل کاربر" and is_admin(from_id):
        waiting_for[key] = "getprofile"
        send_message(chat_id, "🆔 آیدی عددی کاربر را وارد کنید:", CANCEL_KEYBOARD)
        return

    if state == "getprofile" and is_admin(from_id):
        waiting_for.pop(key, None)
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر نبود.", ADMIN_KEYBOARD)
            return
        members = read_text_file("member.txt")
        found = False
        for m in members.split("\n"):
            parts = m.split("|")
            if len(parts) >= 4 and parts[0] == text:
                info = "📋 پروفایل کاربر\n\n"
                info += f"👤 نام: {parts[1]}\n"
                info += f"🆔 آیدی عددی: {parts[0]}\n"
                if parts[2]:
                    info += f"📎 یوزرنیم: @{parts[2]}\n"
                info += f"📅 تاریخ عضویت: {parts[3]}\n"
                info += "🚫 وضعیت: " + ("بلاک شده ❌" if text in banlist else "فعال ✅") + "\n"
                send_message(chat_id, info, ADMIN_KEYBOARD)
                found = True
                break
        if not found:
            send_message(chat_id, "❌ کاربر یافت نشد!", ADMIN_KEYBOARD)
        return

    if text == "📤 ارسال به کاربر" and is_admin(from_id):
        waiting_for[key] = "sendtouser"
        send_message(chat_id, "📝 فرمت: آیدی|پیام\nمثال: 123456789|سلام", CANCEL_KEYBOARD)
        return

    if state == "sendtouser" and is_admin(from_id):
        waiting_for.pop(key, None)
        if "|" not in text:
            send_message(chat_id, "❌ فرمت درست نبود.", ADMIN_KEYBOARD)
            return
        uid, message = text.split("|", 1)
        send_message(uid.strip(), f"📨 پیام مدیریت:\n\n{message.strip()}")
        send_message(chat_id, "✅ پیام ارسال شد", ADMIN_KEYBOARD)
        return

    if text == "📨 ارسال همگانی" and is_admin(from_id):
        waiting_for[key] = "sendall"
        send_message(chat_id, "📝 پیام همگانی را بنویسید:", CANCEL_KEYBOARD)
        return

    if state == "sendall" and is_admin(from_id):
        waiting_for.pop(key, None)
        members = [m for m in read_text_file("member.txt").strip().split("\n") if m]
        count = 0
        for m in members:
            uid = m.split("|")[0]
            send_message(uid, f"📨 پیام مدیریت:\n\n{text}")
            count += 1
            time.sleep(0.3)
        send_message(chat_id, f"✅ پیام به {count} نفر ارسال شد", ADMIN_KEYBOARD)
        return

    if text == "🚫 لیست بلاک" and is_admin(from_id):
        banned = [b for b in banlist.strip().split("\n") if b]
        if not banned:
            send_message(chat_id, "✅ هیچ کاربری بلاک نشده", ADMIN_KEYBOARD)
        else:
            out = "🚫 لیست بلاک:\n\n"
            for b in banned:
                out += f"• {b}\n"
            send_message(chat_id, out, ADMIN_KEYBOARD)
        return

    if text == "🗑 پاک کردن بلاک لیست" and is_admin(from_id):
        write_file("banlist.txt", "")
        send_message(chat_id, "✅ لیست بلاک پاک شد", ADMIN_KEYBOARD)
        return

    if text == "⚙️ تنظیمات" and is_admin(from_id):
        send_message(chat_id, "⚙️ تنظیمات\n\n/setstart [متن]\n/setdone [متن]\n/ban [آیدی]\n/unban [آیدی]\n/remove [آیدی]", ADMIN_KEYBOARD)
        return

    # ========== دستورات ادمین ==========
    if text.startswith("/setstart") and is_admin(from_id):
        val = text.replace("/setstart", "", 1).strip()
        if val:
            write_file("start.txt", val)
            send_message(chat_id, "✅ ذخیره شد", ADMIN_KEYBOARD)
        return

    if text.startswith("/setdone") and is_admin(from_id):
        val = text.replace("/setdone", "", 1).strip()
        if val:
            write_file("done.txt", val)
            send_message(chat_id, "✅ ذخیره شد", ADMIN_KEYBOARD)
        return

    if text.startswith("/ban") and is_admin(from_id):
        uid = text.replace("/ban", "", 1).strip()
        if uid.isdigit() and uid not in banlist:
            append_file("banlist.txt", uid + "\n")
            send_message(chat_id, f"✅ کاربر {uid} بلاک شد", ADMIN_KEYBOARD)
        return

    if text.startswith("/unban") and is_admin(from_id):
        uid = text.replace("/unban", "", 1).strip()
        if uid.isdigit():
            new_ban = banlist.replace(uid + "\n", "")
            write_file("banlist.txt", new_ban)
            send_message(chat_id, f"✅ کاربر {uid} آزاد شد", ADMIN_KEYBOARD)
        return

    if text.startswith("/remove") and is_admin(from_id):
        uid = text.replace("/remove", "", 1).strip()
        if uid.isdigit():
            members = read_text_file("member.txt")
            members = re.sub(re.escape(uid) + r"\|.*\n", "", members)
            write_file("member.txt", members)
            send_message(chat_id, "✅ حذف شد", ADMIN_KEYBOARD)
        return

    # ========== پیش‌فرض ==========
    # توجه: عمداً هیچ «فوروارد خودکارِ هر پیامی» اینجا وجود نداره. کاربر باید صریحاً از دکمه‌ی
    # «📤 ارسال پیام به پشتیبانی» استفاده کنه تا پیامش فوروارد بشه. این از قاطی‌شدن پیام‌های
    # کاربرهای مختلف و فوروارد ناخواسته‌ی پیام‌های ادمین جلوگیری می‌کنه.
    if is_admin(from_id):
        send_message(chat_id, f"دستور شناخته نشد. برای پنل مدیریت: {ADMIN_CMD}", ADMIN_KEYBOARD)
    else:
        send_message(chat_id, start_text, USER_KEYBOARD)


def run():
    last_update_id = 0
    while True:
        try:
            updates = api_request("getUpdates", {"offset": last_update_id + 1, "timeout": 20})
            if updates.get("ok"):
                for update in updates.get("result", []):
                    last_update_id = update["update_id"]
                    try:
                        handle_update(update)
                    except Exception as e:
                        print(f"⚠️ خطا در پردازش پیام: {e}")
            time.sleep(0.5)
        except KeyboardInterrupt:
            print("\n🛑 بات متوقف شد")
            break
        except Exception as e:
            print(f"⚠️ خطا: {e}")
            time.sleep(1)


if __name__ == "__main__":
    check_and_create_files()
    print("🚀 ربات پشتیبانی آماده شد")
    print(f"👑 دستور پنل مدیریت: {ADMIN_CMD}")
    print("=" * 40)
    run()
