import os, sys, json, time, sqlite3, requests
from datetime import datetime
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except: pass
TOKEN="{{BOT_TOKEN}}"
ADMIN_IDS=[{{ADMIN_ID}}]
BASE_URL=f"https://tapi.bale.ai/bot{TOKEN}/"
DB_FILE="member_adv.db"
def db():
    c=sqlite3.connect(DB_FILE); c.row_factory=sqlite3.Row; return c
def init_db():
    conn=db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (chat_id INTEGER PRIMARY KEY, balance INTEGER DEFAULT 0, invited INTEGER DEFAULT 0, created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, user_id INTEGER, channel TEXT, count INTEGER, status TEXT DEFAULT 'pending', price INTEGER)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS channels_pool (username TEXT PRIMARY KEY, members INTEGER DEFAULT 0)""")
    conn.commit(); conn.close()
init_db()
def api(m,d=None):
    import requests; r=requests.post(BASE_URL+m, json=d or {}, timeout=20); return r.json()
def send(c,t,k=None):
    d={"chat_id":c,"text":t}
    if k: d["reply_markup"]=k
    return api("sendMessage", d)
USER_KB={"keyboard":[[{"text":"➕ سفارش ممبر"},{"text":"📋 سفارشات من"}],[{"text":"💰 کسب درآمد"},{"text":"💸 برداشت"}],[{"text":"📊 تعرفه"},{"text":"🎁 هدیه روزانه"}],[{"text":"👥 لینک دعوت"}]]}
ADMIN_KB={"keyboard":[[{"text":"📋 سفارشات جدید"},{"text":"✅ تایید عضویت"}],[{"text":"💵 قیمت ممبر"},{"text":"📊 آمار"}],[{"text":"📢 همگانی"}]]}
def handle(uid,text,chat_id):
    if text=="➕ سفارش ممبر":
        send(chat_id, "آیدی کانال + تعداد را بفرست: @channel 100")
    elif text=="💰 کسب درآمد":
        send(chat_id, "لینک: LINK\nهر عضویت = 150 تومان\nدعوت: COUNT نفر")
    elif text=="📊 تعرفه":
        send(chat_id, "100 ممبر = 15k\n500 ممبر = 60k\n1000 ممبر = 110k")
    else:
        send(chat_id, "سفارش ممبر پیشرفته\nموجودی: BALANCE ت", USER_KB)
print("member adv ready")

# === GOD FIX: هندلر /admin عددی - فقط سازنده ===
# هر جا پیام "/admin" اومد:
# if text.strip() == "/admin":
#     if is_admin_numeric(user_id): send admin panel else deny
