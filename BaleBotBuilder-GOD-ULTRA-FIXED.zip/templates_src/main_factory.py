# ===================================================================
# 🤖 بات‌ساز خودکار بله  |  Bale Bot Factory
# ===================================================================

import os
import sys

# محافظت در برابر کرش روی ویندوز موقع پرینت فارسی/ایموجی وقتی خروجی به فایل ریدایرکت می‌شه
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import re
import json
import time
from zoneinfo import ZoneInfo
import random
import sqlite3
import shutil
import signal
import zipfile
import tempfile
import requests
import subprocess
import importlib.util
from pathlib import Path
from datetime import datetime, timedelta

# ===================================================================
# ⚙️ تنظیمات
# ===================================================================
TOKEN = "445736867:pClzYlOec6VAsy_pIGK8WDS-QyjGZk58ji0"       # توکن همین بات (بات‌ساز)
ADMIN_ID = 1059647848                               # آیدی عددی خودت (ادمین اصلی)
PROVIDER_TOKEN = ""                           # توکن پرداخت واقعی بله رو اینجا بذار (برای فعال شدن «شارژ کیف پول»)

# اختیاری: اگه بات‌ساز رو با webhook می‌خوای بالا بیاری (نیاز به دامنه‌ی HTTPS و ریورس‌پروکسی داره)
# اگه خالی بمونه، بات‌ساز به‌صورت Polling (پیش‌فرض، بدون تنظیم اضافه) اجرا می‌شه.
FACTORY_WEBHOOK_URL = ""     # مثلاً: "https://mydomain.com/factory-hook"
FACTORY_WEBHOOK_PORT = 0     # مثلاً: 8080 (همون پورتی که نگینکس بهش پروکسی می‌کنه)

BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
DB_NAME = "factory.db"
TEHRAN_TZ = ZoneInfo("Asia/Tehran")
BOTS_DIR = "bots"
TEMPLATES_DIR = "templates_src"
BASE_PORT = 6000  # شروع محدوده پورت برای پنل وب بات‌های نوع «shop»
BOT_USERNAME = ""  # با getMe در ابتدای اجرا پر می‌شه (برای لینک زیرمجموعه‌گیری)

# نوع بات‌های قابل ساخت
# kind: python_single (یک فایل main.py) | python_package (پوشه‌ی چندفایلی) | php_single (یک فایل php)
BOT_TYPES = {
    "game": {
        "name": "⚔️ بات بازی جنگ ماتریکس",
        "kind": "python_single",
        "template": "game_bot_template.py",
        "desc": "بازی مدیریت کشور، جنگ، اقتصاد و اتحاد بین کاربران.",
    },
    "shop": {
        "name": "🛍️ بات فروشگاه سورس",
        "kind": "python_single",
        "template": "shop_bot_template.py",
        "desc": "فروش فایل/سورس با کیف پول داخلی و پنل مدیریت وب.",
    },
    "chat": {
        "name": "💬 بات چت ناشناس",
        "kind": "python_package",
        "template": "chat_bot_template",
        "requirements_file": "requirements.txt",
        "check_imports": ["httpx", "aiosqlite", "dotenv"],
        "desc": "چت تصادفی/ناشناس، پروفایل، سکه، افراد نزدیک و پنل ادمین.",
    },
    "support": {
        "name": "🎧 بات پشتیبانی",
        "kind": "python_single",
        "template": "support_bot_template.py",
        "desc": "ارسال پیام کاربر به ادمین، پروفایل کاربر و پنل مدیریت ساده.",
    },
    "earn": {
        "name": "💎 بات کسب درآمد",
        "kind": "python_single",
        "template": "earn_bot_template.py",
        "desc": "کسب درآمد از دعوت زیرمجموعه، برداشت وجه، جوین اجباری و پنل مدیریت کامل.",
    },
    "liro": {
        "name": "🛡️ بات مدیریت گروه",
        "kind": "python_single",
        "template": "liro_bot_template.py",
        "desc": "مدیریت گروه: فیلتر فحش، پاسخ خودکار، سکوت/اخراج، بازی و پنل ادمین گروه.",
    },
    "custom": {
        "name": "🧩 بات سفارشی (دکمه‌ساز)",
        "kind": "python_single",
        "template": "custom_bot_template.py",
        "desc": "بات خالی که خودت از پنلش دکمه و پاسخ دلخواه اضافه/ویرایش/حذف می‌کنی.",
    },
    "lottery": {
        "name": "🎰 بات قرعه‌کشی",
        "kind": "python_single",
        "template": "lottery_bot_template.py",
        "desc": "قرعه‌کشی روزانه با شانس، دعوت دوستان، برندگان قبلی و پنل مدیریت کامل.",
    },
    "font": {
        "name": "🔤 بات فونت‌ساز",
        "kind": "python_single",
        "template": "font_bot_template.py",
        "desc": "تبدیل متن به فونت‌های فانتزی یونیکد (بالانویس، بولد، ایتالیک، دبل‌استراک و ...).",
    },
    "member": {
        "name": "🇮🇷 بات ایران عضو (عضو بگیر)",
        "kind": "python_single",
        "template": "member_bot_template.py",
        "desc": "سفارش ممبر، کسب درآمد از عضویت، کیف پول، برداشت، زیرمجموعه، گزارش کانال و پنل مدیریت.",
    },
}

# ===================================================================
# 🗄️ دیتابیس
# ===================================================================
def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def _safe_add_column(conn, table, col_def):
    try:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {col_def}")
    except sqlite3.OperationalError:
        pass  # ستون از قبل وجود داره

def init_db():
    conn = db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT DEFAULT '',
        first_name TEXT DEFAULT '',
        balance INTEGER DEFAULT 0,
        is_banned INTEGER DEFAULT 0,
        referred_by INTEGER,
        invited_count INTEGER DEFAULT 0,
        created_at TEXT DEFAULT '')""")
    _safe_add_column(conn, "users", "referred_by INTEGER")
    _safe_add_column(conn, "users", "invited_count INTEGER DEFAULT 0")
    _safe_add_column(conn, "users", "free_bot_credits INTEGER DEFAULT 0")
    _safe_add_column(conn, "users", "active_discount_code TEXT DEFAULT ''")
    _safe_add_column(conn, "users", "active_discount_type TEXT DEFAULT ''")
    _safe_add_column(conn, "users", "active_discount_value INTEGER DEFAULT 0")
    conn.execute("""CREATE TABLE IF NOT EXISTS lottery_periods (
        id INTEGER PRIMARY KEY AUTOINCREMENT, start_at TEXT UNIQUE, end_at TEXT,
        result_at TEXT, drawn INTEGER DEFAULT 0, winner_id INTEGER,
        winner_username TEXT DEFAULT "", created_at TEXT DEFAULT "")""")
    conn.execute("""CREATE TABLE IF NOT EXISTS lottery_entries (
        period_id INTEGER, user_id INTEGER, joined_at TEXT DEFAULT "",
        PRIMARY KEY (period_id,user_id))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS prices (
        bot_type TEXT PRIMARY KEY,
        price INTEGER DEFAULT 0)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS created_bots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        bot_type TEXT,
        folder TEXT,
        pid INTEGER,
        status TEXT DEFAULT 'running',
        token TEXT DEFAULT '',
        sub_admin_id INTEGER,
        admin_cmd TEXT DEFAULT '/admin',
        run_mode TEXT DEFAULT 'polling',
        webhook_url TEXT DEFAULT '',
        webhook_port INTEGER,
        created_at TEXT DEFAULT '')""")
    _safe_add_column(conn, "created_bots", "token TEXT DEFAULT ''")
    _safe_add_column(conn, "created_bots", "sub_admin_id INTEGER")
    _safe_add_column(conn, "created_bots", "admin_cmd TEXT DEFAULT '/admin'")
    _safe_add_column(conn, "created_bots", "run_mode TEXT DEFAULT 'polling'")
    _safe_add_column(conn, "created_bots", "webhook_url TEXT DEFAULT ''")
    _safe_add_column(conn, "created_bots", "webhook_port INTEGER")
    _safe_add_column(conn, "created_bots", "expires_at TEXT DEFAULT ''")
    _safe_add_column(conn, "created_bots", "last_reminder_at TEXT DEFAULT ''")
    _safe_add_column(conn, "created_bots", "renewal_status TEXT DEFAULT 'active'")

    # ⏳ تنظیمات دوره و قیمت تمدید، به‌ازای هر نوع بات (period_days=0 یعنی این نوع بات نیاز به تمدید نداره)
    conn.execute("""CREATE TABLE IF NOT EXISTS renewal_settings (
        bot_type TEXT PRIMARY KEY,
        period_days INTEGER DEFAULT 0,
        price INTEGER DEFAULT 0)""")
    for key in BOT_TYPES:
        conn.execute("INSERT OR IGNORE INTO renewal_settings (bot_type, period_days, price) VALUES (?, 0, 0)", (key,))

    # 🎟 کدهای تخفیف
    conn.execute("""CREATE TABLE IF NOT EXISTS discount_codes (
        code TEXT PRIMARY KEY,
        type TEXT DEFAULT 'percent',
        value INTEGER DEFAULT 0,
        max_uses INTEGER DEFAULT 0,
        used_count INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT '')""")

    conn.execute("""CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS admins (
        user_id INTEGER PRIMARY KEY,
        role TEXT DEFAULT 'support',
        added_by INTEGER,
        added_at TEXT DEFAULT '')""")

    conn.execute("""CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount INTEGER,
        type TEXT DEFAULT 'wallet_charge',
        track_code TEXT DEFAULT '',
        created_at TEXT DEFAULT '')""")

    # فاکتورهای پرداخت آنلاین (شارژ کیف پول، انتقال مالکیت و ...)
    # payload = شناسه‌ی یکتای فاکتور که هم به بله فرستاده می‌شه هم داخل successful_payment برمی‌گرده
    conn.execute("""CREATE TABLE IF NOT EXISTS invoices (
        payload TEXT PRIMARY KEY,
        user_id INTEGER,
        amount INTEGER,
        purpose TEXT DEFAULT 'wallet_charge',
        meta TEXT DEFAULT '{}',
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT '',
        paid_at TEXT DEFAULT '')""")

    # 🏦 درخواست‌های پرداخت دستی (کارت‌به‌کارت)
    conn.execute("""CREATE TABLE IF NOT EXISTS manual_payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount INTEGER,
        purpose TEXT DEFAULT 'wallet_charge',
        meta TEXT DEFAULT '{}',
        note TEXT DEFAULT '',
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT '',
        decided_at TEXT DEFAULT '')""")

    for key in BOT_TYPES:
        conn.execute("INSERT OR IGNORE INTO prices (bot_type, price) VALUES (?, 0)", (key,))

    defaults = {
        "payment_mode": "auto",
        "manual_payment_info": "",
        "support_text": "🎧 پشتیبانی\n\nبرای هرگونه سوال یا مشکل به آیدی زیر پیام بدید:\n\n@Fhoenix_Programmer"
        "",
        "welcome_text": DEFAULT_WELCOME_TEXT,
        "required_channel_id": "",
        "required_channel_link": "",
        "help_text": (
            "📖 راهنمای ساخت بات\n\n"
            "۱. یک بات جدید توی بله بساز و توکنش رو از پیام‌رسان بله بگیر.\n"
            "۲. روی «🤖 ساخت بات» بزن و نوع بات مورد نظرت رو انتخاب کن.\n"
            "۳. توکن بات جدیدت رو برام بفرست.\n"
            "۴. آیدی عددی خودت (یا هرکسی که قراره ادمین بات جدید باشه) رو بفرست.\n"
            "۵. اگه موجودیت کافی باشه، بات جدیدت همون لحظه بالا میاد و واقعاً کار می‌کنه!\n\n"
            "🔁 هر وقت خواستی، از «🗂 بات‌های من» می‌تونی مالکیت هر بات رو به یه آیدی عددی دیگه منتقل کنی.\n\n"
            "برای شارژ موجودی به پشتیبانی پیام بده."
        ),
        "referral_reward": "1000",
        "transfer_price": "0",
        "purchase_channel_id": "",
        "renewal_reminder_days": "1",
        "max_total_bots": "0",
        "max_bots_per_user": "0",
        "backup_interval_hours": "24",
        "lottery_broadcast_text": (
            "🎉 برنده قرعه‌کشی روزانه مشخص شد!\n\n"
            "🏆 برنده این دوره:\n👤 {winner}\n\n"
            "تبریک ویژه به برنده عزیز! 🎁\n\n"
            "🎁 جایزه شما:\nیک امتیاز ساخت ربات رایگان\n\n"
            "با این امتیاز می‌توانید یک ربات را بدون پرداخت هزینه بسازید.\n\n"
            "🍀 برای همه شما آرزوی موفقیت داریم!"
        ),
        "lottery_winner_dm_text": (
            "🎊 تبریک! شما برنده قرعه‌کشی روزانه شدید! 🎁\n\n"
            "جایزه شما یک امتیاز ساخت ربات رایگان است.\n\n"
            "✅ امتیاز شما به حساب‌تان اضافه شد.\n"
            "🤖 اکنون می‌توانید یک ربات را بدون پرداخت هزینه بسازید.\n\n"
            "🍀 مبارکتان باشد!"
        ),
        "lottery_other_text": (
            "😔 قرعه‌کشی امروز به پایان رسید و این‌بار شانس با شما نبود.\n\n"
            "🏆 برنده این دوره: {winner}\n\n"
            "نگران نباش، فردا دوباره شرکت کن و شانست رو امتحان کن! 🍀"
        ),
    }
    for k, v in defaults.items():
        conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

    conn.commit()
    conn.close()

def get_setting(key, default=""):
    r = db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r and r["value"] not in (None, "") else default

def set_setting(key, value):
    conn = db()
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    conn.commit()
    conn.close()

# ===================================================================
# 🛡 چند-ادمینی (نقش‌بندی دسترسی)
# ===================================================================
def get_admin_role(user_id):
    """نقش ادمینِ این کاربر رو برمی‌گردونه: 'full' (دسترسی کامل)، 'support' (فقط پشتیبانی)، یا None."""
    if str(user_id) == str(ADMIN_ID):
        return "full"
    r = db().execute("SELECT role FROM admins WHERE user_id=?", (user_id,)).fetchone()
    return r["role"] if r else None

def is_full_admin(user_id):
    return get_admin_role(user_id) == "full"

def is_any_admin(user_id):
    return get_admin_role(user_id) is not None

def add_admin(user_id, role, added_by):
    conn = db()
    conn.execute(
        "INSERT INTO admins (user_id, role, added_by, added_at) VALUES (?,?,?,?) "
        "ON CONFLICT(user_id) DO UPDATE SET role=excluded.role, added_by=excluded.added_by, added_at=excluded.added_at",
        (user_id, role, added_by, datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()

def remove_admin(user_id):
    conn = db()
    cur = conn.execute("DELETE FROM admins WHERE user_id=?", (user_id,))
    conn.commit()
    removed = cur.rowcount > 0
    conn.close()
    return removed

def list_admins():
    return db().execute("SELECT * FROM admins ORDER BY added_at DESC").fetchall()

def admin_home_kb(user_id):
    """کیبورد مناسب پنل مدیریت رو بر اساس نقش کاربر برمی‌گردونه."""
    return kb_admin() if is_full_admin(user_id) else kb_admin_support()

def ensure_user(user_id, username="", first_name="", referred_by=None):
    """کاربر رو می‌سازه اگه نبود. True برمی‌گردونه اگه کاربر تازه ساخته شده باشه."""
    conn = db()
    row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO users (user_id, username, first_name, referred_by, created_at) VALUES (?,?,?,?,?)",
            (user_id, username or "", first_name or "", referred_by, datetime.now().isoformat()),
        )
        conn.commit()
        conn.close()
        return True
    else:
        conn.execute("UPDATE users SET username=?, first_name=? WHERE user_id=?", (username or row["username"], first_name or row["first_name"], user_id))
        conn.commit()
        conn.close()
        return False

def get_user(user_id):
    return db().execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()

def get_all_user_ids():
    return [r["user_id"] for r in db().execute("SELECT user_id FROM users").fetchall()]

def get_balance(user_id):
    u = get_user(user_id)
    return u["balance"] if u else 0

def add_balance(user_id, amount):
    ensure_user(user_id)
    conn = db()
    conn.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()

def sub_balance(user_id, amount):
    conn = db()
    conn.execute("UPDATE users SET balance = balance - ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()

def increment_invited_count(user_id):
    conn = db()
    conn.execute("UPDATE users SET invited_count = invited_count + 1 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

# ---------- 🚫 بلاک/آنبلاک کاربر ----------
def is_user_banned(user_id):
    u = get_user(user_id)
    return bool(u and u["is_banned"])

def ban_user(user_id):
    ensure_user(user_id)
    conn = db()
    conn.execute("UPDATE users SET is_banned=1 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def unban_user(user_id):
    conn = db()
    conn.execute("UPDATE users SET is_banned=0 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

# ---------- 🎟 کد تخفیف ----------
def create_discount_code(code, dtype, value, max_uses=0):
    conn = db()
    conn.execute(
        "INSERT OR REPLACE INTO discount_codes (code,type,value,max_uses,used_count,active,created_at) "
        "VALUES (?,?,?,?, COALESCE((SELECT used_count FROM discount_codes WHERE code=?),0), 1, ?)",
        (code, dtype, value, max_uses, code, datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()

def get_discount_code(code):
    return db().execute("SELECT * FROM discount_codes WHERE code=?", (code,)).fetchone()

def list_discount_codes():
    return db().execute("SELECT * FROM discount_codes ORDER BY created_at DESC").fetchall()

def deactivate_discount_code(code):
    conn = db()
    conn.execute("UPDATE discount_codes SET active=0 WHERE code=?", (code,))
    conn.commit()
    conn.close()

def redeem_discount_code(user_id, code):
    code = (code or "").strip().upper()
    row = get_discount_code(code)
    if not row or not row["active"]:
        return False, "❌ کد تخفیف نامعتبر یا غیرفعاله."
    if row["max_uses"] and row["used_count"] >= row["max_uses"]:
        return False, "❌ ظرفیت این کد تخفیف تموم شده."
    conn = db()
    conn.execute(
        "UPDATE users SET active_discount_code=?, active_discount_type=?, active_discount_value=? WHERE user_id=?",
        (code, row["type"], row["value"], user_id),
    )
    conn.commit()
    conn.close()
    return True, row

def get_discounted_price(user_id, price):
    """خروجی: (قیمت نهایی، کد اعمال‌شده یا None)"""
    u = get_user(user_id)
    if u and u["active_discount_code"] and price > 0:
        code, dtype, value = u["active_discount_code"], u["active_discount_type"], u["active_discount_value"]
        d = int(price * value / 100) if dtype == "percent" else int(value)
        d = max(0, min(d, price))
        return price - d, code
    return price, None

def consume_active_discount(user_id):
    u = get_user(user_id)
    code = u["active_discount_code"] if u else ""
    if code:
        conn = db()
        conn.execute("UPDATE discount_codes SET used_count = used_count + 1 WHERE code=?", (code,))
        conn.execute("UPDATE users SET active_discount_code='', active_discount_type='', active_discount_value=0 WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()

def get_price(bot_type):
    r = db().execute("SELECT price FROM prices WHERE bot_type=?", (bot_type,)).fetchone()
    return r["price"] if r else 0

def set_price(bot_type, price):
    conn = db()
    conn.execute("UPDATE prices SET price=? WHERE bot_type=?", (price, bot_type))
    conn.commit()
    conn.close()

# ---------- ⏳ تنظیمات دوره/قیمت تمدید بات‌ها ----------
def get_renewal_settings(bot_type):
    """خروجی: (period_days, price). period_days=0 یعنی این نوع بات نیازی به تمدید نداره (نامحدود)."""
    r = db().execute("SELECT period_days, price FROM renewal_settings WHERE bot_type=?", (bot_type,)).fetchone()
    if not r:
        return 0, 0
    return int(r["period_days"] or 0), int(r["price"] or 0)

def set_renewal_period(bot_type, days):
    conn = db()
    conn.execute("UPDATE renewal_settings SET period_days=? WHERE bot_type=?", (days, bot_type))
    conn.commit()
    conn.close()

def set_renewal_price(bot_type, price):
    conn = db()
    conn.execute("UPDATE renewal_settings SET price=? WHERE bot_type=?", (price, bot_type))
    conn.commit()
    conn.close()

def save_created_bot(user_id, bot_type, folder, pid, token="", sub_admin_id=None, admin_cmd="/admin",
                      run_mode="polling", webhook_url="", webhook_port=None):
    conn = db()
    cur = conn.execute(
        "INSERT INTO created_bots (user_id, bot_type, folder, pid, status, token, sub_admin_id, admin_cmd, "
        "run_mode, webhook_url, webhook_port, created_at) VALUES (?,?,?,?, 'running', ?,?,?,?,?,?,?)",
        (user_id, bot_type, folder, pid, token, sub_admin_id, admin_cmd, run_mode, webhook_url, webhook_port, datetime.now().isoformat()),
    )
    conn.commit()
    bot_id = cur.lastrowid
    conn.close()
    return bot_id

def get_user_bots(user_id):
    return db().execute("SELECT * FROM created_bots WHERE user_id=? ORDER BY id DESC", (user_id,)).fetchall()

def get_all_bots():
    return db().execute("SELECT * FROM created_bots ORDER BY id DESC").fetchall()

def total_bots_count():
    return db().execute("SELECT COUNT(*) c FROM created_bots").fetchone()["c"]

def user_bots_count(user_id):
    return db().execute("SELECT COUNT(*) c FROM created_bots WHERE user_id=?", (user_id,)).fetchone()["c"]

def check_creation_capacity(user_id):
    """چک می‌کنه ساخت بات جدید مجازه یا نه. خروجی: (ok: bool, پیام‌خطا یا None)"""
    max_total = int(get_setting("max_total_bots", "0") or "0")
    if max_total > 0 and total_bots_count() >= max_total:
        return False, (
            "🚫 ظرفیت بات‌ساز برای ساخت بات جدید فعلاً تکمیله.\n\n"
            f"تعداد بات‌های ساخته‌شده: {total_bots_count()}/{max_total}\n\n"
            f"می‌تونی از بخش «{BTN_REFERRAL}» زیرمجموعه‌گیری کنی و امتیاز رایگان جمع کنی؛ "
            "هر وقت ظرفیت باز شد، خبرت می‌کنیم و می‌تونی بات بسازی."
        )
    max_per_user = int(get_setting("max_bots_per_user", "0") or "0")
    if max_per_user > 0 and user_bots_count(user_id) >= max_per_user:
        return False, f"🚫 شما به سقف مجاز ساخت بات ({max_per_user} بات) رسیدی."
    return True, None

def get_bot_by_id(bot_id):
    return db().execute("SELECT * FROM created_bots WHERE id=?", (bot_id,)).fetchone()

def set_bot_status(bot_id, status):
    conn = db()
    conn.execute("UPDATE created_bots SET status=? WHERE id=?", (status, bot_id))
    conn.commit()
    conn.close()

def next_free_webhook_port():
    count = db().execute("SELECT COUNT(*) c FROM created_bots WHERE run_mode='webhook'").fetchone()["c"]
    return BASE_PORT + count + 1

# ===================================================================
# 🌐 توابع API بله
# ===================================================================
def api_request(method, data=None, max_retries=3):
    for attempt in range(max_retries):
        try:
            url = BASE_URL + method
            if data:
                r = requests.post(url, json=data, timeout=20)
            else:
                r = requests.get(url, timeout=20)
            return r.json()
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(2)
    return {"ok": False}

PAYMENTS_LOG_FILE = "payments.txt"

PAYMENT_TYPE_FA = {
    "wallet_charge": "شارژ کیف پول",
    "bot_purchase": "خرید ساخت بات",
    "ownership_transfer": "انتقال مالکیت بات",
    "bot_renewal": "تمدید بات",
}

def log_payment(user_id, amount, ptype, track_code=""):
    conn = db()
    conn.execute(
        "INSERT INTO payments (user_id, amount, type, track_code, created_at) VALUES (?,?,?,?,?)",
        (user_id, amount, ptype, track_code, datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()
    try:
        with open(PAYMENTS_LOG_FILE, "a", encoding="utf-8") as f:
            label = PAYMENT_TYPE_FA.get(ptype, ptype)
            f.write(f"{datetime.now().isoformat()} | کاربر {user_id} | {amount:,} تومان | {label} | کد: {track_code}\n")
    except Exception:
        pass

def _income_between(start_iso):
    rows = db().execute(
        "SELECT type, SUM(amount) s, COUNT(*) c FROM payments WHERE created_at>=? AND amount>0 GROUP BY type",
        (start_iso,),
    ).fetchall()
    total = sum(r["s"] or 0 for r in rows)
    return total, rows

def admin_dashboard_text():
    """داشبورد آماری کامل‌تر: درآمد روزانه/هفتگی/ماهانه + پرفروش‌ترین نوع بات‌ها + نرخ رشد کاربرا."""
    now = datetime.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    week_start = (now - timedelta(days=7)).isoformat()
    month_start = (now - timedelta(days=30)).isoformat()

    today_total, _ = _income_between(today_start)
    week_total, _ = _income_between(week_start)
    month_total, _ = _income_between(month_start)

    conn = db()
    top_rows = conn.execute(
        "SELECT bot_type, COUNT(*) c FROM created_bots GROUP BY bot_type ORDER BY c DESC LIMIT 5"
    ).fetchall()
    users_today = conn.execute("SELECT COUNT(*) c FROM users WHERE created_at>=?", (today_start,)).fetchone()["c"]
    users_week = conn.execute("SELECT COUNT(*) c FROM users WHERE created_at>=?", (week_start,)).fetchone()["c"]
    users_month = conn.execute("SELECT COUNT(*) c FROM users WHERE created_at>=?", (month_start,)).fetchone()["c"]
    users_total = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    active_bots = conn.execute("SELECT COUNT(*) c FROM created_bots WHERE status='running'").fetchone()["c"]
    conn.close()

    lines = ["📊 داشبورد آماری بات‌ساز\n", "💰 درآمد:"]
    lines.append(f"  📅 امروز: {today_total:,} تومان")
    lines.append(f"  🗓 ۷ روز اخیر: {week_total:,} تومان")
    lines.append(f"  🗓 ۳۰ روز اخیر: {month_total:,} تومان")
    lines.append("")
    lines.append("🏆 پرفروش‌ترین نوع بات‌ها:")
    if top_rows:
        medals = ["🥇", "🥈", "🥉"]
        for i, r in enumerate(top_rows):
            info = BOT_TYPES.get(r["bot_type"], {"name": r["bot_type"]})
            medal = medals[i] if i < 3 else f"{i + 1}."
            lines.append(f"  {medal} {info['name']} — {r['c']} بات")
    else:
        lines.append("  هنوز باتی ساخته نشده.")
    lines.append("")
    lines.append("👥 رشد کاربران:")
    lines.append(f"  کاربر جدید امروز: {users_today}")
    lines.append(f"  کاربر جدید ۷ روز اخیر: {users_week}")
    lines.append(f"  کاربر جدید ۳۰ روز اخیر: {users_month}")
    lines.append(f"  مجموع کاربران: {users_total}")
    lines.append("")
    lines.append(f"🤖 بات‌های فعال الان: {active_bots} از مجموع {total_bots_count()} بات ساخته‌شده")
    return "\n".join(lines)

def income_report_text():
    now = datetime.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    week_start = (now - timedelta(days=7)).isoformat()
    month_start = (now - timedelta(days=30)).isoformat()

    def block(title, start_iso):
        total, rows = _income_between(start_iso)
        lines = [f"{title}: {total:,} تومان"]
        for r in rows:
            label = PAYMENT_TYPE_FA.get(r["type"], r["type"])
            lines.append(f"  • {label}: {r['s']:,} تومان ({r['c']} تراکنش)")
        return "\n".join(lines)

    all_total = db().execute("SELECT SUM(amount) s FROM payments WHERE amount>0").fetchone()["s"] or 0
    return (
        "📊 گزارش درآمد بات‌ساز\n\n"
        f"{block('📅 امروز', today_start)}\n\n"
        f"{block('🗓 ۷ روز اخیر', week_start)}\n\n"
        f"{block('🗓 ۳۰ روز اخیر', month_start)}\n\n"
        f"💰 مجموع کل تاریخچه: {all_total:,} تومان\n"
        f"🤖 تعداد کل بات‌های ساخته‌شده: {total_bots_count()}"
    )

def notify_purchase_channel(text):
    """گزارش هر خرید/تراکنش رو (اگه ادمین کانالی تنظیم کرده باشه) به همون کانال می‌فرسته."""
    chan = get_setting("purchase_channel_id", "")
    if not chan:
        return
    try:
        chan_id = int(chan)
    except (TypeError, ValueError):
        return
    try:
        send_message(chan_id, text)
    except Exception:
        pass

# ---------- فاکتورهای پرداخت آنلاین ----------
def save_invoice(payload, user_id, amount, purpose, meta=None):
    conn = db()
    conn.execute(
        "INSERT OR REPLACE INTO invoices (payload, user_id, amount, purpose, meta, status, created_at) "
        "VALUES (?,?,?,?,?, 'pending', ?)",
        (payload, user_id, amount, purpose, json.dumps(meta or {}, ensure_ascii=False), datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()

def get_invoice(payload):
    return db().execute("SELECT * FROM invoices WHERE payload=?", (payload,)).fetchone()

def mark_invoice_paid(payload):
    conn = db()
    conn.execute("UPDATE invoices SET status='paid', paid_at=? WHERE payload=?", (datetime.now().isoformat(), payload))
    conn.commit()
    conn.close()

# ---------- 🏦 پرداخت دستی (کارت‌به‌کارت) ----------
def create_manual_payment_request(user_id, amount, purpose, meta=None, note=""):
    conn = db()
    conn.execute(
        "INSERT INTO manual_payments (user_id, amount, purpose, meta, note, status, created_at) "
        "VALUES (?,?,?,?,?, 'pending', ?)",
        (user_id, amount, purpose, json.dumps(meta or {}, ensure_ascii=False), note, datetime.now().isoformat()),
    )
    conn.commit()
    req_id = conn.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    conn.close()
    return req_id

def get_manual_payment(req_id):
    return db().execute("SELECT * FROM manual_payments WHERE id=?", (req_id,)).fetchone()

def list_pending_manual_payments():
    return db().execute("SELECT * FROM manual_payments WHERE status='pending' ORDER BY id").fetchall()

def set_manual_payment_status(req_id, status):
    conn = db()
    conn.execute("UPDATE manual_payments SET status=?, decided_at=? WHERE id=?", (status, datetime.now().isoformat(), req_id))
    conn.commit()
    conn.close()

def complete_purchase(user_id, amount, purpose, meta, track_code=""):
    """بعد از تاییدِ پرداخت (چه خودکار چه دستی)، اصل عملیات خرید رو انجام می‌ده.
    خروجی: (ok: bool, پیام برای نمایش به کاربر)"""
    if purpose == "wallet_charge":
        add_balance(user_id, amount)
        log_payment(user_id, amount, "wallet_charge", track_code)
        notify_purchase_channel(
            f"💳 شارژ کیف پول (دستی)\n\n👤 کاربر: {user_id}\n💰 مبلغ: {amount:,} تومان\n🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )
        return True, f"✅ کیف پولت {amount:,} تومان شارژ شد.\n💰 موجودی جدید: {get_balance(user_id):,} تومان"

    if purpose == "bot_renewal":
        bot_id = meta.get("bot_id")
        row = get_bot_by_id(bot_id) if bot_id else None
        if not row or row["user_id"] != user_id:
            return False, "بات موردنظر پیدا نشد یا متعلق به شما نیست."
        ok, warn = extend_bot_expiry(bot_id)
        if not ok:
            return False, warn
        if meta.get("discount_code"):
            consume_active_discount(user_id)
        log_payment(user_id, amount, "bot_renewal", f"bot_{bot_id}_manual")
        info = BOT_TYPES.get(row["bot_type"], {"name": row["bot_type"]})
        notify_purchase_channel(
            f"🔄 تمدید بات (دستی)\n\n🤖 بات: #{bot_id} - {info['name']}\n👤 کاربر: {user_id}\n💵 مبلغ: {amount:,} تومان\n🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )
        row2 = get_bot_by_id(bot_id)
        return True, f"✅ بات #{bot_id} ({info['name']}) تمدید شد!\n{format_expiry_line(row2)}" + (f"\n\n{warn}" if warn else "")

    if purpose == "ownership_transfer":
        bot_id = meta.get("bot_id")
        new_owner_id = meta.get("new_owner_id")
        row = get_bot_by_id(bot_id) if bot_id else None
        if not row or row["user_id"] != user_id or not new_owner_id:
            return False, "بات موردنظر پیدا نشد یا متعلق به شما نیست."
        ok, err = transfer_bot_ownership(bot_id, new_owner_id)
        finish_transfer_notify(user_id, new_owner_id, bot_id, row["bot_type"], row["admin_cmd"], ok, err, paid_amount=amount)
        return ok, ("✅ انتقال با موفقیت انجام شد." if ok else f"❌ انتقال ناموفق بود: {err}")

    return False, "نوع تراکنش نامشخصه."

def send_invoice_or_manual(user_id, title, amount, purpose, meta=None, extra_desc="", forced_mode=None):
    """بر اساس تنظیم «حالت پرداخت» ادمین (یا forced_mode اگه داده بشه)، فاکتور آنلاین یا درخواست پرداخت دستی می‌سازه.
    خروجی: (ok: bool, پیام برای کاربر)"""
    mode = forced_mode or get_setting("payment_mode", "auto")
    meta = meta or {}

    def try_manual():
        info_text = get_setting("manual_payment_info", "")
        if not info_text:
            return False, "روش پرداخت دستی هنوز توسط ادمین تنظیم نشده. به پشتیبانی پیام بده."
        req_id = create_manual_payment_request(user_id, amount, purpose, meta)
        try:
            send_message(
                ADMIN_ID,
                f"🏦 درخواست پرداخت دستی جدید #{req_id}\n\n"
                f"👤 کاربر: {user_id}\n💵 مبلغ: {amount:,} تومان\n🧾 نوع: {PAYMENT_TYPE_FA.get(purpose, purpose)}\n\n"
                f"برای تایید عدد «{req_id}» رو بفرست، برای رد «رد {req_id}» رو بفرست.",
            )
        except Exception:
            pass
        return True, (
            f"🏦 برای پرداخت {amount:,} تومان به شماره/کارت زیر واریز کن:\n\n{info_text}\n\n"
            f"بعد از واریز، رسید یا کد پیگیری رو برای پشتیبانی بفرست تا تایید بشه (کد درخواست: #{req_id})."
        )

    def try_auto():
        payload = f"{purpose}_{user_id}_{int(time.time())}"
        save_invoice(payload, user_id, amount, purpose, meta)
        ok, err = send_invoice_checked(user_id, title, extra_desc or title, payload, amount)
        if ok:
            return True, f"🧾 فاکتور پرداخت {amount:,} تومان ارسال شد. بعد از پرداخت، به‌صورت خودکار انجام می‌شه."
        return False, err

    if mode == "manual":
        return try_manual()
    if mode == "auto":
        ok, msg = try_auto()
        if not ok:
            return False, f"❌ ارسال فاکتور ناموفق بود: {msg}"
        return True, msg
    # both -> اول خودکار رو امتحان کن، اگه درگاه تنظیم نبود برو سراغ دستی
    ok, msg = try_auto()
    if ok:
        return True, msg
    return try_manual()

MIN_ONLINE_INVOICE_TOMAN = 1000  # حداقل مبلغی که درگاه پرداخت آنلاین بله قبول می‌کنه (خط زیر رو ببین)

def parse_thousand_toman(text):
    """همه‌جای ربات، مبلغ‌ها رو به «هزار تومان» می‌گیریم تا وارد کردنشون راحت‌تر باشه:
    وقتی ادمین/کاربر عدد 40 رو می‌فرسته، یعنی 40 هزار تومان (= 40000 تومان).
    می‌تونه منفی هم باشه (برای کسر از موجودی)."""
    return int(text) * 1000

def send_invoice(chat_id, title, description, payload, amount_toman):
    """فاکتور پرداخت آنلاین بله رو می‌فرسته (پرداخت خودکار).
    مبلغ ورودی تومانه؛ چون واحد داخلی API ریاله، ضربدر ۱۰ می‌شه.
    عنوان و توضیحات طبق محدودیت درگاه بله کوتاه می‌شن تا فاکتور رد نشه."""
    safe_title = (title or "پرداخت")[:32]
    safe_desc = (description or "")[:255]
    data = {
        "chat_id": chat_id,
        "title": safe_title,
        "description": safe_desc,
        "payload": payload,
        "provider_token": PROVIDER_TOKEN,
        "currency": "IRR",
        "prices": [{"label": safe_title, "amount": amount_toman * 10}],
    }
    return api_request("sendInvoice", data)

def send_invoice_checked(chat_id, title, description, payload, amount_toman):
    """مثل send_invoice ولی نتیجه رو چک می‌کنه؛ (ok, error_text) برمی‌گردونه."""
    if not PROVIDER_TOKEN:
        return False, "درگاه پرداخت آنلاین هنوز توسط ادمین تنظیم نشده."
    if amount_toman < MIN_ONLINE_INVOICE_TOMAN:
        return False, f"حداقل مبلغ قابل پرداخت از درگاه آنلاین {MIN_ONLINE_INVOICE_TOMAN:,} تومانه."
    r = send_invoice(chat_id, title, description, payload, amount_toman)
    if not r or not r.get("ok"):
        err = (r or {}).get("description") or "خطای نامشخص از درگاه پرداخت"
        return False, err
    return True, None

def answer_pre_checkout_query(query_id, ok=True, error_message=None):
    data = {"pre_checkout_query_id": query_id, "ok": ok}
    if error_message:
        data["error_message"] = error_message
    return api_request("answerPreCheckoutQuery", data)

def handle_pre_checkout(pcq):
    """قبل از تایید نهایی پرداخت، فاکتور رو با چیزی که خودمون ثبت کردیم مطابقت می‌ده
    تا از تایید فاکتورهای جعلی/دستکاری‌شده یا پرداخت تکراری جلوگیری بشه."""
    payload = pcq.get("invoice_payload", "")
    total_amount = pcq.get("total_amount", 0)
    inv = get_invoice(payload)
    if inv is None:
        # فاکتور ناشناخته (مثلاً قدیمی) - محتاطانه رد می‌کنیم
        answer_pre_checkout_query(pcq["id"], ok=False, error_message="این فاکتور معتبر نیست، دوباره تلاش کن.")
        return
    if inv["status"] == "paid":
        answer_pre_checkout_query(pcq["id"], ok=False, error_message="این فاکتور قبلاً پرداخت شده.")
        return
    if int(inv["amount"]) * 10 != int(total_amount):
        answer_pre_checkout_query(pcq["id"], ok=False, error_message="مبلغ فاکتور نامعتبره.")
        return
    answer_pre_checkout_query(pcq["id"], ok=True)

def send_message(chat_id, text, keyboard=None):
    data = {"chat_id": chat_id, "text": text}
    if keyboard:
        data["reply_markup"] = keyboard
    return api_request("sendMessage", data)

def send_document(chat_id, file_path, caption=None, max_retries=2):
    for attempt in range(max_retries):
        try:
            url = BASE_URL + "sendDocument"
            with open(file_path, "rb") as f:
                files = {"document": (os.path.basename(file_path), f)}
                data = {"chat_id": chat_id}
                if caption:
                    data["caption"] = caption
                r = requests.post(url, data=data, files=files, timeout=120)
            return r.json()
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(2)
    return {"ok": False}

def fetch_bot_username():
    global BOT_USERNAME
    r = api_request("getMe")
    if r.get("ok"):
        BOT_USERNAME = r["result"].get("username", "")

def validate_token(token):
    """با getMe چک می‌کنه توکن معتبره یا نه، و یوزرنیم بات رو برمی‌گردونه"""
    try:
        r = requests.get(f"https://tapi.bale.ai/bot{token}/getMe", timeout=15)
        data = r.json()
        if data.get("ok"):
            return True, data["result"].get("username", "")
        return False, None
    except Exception:
        return False, None

# ===================================================================
# 🚀 راه‌اندازی واقعی بات ساخته‌شده
# ===================================================================
def ensure_requirements_installed(check_imports, req_file_path):
    """اگه پکیج‌های لازم برای بات پکیجی (مثل چت ناشناس) نصب نباشن، خودکار نصبشون می‌کنه."""
    missing = [m for m in check_imports if importlib.util.find_spec(m) is None]
    if not missing:
        return True, None
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", req_file_path],
            capture_output=True, text=True, timeout=240,
        )
        if result.returncode != 0:
            return False, f"نصب پکیج‌های موردنیاز ناموفق بود:\n{result.stderr[-600:]}"
        still_missing = [m for m in check_imports if importlib.util.find_spec(m) is None]
        if still_missing:
            return False, f"بعد از نصب هم پکیج‌های {still_missing} پیدا نشدن."
        return True, None
    except Exception as e:
        return False, f"خطا در نصب پکیج‌ها: {e}"

def launch_bot(user_id, bot_type, token, admin_id, admin_cmd="/admin", run_mode="polling", webhook_url=""):
    info = BOT_TYPES[bot_type]
    kind = info["kind"]

    stamp = int(time.time())
    folder = os.path.join(BOTS_DIR, f"{bot_type}_{user_id}_{stamp}")

    webhook_port = next_free_webhook_port() if run_mode == "webhook" else None

    child_env = os.environ.copy()
    child_env["PYTHONIOENCODING"] = "utf-8"
    child_env["PYTHONUTF8"] = "1"
    if run_mode == "webhook" and webhook_url:
        child_env["WEBHOOK_URL"] = webhook_url
        child_env["WEBHOOK_PORT"] = str(webhook_port)

    cmd = None
    setup_error = None

    if kind == "python_single":
        os.makedirs(folder, exist_ok=True)
        template_path = os.path.join(TEMPLATES_DIR, info["template"])
        with open(template_path, "r", encoding="utf-8") as f:
            content = f.read()
        content = content.replace("{{BOT_TOKEN}}", token).replace("{{ADMIN_ID}}", str(admin_id))
        content = content.replace("{{ADMIN_CMD}}", admin_cmd)

        with open(os.path.join(folder, "main.py"), "w", encoding="utf-8") as f:
            f.write(content)
        cmd = [sys.executable, "-X", "utf8", "main.py"]

    elif kind == "python_package":
        src_dir = os.path.join(TEMPLATES_DIR, info["template"])
        shutil.copytree(
            src_dir, folder,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".env", "*.db"),
        )
        req_file = os.path.join(folder, info.get("requirements_file", "requirements.txt"))
        if os.path.exists(req_file) and info.get("check_imports"):
            ok, err = ensure_requirements_installed(info["check_imports"], req_file)
            if not ok:
                setup_error = err
        child_env["BOT_TOKEN"] = token
        child_env["ADMIN_IDS"] = str(admin_id)
        child_env["ADMIN_CMD"] = admin_cmd
        cmd = [sys.executable, "-X", "utf8", "main.py"]

    elif kind == "php_single":
        os.makedirs(folder, exist_ok=True)
        php_exe = shutil.which("php")
        template_path = os.path.join(TEMPLATES_DIR, info["template"])
        with open(template_path, "r", encoding="utf-8") as f:
            content = f.read()
        content = content.replace("{{BOT_TOKEN}}", token).replace("{{ADMIN_ID}}", str(admin_id))
        content = content.replace("{{ADMIN_CMD}}", admin_cmd)
        with open(os.path.join(folder, "main.php"), "w", encoding="utf-8") as f:
            f.write(content)
        if not php_exe:
            setup_error = "PHP روی این سیستم نصب نیست یا به PATH اضافه نشده."
        else:
            cmd = [php_exe, "main.php"]

    else:
        setup_error = f"نوع بات ناشناخته: {kind}"

    if not setup_error:
        owner = get_user(user_id)
        info_data = {
            "note": "این فایل فقط برای اطلاعات و پیگیریه؛ خودِ بات به این فایل نیازی نداره و ازش استفاده نمی‌کنه.",
            "owner_user_id": user_id,
            "owner_username": owner["username"] if owner else "",
            "owner_first_name": owner["first_name"] if owner else "",
            "bot_type": bot_type,
            "bot_type_name": info["name"],
            "bot_token": token,
            "bot_admin_id": admin_id,
            "admin_panel_command": admin_cmd,
            "run_mode": run_mode,
            "created_at": datetime.now().isoformat(),
        }
        try:
            with open(os.path.join(folder, "bot_info.json"), "w", encoding="utf-8") as f:
                json.dump(info_data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    if setup_error or not cmd:
        bot_id = save_created_bot(user_id, bot_type, folder, 0, token=token, sub_admin_id=admin_id, admin_cmd=admin_cmd, run_mode=run_mode, webhook_url=webhook_url, webhook_port=webhook_port)
        set_bot_status(bot_id, "crashed")
        return bot_id, False, (setup_error or "خطای نامشخص در آماده‌سازی بات")

    log_path = os.path.join(folder, "run.log")
    log_file = open(log_path, "a", encoding="utf-8")

    owner = get_user(user_id)
    owner_info = {
        "note": "این فایل فقط برای مرجع خود بات‌سازه؛ داخل کد بات استفاده نمی‌شه.",
        "owner_user_id": user_id,
        "owner_username": owner["username"] if owner else "",
        "owner_first_name": owner["first_name"] if owner else "",
        "bot_type": bot_type,
        "bot_type_name": info["name"],
        "bot_token": token,
        "sub_admin_id": admin_id,
        "admin_panel_command": admin_cmd,
        "run_mode": run_mode,
        "created_at": datetime.now().isoformat(),
    }
    try:
        with open(os.path.join(folder, "owner_info.json"), "w", encoding="utf-8") as f:
            json.dump(owner_info, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    popen_kwargs = dict(
        cwd=folder, stdout=log_file, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=child_env,
    )
    if os.name == "posix":
        popen_kwargs["start_new_session"] = True
    else:
        popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)

    process = subprocess.Popen(cmd, **popen_kwargs)

    time.sleep(3)
    running = process.poll() is None
    log_file.flush()

    log_tail = ""
    try:
        with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
            log_tail = f.read()[-800:]
    except Exception:
        pass

    bot_id = save_created_bot(user_id, bot_type, folder, process.pid, token=token, sub_admin_id=admin_id, admin_cmd=admin_cmd, run_mode=run_mode, webhook_url=webhook_url, webhook_port=webhook_port)
    if not running:
        set_bot_status(bot_id, "crashed")
    return bot_id, running, log_tail

def is_pid_alive(pid):
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError, PermissionError):
        return False
    except Exception:
        return False

def refresh_bot_status(bot_id):
    row = get_bot_by_id(bot_id)
    if row and row["status"] == "running" and not is_pid_alive(row["pid"]):
        set_bot_status(bot_id, "crashed")
        row = get_bot_by_id(bot_id)
    return row

def get_log_tail(folder, n_chars=1000):
    log_path = os.path.join(folder, "run.log")
    try:
        with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
            data = f.read()
        return data[-n_chars:] if data else "(لاگ خالیه)"
    except FileNotFoundError:
        return "(فایل لاگ پیدا نشد)"
    except Exception as e:
        return f"(خطا در خوندن لاگ: {e})"

def stop_bot(bot_id):
    row = get_bot_by_id(bot_id)
    if not row or row["status"] != "running":
        return False
    try:
        os.kill(row["pid"], signal.SIGTERM)
    except Exception:
        pass
    set_bot_status(bot_id, "stopped")
    return True

# ===================================================================
# ⏳ تمدید بات‌ها
# ===================================================================
def set_bot_expiry(bot_id, expires_at, renewal_status="active", reset_reminder=True):
    conn = db()
    if reset_reminder:
        conn.execute(
            "UPDATE created_bots SET expires_at=?, renewal_status=?, last_reminder_at='' WHERE id=?",
            (expires_at, renewal_status, bot_id),
        )
    else:
        conn.execute(
            "UPDATE created_bots SET expires_at=?, renewal_status=? WHERE id=?",
            (expires_at, renewal_status, bot_id),
        )
    conn.commit()
    conn.close()

def backfill_bot_type_expiry(bot_type, days):
    """وقتی ادمین برای یه نوع بات دوره‌ی تمدید تنظیم/تغییر می‌ده، بات‌هایی از همون نوع که
    قبلاً (چون هنوز تمدید براشون فعال نشده بود) 'نامحدود' نشون داده می‌شدن رو هم وارد
    چرخه‌ی تمدید می‌کنه: از همین الان یه سررسید تازه (days روز بعد) می‌گیرن.
    فقط رو بات‌هایی اثر می‌ذاره که فعلاً expires_at خالیه، تا سررسید بات‌هایی که از قبل
    توی چرخه‌ی تمدید بودن به‌هم نریزه. خروجی: لیست ردیف‌های آپدیت‌شده (برای اطلاع‌رسانی)."""
    if not days or days <= 0:
        return []
    conn = db()
    rows = conn.execute(
        "SELECT * FROM created_bots WHERE bot_type=? AND (expires_at IS NULL OR expires_at='')",
        (bot_type,),
    ).fetchall()
    conn.close()
    if not rows:
        return []
    new_expiry = (datetime.now() + timedelta(days=int(days))).isoformat()
    for row in rows:
        set_bot_expiry(row["id"], new_expiry, renewal_status="active", reset_reminder=True)
    return rows

def clear_bot_type_expiry(bot_type):
    """وقتی ادمین تمدید یه نوع بات رو کامل غیرفعال می‌کنه (نامحدود)، سررسید بات‌های
    فعلاً‌فعالِ همون نوع هم پاک می‌شه تا دیگه خودکار خاموش نشن. خروجی: لیست ردیف‌های آپدیت‌شده."""
    conn = db()
    rows = conn.execute(
        "SELECT * FROM created_bots WHERE bot_type=? AND expires_at != '' AND renewal_status='active'",
        (bot_type,),
    ).fetchall()
    conn.close()
    for row in rows:
        set_bot_expiry(row["id"], "", renewal_status="active", reset_reminder=True)
    return rows

def extend_bot_expiry(bot_id, days=None):
    """بات رو "days" روز تمدید می‌کنه (اگه از تاریخ انقضای فعلی هنوز چیزی مونده بود، تمدید بهش اضافه می‌شه نه اینکه بپره روش).
    اگه بات به‌خاطر تموم‌شدن تمدید خاموش شده بود، خودکار دوباره روشنش می‌کنه.
    خروجی: (ok: bool, warning_or_none)"""
    row = get_bot_by_id(bot_id)
    if not row:
        return False, "بات پیدا نشد."
    if days is None:
        days, _ = get_renewal_settings(row["bot_type"])
    if not days or days <= 0:
        return False, "این نوع بات نیازی به تمدید نداره یا دوره‌ی تمدیدش هنوز توسط ادمین تنظیم نشده."

    now = datetime.now()
    base = now
    if row["expires_at"]:
        try:
            cur_exp = datetime.fromisoformat(row["expires_at"])
            if cur_exp > now:
                base = cur_exp
        except Exception:
            pass
    new_expiry = base + timedelta(days=int(days))
    set_bot_expiry(bot_id, new_expiry.isoformat(), renewal_status="active", reset_reminder=True)

    row = get_bot_by_id(bot_id)
    if row["status"] != "running" or not is_pid_alive(row["pid"]):
        ok, err = restart_existing_bot_process(bot_id)
        if not ok:
            return True, f"⚠️ تمدید با موفقیت ثبت شد ولی روشن‌کردن دوباره‌ی بات ناموفق بود: {err}\nبا پشتیبانی هماهنگ کن."
    return True, None

def format_expiry_line(row):
    """یک خط توضیحیِ وضعیت تمدید یک بات رو برمی‌گردونه (برای نمایش توی «بات‌های من» و لیست ادمین)."""
    if not row["expires_at"]:
        return "⏳ تمدید: نامحدود"
    try:
        exp = datetime.fromisoformat(row["expires_at"])
    except Exception:
        return "⏳ تمدید: نامشخص"
    if row["renewal_status"] == "expired" or exp <= datetime.now():
        return f"⛔ منقضی‌شده (تاریخ سررسید: {exp.strftime('%Y/%m/%d')})"
    days_left = (exp - datetime.now()).days
    return f"⏳ تمدید تا: {exp.strftime('%Y/%m/%d')} ({days_left} روز مونده)"

# ===================================================================
# 🔁 انتقال مالکیت بات
# ===================================================================
def _replace_admin_id_in_file(file_path, old_admin_id, new_admin_id):
    """داخل فایل تولیدشده‌ی بات (main.py/main.php) خط تعریف ADMIN_ID/ADMIN_IDS رو پیدا
    و آیدی قدیمی رو با آیدی جدید عوض می‌کنه، تا مالک قبلی کاملاً از ادمینی خارج بشه."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        return False, f"فایل بات پیدا/خونده نشد: {e}"

    old_id_str = str(old_admin_id)
    new_id_str = str(new_admin_id)
    pattern = re.compile(r'(ADMIN_IDS?\s*=\s*(?:\[)?"?)' + re.escape(old_id_str) + r'("?\]?)')
    new_content, n = pattern.subn(lambda m: m.group(1) + new_id_str + m.group(2), content, count=1)

    if n == 0:
        # حالت اضطراری: اگه با الگوی بالا پیدا نشد، اولین وقوع دقیق همون عدد رو عوض کن
        if old_id_str in content:
            new_content = content.replace(old_id_str, new_id_str, 1)
        else:
            return False, "خط تعریف ادمین توی فایل بات پیدا نشد."

    try:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(new_content)
    except Exception as e:
        return False, f"نوشتن فایل بات ناموفق بود: {e}"
    return True, None

def transfer_bot_ownership(bot_id, new_owner_id):
    """مالکیت یک بات ساخته‌شده رو کامل به یه کاربر دیگه منتقل می‌کنه:
    - بات (اگه روشنه) متوقف می‌شه
    - آیدی ادمینِ داخل خودِ بات (فایل یا env) عوض می‌شه تا مالک قبلی کاملاً حذف بشه
    - بات دوباره بالا میاد
    - ردیف بات توی دیتابیس بات‌ساز به مالک جدید منتقل می‌شه (از «بات‌های من» قبلی حذف و به جدید اضافه می‌شه)
    خروجی: (ok: bool, error_or_none)"""
    row = get_bot_by_id(bot_id)
    if not row:
        return False, "بات پیدا نشد."

    info = BOT_TYPES.get(row["bot_type"], {})
    kind = info.get("kind")
    folder = row["folder"]
    old_admin_id = row["sub_admin_id"] or row["user_id"]

    # ۱. اگه روشنه، متوقفش کن
    if row["status"] == "running" and is_pid_alive(row["pid"]):
        try:
            os.kill(row["pid"], signal.SIGTERM)
            time.sleep(1)
        except Exception:
            pass

    # ۲. برای بات‌های تک‌فایلی (پایتون/PHP) آیدی ادمین رو مستقیم داخل فایل عوض کن
    if kind in ("python_single", "php_single"):
        fname = "main.py" if kind == "python_single" else "main.php"
        ok, err = _replace_admin_id_in_file(os.path.join(folder, fname), old_admin_id, new_owner_id)
        if not ok:
            return False, err

    # ۳. دوباره اجراش کن (بدون بازسازی پوشه، تا داده‌های قبلی بات از بین نره)
    child_env = os.environ.copy()
    child_env["PYTHONIOENCODING"] = "utf-8"
    child_env["PYTHONUTF8"] = "1"
    if kind == "python_package":
        child_env["BOT_TOKEN"] = row["token"]
        child_env["ADMIN_IDS"] = str(new_owner_id)
        child_env["ADMIN_CMD"] = row["admin_cmd"] or "/admin"
    run_mode = row["run_mode"] if "run_mode" in row.keys() else "polling"
    if run_mode == "webhook" and row["webhook_url"]:
        child_env["WEBHOOK_URL"] = row["webhook_url"]
        child_env["WEBHOOK_PORT"] = str(row["webhook_port"])

    if kind == "php_single":
        php_exe = shutil.which("php")
        if not php_exe:
            return False, "PHP روی سرور پیدا نشد."
        cmd = [php_exe, "main.php"]
    else:
        cmd = [sys.executable, "-X", "utf8", "main.py"]

    log_path = os.path.join(folder, "run.log")
    try:
        log_file = open(log_path, "a", encoding="utf-8")
    except Exception as e:
        return False, f"فایل لاگ باز نشد: {e}"

    popen_kwargs = dict(cwd=folder, stdout=log_file, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=child_env)
    if os.name == "posix":
        popen_kwargs["start_new_session"] = True
    else:
        popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)

    try:
        process = subprocess.Popen(cmd, **popen_kwargs)
    except Exception as e:
        set_bot_status(bot_id, "crashed")
        return False, f"اجرای دوباره‌ی بات ناموفق بود: {e}"

    time.sleep(2)
    running = process.poll() is None

    # ۴. ردیف بات‌ساز رو به مالک جدید منتقل کن (هم مالک، هم ادمین داخلی بات)
    ensure_user(new_owner_id)
    conn = db()
    conn.execute(
        "UPDATE created_bots SET user_id=?, sub_admin_id=?, pid=?, status=? WHERE id=?",
        (new_owner_id, new_owner_id, process.pid, "running" if running else "crashed", bot_id),
    )
    conn.commit()
    conn.close()

    # ۵. فایل‌های اطلاعاتی (فقط جهت مرجع/بکاپ) رو هم به‌روز کن
    try:
        new_owner = get_user(new_owner_id)
        for fname in ("owner_info.json", "bot_info.json"):
            fpath = os.path.join(folder, fname)
            if os.path.exists(fpath):
                with open(fpath, "r", encoding="utf-8") as f:
                    d = json.load(f)
                d["owner_user_id"] = new_owner_id
                d["owner_username"] = new_owner["username"] if new_owner else ""
                d["owner_first_name"] = new_owner["first_name"] if new_owner else ""
                d["sub_admin_id"] = new_owner_id
                d["bot_admin_id"] = new_owner_id
                d["transferred_from"] = old_admin_id
                d["transferred_at"] = datetime.now().isoformat()
                with open(fpath, "w", encoding="utf-8") as f:
                    json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    if not running:
        return False, get_log_tail(folder)
    return True, None

def finish_transfer_notify(old_owner_id, new_owner_id, bot_id, bot_type, admin_cmd, ok, err, paid_amount=0):
    info = BOT_TYPES.get(bot_type, {"name": bot_type})
    amount_line = "رایگان 🎁" if paid_amount <= 0 else f"{paid_amount:,} تومان"
    if ok:
        send_message(
            old_owner_id,
            f"✅ مالکیت بات #{bot_id} ({info['name']}) با موفقیت به آیدی {new_owner_id} منتقل شد.\n"
            f"💵 هزینه‌ی انتقال: {amount_line}\n\n"
            f"⚠️ شما از این به بعد به‌هیچ‌وجه دسترسی ادمین به این بات ندارید و این بات دیگه توی «{BTN_MYBOTS}» شما نمایش داده نمی‌شه.",
            kb_main(old_owner_id),
        )
        try:
            send_message(
                new_owner_id,
                f"🎉 بات #{bot_id} ({info['name']}) به مالکیت شما منتقل شد!\n\n"
                f"برای باز کردن پنل مدیریتش، داخل خودِ اون بات دستور {admin_cmd} رو بفرست.\n"
                f"از این به بعد این بات توی «{BTN_MYBOTS}» بات‌ساز برای شما نمایش داده می‌شه.",
            )
        except Exception:
            pass
        log_payment(old_owner_id, paid_amount, "ownership_transfer", f"bot_{bot_id}_to_{new_owner_id}")
        notify_purchase_channel(
            "🔁 انتقال مالکیت بات\n\n"
            f"🤖 بات: #{bot_id} - {info['name']}\n"
            f"👤 از آیدی: {old_owner_id}\n"
            f"👤 به آیدی: {new_owner_id}\n"
            f"💵 مبلغ: {amount_line}\n"
            f"🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )
    else:
        send_message(
            old_owner_id,
            f"⚠️ انتقال مالکیت بات #{bot_id} با خطا مواجه شد:\n{err}\n\n"
            f"اگه پرداختی هم انجام شده، به پشتیبانی اطلاع بده تا بررسی و در صورت نیاز برگردونده بشه.",
            kb_mybots(),
        )

DATA_EXTENSIONS = (".db", ".db3", ".sqlite", ".sqlite3", ".json", ".txt")

def zip_folder(folder, only_data=False):
    """کل پوشه (یا فقط فایل‌های داده‌ای db/json/txt) رو زیپ می‌کنه و مسیر فایل زیپ رو برمی‌گردونه."""
    tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    tmp.close()
    with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(folder):
            for fname in files:
                if only_data and not fname.lower().endswith(DATA_EXTENSIONS):
                    continue
                full = os.path.join(root, fname)
                rel = os.path.relpath(full, folder)
                try:
                    zf.write(full, rel)
                except Exception:
                    pass
    return tmp.name

def backup_full_database():
    """یک کپیِ فوری و کامل از factory.db می‌گیره — تنها فایلی که همه‌ی اطلاعات ربات
    (تنظیمات، کاربران، بات‌های ساخته‌شده + توکن‌ها، پرداخت‌ها، تخفیف‌ها) توش نگه‌داری می‌شه.
    این فایل روی دیسک می‌مونه (چه روی هاست، چه اجرای لوکال) و با ری‌استارت سرور پاک نمی‌شه."""
    os.makedirs("backups", exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = os.path.join("backups", f"factory_{stamp}.db")
    shutil.copyfile(DB_NAME, dest)
    return dest

def export_bots_json():
    """خروجی JSON از همه‌ی بات‌های ساخته‌شده + توکن‌هاشون."""
    bots = get_all_bots()
    data = []
    for b in bots:
        data.append({
            "id": b["id"],
            "user_id": b["user_id"],
            "bot_type": b["bot_type"],
            "bot_type_name": BOT_TYPES.get(b["bot_type"], {}).get("name", b["bot_type"]),
            "token": b["token"],
            "sub_admin_id": b["sub_admin_id"],
            "admin_cmd": b["admin_cmd"] if "admin_cmd" in b.keys() else "/admin",
            "run_mode": b["run_mode"] if "run_mode" in b.keys() else "polling",
            "webhook_url": b["webhook_url"] if "webhook_url" in b.keys() else "",
            "webhook_port": b["webhook_port"] if "webhook_port" in b.keys() else None,
            "status": b["status"],
            "folder": b["folder"],
            "created_at": b["created_at"],
        })
    tmp = tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w", encoding="utf-8")
    json.dump(data, tmp, ensure_ascii=False, indent=2)
    tmp.close()
    return tmp.name

# ===================================================================
# 🧩 حالت‌های در انتظار ورودی متنی
# ===================================================================
waiting_for = {}  # user_id(str) -> {"type": ..., ...}

CANCEL_KEYBOARD = {"keyboard": [[{"text": "❌ انصراف"}]], "resize_keyboard": True}
CANCEL_KEYBOARD_TEXT = "❌ انصراف"  # رفع باگ: قبلاً استفاده می‌شد ولی هیچ‌جا تعریف نشده بود (NameError)

# ===================================================================
# 🔤 متن دکمه‌ها
# ===================================================================
BTN_CREATE = "🤖 ساخت بات"
BTN_SUPPORT = "🎧 پشتیبانی"
BTN_HELP = "📖 راهنما"
BTN_MYBOTS = "🗂 بات‌های من"
BTN_PROFILE = "👤 پروفایل من"
BTN_CHARGE_WALLET = "💳 شارژ کیف پول"
BTN_REFERRAL = "👥 زیرمجموعه‌گیری"
BTN_REFERRAL_LEADERBOARD = "🏆 لیدربرد زیرمجموعه‌گیری"
BTN_LOTTERY = "🎁 قرعه‌کشی"
BTN_ADMIN = "👑 پنل مدیریت"

BTN_BACK_MAIN = "🔙 بازگشت به منوی اصلی"
BTN_BACK_ADMIN = "🔙 بازگشت به پنل مدیریت"

BTN_STOP_A_BOT = "⏹ توقف یک بات"
BTN_LOG_A_BOT = "📄 لاگ یک بات"
BTN_TRANSFER_BOT = "🔁 انتقال مالکیت بات"
BTN_RENEW_BOT = "🔄 تمدید بات"

BTN_ADMIN_PRICES = "💵 تنظیم قیمت بات‌ها"
BTN_ADMIN_CHARGE = "💰 شارژ کاربر"
BTN_ADMIN_BROADCAST = "📨 ارسال همگانی"
BTN_ADMIN_REF_REWARD = "🎁 تنظیم پاداش دعوت"
BTN_ADMIN_BULK_CHARGE = "💳 شارژ همگانی"
BTN_ADMIN_BULK_DEDUCT = "➖ کسر همگانی"
BTN_ADMIN_EXPORT_JSON = "📦 خروجی بات‌ها (JSON)"
BTN_ADMIN_PAYMENTS_FILE = "📄 فایل پرداخت‌ها"
BTN_ADMIN_BOTS = "🗂 مدیریت بات‌ها"
BTN_ADMIN_SUPPORT_TEXT = "🎧 تنظیم آیدی پشتیبانی"
BTN_ADMIN_WELCOME_TEXT = "👋 تنظیم پیام خوش‌آمد"
BTN_ADMIN_FULL_BACKUP = "🗄 دانلود کامل اطلاعات ربات"
BTN_ADMIN_TRANSFER_PRICE = "🔁 قیمت انتقال مالکیت"
BTN_ADMIN_PURCHASE_CHANNEL = "📢 تنظیم کانال خریدها"
BTN_ADMIN_PAYMENT_MODE = "💳 حالت پرداخت (خودکار/دستی)"
BTN_ADMIN_MANUAL_INFO = "🏦 متن/شماره‌کارت پرداخت دستی"
BTN_ADMIN_MANUAL_REQUESTS = "🧾 درخواست‌های پرداخت دستی"
BTN_ADMIN_LOTTERY_BROADCAST_TEXT = "📢 متن همگانیِ برنده قرعه‌کشی"
BTN_ADMIN_LOTTERY_WINNER_TEXT = "🏆 متن خصوصی به برنده"
BTN_ADMIN_LOTTERY_OTHER_TEXT = "🎗 متن خصوصی به سایر شرکت‌کنندگان"
BTN_ADMIN_RENEWAL_SETTINGS = "⏳ دوره و قیمت تمدید بات‌ها"
BTN_ADMIN_RENEWAL_REMINDER = "⏰ تنظیم روزهای یادآوری تمدید"
BTN_ADMIN_RENEW_A_BOT = "✅ تمدید دستی/رایگان یک بات"
BTN_ADMIN_DISCOUNTS = "🎟 کدهای تخفیف"
BTN_ADMIN_DISCOUNT_NEW = "➕ ساخت کد تخفیف جدید"
BTN_ADMIN_DISCOUNT_LIST = "📋 لیست کدهای تخفیف"
BTN_ADMIN_REPORT = "📊 گزارش درآمد"
BTN_ADMIN_CAPACITY = "🎚 محدودیت ظرفیت بات‌ساز"
BTN_ADMIN_BAN_USER = "🚫 مسدودکردن کاربر"
BTN_ADMIN_UNBAN_USER = "✅ رفع مسدودی کاربر"
BTN_ADMIN_BACKUP_INTERVAL = "🕐 تنظیم فاصله‌ی بکاپ خودکار"
BTN_ADMIN_DASHBOARD = "📊 داشبورد آماری"
BTN_ADMIN_MANAGE_ADMINS = "🛡 مدیریت ادمین‌ها"
BTN_ADMIN_ADD_SUBADMIN = "➕ افزودن ادمین پشتیبانی"
BTN_ADMIN_REMOVE_SUBADMIN = "➖ حذف ادمین"
BTN_ADMIN_LIST_ADMINS = "📋 لیست ادمین‌ها"
BTN_ADMIN_REQUIRED_CHANNEL = "🔒 جوین اجباری کانال"
BTN_CHECK_CHANNEL_JOIN = "✅ عضو شدم"

BTN_ADMIN_BOTS_LIST = "📋 لیست همه بات‌ها"
BTN_ADMIN_BOTS_STOP = "⏹ خاموش کردن یک بات"
BTN_ADMIN_BOTS_BACKUP = "📥 بکاپ کامل یک بات"
BTN_ADMIN_BOTS_DB = "🗄 دیتابیس یک بات"

BTN_DISCOUNT_REDEEM = "🎟 کد تخفیف"

# ===================================================================
# ⌨️ کیبوردها
# ===================================================================
def build_menu_rows(button_texts, columns_pattern=(1, 2)):
    """دکمه‌ها رو به‌ترتیب توی ردیف‌هایی با الگوی ثابتِ 1، 2، 1، 2، ... می‌چینه.
    اگه تعداد دکمه‌های باقی‌مونده کمتر از اندازه‌ی موردنیاز ردیف بعدی باشه،
    همون تعداد باقی‌مونده توی یه ردیف می‌ره (بدون کرش و بدون دکمه‌ی گم‌شده)."""
    rows = []
    i = 0
    p = 0
    n = len(button_texts)
    while i < n:
        size = columns_pattern[p % len(columns_pattern)]
        chunk = button_texts[i:i + size]
        rows.append([{"text": b} for b in chunk])
        i += len(chunk)
        p += 1
    return rows

DEFAULT_WELCOME_TEXT = (
    "🤖 به بات‌ساز خودکار بله خوش اومدی!\n\n"
    "💰 موجودی شما: {balance} تومان\n\n"
    "از دکمه‌های زیر استفاده کن:"
)

def kb_main(user_id):
    buttons = [
        BTN_CREATE, BTN_HELP, BTN_SUPPORT, BTN_PROFILE,
        BTN_MYBOTS, BTN_REFERRAL, BTN_CHARGE_WALLET,
        BTN_DISCOUNT_REDEEM, BTN_LOTTERY,
    ]
    if is_any_admin(user_id):
        buttons.append(BTN_ADMIN)
    rows = build_menu_rows(buttons)
    return {"keyboard": rows, "resize_keyboard": True}

def kb_create():
    buttons = [info["name"] for info in BOT_TYPES.values()]
    rows = build_menu_rows(buttons)
    rows.append([{"text": BTN_BACK_MAIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_mybots():
    buttons = [BTN_STOP_A_BOT, BTN_LOG_A_BOT, BTN_TRANSFER_BOT, BTN_RENEW_BOT]
    rows = build_menu_rows(buttons)
    rows.append([{"text": BTN_BACK_MAIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_admin():
    buttons = [
        BTN_ADMIN_DASHBOARD, BTN_ADMIN_PRICES,
        BTN_ADMIN_CHARGE, BTN_ADMIN_BROADCAST,
        BTN_ADMIN_REF_REWARD, BTN_ADMIN_BULK_CHARGE,
        BTN_ADMIN_BULK_DEDUCT, BTN_ADMIN_TRANSFER_PRICE,
        BTN_ADMIN_PURCHASE_CHANNEL, BTN_ADMIN_PAYMENT_MODE,
        BTN_ADMIN_MANUAL_INFO, BTN_ADMIN_MANUAL_REQUESTS,
        BTN_ADMIN_SUPPORT_TEXT, BTN_ADMIN_WELCOME_TEXT,
        BTN_ADMIN_RENEWAL_SETTINGS, BTN_ADMIN_RENEWAL_REMINDER,
        BTN_ADMIN_DISCOUNTS, BTN_ADMIN_REPORT,
        BTN_ADMIN_CAPACITY, BTN_ADMIN_BACKUP_INTERVAL,
        BTN_ADMIN_BAN_USER, BTN_ADMIN_UNBAN_USER,
        BTN_ADMIN_REQUIRED_CHANNEL, BTN_ADMIN_MANAGE_ADMINS,
        BTN_ADMIN_LOTTERY_BROADCAST_TEXT, BTN_ADMIN_LOTTERY_WINNER_TEXT,
        BTN_ADMIN_LOTTERY_OTHER_TEXT,
        BTN_ADMIN_EXPORT_JSON, BTN_ADMIN_PAYMENTS_FILE, BTN_ADMIN_FULL_BACKUP,
        BTN_ADMIN_BOTS,
    ]
    rows = build_menu_rows(buttons)
    rows.append([{"text": BTN_BACK_MAIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_admin_support():
    """پنل محدود برای ادمین‌های نقش «پشتیبانی»: بدون دسترسی به تنظیمات مالی/قیمت‌گذاری."""
    buttons = [
        BTN_ADMIN_MANUAL_REQUESTS, BTN_ADMIN_SUPPORT_TEXT,
        BTN_ADMIN_BAN_USER, BTN_ADMIN_UNBAN_USER,
        BTN_ADMIN_BOTS_LIST,
    ]
    rows = build_menu_rows(buttons)
    rows.append([{"text": BTN_BACK_MAIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_admin_manage_admins():
    buttons = [BTN_ADMIN_LIST_ADMINS, BTN_ADMIN_ADD_SUBADMIN, BTN_ADMIN_REMOVE_SUBADMIN]
    rows = build_menu_rows(buttons)
    rows.append([{"text": BTN_BACK_ADMIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_admin_discounts():
    buttons = [BTN_ADMIN_DISCOUNT_NEW, BTN_ADMIN_DISCOUNT_LIST]
    rows = build_menu_rows(buttons)
    rows.append([{"text": BTN_BACK_ADMIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_join_channel():
    link = get_setting("required_channel_link", "")
    rows = []
    if link:
        rows.append([{"text": f"🔗 {link}"}])
    rows.append([{"text": BTN_CHECK_CHANNEL_JOIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_admin_prices():
    rows = [[{"text": f"{info['name']} - {get_price(key):,} تومان"}] for key, info in BOT_TYPES.items()]
    rows.append([{"text": BTN_BACK_ADMIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_admin_renewal_types():
    rows = []
    for key, info in BOT_TYPES.items():
        days, price = get_renewal_settings(key)
        period_line = "نامحدود" if days <= 0 else f"هر {days} روز"
        price_line = "-" if days <= 0 else ("رایگان" if price <= 0 else f"{price:,} تومان")
        rows.append([{"text": f"{info['name']} | {period_line} | {price_line}"}])
    rows.append([{"text": BTN_BACK_ADMIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def kb_admin_bots():
    buttons = [BTN_ADMIN_BOTS_LIST, BTN_ADMIN_BOTS_STOP, BTN_ADMIN_RENEW_A_BOT, BTN_ADMIN_BOTS_BACKUP, BTN_ADMIN_BOTS_DB]
    rows = build_menu_rows(buttons)
    rows.append([{"text": BTN_BACK_ADMIN}])
    return {"keyboard": rows, "resize_keyboard": True}

def match_price_button(text):
    """تشخیص می‌ده کدوم نوع بات با این متن دکمه مطابقت داره (برای تنظیم قیمت).
    باگ قبلی: فقط startswith(name) چک می‌شد، که چون دکمه‌های «دوره و قیمت تمدید»
    هم با همون نام بات شروع می‌شن (مثلاً «... | هر 30 روز | ...»)، اشتباهی به‌جای
    باز کردن فرم تمدید، فرم «تغییر قیمت بات» باز می‌شد. حالا دقیقاً همون جداکننده‌ای
    که kb_admin_prices می‌سازه (" - ") رو چک می‌کنیم تا با دکمه‌های تمدید قاطی نشه."""
    for key, info in BOT_TYPES.items():
        if text.startswith(f"{info['name']} - "):
            return key
    return None

def match_renewal_type_button(text):
    """تشخیص می‌ده کدوم نوع بات با این متن دکمه‌ی «دوره و قیمت تمدید» مطابقت داره."""
    for key, info in BOT_TYPES.items():
        if text.startswith(f"{info['name']} |"):
            return key
    return None

# ===================================================================
# 📋 متن منوها
# ===================================================================
def main_menu_text(user_id):
    balance = get_balance(user_id)
    template = get_setting("welcome_text", DEFAULT_WELCOME_TEXT)
    try:
        return template.format(balance=f"{balance:,}")
    except Exception:
        # اگه ادمین توی متن خوش‌آمد از { } نامعتبر استفاده کرده باشه، بات کرش نکنه
        return template

def create_menu_text():
    text = "🤖 نوع بات مورد نظرت رو انتخاب کن:\n"
    for bkey, info in BOT_TYPES.items():
        price = get_price(bkey)
        text += f"\n{info['name']}\n{info['desc']}\n💵 قیمت: {price:,} تومان\n"
    return text

def mybots_text(user_id):
    bots = get_user_bots(user_id)
    if not bots:
        return "🗂 هنوز هیچ باتی نساختی. از «🤖 ساخت بات» شروع کن."
    status_fa = {"running": "🟢 فعال", "stopped": "🔴 متوقف‌شده", "crashed": "⚠️ خطا/خاموش"}
    text = "🗂 بات‌های ساخته‌شده توسط تو:\n"
    for b in bots:
        b2 = refresh_bot_status(b["id"]) or b
        info = BOT_TYPES.get(b2["bot_type"], {"name": b2["bot_type"]})
        text += f"\n#{b2['id']} - {info['name']} - {status_fa.get(b2['status'], b2['status'])}\n{format_expiry_line(b2)}\n"
    return text

def profile_text(user_id):
    u = get_user(user_id)
    if not u:
        return "پروفایل پیدا نشد."
    join = u["created_at"][:10] if u["created_at"] else "-"
    ref_line = f"👤 دعوت‌شده توسط: {u['referred_by']}\n" if u["referred_by"] else ""
    return (
        f"👤 پروفایل شما\n\n"
        f"🆔 آیدی عددی: {user_id}\n"
        f"💰 موجودی: {u['balance']:,} تومان\n"
        f"🗓 تاریخ عضویت: {join}\n"
        f"👥 تعداد دعوت‌شده‌ها: {u['invited_count']}\n"
        f"{ref_line}"
    )


# ===================== 🎁 قرعه‌کشی روزانه =====================
def tehran_now(): return datetime.now(TEHRAN_TZ).replace(microsecond=0)
def lottery_period_for(dt=None):
    dt=dt or tehran_now()
    d=dt.date()
    start_d=d if (dt.hour,dt.minute)>=(22,30) else d-timedelta(days=1)
    end_d=start_d+timedelta(days=1)
    start=datetime.combine(start_d,datetime.min.time(),tzinfo=TEHRAN_TZ).replace(hour=22,minute=30)
    end=datetime.combine(end_d,datetime.min.time(),tzinfo=TEHRAN_TZ).replace(hour=22)
    result=datetime.combine(end_d,datetime.min.time(),tzinfo=TEHRAN_TZ).replace(hour=22,minute=30)
    return start,end,result
def ensure_lottery_period():
    s,e,r=lottery_period_for(); c=db()
    c.execute("INSERT OR IGNORE INTO lottery_periods(start_at,end_at,result_at,created_at) VALUES(?,?,?,?)",(s.isoformat(),e.isoformat(),r.isoformat(),tehran_now().isoformat()))
    c.commit(); row=c.execute("SELECT * FROM lottery_periods WHERE start_at=?",(s.isoformat(),)).fetchone(); c.close(); return row
def lottery_info(uid):
    row=ensure_lottery_period(); u=get_user(uid); inv=int(u["invited_count"]) if u else 0
    joined=bool(db().execute("SELECT 1 FROM lottery_entries WHERE period_id=? AND user_id=?",(row["id"],uid)).fetchone())
    cnt=db().execute("SELECT COUNT(*) c FROM lottery_entries WHERE period_id=?",(row["id"],)).fetchone()["c"]
    return row,inv,1+inv,joined,cnt,datetime.fromisoformat(row["start_at"]),datetime.fromisoformat(row["end_at"]),datetime.fromisoformat(row["result_at"])
def lottery_text(uid):
    row,inv,ch,j,cnt,s,e,r=lottery_info(uid)
    prev=db().execute("SELECT * FROM lottery_periods WHERE drawn=1 ORDER BY id DESC LIMIT 1").fetchone()
    prevline=f"🏆 برنده دوره قبل: @{prev['winner_username']}" if prev and prev["winner_username"] else "🏆 برنده دوره قبل: هنوز ثبت نشده"
    return ("🎁 قرعه‌کشی روزانه ربات رایگان\n\nهر شب ساعت ۲۲:۳۰ قرعه‌کشی انجام می‌شود.\n"
            "فقط کسانی شرکت داده می‌شوند که از بعد اعلام نتیجه ساعت ۲۲:۳۰ تا فردا ساعت ۲۲:۰۰ دکمه شرکت را زده باشند.\n"
            "شانس هر نفر برابر است با ۱ + تعداد زیرمجموعه‌های مستقیم او.\n\n"
            f"دوره فعال: `{s.strftime('%Y/%m/%d')} ساعت 22:30` تا `{e.strftime('%Y/%m/%d')} ساعت 22:00`\n"
            f"نتیجه: `{r.strftime('%Y/%m/%d')} ساعت 22:30`\n"
            f"زیرمجموعه‌های شما: {inv}\nشانس شما: {ch}\n👥 تعداد شرکت‌کنندگان: {cnt}\n\n{prevline}\n\n"
            + ("✅ شما در این دوره شرکت کرده‌اید." if j else "برای ورود به قرعه‌کشی دکمه زیر را بزن."))
def kb_lottery(uid):
    _,_,_,j,_,_,_,_=lottery_info(uid)
    return {"keyboard":[[{"text":"✅ شما شرکت کرده‌اید" if j else "🎁 شرکت در قرعه‌کشی"}],
                       [{"text":"🏆 برنده دوره قبل"},{"text":"👥 شرکت‌کنندگان"}],
                       [{"text":"📋 قوانین قرعه‌کشی"}],[{"text":BTN_BACK_MAIN}]],"resize_keyboard":True}
def join_lottery(uid):
    row=ensure_lottery_period()
    if tehran_now()>=datetime.fromisoformat(row["end_at"]): return False,"⛔ زمان شرکت در این دوره به پایان رسیده است."
    c=db()
    try:
        c.execute("INSERT INTO lottery_entries(period_id,user_id,joined_at) VALUES(?,?,?)",(row["id"],uid,tehran_now().isoformat())); c.commit()
        return True,"🎉 با موفقیت وارد قرعه‌کشی شدی!"
    except sqlite3.IntegrityError: return False,"✅ تو قبلاً در این دوره شرکت کرده‌ای."
    finally: c.close()
def add_free_bot_credit(uid):
    c=db(); c.execute("UPDATE users SET free_bot_credits=COALESCE(free_bot_credits,0)+1 WHERE user_id=?",(uid,)); c.commit(); c.close()
def free_bot_credits(uid):
    u=get_user(uid); return int(u["free_bot_credits"] or 0) if u else 0
def consume_free_credit(uid):
    c=db(); cur=c.execute("UPDATE users SET free_bot_credits=free_bot_credits-1 WHERE user_id=? AND free_bot_credits>0",(uid,)); c.commit(); c.close(); return cur.rowcount>0
def lottery_broadcast(msg):
    for uid in get_all_user_ids():
        try: send_message(uid,msg,kb_main(uid))
        except Exception: pass
        time.sleep(.03)
def process_lottery():
    now=tehran_now(); c=db()
    rows=c.execute("SELECT * FROM lottery_periods WHERE drawn=0 AND result_at<=? ORDER BY id",(now.isoformat(),)).fetchall(); c.close()
    for p in rows:
        c=db(); entries=c.execute("SELECT e.user_id,u.username,u.invited_count FROM lottery_entries e JOIN users u ON u.user_id=e.user_id WHERE e.period_id=?",(p["id"],)).fetchall(); c.close()
        if entries:
            weighted=[e["user_id"] for e in entries for _ in range(1+int(e["invited_count"] or 0))]
            wid=random.choice(weighted); w=next(e for e in entries if e["user_id"]==wid)
            c=db(); c.execute("UPDATE lottery_periods SET drawn=1,winner_id=?,winner_username=? WHERE id=?",(wid,w["username"] or "",p["id"])); c.commit(); c.close()
            add_free_bot_credit(wid); who=f"@{w['username']}" if w["username"] else f"کاربر {wid}"
            broadcast_text = get_setting("lottery_broadcast_text").replace("{winner}", who)
            lottery_broadcast(broadcast_text)
            try:
                winner_text = get_setting("lottery_winner_dm_text")
                send_message(wid, winner_text, kb_main(wid))
            except Exception: pass
            other_tpl = get_setting("lottery_other_text")
            for e in entries:
                if e["user_id"] == wid:
                    continue
                try: send_message(e["user_id"], other_tpl.replace("{winner}", who), kb_main(e["user_id"]))
                except Exception: pass
                time.sleep(.03)
        else:
            c=db(); c.execute("UPDATE lottery_periods SET drawn=1 WHERE id=?",(p["id"],)); c.commit(); c.close()
        ensure_lottery_period()

_last_auto_backup_at = None

def process_auto_backup():
    """هر چند ساعت یک‌بار (تنظیم ادمین) از دیتابیس اصلیِ بات‌ساز بکاپ می‌گیره و برای ادمین می‌فرسته."""
    global _last_auto_backup_at
    hours = int(get_setting("backup_interval_hours", "24") or "24")
    if hours <= 0:
        return
    now = datetime.now()
    if _last_auto_backup_at and (now - _last_auto_backup_at).total_seconds() < hours * 3600:
        return
    _last_auto_backup_at = now
    try:
        os.makedirs("backups", exist_ok=True)
        stamp = now.strftime("%Y%m%d_%H%M%S")
        dest = os.path.join("backups", f"factory_{stamp}.db")
        shutil.copyfile(DB_NAME, dest)
        try:
            send_document(ADMIN_ID, dest, caption=f"🗄 بکاپ خودکار دیتابیس بات‌ساز - {stamp}")
        except Exception:
            pass
    except Exception as e:
        print(f"⚠️ خطا در بکاپ خودکار: {e}")

def process_renewals():
    """هر بات دارای تاریخ انقضا رو چک می‌کنه:
    - اگه نزدیک سررسیده (بر اساس تعداد روز تنظیم‌شده توسط ادمین)، هر روز یک یادآوری به مالک می‌فرسته.
    - اگه سررسیدش گذشته و تمدید نشده، خودکار خاموشش می‌کنه و به مالک اطلاع می‌ده."""
    now = datetime.now()
    reminder_days = int(get_setting("renewal_reminder_days", "1") or "1")
    rows = db().execute(
        "SELECT * FROM created_bots WHERE expires_at != '' AND renewal_status='active'"
    ).fetchall()
    for row in rows:
        try:
            exp = datetime.fromisoformat(row["expires_at"])
        except Exception:
            continue
        info = BOT_TYPES.get(row["bot_type"], {"name": row["bot_type"]})
        _, price = get_renewal_settings(row["bot_type"])
        price_line = "رایگان 🎁" if price <= 0 else f"{price:,} تومان"
        owner_id = row["user_id"]

        if now >= exp:
            if row["status"] == "running":
                stop_bot(row["id"])
            set_bot_expiry(row["id"], row["expires_at"], renewal_status="expired", reset_reminder=False)
            try:
                send_message(
                    owner_id,
                    f"⛔ بات #{row['id']} ({info['name']}) چون تا موعدش تمدید نشد، به‌صورت خودکار خاموش شد.\n\n"
                    f"💵 هزینه‌ی تمدید: {price_line}\n\n"
                    f"برای روشن‌کردنِ دوباره‌اش از «{BTN_MYBOTS}» گزینه‌ی «{BTN_RENEW_BOT}» رو بزن.",
                    kb_mybots(),
                )
            except Exception:
                pass
            continue

        days_left = (exp - now).days
        if days_left <= reminder_days:
            today_str = now.strftime("%Y-%m-%d")
            if row["last_reminder_at"] != today_str:
                conn = db()
                conn.execute("UPDATE created_bots SET last_reminder_at=? WHERE id=?", (today_str, row["id"]))
                conn.commit()
                conn.close()
                remain_line = "امروز آخرین مهلته، همین امروز تمدید کن!" if days_left <= 0 else f"{days_left} روز دیگه"
                try:
                    send_message(
                        owner_id,
                        f"⏰ یادآوری تمدید بات #{row['id']} ({info['name']})\n\n"
                        f"⌛ تا خاموش شدنِ خودکار: {remain_line}\n"
                        f"📅 تاریخ سررسید: {exp.strftime('%Y/%m/%d %H:%M')}\n"
                        f"💵 هزینه‌ی تمدید: {price_line}\n\n"
                        f"برای اینکه باتت خاموش نشه، از «{BTN_MYBOTS}» گزینه‌ی «{BTN_RENEW_BOT}» رو بزن.",
                        kb_mybots(),
                    )
                except Exception:
                    pass

_bot_monitor_state = {}  # bot_id -> {"fail_count": int, "notified_down": bool}

def process_bot_monitor():
    """هر بات‌ که status='running' ثبت شده رو چک می‌کنه واقعاً روشنه یا نه؛
    اگه خاموش/کرش شده بود، خودکار سعی می‌کنه دوباره روشنش کنه و به کاربر خبر بده.
    اگه چند بار پشت‌سرهم روشن‌کردن ناموفق بود (مثلاً توکن بات باطل شده)، دیگه اسپم نمی‌کنه
    و فقط یک‌بار به کاربر و ادمین هشدار می‌ده."""
    rows = db().execute("SELECT * FROM created_bots WHERE status='running'").fetchall()
    for row in rows:
        bot_id = row["id"]
        if row["expires_at"] and row["renewal_status"] == "expired":
            continue  # این مورد رو process_renewals مدیریت می‌کنه
        if is_pid_alive(row["pid"]):
            _bot_monitor_state.pop(bot_id, None)
            continue

        st = _bot_monitor_state.setdefault(bot_id, {"fail_count": 0, "notified_down": False})
        if st["fail_count"] >= 3:
            continue  # بعد از ۳ تلاش ناموفق، دیگه امتحان نکن تا اسپم نشه

        info = BOT_TYPES.get(row["bot_type"], {"name": row["bot_type"]})
        ok, err = restart_existing_bot_process(bot_id)
        if ok:
            _bot_monitor_state.pop(bot_id, None)
            try:
                send_message(row["user_id"], f"✅ بات #{bot_id} ({info['name']}) که به‌طور غیرمنتظره خاموش شده بود، خودکار دوباره روشن شد.")
            except Exception:
                pass
        else:
            st["fail_count"] += 1
            if not st["notified_down"]:
                st["notified_down"] = True
                try:
                    send_message(
                        row["user_id"],
                        f"⚠️ بات #{bot_id} ({info['name']}) از کار افتاده و تلاش برای روشن‌کردن خودکارش ناموفق بود.\n"
                        f"برای بررسی به پشتیبانی پیام بده.",
                    )
                except Exception:
                    pass
                try:
                    send_message(ADMIN_ID, f"🚨 مانیتورینگ: بات #{bot_id} ({info['name']}, کاربر {row['user_id']}) از کار افتاده و ری‌استارت خودکار ناموفق بود:\n{err}")
                except Exception:
                    pass

def referral_text(user_id):
    reward = get_setting("referral_reward", "1000")
    if BOT_USERNAME:
        link = f"https://ble.ir/{BOT_USERNAME}?start=ref_{user_id}"
        link_line = f"🔗 لینک اختصاصی شما:\n{link}\n\n"
    else:
        link_line = (
            f"🔗 لینک آماده نشد (بات هنوز یوزرنیمش گرفته نشده). "
            f"می‌تونی به دوستت بگی این‌طوری وارد بشه:\n/start ref_{user_id}\n\n"
        )
    u = get_user(user_id)
    invited = u["invited_count"] if u else 0
    return (
        "👥 زیرمجموعه‌گیری\n\n"
        f"{link_line}"
        f"🎁 پاداش هر دعوت موفق: {reward} تومان\n"
        f"✅ تعداد دعوت‌های موفق شما: {invited}\n\n"
        "هرکسی با این لینک وارد بات بشه (برای اولین بار)، پاداش بالا به موجودی شما اضافه می‌شه."
    )

def is_member_of_required_channel(user_id):
    """چک می‌کنه کاربر عضو کانال اجباریه یا نه. اگه کانالی تنظیم نشده، همیشه True (قابلیت خاموشه).
    اگه به هر دلیلی (مثلاً بات ادمین کانال نیست) نشه نتیجه گرفت، fail-open می‌کنه تا یه تنظیم
    اشتباه کل بات‌ساز رو برای همه قفل نکنه."""
    channel_id = get_setting("required_channel_id", "")
    if not channel_id:
        return True
    try:
        r = api_request("getChatMember", {"chat_id": channel_id, "user_id": user_id})
        if not r.get("ok"):
            return True
        status = (r.get("result") or {}).get("status", "")
        return status in ("member", "administrator", "creator", "owner")
    except Exception:
        return True

def required_channel_join_text():
    link = get_setting("required_channel_link", "")
    link_line = f"\n\n🔗 {link}" if link else ""
    return "🔒 برای استفاده از بات‌ساز، اول باید عضو کانال ما بشی." + link_line + "\n\nبعد از عضویت، دکمه‌ی زیر رو بزن 👇"

def referral_leaderboard_text(limit=10):
    rows = db().execute(
        "SELECT user_id, username, first_name, invited_count FROM users WHERE invited_count>0 ORDER BY invited_count DESC LIMIT ?",
        (limit,),
    ).fetchall()
    if not rows:
        return "🏆 لیدربرد زیرمجموعه‌گیری\n\nهنوز کسی زیرمجموعه‌گیری موفق نداشته؛ اولین نفر باش! 🚀"
    medals = ["🥇", "🥈", "🥉"]
    lines = ["🏆 لیدربرد زیرمجموعه‌گیری (برترین دعوت‌کننده‌ها)\n"]
    for i, r in enumerate(rows):
        medal = medals[i] if i < 3 else f"{i + 1}."
        name = f"@{r['username']}" if r["username"] else (r["first_name"] or f"کاربر {r['user_id']}")
        lines.append(f"{medal} {name} — {r['invited_count']} دعوت موفق")
    return "\n".join(lines)

# ===================================================================
# 📨 پردازش پیام‌ها
# ===================================================================
def handle_referral_start(user_id, text):
    """اگه کاربر تازه‌واردی با /start ref_<id> اومده، پاداش رو به دعوت‌کننده می‌ده."""
    parts = text.split(None, 1)
    if len(parts) < 2:
        return None
    payload = parts[1].strip()
    if not payload.startswith("ref_"):
        return None
    ref_id_raw = payload[4:]
    if not ref_id_raw.isdigit():
        return None
    referrer_id = int(ref_id_raw)
    if referrer_id == user_id:
        return None
    if get_user(referrer_id) is None:
        return None
    return referrer_id


def finalize_bot_creation(user_id, key, wait):
    bot_type = wait["bot_type"]
    token = wait["token"]
    new_admin_id = wait["admin_id"]
    admin_cmd = wait["admin_cmd"]
    run_mode = wait.get("run_mode", "polling")
    webhook_url = wait.get("webhook_url", "")

    cap_ok, cap_msg = check_creation_capacity(user_id)
    if not cap_ok:
        waiting_for.pop(key, None)
        send_message(user_id, cap_msg, kb_main(user_id))
        return

    price = get_price(bot_type)
    price, applied_code = get_discounted_price(user_id, price)

    use_free = free_bot_credits(user_id) > 0 and price > 0
    if not use_free and get_balance(user_id) < price:
        send_message(user_id, f"❌ موجودی کافی نیست.\n💰 موجودی: {get_balance(user_id):,}\n💵 قیمت: {price:,}\nبرای شارژ به پشتیبانی پیام بده.")
        waiting_for.pop(key, None); send_message(user_id, main_menu_text(user_id), kb_main(user_id)); return
    send_message(user_id, "⏳ در حال ساخت و بالا آوردن بات جدیدت... چند ثانیه صبر کن.", kb_main(user_id))
    if use_free: consume_free_credit(user_id); paid_price=0
    else: sub_balance(user_id, price); paid_price=price
    if applied_code: consume_active_discount(user_id)
    bot_id, running, log_tail = launch_bot(user_id, bot_type, token, new_admin_id, admin_cmd, run_mode, webhook_url)
    waiting_for.pop(key, None)

    renewal_days, _ = get_renewal_settings(bot_type)
    if renewal_days > 0:
        first_expiry = (datetime.now() + timedelta(days=renewal_days)).isoformat()
        set_bot_expiry(bot_id, first_expiry, renewal_status="active", reset_reminder=True)

    info_bt = BOT_TYPES.get(bot_type, {"name": bot_type})
    log_payment(user_id, paid_price, "bot_purchase", f"bot_{bot_id}")
    notify_purchase_channel(
        "🤖 خرید ساخت بات\n\n"
        f"👤 کاربر: {user_id}\n"
        f"🧩 نوع بات: {info_bt['name']}\n"
        f"💵 مبلغ: {'رایگان 🎁' if price <= 0 else f'{price:,} تومان'}\n"
        f"🆔 شماره بات: #{bot_id}\n"
        f"📶 وضعیت: {'✅ فعال' if running else '⚠️ خطا در اجرا'}\n"
        f"🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    )

    if running:
        mode_line = ""
        if run_mode == "webhook":
            row = get_bot_by_id(bot_id)
            mode_line = f"\n🌐 حالت Webhook - پورت داخلی روی سرور: {row['webhook_port']}\n(مطمئن شو {webhook_url} به این پورت روی سرور وصله)"
        renewal_line = ""
        if renewal_days > 0:
            _, renewal_price = get_renewal_settings(bot_type)
            price_line = "رایگان 🎁" if renewal_price <= 0 else f"{renewal_price:,} تومان"
            renewal_line = (
                f"\n\n⏳ این نوع بات هر {renewal_days} روز نیاز به تمدید داره (هزینه: {price_line}).\n"
                f"چند روز قبل از سررسید بهت یادآوری می‌کنم؛ اگه تمدید نشه، بات به‌صورت خودکار خاموش می‌شه."
            )
        send_message(
            user_id,
            f"🎉 بات جدیدت با موفقیت ساخته و روشن شد! (شماره #{bot_id})\n\n"
            f"می‌تونی همین الان بری تو بله سراغ باتت و بهش /start بزنی.\n"
            f"برای پنل مدیریتش هم دستور {admin_cmd} رو بفرست."
            f"{mode_line}"
            f"{renewal_line}\n\n"
            f"وضعیتش رو از «{BTN_MYBOTS}» می‌تونی ببینی یا خاموشش کنی.",
        )
    else:
        tail_msg = f"\n\n📄 آخرین خطای ثبت‌شده:\n{log_tail}" if log_tail else ""
        send_message(
            user_id,
            f"⚠️ بات ساخته شد ولی موقع اجرا با خطا مواجه شد و بلافاصله خاموش شد (شماره #{bot_id}).{tail_msg}\n\n"
            f"مبلغ کسر شده رو به پشتیبانی اطلاع بده تا بررسی و برگردونده بشه.",
        )
    send_message(user_id, main_menu_text(user_id), kb_main(user_id))


def handle_message(message):
    chat = message.get("chat", {})
    user_id = chat.get("id")
    if user_id is None:
        return
    text = (message.get("text") or "").strip()
    username = chat.get("username", "")
    first_name = chat.get("first_name", "")

    # ---------- پرداخت موفق (پرداخت خودکار بله: شارژ کیف پول / انتقال مالکیت / ...) ----------
    sp = message.get("successful_payment")
    if sp:
        payload = sp.get("invoice_payload", "")
        amount_rial = sp.get("total_amount", 0)
        amount_toman = amount_rial // 10
        track_code = sp.get("provider_payment_charge_id", "") or payload

        inv = get_invoice(payload)

        # جلوگیری از پردازش دوباره‌ی یک پرداخت (مثلاً اگه آپدیت بله دوبار برسه)
        if inv and inv["status"] == "paid":
            send_message(user_id, "✅ این پرداخت قبلاً پردازش شده.", kb_main(user_id))
            return

        purpose = inv["purpose"] if inv else "wallet_charge"
        if inv:
            mark_invoice_paid(payload)

        if purpose == "ownership_transfer" and inv:
            meta = json.loads(inv["meta"] or "{}")
            bot_id = meta.get("bot_id")
            new_owner_id = meta.get("new_owner_id")
            row = get_bot_by_id(bot_id) if bot_id else None
            if row and row["user_id"] == user_id and new_owner_id:
                ok, err = transfer_bot_ownership(bot_id, new_owner_id)
                finish_transfer_notify(user_id, new_owner_id, bot_id, row["bot_type"], row["admin_cmd"], ok, err, paid_amount=amount_toman)
            else:
                send_message(
                    user_id,
                    "⚠️ پرداخت با موفقیت دریافت شد ولی بات موردنظر دیگه پیدا نشد یا متعلق به شما نیست؛ حتماً به پشتیبانی پیام بده تا مبلغ بررسی/برگردونده بشه.",
                    kb_main(user_id),
                )
            return

        if purpose == "bot_renewal" and inv:
            meta = json.loads(inv["meta"] or "{}")
            bot_id = meta.get("bot_id")
            row = get_bot_by_id(bot_id) if bot_id else None
            if row and row["user_id"] == user_id:
                ok, warn = extend_bot_expiry(bot_id)
                info = BOT_TYPES.get(row["bot_type"], {"name": row["bot_type"]})
                row2 = get_bot_by_id(bot_id)
                if ok:
                    if meta.get("discount_code"):
                        consume_active_discount(user_id)
                    send_message(
                        user_id,
                        f"✅ بات #{bot_id} ({info['name']}) با موفقیت تمدید شد!\n"
                        f"{format_expiry_line(row2)}\n\n"
                        f"💵 مبلغ پرداخت‌شده: {amount_toman:,} تومان" + (f"\n\n{warn}" if warn else ""),
                        kb_mybots(),
                    )
                    log_payment(user_id, amount_toman, "bot_renewal", f"bot_{bot_id}")
                    notify_purchase_channel(
                        "🔄 تمدید بات\n\n"
                        f"🤖 بات: #{bot_id} - {info['name']}\n"
                        f"👤 کاربر: {user_id}\n"
                        f"💵 مبلغ: {amount_toman:,} تومان\n"
                        f"🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                    )
                else:
                    send_message(user_id, f"⚠️ پرداخت دریافت شد ولی تمدید انجام نشد: {warn}\nبه پشتیبانی پیام بده.", kb_mybots())
            else:
                send_message(
                    user_id,
                    "⚠️ پرداخت با موفقیت دریافت شد ولی بات موردنظر دیگه پیدا نشد یا متعلق به شما نیست؛ حتماً به پشتیبانی پیام بده تا مبلغ بررسی/برگردونده بشه.",
                    kb_main(user_id),
                )
            return

        # حالت پیش‌فرض: شارژ کیف پول
        add_balance(user_id, amount_toman)
        log_payment(user_id, amount_toman, "wallet_charge", track_code)
        send_message(user_id, f"✅ پرداخت موفق بود و کیف پولت {amount_toman:,} تومان شارژ شد.\n💰 موجودی جدید: {get_balance(user_id):,}", kb_main(user_id))
        notify_purchase_channel(
            "💳 شارژ کیف پول\n\n"
            f"👤 کاربر: {user_id}\n"
            f"💰 مبلغ: {amount_toman:,} تومان\n"
            f"🎟 کد پیگیری: {track_code}\n"
            f"🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )
        try:
            send_message(ADMIN_ID, f"💳 پرداخت جدید!\n👤 کاربر: {user_id}\n💰 مبلغ: {amount_toman:,} تومان\n🎟 کد: {track_code}")
        except Exception:
            pass
        return

    key = str(user_id)
    is_admin_user_early = str(user_id) == str(ADMIN_ID)
    if not is_admin_user_early and is_user_banned(user_id):
        send_message(user_id, "⛔ دسترسی شما به این بات‌ساز مسدود شده.\nبرای پیگیری با پشتیبانی تماس بگیرید.")
        return

    wait = waiting_for.get(key)

    # ---------- انصراف عمومی ----------
    if text == "❌ انصراف" and wait:
        del waiting_for[key]
        send_message(user_id, "لغو شد.", kb_main(user_id))
        return

    # ---------- حالت‌های در انتظار ورودی ----------
    if wait:
        wtype = wait["type"]

        if wtype == "charge_wallet_amount":
            if not text.isdigit() or int(text) <= 0:
                send_message(user_id, "❌ یه عدد مثبت بفرست (به هزار تومان؛ مثلاً 40 یعنی 40 هزار تومان):", CANCEL_KEYBOARD)
                return
            amount = parse_thousand_toman(text)
            mode = get_setting("payment_mode", "auto")
            if mode == "both":
                wait["amount"] = amount
                wait["type"] = "charge_wallet_method_choice"
                send_message(
                    user_id,
                    f"💵 مبلغ: {amount:,} تومان\n\nروش پرداخت رو انتخاب کن: «پرداخت آنلاین» یا «پرداخت دستی»",
                    {"keyboard": [[{"text": "💳 پرداخت آنلاین"}, {"text": "🏦 پرداخت دستی"}], [{"text": CANCEL_KEYBOARD_TEXT}]], "resize_keyboard": True},
                )
                return
            waiting_for.pop(key, None)
            ok, msg = send_invoice_or_manual(user_id, "شارژ کیف پول", amount, "wallet_charge")
            send_message(user_id, msg, kb_main(user_id))
            return

        if wtype == "charge_wallet_method_choice":
            amount = wait["amount"]
            if text not in ("💳 پرداخت آنلاین", "🏦 پرداخت دستی"):
                send_message(user_id, "❌ یکی از دو گزینه رو انتخاب کن:", {"keyboard": [[{"text": "💳 پرداخت آنلاین"}, {"text": "🏦 پرداخت دستی"}], [{"text": CANCEL_KEYBOARD_TEXT}]], "resize_keyboard": True})
                return
            waiting_for.pop(key, None)
            forced_mode = "auto" if text == "💳 پرداخت آنلاین" else "manual"
            ok, msg = send_invoice_or_manual(user_id, "شارژ کیف پول", amount, "wallet_charge", forced_mode=forced_mode)
            send_message(user_id, msg, kb_main(user_id))
            return

        if wtype == "await_token":
            token = text.strip()
            ok, bot_username = validate_token(token)
            if not ok:
                send_message(user_id, "❌ این توکن معتبر نیست یا بات از کار افتاده. یه توکن درست بفرست:", CANCEL_KEYBOARD)
                return
            wait["token"] = token
            wait["type"] = "await_admin_id"
            send_message(
                user_id,
                f"✅ توکن تایید شد (بات: @{bot_username})\n\n👤 حالا آیدی عددی ادمینِ بات جدید رو بفرست:\n(می‌تونی آیدی عددی خودت رو بفرستی)",
                CANCEL_KEYBOARD,
            )
            return

        if wtype == "await_admin_id":
            if not text.isdigit():
                send_message(user_id, "❌ آیدی عددی باید فقط عدد باشه. دوباره بفرست:", CANCEL_KEYBOARD)
                return
            bot_type = wait["bot_type"]
            token = wait["token"]
            new_admin_id = int(text)
            price = get_price(bot_type)

            if free_bot_credits(user_id) <= 0 and get_balance(user_id) < price:
                send_message(user_id, f"❌ موجودی کافی نیست.\n💰 موجودی: {get_balance(user_id):,}\n💵 قیمت: {price:,}\nبرای شارژ به پشتیبانی پیام بده.")
                del waiting_for[key]
                send_message(user_id, main_menu_text(user_id), kb_main(user_id))
                return

            wait["admin_id"] = new_admin_id
            wait["type"] = "await_admin_cmd"
            send_message(
                user_id,
                "⌨️ پنل مدیریت باتت با چه دستوری بالا بیاد؟\n\n"
                "مثلاً می‌تونی بفرستی: /admin یا /panel یا هر کلمه‌ی دلخواه دیگه\n"
                "اگه فرقی برات نداره و همون پیش‌فرض /admin کافیه، فقط بفرست: -",
                CANCEL_KEYBOARD,
            )
            return

        if wtype == "await_admin_cmd":
            admin_cmd = text.strip()
            if admin_cmd == "-" or not admin_cmd:
                admin_cmd = "/admin"
            elif not admin_cmd.startswith("/"):
                admin_cmd = "/" + admin_cmd

            wait["admin_cmd"] = admin_cmd
            wait["run_mode"] = "polling"
            return finalize_bot_creation(user_id, key, wait)





        if wtype == "stop_bot_id":
            if not text.isdigit():
                send_message(user_id, "❌ فقط شماره بات (#) رو بفرست:", CANCEL_KEYBOARD)
                return
            row = get_bot_by_id(int(text))
            del waiting_for[key]
            if row and row["user_id"] == user_id:
                stop_bot(row["id"])
                send_message(user_id, f"⏹ بات #{row['id']} متوقف شد.", kb_mybots())
            else:
                send_message(user_id, "❌ باتی با این شماره متعلق به تو پیدا نشد.", kb_mybots())
            return

        if wtype == "log_bot_id":
            if not text.isdigit():
                send_message(user_id, "❌ فقط شماره بات (#) رو بفرست:", CANCEL_KEYBOARD)
                return
            row = get_bot_by_id(int(text))
            del waiting_for[key]
            if row and row["user_id"] == user_id:
                row2 = refresh_bot_status(row["id"]) or row
                tail = get_log_tail(row2["folder"])
                send_message(user_id, f"📄 لاگ بات #{row2['id']}\n\n{tail}", kb_mybots())
            else:
                send_message(user_id, "❌ باتی با این شماره متعلق به تو پیدا نشد.", kb_mybots())
            return

        # ---------- انتقال مالکیت بات ----------
        if wtype == "transfer_bot_id":
            if not text.isdigit():
                send_message(user_id, "❌ فقط شماره بات (#) رو بفرست:", CANCEL_KEYBOARD)
                return
            row = get_bot_by_id(int(text))
            if not row or row["user_id"] != user_id:
                del waiting_for[key]
                send_message(user_id, "❌ باتی با این شماره متعلق به تو پیدا نشد.", kb_mybots())
                return
            wait["bot_id"] = row["id"]
            wait["type"] = "transfer_new_owner_id"
            send_message(
                user_id,
                f"👤 آیدی عددی مالک/ادمین جدیدِ بات #{row['id']} رو بفرست:\n"
                "(بعد از تکمیل انتقال، خودت کاملاً و برای همیشه از ادمینیِ این بات خارج می‌شی)",
                CANCEL_KEYBOARD,
            )
            return

        if wtype == "transfer_new_owner_id":
            if not text.isdigit():
                send_message(user_id, "❌ آیدی عددی باید فقط عدد باشه. دوباره بفرست:", CANCEL_KEYBOARD)
                return
            new_owner_id = int(text)
            bot_id = wait["bot_id"]
            if new_owner_id == user_id:
                send_message(user_id, "❌ نمی‌تونی بات رو به خودت منتقل کنی. یه آیدی دیگه بفرست:", CANCEL_KEYBOARD)
                return
            row = get_bot_by_id(bot_id)
            if not row or row["user_id"] != user_id:
                del waiting_for[key]
                send_message(user_id, "❌ این بات دیگه متعلق به تو نیست.", kb_mybots())
                return

            price = int(get_setting("transfer_price", "0") or "0")
            del waiting_for[key]

            if price <= 0:
                ok, err = transfer_bot_ownership(bot_id, new_owner_id)
                finish_transfer_notify(user_id, new_owner_id, bot_id, row["bot_type"], row["admin_cmd"], ok, err, paid_amount=0)
                send_message(user_id, main_menu_text(user_id), kb_main(user_id))
                return

            info = BOT_TYPES.get(row["bot_type"], {"name": row["bot_type"]})
            ok, msg = send_invoice_or_manual(
                user_id, "انتقال مالکیت بات", price, "ownership_transfer",
                meta={"bot_id": bot_id, "new_owner_id": new_owner_id},
                extra_desc=f"انتقال مالکیت بات #{bot_id} ({info['name']}) به آیدی {new_owner_id}",
            )
            send_message(user_id, msg, kb_mybots())
            return

        # ---------- تمدید بات ----------
        if wtype == "renew_bot_id":
            if not text.isdigit():
                send_message(user_id, "❌ فقط شماره بات (#) رو بفرست:", CANCEL_KEYBOARD)
                return
            row = get_bot_by_id(int(text))
            del waiting_for[key]
            if not row or row["user_id"] != user_id:
                send_message(user_id, "❌ باتی با این شماره متعلق به تو پیدا نشد.", kb_mybots())
                return

            days, base_price = get_renewal_settings(row["bot_type"])
            if days <= 0:
                send_message(user_id, "ℹ️ این نوع بات نیازی به تمدید نداره (نامحدوده).", kb_mybots())
                return

            bot_id = row["id"]
            info = BOT_TYPES.get(row["bot_type"], {"name": row["bot_type"]})
            price, applied_code = get_discounted_price(user_id, base_price)

            if price <= 0:
                ok, warn = extend_bot_expiry(bot_id)
                row2 = get_bot_by_id(bot_id)
                if ok:
                    if applied_code: consume_active_discount(user_id)
                    log_payment(user_id, 0, "bot_renewal", f"bot_{bot_id}")
                    notify_purchase_channel(
                        "🔄 تمدید بات (رایگان)\n\n"
                        f"🤖 بات: #{bot_id} - {info['name']}\n"
                        f"👤 کاربر: {user_id}\n"
                        f"🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                    )
                    send_message(
                        user_id,
                        f"✅ بات #{bot_id} ({info['name']}) با موفقیت و رایگان تمدید شد!\n{format_expiry_line(row2)}"
                        + (f"\n\n{warn}" if warn else ""),
                        kb_mybots(),
                    )
                else:
                    send_message(user_id, f"❌ تمدید انجام نشد: {warn}", kb_mybots())
                return

            # اگه موجودیِ کیف پول کافیه، مستقیم از کیف پول کسر و همون لحظه تمدید کن (بدون نیاز به فاکتور بانکی)
            if get_balance(user_id) >= price:
                sub_balance(user_id, price)
                if applied_code: consume_active_discount(user_id)
                ok, warn = extend_bot_expiry(bot_id)
                row2 = get_bot_by_id(bot_id)
                if ok:
                    log_payment(user_id, price, "bot_renewal", f"bot_{bot_id}_wallet")
                    notify_purchase_channel(
                        "🔄 تمدید بات (از کیف پول)\n\n"
                        f"🤖 بات: #{bot_id} - {info['name']}\n"
                        f"👤 کاربر: {user_id}\n"
                        f"💵 مبلغ: {price:,} تومان\n"
                        f"🗓 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                    )
                    send_message(
                        user_id,
                        f"✅ بات #{bot_id} ({info['name']}) با کسر {price:,} تومان از کیف پولت تمدید شد!\n"
                        f"{format_expiry_line(row2)}\n💰 موجودی جدید: {get_balance(user_id):,} تومان"
                        + (f"\n\n{warn}" if warn else ""),
                        kb_mybots(),
                    )
                else:
                    add_balance(user_id, price)  # برگردوندن پول چون تمدید انجام نشد
                    send_message(user_id, f"❌ تمدید انجام نشد و مبلغ به کیف پولت برگشت: {warn}", kb_mybots())
                return

            pay_mode = get_setting("payment_mode", "auto")
            gateway_missing = (
                (pay_mode == "auto" and not PROVIDER_TOKEN)
                or (pay_mode == "manual" and not get_setting("manual_payment_info", ""))
                or (pay_mode == "both" and not PROVIDER_TOKEN and not get_setting("manual_payment_info", ""))
            )
            if gateway_missing:
                send_message(
                    user_id,
                    f"💰 موجودی کیف پولت ({get_balance(user_id):,} تومان) برای تمدید بات #{bot_id} کافی نیست، "
                    "و درگاه پرداخت هم هنوز توسط ادمین تنظیم نشده.\n\n"
                    "برای افزایش موجودی جهت تمدید، به پشتیبانی پیام بده.",
                    kb_mybots(),
                )
                return

            ok, msg = send_invoice_or_manual(
                user_id, "تمدید بات", price, "bot_renewal",
                meta={"bot_id": bot_id, "discount_code": applied_code},
                extra_desc=f"تمدید بات #{bot_id} ({info['name']}) به مدت {days} روز",
            )
            send_message(user_id, f"💰 موجودی کیف پولت ({get_balance(user_id):,} تومان) برای تمدید کافی نبود.\n{msg}", kb_mybots())
            return

        # ---------- 🎟 اعمال کد تخفیف (کاربر) ----------
        if wtype == "redeem_discount_code_input":
            del waiting_for[key]
            ok, res = redeem_discount_code(user_id, text.strip())
            if ok:
                val_line = f"{res['value']}٪" if res["type"] == "percent" else f"{res['value']:,} تومان"
                send_message(
                    user_id,
                    f"✅ کد تخفیف «{res['code']}» ({val_line}) فعال شد!\n"
                    "توی خریدِ ساخت بات یا تمدید بعدیت به‌صورت خودکار اعمال می‌شه.",
                    kb_main(user_id),
                )
            else:
                send_message(user_id, res, kb_main(user_id))
            return

        # ---------- ادمین ----------
        if wtype == "admin_set_price":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (به هزار تومان):", CANCEL_KEYBOARD)
                return
            set_price(wait["bot_type"], parse_thousand_toman(text))
            del waiting_for[key]
            send_message(user_id, "✅ قیمت به‌روزرسانی شد.", kb_admin_prices())
            return

        if wtype == "admin_charge_id":
            if not text.isdigit():
                send_message(user_id, "❌ آیدی عددی کاربر رو بفرست:", CANCEL_KEYBOARD)
                return
            wait["target_id"] = int(text)
            wait["type"] = "admin_charge_amount"
            send_message(user_id, "💰 مبلغ شارژ رو به هزار تومان بفرست (عدد؛ می‌تونه منفی هم باشه برای کسر؛ مثلاً 40 یعنی 40 هزار تومان):", CANCEL_KEYBOARD)
            return

        if wtype == "admin_charge_amount":
            if not text.lstrip("-").isdigit():
                send_message(user_id, "❌ فقط عدد بفرست:", CANCEL_KEYBOARD)
                return
            amount = parse_thousand_toman(text)
            target_id = wait["target_id"]
            add_balance(target_id, amount)
            del waiting_for[key]
            send_message(user_id, f"✅ مبلغ {amount:,} تومان به کاربر {target_id} اضافه شد.\n💰 موجودی جدید: {get_balance(target_id):,}", kb_admin())
            try:
                send_message(target_id, f"🎁 موجودی شما {amount:,} تومان تغییر کرد.\n💰 موجودی فعلی: {get_balance(target_id):,}")
            except Exception:
                pass
            return

        if wtype == "admin_broadcast":
            del waiting_for[key]
            ids = get_all_user_ids()
            count = 0
            for uid in ids:
                try:
                    send_message(uid, text)
                    count += 1
                except Exception:
                    pass
                time.sleep(0.2)
            send_message(user_id, f"✅ پیام همگانی به {count} نفر ارسال شد.", kb_admin())
            return

        if wtype == "admin_ref_reward":
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (به هزار تومان):", CANCEL_KEYBOARD)
                return
            amount = parse_thousand_toman(text)
            set_setting("referral_reward", str(amount))
            del waiting_for[key]
            send_message(user_id, f"✅ پاداش هر دعوت روی {amount:,} تومان تنظیم شد.", kb_admin())
            return

        if wtype == "admin_bulk_charge":
            if not text.lstrip("-").isdigit():
                send_message(user_id, "❌ فقط عدد بفرست:", CANCEL_KEYBOARD)
                return
            amount = parse_thousand_toman(text)
            del waiting_for[key]
            ids = get_all_user_ids()
            for uid in ids:
                add_balance(uid, amount)
            send_message(user_id, f"✅ مبلغ {amount:,} تومان به موجودی همه‌ی {len(ids)} کاربر اضافه شد.", kb_admin())
            return

        if wtype == "admin_bulk_deduct":
            if not text.lstrip("-").isdigit():
                send_message(user_id, "❌ فقط عدد بفرست:", CANCEL_KEYBOARD)
                return
            amount = parse_thousand_toman(text)
            del waiting_for[key]
            ids = get_all_user_ids()
            for uid in ids:
                sub_balance(uid, amount)
            send_message(user_id, f"✅ مبلغ {amount:,} تومان از موجودی همه‌ی {len(ids)} کاربر کسر شد.", kb_admin())
            return

        if wtype == "admin_set_transfer_price":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (0 یعنی رایگان؛ به هزار تومان):", CANCEL_KEYBOARD)
                return
            amount = parse_thousand_toman(text)
            set_setting("transfer_price", str(amount))
            del waiting_for[key]
            price_line = "رایگان 🎁" if amount <= 0 else f"{amount:,} تومان"
            send_message(user_id, f"✅ قیمت انتقال مالکیت بات روی {price_line} تنظیم شد.", kb_admin())
            return

        if wtype == "admin_set_renewal_reminder_days":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست:", CANCEL_KEYBOARD)
                return
            set_setting("renewal_reminder_days", text)
            del waiting_for[key]
            send_message(user_id, f"✅ از {int(text)} روز مونده به سررسید، یادآوری تمدید فرستاده می‌شه.", kb_admin())
            return

        if wtype == "admin_set_renewal_period":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (0 یعنی نامحدود):", CANCEL_KEYBOARD)
                return
            bot_type = wait["bot_type"]
            days = int(text)
            set_renewal_period(bot_type, days)
            if days <= 0:
                del waiting_for[key]
                cleared = clear_bot_type_expiry(bot_type)
                extra = f"\n♻️ سررسید {len(cleared)} بات فعالِ این نوع هم پاک شد (دیگه نیازی به تمدید ندارن)." if cleared else ""
                send_message(user_id, f"✅ تمدید برای «{BOT_TYPES[bot_type]['name']}» غیرفعال شد (نامحدود).{extra}", kb_admin_renewal_types())
                return
            wait["type"] = "admin_set_renewal_price"
            send_message(
                user_id,
                f"💵 حالا قیمت هر بار تمدید برای «{BOT_TYPES[bot_type]['name']}» (هر {days} روز) رو بفرست (به هزار تومان؛ 0 یعنی رایگان؛ مثلاً 40 یعنی 40 هزار تومان):",
                CANCEL_KEYBOARD,
            )
            return

        if wtype == "admin_set_renewal_price":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (0 یعنی رایگان؛ به هزار تومان):", CANCEL_KEYBOARD)
                return
            bot_type = wait["bot_type"]
            set_renewal_price(bot_type, parse_thousand_toman(text))
            del waiting_for[key]
            days, price = get_renewal_settings(bot_type)
            backfilled = backfill_bot_type_expiry(bot_type, days)
            price_line = "رایگان 🎁" if price <= 0 else f"{price:,} تومان"
            extra = (
                f"\n♻️ {len(backfilled)} بات ساخته‌شده‌ی این نوع که قبلاً «نامحدود» بودن، "
                f"از همین الان وارد چرخه‌ی تمدید شدن (سررسید تازه: {days} روز دیگه)."
                if backfilled else ""
            )
            send_message(
                user_id,
                f"✅ تنظیم شد: «{BOT_TYPES[bot_type]['name']}» هر {days} روز، با هزینه‌ی {price_line} تمدید می‌شه.{extra}",
                kb_admin_renewal_types(),
            )
            info_bt = BOT_TYPES.get(bot_type, {"name": bot_type})
            for brow in backfilled:
                try:
                    send_message(
                        brow["user_id"],
                        f"⏳ توجه: بات #{brow['id']} ({info_bt['name']}) شما از این پس هر {days} روز نیاز به تمدید داره "
                        f"(هزینه: {price_line}).\nسررسید بعدی رو از «{BTN_MYBOTS}» می‌تونی ببینی.",
                    )
                except Exception:
                    pass
            return

        if wtype == "admin_renew_bot_id":
            if not text.isdigit():
                send_message(user_id, "❌ فقط شماره بات (#) رو بفرست:", CANCEL_KEYBOARD)
                return
            row = get_bot_by_id(int(text))
            if not row:
                del waiting_for[key]
                send_message(user_id, "❌ باتی با این شماره پیدا نشد.", kb_admin_bots())
                return
            wait["bot_id"] = row["id"]
            wait["type"] = "admin_renew_bot_days"
            default_days, _ = get_renewal_settings(row["bot_type"])
            send_message(
                user_id,
                f"⏳ چند روز به تاریخ انقضای بات #{row['id']} اضافه بشه؟ رو بفرست\n"
                f"(دوره‌ی پیش‌فرض این نوع بات: {default_days if default_days > 0 else 'نامحدود'} روزه):",
                CANCEL_KEYBOARD,
            )
            return

        if wtype == "admin_renew_bot_days":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit() or int(text) <= 0:
                send_message(user_id, "❌ فقط یک عدد مثبت بفرست:", CANCEL_KEYBOARD)
                return
            bot_id = wait["bot_id"]
            del waiting_for[key]
            ok, warn = extend_bot_expiry(bot_id, days=int(text))
            row2 = get_bot_by_id(bot_id)
            if ok:
                log_payment(row2["user_id"], 0, "bot_renewal", f"bot_{bot_id}_admin")
                try:
                    info = BOT_TYPES.get(row2["bot_type"], {"name": row2["bot_type"]})
                    send_message(
                        row2["user_id"],
                        f"🎁 بات #{bot_id} ({info['name']}) توسط پشتیبانی به‌صورت رایگان تمدید شد!\n{format_expiry_line(row2)}",
                        kb_main(row2["user_id"]),
                    )
                except Exception:
                    pass
                send_message(user_id, f"✅ بات #{bot_id} به مدت {text} روز تمدید شد.\n{format_expiry_line(row2)}" + (f"\n\n{warn}" if warn else ""), kb_admin_bots())
            else:
                send_message(user_id, f"❌ تمدید انجام نشد: {warn}", kb_admin_bots())
            return

        # ---------- 🎟 ساخت کد تخفیف (ادمین) ----------
        if wtype == "admin_discount_code_name":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            code = text.strip().upper().replace(" ", "")
            if not code:
                send_message(user_id, "❌ کد نامعتبره، دوباره بفرست:", CANCEL_KEYBOARD)
                return
            wait["code"] = code
            wait["type"] = "admin_discount_code_type"
            send_message(user_id, "نوع تخفیف رو بفرست: «درصد» یا «مبلغ»", CANCEL_KEYBOARD)
            return

        if wtype == "admin_discount_code_type":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if text.strip() not in ("درصد", "مبلغ"):
                send_message(user_id, "❌ فقط «درصد» یا «مبلغ» رو بفرست:", CANCEL_KEYBOARD)
                return
            wait["dtype"] = "percent" if text.strip() == "درصد" else "flat"
            wait["type"] = "admin_discount_code_value"
            unit = "بین 1 تا 100" if wait["dtype"] == "percent" else "به هزار تومان؛ مثلاً 40 یعنی 40 هزار تومان"
            send_message(user_id, f"مقدار تخفیف رو بفرست ({unit}):", CANCEL_KEYBOARD)
            return

        if wtype == "admin_discount_code_value":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit() or int(text) <= 0:
                send_message(user_id, "❌ فقط یک عدد مثبت بفرست:", CANCEL_KEYBOARD)
                return
            raw = int(text)
            if wait["dtype"] == "percent":
                if raw > 100:
                    send_message(user_id, "❌ درصد باید بین 1 تا 100 باشه:", CANCEL_KEYBOARD)
                    return
                wait["value"] = raw
            else:
                wait["value"] = parse_thousand_toman(text)
            wait["type"] = "admin_discount_code_maxuses"
            send_message(user_id, "حداکثر تعداد دفعات استفاده از این کد چند بار باشه؟ (0 = نامحدود):", CANCEL_KEYBOARD)
            return

        if wtype == "admin_discount_code_maxuses":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (0 = نامحدود):", CANCEL_KEYBOARD)
                return
            create_discount_code(wait["code"], wait["dtype"], wait["value"], int(text))
            del waiting_for[key]
            val_line = f"{wait['value']}٪" if wait["dtype"] == "percent" else f"{wait['value']:,} تومان"
            send_message(
                user_id,
                f"✅ کد تخفیف «{wait['code']}» ساخته شد.\n💵 مقدار: {val_line}\nروی خرید ساخت بات و تمدید بات قابل استفاده‌ست.",
                kb_admin_discounts(),
            )
            return

        if wtype == "admin_discount_deactivate":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            del waiting_for[key]
            code = text.strip().upper()
            row = get_discount_code(code)
            if not row:
                send_message(user_id, "❌ همچین کدی پیدا نشد.", kb_admin_discounts())
                return
            deactivate_discount_code(code)
            send_message(user_id, f"✅ کد «{code}» غیرفعال شد.", kb_admin_discounts())
            return

        # ---------- 🎚 ظرفیت بات‌ساز (ادمین) ----------
        if wtype == "admin_set_max_total_bots":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (0 = نامحدود):", CANCEL_KEYBOARD)
                return
            set_setting("max_total_bots", text)
            wait["type"] = "admin_set_max_bots_per_user"
            send_message(user_id, "حالا سقف تعداد بات به‌ازای هر کاربر رو بفرست (0 = نامحدود):", CANCEL_KEYBOARD)
            return

        if wtype == "admin_set_max_bots_per_user":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (0 = نامحدود):", CANCEL_KEYBOARD)
                return
            set_setting("max_bots_per_user", text)
            del waiting_for[key]
            max_total = get_setting("max_total_bots", "0")
            send_message(
                user_id,
                f"✅ تنظیم شد.\n📦 سقف کل بات‌ها: {max_total if max_total != '0' else 'نامحدود'}\n"
                f"👤 سقف هر کاربر: {text if text != '0' else 'نامحدود'}",
                kb_admin(),
            )
            return

        # ---------- 🚫 بلاک/آنبلاک کاربر (ادمین) ----------
        if wtype == "admin_ban_user_id":
            if not is_any_admin(user_id):
                del waiting_for[key]
                return
            del waiting_for[key]
            if not text.isdigit():
                send_message(user_id, "❌ آیدی عددی نامعتبره.", admin_home_kb(user_id))
                return
            ban_user(int(text))
            send_message(user_id, f"🚫 کاربر {text} مسدود شد.", admin_home_kb(user_id))
            try:
                send_message(int(text), "⛔ دسترسی شما به این بات‌ساز مسدود شد.")
            except Exception:
                pass
            return

        if wtype == "admin_unban_user_id":
            if not is_any_admin(user_id):
                del waiting_for[key]
                return
            del waiting_for[key]
            if not text.isdigit():
                send_message(user_id, "❌ آیدی عددی نامعتبره.", admin_home_kb(user_id))
                return
            unban_user(int(text))
            send_message(user_id, f"✅ مسدودیت کاربر {text} رفع شد.", admin_home_kb(user_id))
            try:
                send_message(int(text), "✅ دسترسی شما به بات‌ساز دوباره فعال شد.", kb_main(int(text)))
            except Exception:
                pass
            return

        # ---------- 🕐 فاصله‌ی بکاپ خودکار (ادمین) ----------
        if wtype == "admin_set_backup_interval":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            if not text.isdigit():
                send_message(user_id, "❌ فقط عدد بفرست (ساعت؛ 0 = غیرفعال):", CANCEL_KEYBOARD)
                return
            set_setting("backup_interval_hours", text)
            del waiting_for[key]
            msg = "بکاپ خودکار غیرفعال شد." if text == "0" else f"✅ هر {text} ساعت یک‌بار بکاپ خودکار گرفته می‌شه."
            send_message(user_id, msg, kb_admin())
            return

        if wtype == "admin_set_lottery_broadcast_text":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            set_setting("lottery_broadcast_text", text)
            del waiting_for[key]
            send_message(user_id, "✅ متن همگانیِ اعلام برنده به‌روزرسانی شد.", kb_admin())
            return

        if wtype == "admin_set_lottery_winner_text":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            set_setting("lottery_winner_dm_text", text)
            del waiting_for[key]
            send_message(user_id, "✅ متن خصوصیِ برنده به‌روزرسانی شد.", kb_admin())
            return

        if wtype == "admin_set_lottery_other_text":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            set_setting("lottery_other_text", text)
            del waiting_for[key]
            send_message(user_id, "✅ متن خصوصیِ سایر شرکت‌کنندگان به‌روزرسانی شد.", kb_admin())
            return

        if wtype == "admin_set_payment_mode":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            mapping = {"خودکار": "auto", "دستی": "manual", "هردو": "both"}
            if text.strip() not in mapping:
                send_message(user_id, "❌ یکی از این‌ها رو بفرست: «خودکار» یا «دستی» یا «هردو»", {"keyboard": [[{"text": "خودکار"}, {"text": "دستی"}, {"text": "هردو"}], [{"text": CANCEL_KEYBOARD_TEXT}]], "resize_keyboard": True})
                return
            set_setting("payment_mode", mapping[text.strip()])
            del waiting_for[key]
            send_message(user_id, f"✅ حالت پرداخت روی «{text.strip()}» تنظیم شد.", kb_admin())
            return

        if wtype == "admin_set_manual_info":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            set_setting("manual_payment_info", text)
            del waiting_for[key]
            send_message(user_id, "✅ متن پرداخت دستی ذخیره شد.", kb_admin())
            return

        if wtype == "admin_set_support_text":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            set_setting("support_text", text)
            del waiting_for[key]
            send_message(user_id, "✅ متن/آیدی پشتیبانی ذخیره شد.", kb_admin())
            return

        if wtype == "admin_set_welcome_text":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            set_setting("welcome_text", text)
            del waiting_for[key]
            send_message(user_id, "✅ پیام خوش‌آمد ذخیره شد.", kb_admin())
            return

        if wtype == "admin_manual_payment_action":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            t = text.strip()
            reject = False
            if t.startswith("رد"):
                reject = True
                t = t.replace("رد", "").strip()
            if not t.isdigit():
                send_message(user_id, "❌ فقط شماره‌ی درخواست (یا «رد <شماره>») رو بفرست:", CANCEL_KEYBOARD)
                return
            req_id = int(t)
            req = get_manual_payment(req_id)
            if not req or req["status"] != "pending":
                send_message(user_id, "❌ این درخواست پیدا نشد یا قبلاً بررسی شده.", CANCEL_KEYBOARD)
                return
            if reject:
                set_manual_payment_status(req_id, "rejected")
                del waiting_for[key]
                send_message(user_id, f"✅ درخواست #{req_id} رد شد.", kb_admin())
                try:
                    send_message(req["user_id"], f"❌ درخواست پرداخت دستی #{req_id} تو ({req['amount']:,} تومان) توسط ادمین رد شد.\nبه پشتیبانی پیام بده.", kb_main(req["user_id"]))
                except Exception:
                    pass
                return
            meta = json.loads(req["meta"] or "{}")
            ok, result_msg = complete_purchase(req["user_id"], req["amount"], req["purpose"], meta, track_code=f"manual_{req_id}")
            if ok:
                set_manual_payment_status(req_id, "approved")
                del waiting_for[key]
                send_message(user_id, f"✅ درخواست #{req_id} تایید و انجام شد.", kb_admin())
                try:
                    send_message(req["user_id"], f"✅ پرداخت دستیت (درخواست #{req_id}) تایید شد!\n\n{result_msg}", kb_main(req["user_id"]))
                except Exception:
                    pass
            else:
                send_message(user_id, f"❌ تایید شد ولی انجام عملیات با خطا مواجه شد: {result_msg}\nدرخواست همچنان در انتظاره.", CANCEL_KEYBOARD)
            return

        if wtype == "admin_set_purchase_channel":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            t = text.strip()
            if t == "0":
                set_setting("purchase_channel_id", "")
                del waiting_for[key]
                send_message(user_id, "✅ کانال گزارش خریدها غیرفعال شد.", kb_admin())
                return
            if not t.lstrip("-").isdigit():
                send_message(user_id, "❌ فقط آیدی عددی کانال رو بفرست (یا 0 برای غیرفعال کردن):", CANCEL_KEYBOARD)
                return
            set_setting("purchase_channel_id", t)
            del waiting_for[key]
            test = send_message(int(t), "✅ این کانال به‌عنوان کانال گزارش خریدهای بات‌ساز تنظیم شد.")
            if not test or not test.get("ok"):
                send_message(
                    user_id,
                    "⚠️ آیدی ذخیره شد ولی ارسال پیام تست به کانال ناموفق بود؛ مطمئن شو بات‌ساز داخل اون کانال ادمینه.",
                    kb_admin(),
                )
            else:
                send_message(user_id, "✅ کانال خریدها با موفقیت تنظیم شد و پیام تست هم ارسال شد.", kb_admin())
            return

        if wtype == "admin_set_required_channel_id":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            t = text.strip()
            if t == "0":
                set_setting("required_channel_id", "")
                set_setting("required_channel_link", "")
                del waiting_for[key]
                send_message(user_id, "✅ جوین اجباری کانال کاملاً غیرفعال شد.", kb_admin())
                return
            if not (t.lstrip("-").isdigit() or t.startswith("@")):
                send_message(user_id, "❌ آیدی عددی کانال (یا @یوزرنیم) رو بفرست، یا 0 برای غیرفعال کردن:", CANCEL_KEYBOARD)
                return
            test = api_request("getChatMember", {"chat_id": t, "user_id": ADMIN_ID})
            if not test.get("ok"):
                send_message(
                    user_id,
                    "⚠️ نتونستم به این کانال دسترسی پیدا کنم. مطمئن شو بات‌ساز داخل اون کانال ادمینه و آیدی درسته.\n"
                    "اگه مطمئنی درسته، دوباره همین آیدی رو بفرست تا با همین ادامه بدیم.",
                    CANCEL_KEYBOARD,
                )
                # اجازه بده اگه ادمین دوباره همون رو فرستاد، بدون چک دوباره قبول بشه
                waiting_for[key] = {"type": "admin_set_required_channel_id_force", "value": t}
                return
            waiting_for[key] = {"type": "admin_set_required_channel_link", "channel_id": t}
            send_message(
                user_id,
                f"✅ آیدی کانال ({t}) تایید شد.\n\n"
                "حالا لینک/یوزرنیم عمومی کانال (که به کاربر نشون داده می‌شه تا بتونه عضو بشه) رو بفرست "
                "(مثلاً https://ble.ir/join/xxxx یا @channel):",
                CANCEL_KEYBOARD,
            )
            return

        if wtype == "admin_set_required_channel_id_force":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            t = wait.get("value", text.strip())
            waiting_for[key] = {"type": "admin_set_required_channel_link", "channel_id": t}
            send_message(
                user_id,
                f"⚠️ بدون تایید دسترسی، آیدی کانال ({t}) ذخیره می‌شه (چک عضویت ممکنه کار نکنه تا وقتی بات‌ساز رو ادمین کانال کنی).\n\n"
                "حالا لینک/یوزرنیم عمومی کانال رو بفرست:",
                CANCEL_KEYBOARD,
            )
            return

        if wtype == "admin_set_required_channel_link":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            channel_id = wait["channel_id"]
            set_setting("required_channel_id", channel_id)
            set_setting("required_channel_link", text.strip())
            del waiting_for[key]
            send_message(
                user_id,
                f"✅ جوین اجباری کانال فعال شد.\nآیدی کانال: {channel_id}\nلینک نمایشی: {text.strip()}",
                kb_admin(),
            )
            return

        if wtype == "admin_add_subadmin_id":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            del waiting_for[key]
            if not text.isdigit():
                send_message(user_id, "❌ آیدی عددی نامعتبره.", kb_admin_manage_admins())
                return
            new_id = int(text)
            if str(new_id) == str(ADMIN_ID):
                send_message(user_id, "❌ این آیدی همون ادمین اصلیه.", kb_admin_manage_admins())
                return
            add_admin(new_id, "support", user_id)
            send_message(user_id, f"✅ کاربر {new_id} به‌عنوان ادمین پشتیبانی اضافه شد.", kb_admin_manage_admins())
            try:
                send_message(new_id, "🛟 تبریک! شما به‌عنوان ادمین پشتیبانی این بات‌ساز تعیین شدید.\nاز منوی اصلی، دکمه‌ی «👑 پنل مدیریت» رو بزنید.", kb_main(new_id))
            except Exception:
                pass
            return

        if wtype == "admin_remove_subadmin_id":
            if str(user_id) != str(ADMIN_ID):
                del waiting_for[key]
                return
            del waiting_for[key]
            if not text.isdigit():
                send_message(user_id, "❌ آیدی عددی نامعتبره.", kb_admin_manage_admins())
                return
            rm_id = int(text)
            removed = remove_admin(rm_id)
            msg = f"✅ ادمین {rm_id} حذف شد." if removed else f"❌ ادمینی با آیدی {rm_id} پیدا نشد."
            send_message(user_id, msg, kb_admin_manage_admins())
            return

        if wtype == "admin_bot_stop_id":
            del waiting_for[key]
            if not text.isdigit():
                send_message(user_id, "❌ شماره بات نامعتبره.", kb_admin_bots())
                return
            row = get_bot_by_id(int(text))
            if row:
                stop_bot(row["id"])
                send_message(user_id, f"⏹ بات #{row['id']} خاموش شد.", kb_admin_bots())
            else:
                send_message(user_id, "❌ باتی با این شماره پیدا نشد.", kb_admin_bots())
            return

        if wtype in ("admin_bot_backup_id", "admin_bot_db_id"):
            del waiting_for[key]
            if not text.isdigit():
                send_message(user_id, "❌ شماره بات نامعتبره.", kb_admin_bots())
                return
            row = get_bot_by_id(int(text))
            if not row:
                send_message(user_id, "❌ باتی با این شماره پیدا نشد.", kb_admin_bots())
                return
            only_data = (wtype == "admin_bot_db_id")
            send_message(user_id, "⏳ در حال آماده‌سازی فایل...")
            zpath = zip_folder(row["folder"], only_data=only_data)
            label = "دیتابیس" if only_data else "بکاپ کامل"
            send_document(user_id, zpath, caption=f"{label} بات #{row['id']} ({row['bot_type']})")
            try:
                os.remove(zpath)
            except Exception:
                pass
            send_message(user_id, "تمام شد.", kb_admin_bots())
            return

    # ---------- /start (با یا بدون رفرال) ----------
    if text.startswith("/start"):
        referrer_id = handle_referral_start(user_id, text)
        is_new = ensure_user(user_id, username, first_name, referred_by=referrer_id)
        if is_new and referrer_id:
            reward = int(get_setting("referral_reward", "1000"))
            add_balance(referrer_id, reward)
            increment_invited_count(referrer_id)
            try:
                send_message(referrer_id, f"🎉 یک نفر با لینک شما وارد بات شد و {reward:,} تومان جایزه به موجودی شما اضافه شد!")
            except Exception:
                pass
        if not is_any_admin(user_id) and not is_member_of_required_channel(user_id):
            send_message(user_id, required_channel_join_text(), kb_join_channel())
            return
        send_message(user_id, main_menu_text(user_id), kb_main(user_id))
        return

    ensure_user(user_id, username, first_name)

    # ---------- 🔒 جوین اجباری کانال ----------
    if not is_any_admin(user_id):
        if text == BTN_CHECK_CHANNEL_JOIN:
            if is_member_of_required_channel(user_id):
                send_message(user_id, "✅ عضویتت تایید شد، خوش اومدی!", kb_main(user_id))
            else:
                send_message(user_id, "❌ هنوز عضو کانال نشدی. اول عضو شو، بعد دوباره همین دکمه رو بزن.", kb_join_channel())
            return
        if not is_member_of_required_channel(user_id):
            send_message(user_id, required_channel_join_text(), kb_join_channel())
            return

    # ---------- دکمه‌های اصلی ----------
    if text == BTN_BACK_MAIN:
        send_message(user_id, main_menu_text(user_id), kb_main(user_id))
        return

    if text == BTN_CREATE:
        cap_ok, cap_msg = check_creation_capacity(user_id)
        if not cap_ok:
            send_message(user_id, cap_msg, kb_main(user_id))
            return
        send_message(user_id, create_menu_text(), kb_create())
        return

    if text == BTN_SUPPORT:
        send_message(user_id, get_setting("support_text"), kb_main(user_id))
        return

    if text == BTN_HELP:
        send_message(user_id, get_setting("help_text"), kb_main(user_id))
        return

    if text == BTN_MYBOTS:
        send_message(user_id, mybots_text(user_id), kb_mybots())
        return

    if text == BTN_PROFILE:
        send_message(user_id, profile_text(user_id), kb_main(user_id))
        return

    if text == BTN_CHARGE_WALLET:
        pay_mode = get_setting("payment_mode", "auto")
        if pay_mode == "auto" and not PROVIDER_TOKEN:
            send_message(user_id, "⚠️ درگاه پرداخت هنوز توسط ادمین تنظیم نشده. برای شارژ به پشتیبانی پیام بده.", kb_main(user_id))
            return
        if pay_mode == "manual" and not get_setting("manual_payment_info", ""):
            send_message(user_id, "⚠️ روش پرداخت دستی هنوز توسط ادمین تنظیم نشده. برای شارژ به پشتیبانی پیام بده.", kb_main(user_id))
            return
        waiting_for[key] = {"type": "charge_wallet_amount"}
        send_message(user_id, "💳 چند هزار تومان می‌خوای کیف پولت رو شارژ کنی؟ عدد رو بفرست (مثلاً 40 یعنی 40 هزار تومان):", CANCEL_KEYBOARD)
        return

    if text == BTN_DISCOUNT_REDEEM:
        u = get_user(user_id)
        if u and u["active_discount_code"]:
            val_line = f"{u['active_discount_value']}٪" if u["active_discount_type"] == "percent" else f"{u['active_discount_value']:,} تومان"
            send_message(
                user_id,
                f"🎟 الان یک کد فعال داری: «{u['active_discount_code']}» ({val_line})\n"
                "توی خرید ساخت بات یا تمدید بعدیت خودکار اعمال می‌شه.\n\n"
                "برای جایگزینی، کد جدید رو بفرست:",
                CANCEL_KEYBOARD,
            )
        else:
            send_message(user_id, "🎟 کد تخفیفت رو بفرست:", CANCEL_KEYBOARD)
        waiting_for[key] = {"type": "redeem_discount_code_input"}
        return

    if text == BTN_LOTTERY:
        send_message(user_id, lottery_text(user_id), kb_lottery(user_id)); return
    if text in ("🎁 شرکت در قرعه‌کشی","✅ شما شرکت کرده‌اید"):
        ok,msg=join_lottery(user_id); send_message(user_id,msg+"\n\n"+lottery_text(user_id),kb_lottery(user_id)); return
    if text == "🏆 برنده دوره قبل":
        p=db().execute("SELECT * FROM lottery_periods WHERE drawn=1 ORDER BY id DESC LIMIT 1").fetchone()
        who=(f"@{p['winner_username']}" if p and p["winner_username"] else (f"کاربر {p['winner_id']}" if p else "هنوز ثبت نشده"))
        send_message(user_id,f"🏆 برنده دوره قبل:\n\n👤 {who}\n🎁 جایزه: یک امتیاز ساخت ربات رایگان",kb_lottery(user_id)); return
    if text == "👥 شرکت‌کنندگان":
        p=ensure_lottery_period(); n=db().execute("SELECT COUNT(*) c FROM lottery_entries WHERE period_id=?",(p["id"],)).fetchone()["c"]
        send_message(user_id,f"👥 تعداد شرکت‌کنندگان دوره فعلی: {n}",kb_lottery(user_id)); return
    if text == "📋 قوانین قرعه‌کشی":
        send_message(user_id,"📋 قوانین قرعه‌کشی\n\n• هر شب ساعت ۲۲:۳۰ قرعه‌کشی انجام می‌شود.\n• ثبت‌نام تا ساعت ۲۲:۰۰ روز بعد باز است.\n• شانس = ۱ + تعداد زیرمجموعه‌های مستقیم.\n• هر کاربر در هر دوره فقط یک‌بار شرکت می‌کند.\n• جایزه: یک امتیاز ساخت ربات رایگان.\n• همه مراحل کاملاً خودکار انجام می‌شود.",kb_lottery(user_id)); return

    if text == BTN_REFERRAL:
        send_message(
            user_id, referral_text(user_id),
            {"keyboard": [[{"text": BTN_REFERRAL_LEADERBOARD}], [{"text": BTN_BACK_MAIN}]], "resize_keyboard": True},
        )
        return

    if text == BTN_REFERRAL_LEADERBOARD:
        send_message(
            user_id, referral_leaderboard_text(),
            {"keyboard": [[{"text": BTN_REFERRAL_LEADERBOARD}], [{"text": BTN_BACK_MAIN}]], "resize_keyboard": True},
        )
        return

    if text == BTN_STOP_A_BOT:
        waiting_for[key] = {"type": "stop_bot_id"}
        send_message(user_id, "شماره بات (#) که می‌خوای متوقفش کنی رو بفرست:", CANCEL_KEYBOARD)
        return

    if text == BTN_LOG_A_BOT:
        waiting_for[key] = {"type": "log_bot_id"}
        send_message(user_id, "شماره بات (#) که می‌خوای لاگش رو ببینی رو بفرست:", CANCEL_KEYBOARD)
        return

    if text == BTN_TRANSFER_BOT:
        transfer_price = int(get_setting("transfer_price", "0") or "0")
        price_line = "رایگانه 🎁" if transfer_price <= 0 else f"{transfer_price:,} تومان (با پرداخت آنلاین خودکار)"
        waiting_for[key] = {"type": "transfer_bot_id"}
        send_message(
            user_id,
            f"🔁 انتقال مالکیت بات\n\n💵 هزینه‌ی انتقال مالکیت: {price_line}\n\n"
            "شماره بات (#) که می‌خوای مالکیتش رو منتقل کنی رو بفرست:",
            CANCEL_KEYBOARD,
        )
        return

    if text == BTN_RENEW_BOT:
        waiting_for[key] = {"type": "renew_bot_id"}
        send_message(
            user_id,
            "🔄 تمدید بات\n\nشماره بات (#) که می‌خوای تمدیدش کنی رو بفرست:",
            CANCEL_KEYBOARD,
        )
        return

    # ---------- انتخاب نوع بات برای ساخت ----------
    bot_type_match = None
    for bkey, info in BOT_TYPES.items():
        if text == info["name"]:
            bot_type_match = bkey
            break
    if bot_type_match:
        cap_ok, cap_msg = check_creation_capacity(user_id)
        if not cap_ok:
            send_message(user_id, cap_msg, kb_main(user_id))
            return
        price = get_price(bot_type_match)
        discounted_price, applied_code = get_discounted_price(user_id, price)
        if get_balance(user_id) < discounted_price:
            send_message(
                user_id,
                f"❌ موجودی کافی نیست.\n💰 موجودی: {get_balance(user_id):,}\n💵 قیمت: {discounted_price:,}\nبرای شارژ به پشتیبانی پیام بده.",
                kb_create(),
            )
            return
        waiting_for[key] = {"type": "await_token", "bot_type": bot_type_match}
        price_line = f"💵 قیمت: {discounted_price:,} تومان" if price == discounted_price else f"💵 قیمت: {price:,} تومان → با کد تخفیف: {discounted_price:,} تومان"
        renewal_days, renewal_price = get_renewal_settings(bot_type_match)
        renewal_line = ""
        if renewal_days > 0:
            rprice_line = "رایگان" if renewal_price <= 0 else f"{renewal_price:,} تومان"
            renewal_line = f"\n⏳ این نوع بات هر {renewal_days} روز نیاز به تمدید داره (هزینه‌ی هر بار تمدید: {rprice_line}).\n"
        send_message(
            user_id,
            f"{BOT_TYPES[bot_type_match]['name']} انتخاب شد ✅\n\n{price_line}{renewal_line}\n"
            "🔑 حالا توکن بات جدیدت (که از بله گرفتی) رو بفرست:",
            CANCEL_KEYBOARD,
        )
        return

    # ---------- پنل ادمین ----------
    is_admin_user = is_full_admin(user_id)          # دسترسی کامل (ADMIN_ID یا ادمین‌های نقش full)
    is_support_admin_user = is_any_admin(user_id)   # دسترسی محدود (نقش support هم همینو داره)

    if text == BTN_ADMIN and is_support_admin_user:
        if is_admin_user:
            send_message(user_id, "👑 پنل مدیریت بات‌ساز", kb_admin())
        else:
            send_message(user_id, "🛟 پنل پشتیبانی", kb_admin_support())
        return

    if is_admin_user and text == BTN_ADMIN_DASHBOARD:
        send_message(user_id, admin_dashboard_text(), kb_admin())
        return

    if is_admin_user and text == BTN_ADMIN_PRICES:
        send_message(user_id, "💵 روی نوع بات موردنظر بزن تا قیمتش رو تغییر بدی:", kb_admin_prices())
        return

    if is_admin_user and text == BTN_BACK_ADMIN:
        send_message(user_id, "👑 پنل مدیریت بات‌ساز", kb_admin())
        return

    if is_admin_user:
        matched_type = match_price_button(text)
        if matched_type:
            waiting_for[key] = {"type": "admin_set_price", "bot_type": matched_type}
            send_message(user_id, f"💵 قیمت جدید برای «{BOT_TYPES[matched_type]['name']}» رو بفرست (به هزار تومان؛ مثلاً 40 یعنی 40 هزار تومان):", CANCEL_KEYBOARD)
            return

    if is_admin_user and text == BTN_ADMIN_CHARGE:
        waiting_for[key] = {"type": "admin_charge_id"}
        send_message(user_id, "👤 آیدی عددی کاربری که می‌خوای شارژ کنی رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_BROADCAST:
        waiting_for[key] = {"type": "admin_broadcast"}
        send_message(user_id, "📨 پیامی که می‌خوای برای همه ارسال بشه رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_REF_REWARD:
        current = get_setting("referral_reward", "1000")
        waiting_for[key] = {"type": "admin_ref_reward"}
        send_message(user_id, f"🎁 مبلغ فعلی پاداش هر دعوت: {int(current):,} تومان\n\nمبلغ جدید رو بفرست (به هزار تومان؛ مثلاً 40 یعنی 40 هزار تومان):", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_BULK_CHARGE:
        waiting_for[key] = {"type": "admin_bulk_charge"}
        send_message(user_id, "💳 مبلغی که می‌خوای به موجودی همه‌ی کاربران اضافه بشه رو بفرست (به هزار تومان):", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_BULK_DEDUCT:
        waiting_for[key] = {"type": "admin_bulk_deduct"}
        send_message(user_id, "➖ مبلغی که می‌خوای از موجودی همه‌ی کاربران کسر بشه رو بفرست (به هزار تومان):", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_TRANSFER_PRICE:
        current = get_setting("transfer_price", "0")
        waiting_for[key] = {"type": "admin_set_transfer_price"}
        send_message(
            user_id,
            f"🔁 قیمت فعلی انتقال مالکیت بات: {int(current or 0):,} تومان\n(0 یعنی رایگان)\n\nمبلغ جدید رو بفرست (به هزار تومان):",
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_PAYMENT_MODE:
        current = get_setting("payment_mode", "auto")
        current_fa = {"auto": "فقط خودکار (درگاه آنلاین)", "manual": "فقط دستی (کارت‌به‌کارت)", "both": "هردو (کاربر انتخاب می‌کنه)"}.get(current, current)
        waiting_for[key] = {"type": "admin_set_payment_mode"}
        send_message(
            user_id,
            f"💳 حالت پرداخت فعلی: {current_fa}\n\n"
            "یکی از این‌ها رو بفرست:\n«خودکار» یا «دستی» یا «هردو»",
            {"keyboard": [[{"text": "خودکار"}, {"text": "دستی"}, {"text": "هردو"}], [{"text": CANCEL_KEYBOARD_TEXT}]], "resize_keyboard": True},
        )
        return

    if is_admin_user and text == BTN_ADMIN_MANUAL_INFO:
        current = get_setting("manual_payment_info", "")
        cur_line = f"\n\n📌 متن فعلی:\n{current}" if current else "\n\nهنوز چیزی تنظیم نشده."
        waiting_for[key] = {"type": "admin_set_manual_info"}
        send_message(
            user_id,
            "🏦 شماره کارت/شبا و توضیحاتی که به کاربر برای پرداخت دستی نشون داده بشه رو بفرست:" + cur_line,
            CANCEL_KEYBOARD,
        )
        return

    if is_support_admin_user and text == BTN_ADMIN_SUPPORT_TEXT:
        current = get_setting("support_text", "")
        cur_line = f"\n\n📌 متن فعلی:\n{current}" if current else "\n\nهنوز چیزی تنظیم نشده."
        waiting_for[key] = {"type": "admin_set_support_text"}
        send_message(
            user_id,
            "🎧 متن/آیدی پشتیبانی که با زدن دکمه‌ی «🎧 پشتیبانی» به کاربر نشون داده می‌شه رو بفرست "
            "(می‌تونی آیدی عددی، یوزرنیم یا هر متن دلخواه دیگه‌ای رو داخلش بذاری):" + cur_line,
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_WELCOME_TEXT:
        current = get_setting("welcome_text", DEFAULT_WELCOME_TEXT)
        waiting_for[key] = {"type": "admin_set_welcome_text"}
        send_message(
            user_id,
            "👋 پیام خوش‌آمدی که موقع ورود به منوی اصلی به کاربر نشون داده می‌شه رو بفرست.\n"
            "اگه بخوای می‌تونی داخلش از «{balance}» استفاده کنی تا خودکار با موجودی کاربر جایگزین بشه "
            "(اختیاریه؛ اگه ننویسیش هم مشکلی نیست).\n\n"
            f"📌 متن فعلی:\n{current}",
            CANCEL_KEYBOARD,
        )
        return

    if is_support_admin_user and text == BTN_ADMIN_MANUAL_REQUESTS:
        pending = list_pending_manual_payments()
        if not pending:
            send_message(user_id, "🧾 هیچ درخواست پرداخت دستیِ در انتظاری وجود نداره.", admin_home_kb(user_id))
            return
        lines = ["🧾 درخواست‌های پرداخت دستیِ در انتظار:\n"]
        for r in pending:
            lines.append(f"#{r['id']} - کاربر {r['user_id']} - {r['amount']:,} تومان - {PAYMENT_TYPE_FA.get(r['purpose'], r['purpose'])}")
        lines.append("\nبرای تایید، شماره‌ی درخواست رو بفرست.\nبرای رد، «رد <شماره>» رو بفرست (مثلاً: رد 3)")
        waiting_for[key] = {"type": "admin_manual_payment_action"}
        send_message(user_id, "\n".join(lines), CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_PURCHASE_CHANNEL:
        current = get_setting("purchase_channel_id", "")
        cur_line = f"\n\n📌 کانال فعلی: {current}" if current else "\n\nهنوز کانالی تنظیم نشده."
        waiting_for[key] = {"type": "admin_set_purchase_channel"}
        send_message(
            user_id,
            "📢 آیدی عددی کانالی که می‌خوای گزارش هر خرید/تراکنش (شارژ کیف پول، خرید ساخت بات، انتقال مالکیت) توش ارسال بشه رو بفرست.\n"
            "⚠️ حتماً باید بات‌ساز داخل اون کانال ادمین باشه.\n"
            "برای غیرفعال کردن، عدد 0 رو بفرست." + cur_line,
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_REQUIRED_CHANNEL:
        cur_id = get_setting("required_channel_id", "")
        cur_link = get_setting("required_channel_link", "")
        if cur_id:
            status_line = f"\n\n📌 وضعیت فعلی: فعال\nآیدی کانال: {cur_id}\nلینک نمایشی: {cur_link or '(تنظیم نشده)'}"
        else:
            status_line = "\n\n📌 وضعیت فعلی: غیرفعال"
        waiting_for[key] = {"type": "admin_set_required_channel_id"}
        send_message(
            user_id,
            "🔒 جوین اجباری کانال\n\n"
            "آیدی عددی یا یوزرنیم (با @) کانالی که کاربرا باید قبل از استفاده از بات‌ساز عضوش بشن رو بفرست.\n"
            "⚠️ حتماً باید بات‌ساز داخل اون کانال ادمین باشه تا بتونه عضویت رو چک کنه.\n"
            "برای غیرفعال کردن کامل این قابلیت، عدد 0 رو بفرست." + status_line,
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_MANAGE_ADMINS:
        send_message(user_id, "🛡 مدیریت ادمین‌های پشتیبانی", kb_admin_manage_admins())
        return

    if is_admin_user and text == BTN_ADMIN_LIST_ADMINS:
        rows = list_admins()
        if not rows:
            send_message(user_id, f"👑 ادمین اصلی: {ADMIN_ID}\n\nهیچ ادمین پشتیبانی دیگه‌ای اضافه نشده.", kb_admin_manage_admins())
            return
        lines = [f"👑 ادمین اصلی: {ADMIN_ID}\n", "🛟 ادمین‌های پشتیبانی:"]
        for r in rows:
            lines.append(f"  • {r['user_id']} (نقش: {r['role']})")
        send_message(user_id, "\n".join(lines), kb_admin_manage_admins())
        return

    if is_admin_user and text == BTN_ADMIN_ADD_SUBADMIN:
        waiting_for[key] = {"type": "admin_add_subadmin_id"}
        send_message(user_id, "➕ آیدی عددی کاربری که می‌خوای ادمین پشتیبانی بشه رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_REMOVE_SUBADMIN:
        waiting_for[key] = {"type": "admin_remove_subadmin_id"}
        send_message(user_id, "➖ آیدی عددی ادمینی که می‌خوای حذفش کنی رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_RENEWAL_SETTINGS:
        send_message(
            user_id,
            "⏳ دوره و قیمت تمدید بات‌ها\n\n"
            "روی هر نوع بات بزن تا اول تعداد روزهای دوره‌ی تمدیدش (0 یعنی نامحدود/بدون نیاز به تمدید) "
            "و بعد قیمت هر بار تمدیدش (0 یعنی رایگان) رو تنظیم کنی:",
            kb_admin_renewal_types(),
        )
        return

    if is_admin_user and text == BTN_ADMIN_RENEWAL_REMINDER:
        current = get_setting("renewal_reminder_days", "1")
        waiting_for[key] = {"type": "admin_set_renewal_reminder_days"}
        send_message(
            user_id,
            f"⏰ الان از {current} روز مونده به سررسید، هر روز یادآوری تمدید فرستاده می‌شه.\n\n"
            "عدد جدید (تعداد روز) رو بفرست:",
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user:
        matched_renewal_type = match_renewal_type_button(text)
        if matched_renewal_type:
            waiting_for[key] = {"type": "admin_set_renewal_period", "bot_type": matched_renewal_type}
            send_message(
                user_id,
                f"⏳ تعداد روزهای دوره‌ی تمدید برای «{BOT_TYPES[matched_renewal_type]['name']}» رو بفرست "
                "(عدد؛ 0 یعنی این نوع بات نیازی به تمدید نداره/نامحدوده):",
                CANCEL_KEYBOARD,
            )
            return

    # ---------- 🎟 کدهای تخفیف (ادمین) ----------
    if is_admin_user and text == BTN_ADMIN_DISCOUNTS:
        send_message(user_id, "🎟 مدیریت کدهای تخفیف:", kb_admin_discounts())
        return

    if is_admin_user and text == BTN_ADMIN_DISCOUNT_NEW:
        waiting_for[key] = {"type": "admin_discount_code_name"}
        send_message(user_id, "🎟 یک کد دلخواه (مثلاً OFF20) رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_DISCOUNT_LIST:
        codes = list_discount_codes()
        if not codes:
            send_message(user_id, "هیچ کد تخفیفی هنوز ساخته نشده.", kb_admin_discounts())
            return
        lines = ["🎟 کدهای تخفیف:\n"]
        for c in codes:
            val_line = f"{c['value']}٪" if c["type"] == "percent" else f"{c['value']:,} تومان"
            uses_line = f"{c['used_count']}/{c['max_uses']}" if c["max_uses"] else f"{c['used_count']}/نامحدود"
            active_line = "✅ فعال" if c["active"] else "❌ غیرفعال"
            lines.append(f"«{c['code']}» - {val_line} - استفاده: {uses_line} - {active_line}")
        lines.append("\nبرای غیرفعال‌کردن یک کد، متن دقیق کد رو بفرست (بدون گیومه).")
        waiting_for[key] = {"type": "admin_discount_deactivate"}
        send_message(user_id, "\n".join(lines), CANCEL_KEYBOARD)
        return

    # ---------- 📊 گزارش درآمد ----------
    if is_admin_user and text == BTN_ADMIN_REPORT:
        send_message(user_id, income_report_text(), kb_admin())
        return

    # ---------- 🎚 ظرفیت بات‌ساز ----------
    if is_admin_user and text == BTN_ADMIN_CAPACITY:
        max_total = get_setting("max_total_bots", "0")
        max_per_user = get_setting("max_bots_per_user", "0")
        waiting_for[key] = {"type": "admin_set_max_total_bots"}
        send_message(
            user_id,
            f"🎚 محدودیت ظرفیت بات‌ساز\n\n"
            f"📦 سقف کل بات‌های قابل ساخت: {max_total if max_total != '0' else 'نامحدود'} (الان: {total_bots_count()} بات ساخته شده)\n"
            f"👤 سقف بات به‌ازای هر کاربر: {max_per_user if max_per_user != '0' else 'نامحدود'}\n\n"
            "✏️ عدد جدید برای «سقف کل بات‌ها» رو بفرست (0 = نامحدود):",
            CANCEL_KEYBOARD,
        )
        return

    # ---------- 🚫 بلاک/آنبلاک کاربر ----------
    if is_support_admin_user and text == BTN_ADMIN_BAN_USER:
        waiting_for[key] = {"type": "admin_ban_user_id"}
        send_message(user_id, "🚫 آیدی عددی کاربری که می‌خوای مسدودش کنی رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_support_admin_user and text == BTN_ADMIN_UNBAN_USER:
        waiting_for[key] = {"type": "admin_unban_user_id"}
        send_message(user_id, "✅ آیدی عددی کاربری که می‌خوای رفع مسدودیت کنی رو بفرست:", CANCEL_KEYBOARD)
        return

    # ---------- 🕐 فاصله‌ی بکاپ خودکار ----------
    if is_admin_user and text == BTN_ADMIN_BACKUP_INTERVAL:
        current = get_setting("backup_interval_hours", "24")
        waiting_for[key] = {"type": "admin_set_backup_interval"}
        send_message(
            user_id,
            f"🕐 الان هر {current} ساعت یک‌بار از دیتابیس بات‌ساز بکاپ خودکار گرفته می‌شه و برات فرستاده می‌شه.\n\n"
            "عدد جدید (ساعت؛ 0 = غیرفعال) رو بفرست:",
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_LOTTERY_BROADCAST_TEXT:
        current = get_setting("lottery_broadcast_text")
        waiting_for[key] = {"type": "admin_set_lottery_broadcast_text"}
        send_message(
            user_id,
            f"📢 متن فعلیِ پیام همگانیِ اعلام برنده (به همه‌ی کاربران بات‌ساز فرستاده می‌شه):\n\n{current}\n\n"
            "✏️ متن جدید رو بفرست.\nمی‌تونی از {winner} برای جایگذاری خودکار نام/آیدی برنده استفاده کنی.",
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_LOTTERY_WINNER_TEXT:
        current = get_setting("lottery_winner_dm_text")
        waiting_for[key] = {"type": "admin_set_lottery_winner_text"}
        send_message(
            user_id,
            f"🏆 متن فعلیِ پیام خصوصی که فقط به خودِ برنده فرستاده می‌شه:\n\n{current}\n\n✏️ متن جدید رو بفرست.",
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_LOTTERY_OTHER_TEXT:
        current = get_setting("lottery_other_text")
        waiting_for[key] = {"type": "admin_set_lottery_other_text"}
        send_message(
            user_id,
            f"🎗 متن فعلیِ پیام خصوصی که به سایر شرکت‌کننده‌ها (غیر از برنده) فرستاده می‌شه:\n\n{current}\n\n"
            "✏️ متن جدید رو بفرست.\nمی‌تونی از {winner} برای جایگذاری خودکار نام/آیدی برنده استفاده کنی.",
            CANCEL_KEYBOARD,
        )
        return

    if is_admin_user and text == BTN_ADMIN_EXPORT_JSON:
        send_message(user_id, "⏳ در حال آماده‌سازی فایل JSON...")
        path = export_bots_json()
        send_document(user_id, path, caption="📦 لیست بات‌های ساخته‌شده + توکن‌ها")
        try:
            os.remove(path)
        except Exception:
            pass
        return

    if is_admin_user and text == BTN_ADMIN_PAYMENTS_FILE:
        if os.path.exists(PAYMENTS_LOG_FILE):
            send_document(user_id, PAYMENTS_LOG_FILE, caption="📄 لاگ همه‌ی پرداخت‌های موفق")
        else:
            send_message(user_id, "هنوز هیچ پرداختی ثبت نشده.")
        return

    if is_admin_user and text == BTN_ADMIN_FULL_BACKUP:
        send_message(user_id, "⏳ در حال آماده‌سازی فایل کامل اطلاعات ربات...")
        try:
            path = backup_full_database()
            send_document(
                user_id, path,
                caption="🗄 بکاپ کامل و لحظه‌ای همه‌ی اطلاعات ربات (کاربران، تنظیمات، پیام خوش‌آمد، "
                        "آیدی پشتیبانی، بات‌های ساخته‌شده + توکن‌ها، پرداخت‌ها).\n"
                        "این فایل روی دیسک ذخیره شده و چه روی هاست چه روی سیستم لوکال، با ری‌استارت پاک نمی‌شه.",
            )
        except Exception as e:
            send_message(user_id, f"❌ خطا در تهیه‌ی بکاپ: {e}")
        return

    if is_admin_user and text == BTN_ADMIN_BOTS:
        send_message(user_id, "🗂 مدیریت بات‌های ساخته‌شده", kb_admin_bots())
        return

    if is_support_admin_user and text == BTN_ADMIN_BOTS_LIST:
        bots = get_all_bots()
        back_kb = kb_admin_bots() if is_admin_user else admin_home_kb(user_id)
        if not bots:
            send_message(user_id, "هیچ باتی هنوز ساخته نشده.", back_kb)
            return
        status_fa = {"running": "🟢", "stopped": "🔴", "crashed": "⚠️"}
        lines = ["🗂 همه‌ی بات‌های ساخته‌شده:\n"]
        for b in bots[:60]:
            info = BOT_TYPES.get(b["bot_type"], {"name": b["bot_type"]})
            lines.append(
                f"#{b['id']} {status_fa.get(b['status'],'?')} {info['name']} | مالک: {b['user_id']} | {format_expiry_line(b)}"
            )
        if len(bots) > 60:
            lines.append(f"\n... و {len(bots) - 60} بات دیگه (برای همه از خروجی JSON استفاده کن)")
        send_message(user_id, "\n".join(lines), back_kb)
        return

    if is_admin_user and text == BTN_ADMIN_BOTS_STOP:
        waiting_for[key] = {"type": "admin_bot_stop_id"}
        send_message(user_id, "شماره بات (#) که می‌خوای خاموشش کنی رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_RENEW_A_BOT:
        waiting_for[key] = {"type": "admin_renew_bot_id"}
        send_message(user_id, "✅ شماره بات (#) که می‌خوای دستی/رایگان تمدیدش کنی رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_BOTS_BACKUP:
        waiting_for[key] = {"type": "admin_bot_backup_id"}
        send_message(user_id, "شماره بات (#) که می‌خوای بکاپ کاملش رو بگیری رو بفرست:", CANCEL_KEYBOARD)
        return

    if is_admin_user and text == BTN_ADMIN_BOTS_DB:
        waiting_for[key] = {"type": "admin_bot_db_id"}
        send_message(user_id, "شماره بات (#) که می‌خوای فایل‌های دیتابیسش رو بگیری رو بفرست:", CANCEL_KEYBOARD)
        return

    # هر پیام دیگه‌ای -> منوی اصلی
    send_message(user_id, main_menu_text(user_id), kb_main(user_id))

# ===================================================================
# 🔁 حلقه اصلی (polling)
# ===================================================================
_last_alert_at = {}

def alert_admin_error(tag, err):
    """به ادمین اصلی خطای بحرانی رو اطلاع می‌ده (حداکثر هر ۱۰ دقیقه یک‌بار به‌ازای هر نوع خطا، تا اسپم نشه)."""
    now = time.time()
    if now - _last_alert_at.get(tag, 0) < 600:
        return
    _last_alert_at[tag] = now
    try:
        send_message(ADMIN_ID, f"🚨 خطای بحرانی توی بات‌ساز ({tag}):\n{err}")
    except Exception:
        pass

def run():
    last_update_id = 0
    while True:
        try:
            updates = api_request("getUpdates", {"offset": last_update_id + 1, "timeout": 60})
            if updates.get("ok"):
                for update in updates.get("result", []):
                    last_update_id = update["update_id"]
                    if "message" in update:
                        try:
                            handle_message(update["message"])
                        except Exception as e:
                            print(f"⚠️ خطا در پردازش پیام: {e}")
                            alert_admin_error("پردازش پیام", e)
                    elif "pre_checkout_query" in update:
                        try:
                            handle_pre_checkout(update["pre_checkout_query"])
                        except Exception as e:
                            print(f"⚠️ خطا در pre_checkout_query: {e}")
                            alert_admin_error("pre_checkout_query", e)
            try: process_lottery()
            except Exception as e:
                print(f"⚠️ خطا در قرعه‌کشی خودکار: {e}")
                alert_admin_error("قرعه‌کشی خودکار", e)
            try: process_renewals()
            except Exception as e:
                print(f"⚠️ خطا در بررسی تمدید بات‌ها: {e}")
                alert_admin_error("بررسی تمدید بات‌ها", e)
            try: process_auto_backup()
            except Exception as e:
                print(f"⚠️ خطا در بکاپ خودکار: {e}")
                alert_admin_error("بکاپ خودکار", e)
            try: process_bot_monitor()
            except Exception as e:
                print(f"⚠️ خطا در مانیتورینگ سلامت بات‌ها: {e}")
                alert_admin_error("مانیتورینگ سلامت بات‌ها", e)
            time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 بات متوقف شد")
            break
        except Exception as e:
            print(f"⚠️ خطا: {e}")
            time.sleep(5)

def run_webhook(port):
    import http.server
    class Handler(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            try:
                update = json.loads(self.rfile.read(length).decode("utf-8"))
                if "message" in update:
                    handle_message(update["message"])
                elif "pre_checkout_query" in update:
                    handle_pre_checkout(update["pre_checkout_query"])
            except Exception as e:
                print(f"⚠️ خطای webhook: {e}")
            self.send_response(200)
            self.end_headers()
        def log_message(self, *a):
            pass
    api_request("setWebhook", {"url": FACTORY_WEBHOOK_URL})
    print(f"🌐 Webhook روی پورت {port} فعال شد -> {FACTORY_WEBHOOK_URL}")
    http.server.ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()

# ===================================================================
# 🔄 روشن کردن دوباره‌ی بات‌ها بعد از ری‌استارت هاست/سرور
# ===================================================================
def restart_existing_bot_process(bot_id):
    """یک بات ساخته‌شده رو - بدون بازسازی پوشه و بدون تغییر مالک/ادمین - دوباره اجرا می‌کنه.
    برای وقتی که خودِ سرور خاموش/روشن یا ری‌استارت شده و پردازش‌های قبلی از بین رفتن
    (در حالی که فایل‌ها و دیتابیس هر بات روی دیسک سالم مونده)."""
    row = get_bot_by_id(bot_id)
    if not row:
        return False, "بات پیدا نشد."
    info = BOT_TYPES.get(row["bot_type"], {})
    kind = info.get("kind")
    folder = row["folder"]
    if not os.path.isdir(folder):
        return False, "پوشه‌ی بات روی دیسک پیدا نشد."

    child_env = os.environ.copy()
    child_env["PYTHONIOENCODING"] = "utf-8"
    child_env["PYTHONUTF8"] = "1"
    if kind == "python_package":
        child_env["BOT_TOKEN"] = row["token"]
        child_env["ADMIN_IDS"] = str(row["sub_admin_id"])
        child_env["ADMIN_CMD"] = row["admin_cmd"] or "/admin"
    run_mode = row["run_mode"] if "run_mode" in row.keys() else "polling"
    if run_mode == "webhook" and row["webhook_url"]:
        child_env["WEBHOOK_URL"] = row["webhook_url"]
        child_env["WEBHOOK_PORT"] = str(row["webhook_port"])

    if kind == "php_single":
        php_exe = shutil.which("php")
        if not php_exe:
            return False, "PHP روی سرور پیدا نشد."
        cmd = [php_exe, "main.php"]
    else:
        cmd = [sys.executable, "-X", "utf8", "main.py"]

    log_path = os.path.join(folder, "run.log")
    try:
        log_file = open(log_path, "a", encoding="utf-8")
    except Exception as e:
        return False, f"فایل لاگ باز نشد: {e}"

    popen_kwargs = dict(cwd=folder, stdout=log_file, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=child_env)
    if os.name == "posix":
        popen_kwargs["start_new_session"] = True
    else:
        popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)

    try:
        process = subprocess.Popen(cmd, **popen_kwargs)
    except Exception as e:
        set_bot_status(bot_id, "crashed")
        return False, f"اجرای دوباره‌ی بات ناموفق بود: {e}"

    time.sleep(1.5)
    running = process.poll() is None
    conn = db()
    conn.execute("UPDATE created_bots SET pid=?, status=? WHERE id=?", (process.pid, "running" if running else "crashed", bot_id))
    conn.commit()
    conn.close()
    if not running:
        return False, get_log_tail(folder)
    return True, None

def resume_all_bots_on_startup():
    """موقع بالا اومدن بات‌ساز (مثلاً بعد از ری‌استارت سرور/هاست)، هر باتی که قبلش وضعیتش
    running بوده ولی پردازشش دیگه زنده نیست رو خودکار دوباره روشن می‌کنه؛ داده‌ها و دیتابیس
    هر بات چون روی دیسک ذخیره شدن (نه توی RAM)، از بین نمی‌رن - فقط پردازششون نیاز به روشن‌شدن دوباره داره."""
    bots = db().execute("SELECT * FROM created_bots WHERE status='running'").fetchall()
    if not bots:
        return
    to_revive = [b for b in bots if not is_pid_alive(b["pid"])]
    if not to_revive:
        return
    print(f"🔄 {len(to_revive)} بات که قبل از خاموشی/ری‌استارت روشن بودن، دارن دوباره اجرا می‌شن...")
    revived, failed = 0, 0
    for row in to_revive:
        ok, err = restart_existing_bot_process(row["id"])
        if ok:
            revived += 1
        else:
            failed += 1
            print(f"  ⚠️ بات #{row['id']} ({row['bot_type']}) دوباره روشن نشد: {err}")
    print(f"✅ {revived} بات با موفقیت دوباره روشن شد" + (f" | ⚠️ {failed} بات ناموفق (لاگشون رو چک کن)" if failed else ""))

if __name__ == "__main__":
    if "توکن بات‌سازت" in TOKEN or not ADMIN_ID:
        print("⚠️ اول توکن و ADMIN_ID رو بالای main.py تنظیم کن، بعد اجرا کن.")
        sys.exit(1)
    init_db()
    fetch_bot_username()
    resume_all_bots_on_startup()
    print("🤖 بات‌ساز آماده شد")
    if BOT_USERNAME:
        print(f"✅ یوزرنیم بات: @{BOT_USERNAME}")
    if FACTORY_WEBHOOK_URL and FACTORY_WEBHOOK_PORT:
        run_webhook(FACTORY_WEBHOOK_PORT)
    else:
        run()
