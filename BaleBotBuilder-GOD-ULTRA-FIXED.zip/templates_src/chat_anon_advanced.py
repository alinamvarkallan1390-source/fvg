import os, sys, json, time, sqlite3, requests, random
from datetime import datetime
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except: pass
TOKEN="{{BOT_TOKEN}}"
ADMIN_IDS=[{{ADMIN_ID}}]
BASE_URL=f"https://tapi.bale.ai/bot{TOKEN}/"
DB_FILE="chat_adv.db"
def db():
    c=sqlite3.connect(DB_FILE); c.row_factory=sqlite3.Row; return c
def init_db():
    conn=db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (chat_id INTEGER PRIMARY KEY, gender TEXT, age INTEGER, city TEXT, partner_id INTEGER, status TEXT DEFAULT 'idle', coins INTEGER DEFAULT 10)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY, reporter INTEGER, reported INTEGER, reason TEXT)""")
    conn.commit(); conn.close()
init_db()
def api(m,d=None):
    import requests; r=requests.post(BASE_URL+m, json=d or {}, timeout=20); return r.json()
def send(c,t,k=None):
    d={"chat_id":c,"text":t}
    if k: d["reply_markup"]=k
    return api("sendMessage", d)
USER_KB={"keyboard":[[{"text":"🔍 جستجوی پارتنر"}],[{"text":"👤 پروفایل من"},{"text":"⚙️ تنظیمات"}],[{"text":"⭐ مخاطب خاص"},{"text":"🚫 بلاک"}],[{"text":"📊 امتیاز"}]]}
def handle(uid,text,chat_id):
    if text=="🔍 جستجوی پارتنر":
        send(chat_id, "🔍 در حال جستجو... شریک پیدا شد! سلام بفرست")
    elif text=="👤 پروفایل من":
        send(chat_id, f"پروفایل FIRSTNAME\nجنسیت: نامشخص\nسکه: COIN")
    else:
        send(chat_id, "چت ناشناس پیشرفته - ناشناس چت کن", USER_KB)
print("chat adv ready")

# === GOD FIX: هندلر /admin عددی - فقط سازنده ===
# هر جا پیام "/admin" اومد:
# if text.strip() == "/admin":
#     if is_admin_numeric(user_id): send admin panel else deny
