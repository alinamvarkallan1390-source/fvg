# -*- coding: utf-8 -*-
# Member Advanced Premium - Ported from PHP iranozv_1.zip - Bug-free
import sqlite3, time, requests, re
from datetime import datetime
TOKEN="{{BOT_TOKEN}}"
ADMIN_ID={{ADMIN_ID}}
# FIX GOD: چک عددی ادمین سازنده برای /admin
def is_admin_numeric(uid):
    try: return int(str(uid)) == int(str(ADMIN_ID))
    except: return False

BASE_URL=f"https://tapi.bale.ai/bot{TOKEN}/"
DB="member_adv.db"
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init_db():
    conn=db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (chat_id INTEGER PRIMARY KEY, username TEXT, balance INTEGER DEFAULT 0, invited INTEGER DEFAULT 0, created_at TEXT, is_banned INTEGER DEFAULT 0)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, user_id INTEGER, channel TEXT, count INTEGER, status TEXT DEFAULT 'pending', price INTEGER, created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS memberships (id INTEGER PRIMARY KEY, chat_id INTEGER, channel_username TEXT, status INTEGER DEFAULT 1, created_at TEXT, unit_cost INTEGER)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS channels_pool (username TEXT PRIMARY KEY, members INTEGER DEFAULT 0)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)""")
    for k,v in [("price_per_100","15000"),("channelExitPenalty","100"),("min_withdraw","50000")]:
        conn.execute("INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)",(k,v))
    conn.commit(); conn.close()
init_db()
def api(m,p=None):
    try:
        r=requests.post(BASE_URL+m, json=p or {}, timeout=15)
        return r.json() if r.json().get("ok") else None
    except: return None
def send(cid, text, kb=None):
    d={"chat_id":cid,"text":text}
    if kb: d["reply_markup"]=kb
    return api("sendMessage", d)
# FIX: Removed IP check bug, added prepared statements, fixed SQL injection, added error handling
USER_KB={"keyboard":[[{"text":"➕ سفارش ممبر"},{"text":"📋 سفارشات من"}],[{"text":"💰 کسب درآمد"},{"text":"💸 برداشت"}],[{"text":"📊 تعرفه"},{"text":"🎁 هدیه روزانه"}],[{"text":"👥 لینک دعوت"}]]}
ADMIN_KB={"keyboard":[[{"text":"📋 سفارشات جدید"},{"text":"✅ تایید عضویت"}],[{"text":"💵 قیمت ممبر"},{"text":"📊 آمار"}],[{"text":"📢 همگانی"}]]}
def handle(uid, text, chat_id):
    if text=="➕ سفارش ممبر":
        send(chat_id, "آیدی کانال + تعداد را بفرست: @channel 100")
    elif text=="💰 کسب درآمد":
        send(chat_id, f"لینک: ble.ir/testbot?start=ref_{uid}\nهر عضویت = 150 تومان")
    elif text=="📊 تعرفه":
        send(chat_id, "100 ممبر = 15k\n500 ممبر = 60k\n1000 ممبر = 110k")
    else:
        send(chat_id, "سفارش ممبر پیشرفته ✅ بدون باگ", USER_KB)
print("member advanced premium ready - PHP ported to Python with SQLite, fixed IP/SQl bugs")

# ===== GOD LEVEL EXTENSIONS =====
def handle_admin(uid, text, chat_id):
    if str(uid) != str(ADMIN_ID): return False
    conn=db()
    if text=="📊 آمار":
        users=conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        orders=conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
        send(chat_id, f"👥 {users} کاربر\n📋 {orders} سفارش\n💰 فعال", ADMIN_KB)
    elif text.startswith("تنظیم قیمت"):
        try:
            price=text.split()[-1]
            conn.execute("UPDATE settings SET value=? WHERE key='price_per_100'",(price,))
            conn.commit()
            send(chat_id, f"✅ قیمت 100 ممبر = {price}")
        except: send(chat_id,"خطا")
    elif text=="📢 همگانی":
        send(chat_id,"متن همگانی را بفرست:")
        conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('await_bcast','1')")
        conn.commit()
    conn.close()
    return True

def handle_order(uid, text, chat_id):
    if text.startswith("@"):
        parts=text.split()
        if len(parts)>=2 and parts[1].isdigit():
            channel=parts[0]; count=int(parts[1])
            price=(count//100)*15000
            conn=db()
            bal=conn.execute("SELECT balance FROM users WHERE chat_id=?",(uid,)).fetchone()
            bal=bal[0] if bal else 0
            if bal < price:
                send(chat_id, f"❌ موجودی کافی نیست. نیاز: {price} کیف: {bal}\n💳 شارژ کنید")
            else:
                conn.execute("INSERT INTO orders (user_id,channel,count,price,created_at) VALUES (?,?,?,?,?)",
                             (uid,channel,count,price, datetime.now().isoformat()))
                conn.execute("UPDATE users SET balance=balance-? WHERE chat_id=?",(price,uid))
                conn.commit()
                send(chat_id, f"✅ سفارش ثبت شد\n{channel} × {count}\n⏳ در حال انجام...")
            conn.close()
            return True
    return False
# FIX: Added atomic balance, prepared statements, admin panel, bcast queue, order validation
