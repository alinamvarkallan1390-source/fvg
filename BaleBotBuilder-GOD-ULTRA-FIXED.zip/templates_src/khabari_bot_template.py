import os, sys, json, time, sqlite3, requests
from datetime import datetime
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except: pass
TOKEN="{{BOT_TOKEN}}"
ADMIN_IDS=[{{ADMIN_ID}}]
BASE_URL=f"https://tapi.bale.ai/bot{TOKEN}/"
DB_FILE="khabari.db"
def db():
    c=sqlite3.connect(DB_FILE); c.row_factory=sqlite3.Row; return c
def init_db():
    conn=db()
    conn.execute("""CREATE TABLE IF NOT EXISTS channels (id INTEGER PRIMARY KEY, username TEXT UNIQUE, title TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY, channel_id INTEGER, text TEXT, status TEXT DEFAULT 'pending', created_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS users (chat_id INTEGER PRIMARY KEY)""")
    conn.commit(); conn.close()
init_db()
def api(m,d=None):
    import requests; r=requests.post(BASE_URL+m, json=d or {}, timeout=20); return r.json()
def send(c,t,k=None):
    d={"chat_id":c,"text":t}
    if k: d["reply_markup"]=k
    return api("sendMessage", d)
USER_KB={"keyboard":[[{"text":"📰 اخبار فوری"},{"text":"⚽ ورزشی"}],[{"text":"💻 تکنولوژی"},{"text":"💰 اقتصادی"}],[{"text":"⚙️ تنظیم کانال"}]]}
ADMIN_KB={"keyboard":[[{"text":"➕ افزودن کانال"},{"text":"📋 لیست کانال‌ها"}],[{"text":"📢 فوروارد خودکار"},{"text":"⏰ زمانبندی"}],[{"text":"📊 آمار بازدید"}]]}
def handle(uid,text,chat_id):
    if text=="📰 اخبار فوری":
        send(chat_id, "📰 تیتر امروز: مذاکرات جدید...\nhttps://ble.ir/news")
    elif text=="⚙️ تنظیم کانال":
        send(chat_id, "آیدی کانال را بفرست: @mynews")
    else:
        send(chat_id, "به بات خبری خوش آمدی", USER_KB)
print("khabari ready")

# === GOD FIX: هندلر /admin عددی - فقط سازنده ===
# هر جا پیام "/admin" اومد:
# if text.strip() == "/admin":
#     if is_admin_numeric(user_id): send admin panel else deny
