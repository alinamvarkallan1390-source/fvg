from typing import Dict, Any

_states: Dict[int, Dict[str, Any]] = {}


def get_state(user_id: int) -> str:
    return _states.get(user_id, {}).get("state", "idle")


def set_state(user_id: int, state: str, **data):
    prev = _states.get(user_id, {})
    _states[user_id] = {"state": state}
    for k, v in data.items():
        _states[user_id][k] = v


def get_data(user_id: int) -> dict:
    s = _states.get(user_id, {})
    return {k: v for k, v in s.items() if k != "state"}


def get_data_key(user_id: int, key: str, default=None):
    return _states.get(user_id, {}).get(key, default)


def update_data(user_id: int, **kwargs):
    if user_id not in _states:
        _states[user_id] = {"state": "idle"}
    _states[user_id].update(kwargs)


def clear_state(user_id: int):
    _states.pop(user_id, None)


STATES = {
    "IDLE":                       "idle",
    "WAITING_NAME":               "waiting_name",
    "WAITING_AGE":                "waiting_age",
    "WAITING_BIO":                "waiting_bio",
    "WAITING_PHOTO":              "waiting_photo",
    "WAITING_PROVINCE":           "waiting_province",
    "IN_CHAT":                    "in_chat",
    "SEARCHING":                  "searching",
    "WAITING_RECEIPT":            "waiting_receipt",
    "WAITING_TRACKING":           "waiting_tracking",
    "WAITING_TX_TIME":            "waiting_tx_time",
    "WAITING_BROADCAST":          "waiting_broadcast",
    "WAITING_BROADCAST_BTN_TEXT": "waiting_broadcast_btn_text",
    "WAITING_BROADCAST_BTN_URL":  "waiting_broadcast_btn_url",
    "WAITING_FORWARD_BROADCAST":  "waiting_forward_broadcast",
    "WAITING_REFERRAL_CONTENT":  "waiting_referral_content",
    "WAITING_REFERRAL_BTN_TEXT": "waiting_referral_btn_text",
    "WAITING_CHANNEL_LINK":       "waiting_channel_link",
    "WAITING_CHANNEL_BTN":        "waiting_channel_btn",
    "WAITING_DIRECT_MSG":         "waiting_direct_msg",
    "WAITING_ANON_MSG":           "waiting_anon_msg",
    "WAITING_ANON_REPLY":         "waiting_anon_reply",
    "WAITING_REJECT_REASON":      "waiting_reject_reason",
    "WAITING_ADMIN_COINS":        "waiting_admin_coins",
    "WAITING_COINS_USER":         "waiting_coins_user",
    "WAITING_DISCOUNT_CODE":      "waiting_discount_code",
    "WAITING_DISCOUNT_PERCENT":   "waiting_discount_percent",
    "WAITING_DISCOUNT_USES":      "waiting_discount_uses",
    "WAITING_DISCOUNT_DAYS":      "waiting_discount_days",
    "WAITING_PACKAGE_TITLE":      "waiting_package_title",
    "WAITING_PACKAGE_COINS":      "waiting_package_coins",
    "WAITING_PACKAGE_PRICE":      "waiting_package_price",
    "WAITING_CARD_NUMBER":        "waiting_card_number",
    "WAITING_BTN_TEXT_VALUE":     "waiting_btn_text_value",
    "WAITING_REFERRAL_REWARD":    "waiting_referral_reward",
    "WAITING_PROFILE_REWARD":     "waiting_profile_reward",
    "WAITING_CHAT_COST":          "waiting_chat_cost",
    "WAITING_LOCATION":           "waiting_location",
    "ADM_REF_CH_REWARD":          "adm_ref_ch_reward",
    "ADM_DISC_CODE":              "adm_disc_code",
    "ADM_DISC_PERCENT":           "adm_disc_percent",
    "ADM_DISC_USES":              "adm_disc_uses",
    "ADM_DISC_DAYS":              "adm_disc_days",
    "WAITING_DB_UPLOAD":          "waiting_db_upload",
    "CONFIRM_DELETE":             "confirm_delete",
    "ORDER_PENDING":              "order_pending",
    "BC_WAITING_BTN_CHOICE":      "bc_waiting_btn_choice",
}
