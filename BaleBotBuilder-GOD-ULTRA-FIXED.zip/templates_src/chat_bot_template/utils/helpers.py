import time
import math
from config import DEFAULT_TEXTS


def get_texts(settings: dict) -> dict:
    result = dict(DEFAULT_TEXTS)
    for key in DEFAULT_TEXTS:
        if key in settings:
            result[key] = settings[key]
    return result


def format_profile(user: dict, online: bool = True) -> str:
    gender_emoji = "🙍‍♀️" if user.get("gender") == "دختر" else "🙍‍♂️" if user.get("gender") == "پسر" else "👤"
    status = "🟢 آنلایـــن" if online else "⚫️ آفلاین"
    uid = user.get("referral_code", "???")
    lines = [
        "╔══════════════════╗",
        f"  👤 <b>پروفایل کاربر</b>",
        "╚══════════════════╝\n",
        f"• <b>نام:</b> {user.get('full_name', 'نامشخص')}",
        f"• <b>سن:</b> {user.get('age', '؟')}",
        f"• <b>جنسیت:</b> {user.get('gender', 'نامشخص')} {gender_emoji}",
        f"• <b>استان:</b> {user.get('province', 'نامشخص')}",
        f"• <b>شهر:</b> {user.get('city', 'نامشخص')}",
        f"\n📝 <b>بیوگرافی:</b> {user.get('bio') or '❓'}",
        f"\n♥ <b>لایک‌ها:</b> {user.get('likes', 0)}",
        f"\n{status} 👀",
        f"\n🆔 <b>آیدی:</b> /user_{uid}",
        f"🔔 تنظیم حالت سایلنت: /silent",
        f"❌ حذف اکانت: /delete_account",
    ]
    return "\n".join(lines)


def format_other_profile(user: dict, distance_m: float = None, in_chat: bool = False) -> str:
    gender_emoji = "🙍‍♀️" if user.get("gender") == "دختر" else "🙍‍♂️" if user.get("gender") == "پسر" else "👤"
    if in_chat:
        status = "💬 در حال چت"
    elif user.get("is_online"):
        status = "🟢 آنلاین"
    else:
        status = "⚫️ آفلاین"
    lines = [
        "╔══════════════════╗",
        f"  👤 <b>پروفایل کاربر</b>",
        "╚══════════════════╝\n",
        f"• <b>نام:</b> {user.get('full_name', 'نامشخص')}",
        f"• <b>سن:</b> {user.get('age', '؟')}",
        f"• <b>جنسیت:</b> {user.get('gender', 'نامشخص')} {gender_emoji}",
        f"• <b>استان:</b> {user.get('province', 'نامشخص')}",
    ]
    if user.get("bio"):
        lines.append(f"\n📝 <b>بیو:</b> {user['bio']}")
    lines.append(f"\n♥ <b>لایک‌ها:</b> {user.get('likes', 0)}")
    lines.append(f"\n{status}")
    if distance_m is not None:
        if distance_m < 1000:
            dist_str = f"{int(distance_m)} متر"
        else:
            dist_str = f"{distance_m/1000:.1f} کیلومتر"
        lines.append(f"📏 فاصله: {dist_str}")
    return "\n".join(lines)


def haversine(lat1, lon1, lat2, lon2) -> float:
    R = 6371000
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1-a))


def is_profile_complete(user: dict) -> bool:
    return all([
        user.get("full_name") and user["full_name"] != "کاربر ربات",
        user.get("age") and user["age"] != 99,
        user.get("gender") and user["gender"] != "نامشخص",
        user.get("province") and user["province"] != "تهران",
        user.get("bio"),
        user.get("photo_file_id"),
    ])


def format_coins(amount: int) -> str:
    return f"{amount:,}"


def time_ago(timestamp: int) -> str:
    diff = int(time.time()) - timestamp
    if diff < 60:
        return "لحظاتی پیش"
    elif diff < 3600:
        return f"{diff//60} دقیقه پیش"
    elif diff < 86400:
        return f"{diff//3600} ساعت پیش"
    else:
        return f"{diff//86400} روز پیش"
