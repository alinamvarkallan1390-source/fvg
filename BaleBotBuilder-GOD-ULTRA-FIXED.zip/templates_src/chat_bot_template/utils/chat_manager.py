import asyncio
import time
from typing import Dict, Optional, Tuple

_search_queue: Dict[str, list] = {
    "random": [],
    "girl": [],
    "boy": [],
    "province": [],
}

_active_chats: Dict[int, Dict] = {}

_chat_timers: Dict[int, float] = {}


def add_to_queue(user_id: int, search_type: str, province: str = None, gender: str = None):
    remove_from_all_queues(user_id)
    entry = {"user_id": user_id, "joined_at": time.time(), "province": province, "gender": gender}
    if search_type == "random":
        _search_queue["random"].append(entry)
    elif search_type == "girl":
        _search_queue["girl"].append(entry)
    elif search_type == "boy":
        _search_queue["boy"].append(entry)
    elif search_type == "province":
        _search_queue["province"].append(entry)


def remove_from_all_queues(user_id: int):
    for key in _search_queue:
        _search_queue[key] = [e for e in _search_queue[key] if e["user_id"] != user_id]


def find_match(user_id: int, search_type: str, province: str = None, gender: str = None) -> Optional[int]:
    queue = _search_queue.get(search_type, [])
    for entry in queue:
        if entry["user_id"] == user_id:
            continue
        if search_type == "province" and province:
            if entry["province"] == province:
                _search_queue[search_type].remove(entry)
                remove_from_all_queues(user_id)
                return entry["user_id"]
        else:
            _search_queue[search_type].remove(entry)
            remove_from_all_queues(user_id)
            return entry["user_id"]
    return None


def start_chat(user1_id: int, user2_id: int, chat_type: str = "random"):
    now = time.time()
    _active_chats[user1_id] = {
        "partner": user2_id,
        "started_at": now,
        "chat_type": chat_type
    }
    _active_chats[user2_id] = {
        "partner": user1_id,
        "started_at": now,
        "chat_type": chat_type
    }


def get_partner(user_id: int) -> Optional[int]:
    chat = _active_chats.get(user_id)
    return chat["partner"] if chat else None


def get_chat_info(user_id: int) -> Optional[Dict]:
    return _active_chats.get(user_id)


def end_chat(user_id: int) -> Tuple[Optional[int], float]:
    chat = _active_chats.pop(user_id, None)
    if not chat:
        return None, 0
    partner = chat["partner"]
    duration = time.time() - chat["started_at"]
    _active_chats.pop(partner, None)
    return partner, duration


def is_in_chat(user_id: int) -> bool:
    return user_id in _active_chats


def get_chat_duration(user_id: int) -> float:
    chat = _active_chats.get(user_id)
    if not chat:
        return 0
    return time.time() - chat["started_at"]


def count_active_chats() -> int:
    return len(_active_chats) // 2


_pending_requests: Dict[int, Dict] = {}


def add_chat_request(from_user: int, to_user: int):
    _pending_requests[to_user] = {
        "from_user": from_user,
        "created_at": time.time()
    }


def get_chat_request(to_user: int) -> Optional[Dict]:
    req = _pending_requests.get(to_user)
    if req and time.time() - req["created_at"] > 120:
        _pending_requests.pop(to_user, None)
        return None
    return req


def remove_chat_request(to_user: int):
    _pending_requests.pop(to_user, None)
