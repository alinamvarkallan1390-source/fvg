import httpx
import asyncio
import json
import logging
from config import BASE_URL

logger = logging.getLogger(__name__)

_client: httpx.AsyncClient = None


async def get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(timeout=30.0)
    return _client


async def close_client():
    global _client
    if _client and not _client.is_closed:
        await _client.aclose()


async def api_call(method: str, data: dict = None, files: dict = None, retries: int = 3) -> dict:
    client = await get_client()
    url = f"{BASE_URL}/{method}"
    for attempt in range(retries):
        try:
            if files:
                # multipart form — reply_markup must be json string
                response = await client.post(url, data=data or {}, files=files)
            else:
                # json body — reply_markup must be dict (not json string)
                response = await client.post(url, json=data or {})
            result = response.json()
            if not result.get("ok"):
                logger.debug(f"API {method} not ok: {result.get('description')}")
            return result
        except Exception as e:
            logger.error(f"API call {method} attempt {attempt+1} failed: {e}")
            if attempt < retries - 1:
                await asyncio.sleep(1.5 * (attempt + 1))
    return {"ok": False}


async def forward_message(chat_id: int, from_chat_id: int, message_id: int) -> dict:
    """فوروارد واقعی یک پیام از چت مبدا به چت مقصد."""
    return await api_call("forwardMessage", {
        "chat_id": chat_id,
        "from_chat_id": from_chat_id,
        "message_id": message_id,
    })


async def send_message(chat_id: int, text: str, reply_markup: dict = None,
                       parse_mode: str = "HTML") -> dict:
    data: dict = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode}
    if reply_markup:
        data["reply_markup"] = reply_markup  # dict — httpx json= handles serialization
    return await api_call("sendMessage", data)


async def send_photo(chat_id: int, photo, caption: str = None,
                     reply_markup: dict = None) -> dict:
    # Bale API requires multipart/form-data for sendPhoto even when using file_id.
    # Sending file_id via JSON body causes a 500 Internal Server Error on Bale.
    form = {"chat_id": str(chat_id)}
    if caption:
        form["caption"] = caption
        form["parse_mode"] = "HTML"
    if reply_markup:
        form["reply_markup"] = json.dumps(reply_markup)

    if isinstance(photo, str):
        # file_id: send as a form field (no binary file attachment)
        form["photo"] = photo
        return await api_call("sendPhoto", form)
    else:
        # binary file: send as multipart file upload
        name = getattr(photo, "name", "photo.jpg")
        files = {"photo": (name, photo, "image/jpeg")}
        return await api_call("sendPhoto", form, files)


async def send_document(chat_id: int, document, caption: str = None,
                        reply_markup: dict = None) -> dict:
    if isinstance(document, str):
        data: dict = {"chat_id": chat_id, "document": document}
        if caption:
            data["caption"] = caption
            data["parse_mode"] = "HTML"
        if reply_markup:
            data["reply_markup"] = reply_markup
        return await api_call("sendDocument", data)
    else:
        form = {"chat_id": str(chat_id)}
        if caption:
            form["caption"] = caption
            form["parse_mode"] = "HTML"
        if reply_markup:
            form["reply_markup"] = json.dumps(reply_markup)
        name = getattr(document, "name", "file.db")
        files = {"document": (name, document, "application/octet-stream")}
        return await api_call("sendDocument", form, files)


async def send_audio(chat_id: int, audio, caption: str = None) -> dict:
    if isinstance(audio, str):
        return await api_call("sendAudio", {"chat_id": chat_id, "audio": audio,
                                             "caption": caption or ""})
    return await api_call("sendAudio", {"chat_id": str(chat_id)},
                          {"audio": (getattr(audio, "name", "audio.mp3"), audio, "audio/mpeg")})


async def send_video(chat_id: int, video, caption: str = None) -> dict:
    if isinstance(video, str):
        return await api_call("sendVideo", {"chat_id": chat_id, "video": video,
                                             "caption": caption or ""})
    return await api_call("sendVideo", {"chat_id": str(chat_id)},
                          {"video": (getattr(video, "name", "video.mp4"), video, "video/mp4")})


async def send_voice(chat_id: int, voice) -> dict:
    if isinstance(voice, str):
        return await api_call("sendVoice", {"chat_id": chat_id, "voice": voice})
    return await api_call("sendVoice", {"chat_id": str(chat_id)},
                          {"voice": (getattr(voice, "name", "voice.ogg"), voice, "audio/ogg")})


async def send_sticker(chat_id: int, sticker: str) -> dict:
    return await api_call("sendSticker", {"chat_id": chat_id, "sticker": sticker})


async def send_location(chat_id: int, latitude: float, longitude: float) -> dict:
    return await api_call("sendLocation",
                          {"chat_id": chat_id, "latitude": latitude, "longitude": longitude})


async def answer_callback_query(callback_query_id: str, text: str = None,
                                show_alert: bool = False) -> dict:
    data: dict = {"callback_query_id": callback_query_id, "show_alert": show_alert}
    if text:
        data["text"] = text
    return await api_call("answerCallbackQuery", data)


async def edit_message_text(chat_id: int, message_id: int, text: str,
                            reply_markup: dict = None) -> dict:
    data: dict = {"chat_id": chat_id, "message_id": message_id,
                  "text": text, "parse_mode": "HTML"}
    if reply_markup:
        data["reply_markup"] = reply_markup
    return await api_call("editMessageText", data)


async def delete_message(chat_id: int, message_id: int) -> dict:
    return await api_call("deleteMessage", {"chat_id": chat_id, "message_id": message_id})


async def get_chat_member(chat_id: str, user_id: int) -> dict:
    return await api_call("getChatMember", {"chat_id": chat_id, "user_id": user_id})


async def get_updates(offset: int = None, timeout: int = 30) -> dict:
    data: dict = {"timeout": timeout,
                  "allowed_updates": ["message", "callback_query"]}
    if offset is not None:
        data["offset"] = offset
    return await api_call("getUpdates", data)


async def get_me() -> dict:
    return await api_call("getMe", {})


async def get_file(file_id: str) -> dict:
    return await api_call("getFile", {"file_id": file_id})


async def get_user_profile_photos(user_id: int, limit: int = 1) -> dict:
    return await api_call("getUserProfilePhotos", {"user_id": user_id, "limit": limit})


async def download_file(file_path: str) -> bytes:
    """دانلود فایل از سرور Bale با file_path."""
    from config import BASE_URL
    # BASE_URL مثلاً https://tapi.bale.ai/bot<TOKEN>
    # آدرس دانلود: https://tapi.bale.ai/file/bot<TOKEN>/<file_path>
    token_part = BASE_URL.rstrip("/").split("/bot")[-1]
    base = BASE_URL.rstrip("/").split("/bot")[0]
    download_url = f"{base}/file/bot{token_part}/{file_path}"
    client = await get_client()
    try:
        resp = await client.get(download_url)
        if resp.status_code == 200:
            return resp.content
    except Exception as e:
        logger.error(f"download_file failed: {e}")
    return None
