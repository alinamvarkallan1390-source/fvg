import time
from database.db import (
    get_user, create_user, update_user, get_active_channels,
    get_user_by_referral, add_coins, get_setting, get_all_settings,
    get_admins
)
from utils.http_client import send_message, get_chat_member, send_photo
from utils.states import clear_state, STATES
from utils.helpers import format_profile, get_texts
from keyboards.builders import (
    main_keyboard, inline_kb, connect_inline
)
from config import BOT_USERNAME, ADMIN_IDS, REFERRAL_JOIN_REWARD


async def check_channels(user_id: int) -> tuple:
    channels = await get_active_channels()
    if not channels:
        return True, []
    not_joined = []
    for ch in channels:
        try:
            result = await get_chat_member(ch["channel_username"], user_id)
            status = result.get("result", {}).get("status", "left")
            if status in ("left", "kicked", "restricted"):
                not_joined.append(ch)
        except Exception:
            not_joined.append(ch)
    return len(not_joined) == 0, not_joined


async def send_join_required(user_id: int, not_joined: list, settings: dict):
    ch_text = "\n".join([f"@{c['channel_username'].lstrip('@')}" for c in not_joined])
    buttons = []
    for ch in not_joined:
        buttons.append([{"text": ch["button_text"], "url": ch["channel_link"]}])
    buttons.append([{"text": "✅ تایید عضویت", "callback_data": "verify_join"}])
    text = (
        "🌟 <b>کاربر گرامی!</b>\n\n"
        "برای استفاده از ربات، لطفاً در کانال‌های زیر عضو شوید:\n\n"
        f"{ch_text}\n\n"
        "پس از عضویت، روی <b>تایید عضویت</b> کلیک کنید 👇"
    )
    markup = inline_kb(buttons)
    await send_message(user_id, text, markup)


async def handle_start(update: dict, settings: dict):
    msg = update.get("message", {})
    user_id = msg["from"]["id"]
    username = msg["from"].get("username", "")
    full_name = msg["from"].get("first_name", "کاربر") + " " + msg["from"].get("last_name", "")
    full_name = full_name.strip()
    text = msg.get("text", "")
    referred_by = None

    parts = text.split()
    if len(parts) > 1:
        param = parts[1]
        if param.startswith("ref_"):
            ref_code = param[4:]
            referrer = await get_user_by_referral(ref_code)
            if referrer and referrer["user_id"] != user_id:
                existing = await get_user(user_id)
                if not existing:
                    referred_by = referrer["user_id"]
        elif param.startswith("anon_"):
            link_code = param[5:]
            await create_user(user_id, username, full_name)
            await update_user(user_id, last_seen=int(time.time()), is_online=1)
            joined, not_joined = await check_channels(user_id)
            if not joined:
                await send_join_required(user_id, not_joined, settings)
                return
            from utils.states import set_state, STATES
            set_state(user_id, STATES["WAITING_ANON_MSG"], link_code=link_code)
            await send_message(user_id,
                "📨 <b>ارسال پیام ناشناس</b>\n\n"
                "پیام خود را بنویسید یا فایل ارسال کنید.\n"
                "هویت شما برای گیرنده مشخص <b>نخواهد</b> شد 🕵️",
                inline_kb([[{"text": "❌ انصراف", "callback_data": "cancel_anon"}]])
            )
            return

    user = await get_user(user_id)
    is_new = user is None

    if is_new:
        await create_user(user_id, username, full_name, referred_by)
        if referred_by:
            ref_reward = int(await get_setting("referral_join_reward", str(REFERRAL_JOIN_REWARD)))
            await add_coins(referred_by, ref_reward)
            ref_user = await get_user(referred_by)
            if ref_user:
                await send_message(referred_by,
                    f"🎉 <b>تبریک!</b>\n\n"
                    f"یک کاربر جدید با لینک دعوت شما وارد ربات شد!\n"
                    f"با عضویت در کانال‌های ربات، <b>{ref_reward} سکه</b> به حساب شما واریز خواهد شد! 🪙"
                )

    await update_user(user_id, last_seen=int(time.time()), is_online=1,
                      username=username, full_name=full_name)

    joined, not_joined = await check_channels(user_id)
    if not joined:
        await send_join_required(user_id, not_joined, settings)
        return

    texts = get_texts(settings)
    admins = await get_admins()
    all_admins = list(set(ADMIN_IDS + admins))
    is_admin = user_id in all_admins

    if is_new:
        await send_message(user_id,
            "🌟 <b>به ربات ناشناس خوش آمدید!</b>\n\n"
            "✨ اینجا می‌تونی با افراد جدید آشنا بشی،\n"
            "💬 چت کنی، لایک بدی و لحظه‌های خوب بسازی!\n\n"
            "🔽 از منوی پایین شروع کن 👇",
            main_keyboard(is_admin, texts)
        )
    else:
        await send_message(user_id,
            "👋 <b>خوش برگشتی!</b>\n\nاز منوی پایین انتخاب کن 👇",
            main_keyboard(is_admin, texts)
        )

    clear_state(user_id)


async def handle_verify_join(user_id: int, callback_id: str, settings: dict):
    from utils.http_client import answer_callback_query
    joined, not_joined = await check_channels(user_id)
    if not joined:
        await answer_callback_query(callback_id, "❌ هنوز در همه کانال‌ها عضو نشدی!", True)
        return

    texts = get_texts(settings)
    admins = await get_admins()
    all_admins = list(set(ADMIN_IDS + admins))
    is_admin = user_id in all_admins
    await answer_callback_query(callback_id, "✅ عضویت تأیید شد!", False)
    await send_message(user_id,
        "✅ <b>عضویت شما تأیید شد!</b>\n\nاز منوی پایین می‌تونی شروع کنی 👇",
        main_keyboard(is_admin, texts)
    )

    referral_join = False
    user = await get_user(user_id)
    if user and user.get("referred_by"):
        ch_reward = int(await get_setting("referral_channel_reward", "5"))
        await add_coins(user["referred_by"], ch_reward)
        ref_user = await get_user(user["referred_by"])
        if ref_user:
            coins = await get_setting("referral_join_reward", "10")
            balance = ref_user["coins"] + ch_reward
            await send_message(user["referred_by"],
                f"🎉 <b>تبریک!</b>\n\n"
                f"زیرمجموعه شما در کانال‌ها عضو شد!\n"
                f"<b>+{ch_reward} سکه</b> به حسابتان اضافه شد 🪙\n"
                f"💰 موجودی جدید: <b>{balance} سکه</b>"
            )
        await update_user(user_id, referred_by=None)
