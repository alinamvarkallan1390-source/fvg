import time
from database.db import (
    get_user, update_user, get_like_count, get_likers,
    get_blocked_list, unblock_user, get_directs, get_setting, add_coins
)
from utils.http_client import (
    send_message, send_photo, answer_callback_query, edit_message_text, delete_message
)
from utils.states import set_state, clear_state, STATES
from utils.helpers import format_profile, is_profile_complete, get_texts
from keyboards.builders import (
    profile_inline, edit_profile_inline, gender_inline, provinces_inline,
    location_keyboard, main_keyboard, inline_kb, remove_keyboard
)
from config import GENDER_CHANGE_FREE_TIMES, GENDER_CHANGE_COIN_COST, ADMIN_IDS
from database.db import get_admins


async def show_profile(user_id: int, settings: dict, edit_msg_id: int = None):
    user = await get_user(user_id)
    if not user:
        return
    text = format_profile(user, user.get("is_online", 1) == 1)
    markup = profile_inline(get_texts(settings))

    if user.get("photo_file_id") and not edit_msg_id:
        await send_photo(user_id, user["photo_file_id"], text, markup)
    elif edit_msg_id:
        await edit_message_text(user_id, edit_msg_id, text, markup)
    else:
        await send_message(user_id, text, markup)


async def handle_profile_callback(user_id: int, data: str, callback_id: str, msg_id: int, settings: dict):
    await answer_callback_query(callback_id)

    if data == "profile:edit":
        await edit_message_text(user_id, msg_id,
            "✏️ <b>ویرایش پروفایل</b>\n\nکدام بخش را می‌خواهید ویرایش کنید؟",
            edit_profile_inline(get_texts(settings))
        )

    elif data == "profile:likes":
        likers = await get_likers(user_id)
        if not likers:
            await send_message(user_id, "💔 هنوز کسی پروفایل شما را لایک نکرده است!")
            return
        lines = ["❤️ <b>لیست لایک‌های شما:</b>\n"]
        for l in likers[:20]:
            uname = f"@{l['username']}" if l.get("username") else l.get("full_name", "ناشناس")
            lines.append(f"• {uname}")
        await send_message(user_id, "\n".join(lines))

    elif data == "profile:location":
        user = await get_user(user_id)
        if user.get("latitude") and user.get("longitude"):
            from utils.http_client import send_location
            await send_location(user_id, user["latitude"], user["longitude"])
        else:
            await send_message(user_id, "📍 موقعیت مکانی شما ثبت نشده است.")

    elif data == "profile:blocked":
        blocked = await get_blocked_list(user_id)
        if not blocked:
            await send_message(user_id, "✅ لیست بلاک‌شده‌های شما خالی است.")
            return
        rows = []
        lines = ["🚫 <b>لیست بلاک‌شده‌ها:</b>\n"]
        for b in blocked:
            uname = f"@{b['username']}" if b.get("username") else b.get("full_name", "ناشناس")
            lines.append(f"• {uname}")
            rows.append([{"text": f"🔓 رفع بلاک {uname}", "callback_data": f"unblock:{b['user_id']}"}])
        await send_message(user_id, "\n".join(lines), inline_kb(rows))

    elif data == "profile:directs":
        directs = await get_directs(user_id)
        if not directs:
            await send_message(user_id, "📭 پیام دایرکتی ندارید.")
            return
        for dm in directs[:10]:
            uname = f"@{dm['username']}" if dm.get("username") else dm.get("full_name", "ناشناس")
            from keyboards.builders import direct_msg_inline
            await send_message(user_id,
                f"📨 <b>پیام دایرکت از</b> {uname}\n\n『 {dm['message']} 』",
                direct_msg_inline(dm["from_user"], dm["id"])
            )

    elif data == "profile:back":
        await show_profile(user_id, settings, msg_id)

    elif data.startswith("unblock:"):
        target_id = int(data.split(":")[1])
        await unblock_user(user_id, target_id)
        await answer_callback_query(callback_id, "✅ بلاک برداشته شد", True)


async def handle_edit_callback(user_id: int, data: str, callback_id: str, msg_id: int, settings: dict):
    await answer_callback_query(callback_id)

    if data == "edit:name":
        set_state(user_id, STATES["WAITING_NAME"])
        await send_message(user_id,
            "📝 <b>تغییر نام</b>\n\nنام جدید خود را وارد کنید:",
            inline_kb([[{"text": "❌ انصراف", "callback_data": "cancel_edit"}]])
        )

    elif data == "edit:photo":
        set_state(user_id, STATES["WAITING_PHOTO"])
        await send_message(user_id,
            "🖼️ <b>تغییر عکس پروفایل</b>\n\nعکس جدید خود را ارسال کنید:",
            inline_kb([[{"text": "❌ انصراف", "callback_data": "cancel_edit"}]])
        )

    elif data == "edit:bio":
        set_state(user_id, STATES["WAITING_BIO"])
        await send_message(user_id,
            "📄 <b>تغییر بیوگرافی</b>\n\nبیوگرافی جدید خود را بنویسید:",
            inline_kb([[{"text": "❌ انصراف", "callback_data": "cancel_edit"}]])
        )

    elif data == "edit:gender":
        user = await get_user(user_id)
        changes = user.get("gender_changes", 0)
        cost_msg = ""
        if changes >= GENDER_CHANGE_FREE_TIMES:
            cost_msg = f"\n\n⚠️ این تغییر <b>{GENDER_CHANGE_COIN_COST} سکه</b> هزینه دارد."
        await send_message(user_id,
            f"⚧️ <b>تغییر جنسیت</b>\n\nجنسیت جدید خود را انتخاب کنید:{cost_msg}",
            gender_inline()
        )

    elif data == "edit:province":
        set_state(user_id, STATES["WAITING_PROVINCE"])
        await send_message(user_id,
            "🏘️ <b>تغییر استان</b>\n\nاستان خود را انتخاب کنید:",
            provinces_inline()
        )

    elif data == "edit:location":
        set_state(user_id, STATES["WAITING_LOCATION"])
        await send_message(user_id,
            "📡 <b>ارسال موقعیت مکانی</b>\n\n"
            "🔒 موقعیت مکانی شما نزد ما محفوظ است و فقط برای یافتن افراد نزدیک استفاده می‌شود.\n\n"
            "دکمه زیر را بزنید تا موقعیت دقیق ارسال شود 👇",
            location_keyboard()
        )

    elif data.startswith("set_gender:"):
        gender = data.split(":")[1]
        user = await get_user(user_id)
        changes = user.get("gender_changes", 0)
        if changes >= GENDER_CHANGE_FREE_TIMES:
            from database.db import deduct_coins
            ok = await deduct_coins(user_id, GENDER_CHANGE_COIN_COST)
            if not ok:
                await answer_callback_query(callback_id,
                    f"❌ سکه کافی ندارید! ({GENDER_CHANGE_COIN_COST} سکه لازم است)", True)
                return
        await update_user(user_id, gender=gender, gender_changes=changes+1)
        await answer_callback_query(callback_id, f"✅ جنسیت به {gender} تغییر یافت", True)
        await check_profile_complete(user_id, settings)

    elif data.startswith("set_province:"):
        province = data.split(":")[1]
        await update_user(user_id, province=province)
        await answer_callback_query(callback_id, f"✅ استان به {province} تغییر یافت", True)
        await check_profile_complete(user_id, settings)

    elif data == "cancel_edit":
        clear_state(user_id)
        await send_message(user_id, "❌ لغو شد.")


async def handle_edit_message(user_id: int, msg: dict, settings: dict):
    from utils.states import get_state, get_data_key
    state = get_state(user_id)
    text = msg.get("text", "")
    photo = msg.get("photo")

    if state == STATES["WAITING_NAME"]:
        if not text or len(text) > 50:
            await send_message(user_id, "⚠️ نام باید بین ۱ تا ۵۰ کاراکتر باشد.")
            return
        await update_user(user_id, full_name=text)
        clear_state(user_id)
        await send_message(user_id, f"✅ نام شما به «<b>{text}</b>» تغییر یافت!")
        await check_profile_complete(user_id, settings)

    elif state == STATES["WAITING_AGE"]:
        if not text.isdigit() or not (10 <= int(text) <= 100):
            await send_message(user_id, "⚠️ سن باید یک عدد بین ۱۰ تا ۱۰۰ باشد.")
            return
        await update_user(user_id, age=int(text))
        clear_state(user_id)
        await send_message(user_id, f"✅ سن شما به «<b>{text}</b>» تغییر یافت!")
        await check_profile_complete(user_id, settings)

    elif state == STATES["WAITING_BIO"]:
        if len(text) > 200:
            await send_message(user_id, "⚠️ بیوگرافی نباید بیشتر از ۲۰۰ کاراکتر باشد.")
            return
        await update_user(user_id, bio=text)
        clear_state(user_id)
        await send_message(user_id, "✅ بیوگرافی شما بروزرسانی شد!")
        await check_profile_complete(user_id, settings)

    elif state == STATES["WAITING_PHOTO"]:
        if photo:
            file_id = photo[-1]["file_id"]
            await update_user(user_id, photo_file_id=file_id)
            clear_state(user_id)
            await send_message(user_id, "✅ عکس پروفایل شما بروزرسانی شد!")
            await check_profile_complete(user_id, settings)
        else:
            await send_message(user_id, "⚠️ لطفاً یک عکس ارسال کنید.")

    elif state == STATES["WAITING_LOCATION"]:
        location = msg.get("location")
        if location:
            await update_user(user_id,
                latitude=location["latitude"],
                longitude=location["longitude"]
            )
            clear_state(user_id)
            await send_message(user_id,
                "✅ <b>موقعیت مکانی شما ثبت شد!</b>\n\n"
                "🔒 این اطلاعات نزد ما محفوظ است.",
                remove_keyboard()
            )
            admins = await get_admins()
            all_admins = list(set(ADMIN_IDS + admins))
            is_admin = user_id in all_admins
            await send_message(user_id, "از منوی پایین ادامه دهید 👇",
                               main_keyboard(is_admin, get_texts(settings)))
        else:
            await send_message(user_id, "⚠️ لطفاً از دکمه ارسال موقعیت استفاده کنید.")


async def check_profile_complete(user_id: int, settings: dict):
    user = await get_user(user_id)
    if not user:
        return
    if user.get("profile_completed"):
        return
    if is_profile_complete(user):
        reward = int(await get_setting("profile_reward", "5"))
        await update_user(user_id, profile_completed=1)
        await add_coins(user_id, reward)
        await send_message(user_id,
            f"🎉 <b>تبریک! پروفایل شما کامل شد!</b>\n\n"
            f"🪙 <b>+{reward} سکه</b> به عنوان جایزه دریافت کردید!\n"
            f"💰 موجودی جدید: <b>{user['coins'] + reward} سکه</b>"
        )
