import time
import aiosqlite
from config import DB_PATH, BOT_USERNAME
from database.db import (
    get_user, get_anon_link, create_anon_link, save_anon_message,
    get_anon_messages, get_anon_message, deduct_coins, is_blocked,
    block_user, get_coins, get_setting
)
from utils.http_client import send_message, send_photo, send_document, send_voice, answer_callback_query
from utils.states import get_state, set_state, clear_state, get_data_key, STATES
from keyboards.builders import anon_inbox_inline, inline_kb


async def _get_anon_cost() -> int:
    val = await get_setting("anon_link_cost", "3")
    return int(val)


async def handle_anon_link_menu(user_id: int, settings: dict):
    link = await get_anon_link(user_id)
    bot_user = BOT_USERNAME.lstrip("@")
    cost = await _get_anon_cost()

    if link:
        url = f"https://ble.ir/{bot_user}?start=anon_{link['link_code']}"
        text = (
            "🔗 <b>لینک ناشناس شما</b>\n\n"
            f"<code>{url}</code>\n\n"
            "هر کسی این لینک را بزند می‌تواند ناشناس برای شما پیام بفرستد 🕵️\n\n"
            "📬 برای مشاهده پیام‌های دریافتی 👇"
        )
        markup = inline_kb([
            [{"text": "📬 پیام‌های دریافتی",           "callback_data": "anon:inbox"}],
            [{"text": f"🔄 ساخت لینک جدید ({cost} سکه)", "callback_data": "anon:new_link"}],
        ])
    else:
        coins = await get_coins(user_id)
        text = (
            "🔗 <b>لینک ناشناس</b>\n\n"
            "با ساخت لینک ناشناس، دیگران می‌توانند بدون لو رفتن هویتشان برای شما پیام بفرستند!\n\n"
            f"💰 هزینه ساخت: <b>{cost} سکه</b>\n"
            f"🪙 موجودی شما: <b>{coins} سکه</b>"
        )
        markup = inline_kb([
            [{"text": f"✨ ساخت لینک ناشناس ({cost} سکه)", "callback_data": "anon:new_link"}],
        ])

    await send_message(user_id, text, markup)


async def handle_anon_callback(user_id: int, data: str, cb_id: str, settings: dict):
    await answer_callback_query(cb_id)

    if data == "anon:new_link":
        cost = await _get_anon_cost()
        if cost > 0:
            ok = await deduct_coins(user_id, cost)
            if not ok:
                user = await get_user(user_id)
                await send_message(user_id,
                    f"❌ <b>سکه کافی ندارید!</b>\n\n"
                    f"هزینه لینک: <b>{cost} سکه</b>\n"
                    f"موجودی شما: <b>{user['coins']} سکه</b>")
                return
        code = await create_anon_link(user_id)
        bot_user = BOT_USERNAME.lstrip("@")
        url = f"https://ble.ir/{bot_user}?start=anon_{code}"
        await send_message(user_id,
            f"✅ <b>لینک ناشناس ساخته شد!</b>\n\n"
            f"<code>{url}</code>\n\n"
            "این لینک را با دیگران به اشتراک بگذارید 🎉")

    elif data == "anon:inbox":
        messages = await get_anon_messages(user_id)
        if not messages:
            await send_message(user_id,
                "📭 <b>صندوق خالی است.</b>\n\nهنوز پیام ناشناسی دریافت نکرده‌اید.")
            return
        await send_message(user_id,
            f"📬 <b>صندوق پیام‌های ناشناس</b>\n\n"
            f"📨 تعداد: <b>{len(messages)}</b> پیام")
        for m in messages[:15]:
            content = m.get("message") or "📎 فایل/رسانه"
            blocked = await is_blocked(user_id, m["from_user"])
            markup  = anon_inbox_inline(m["id"], can_block=not blocked)
            await send_message(user_id,
                f"📨 <b>پیام ناشناس #{m['id']}</b>\n\n"
                f"『 {content} 』",
                markup)

    elif data.startswith("anon_reply:"):
        msg_id = int(data.split(":")[1])
        set_state(user_id, STATES["WAITING_ANON_REPLY"], anon_msg_id=msg_id)
        await send_message(user_id,
            "↩️ <b>پاسخ به پیام ناشناس</b>\n\nپاسخ خود را بنویسید:",
            inline_kb([[{"text": "❌ انصراف", "callback_data": "cancel_anon_reply"}]]))

    elif data.startswith("anon_block:"):
        msg_id = int(data.split(":")[1])
        m = await get_anon_message(msg_id)
        if m:
            await block_user(user_id, m["from_user"])
            await send_message(user_id, "🚫 <b>فرستنده بلاک شد.</b>")


async def handle_anon_message_input(user_id: int, msg: dict, link_code: str, settings: dict):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT owner_id FROM anon_links WHERE link_code = ? AND is_active = 1",
            (link_code,)
        ) as cur:
            row = await cur.fetchone()

    if not row:
        await send_message(user_id, "❌ این لینک معتبر نیست.")
        clear_state(user_id)
        return

    owner_id = row[0]

    if await is_blocked(owner_id, user_id):
        await send_message(user_id, "❌ امکان ارسال پیام وجود ندارد.")
        clear_state(user_id)
        return

    text     = msg.get("text")
    photo    = msg.get("photo")
    document = msg.get("document")
    voice    = msg.get("voice")

    file_id   = None
    file_type = None
    preview   = text or ""

    if photo:
        file_id   = photo[-1]["file_id"]
        file_type = "photo"
        preview   = "📸 عکس"
    elif document:
        file_id   = document["file_id"]
        file_type = "document"
        preview   = "📎 فایل"
    elif voice:
        file_id   = voice["file_id"]
        file_type = "voice"
        preview   = "🎤 صوت"

    msg_id = await save_anon_message(link_code, user_id, owner_id, text, file_id, file_type)
    clear_state(user_id)

    owner = await get_user(owner_id)
    if owner and not owner.get("is_silent"):
        await send_message(owner_id,
            f"📨 <b>پیام ناشناس جدید!</b>\n\n"
            f"『 {preview} 』\n\n"
            f"برای پاسخ: /anon_msg_{msg_id}",
            anon_inbox_inline(msg_id))

    await send_message(user_id,
        "✅ <b>پیام ناشناس شما ارسال شد!</b>\n\nهویت شما کاملاً محفوظ است 🕵️")


async def handle_anon_reply(user_id: int, text: str, settings: dict):
    msg_id = get_data_key(user_id, "anon_msg_id")
    m = await get_anon_message(msg_id)
    if not m:
        clear_state(user_id)
        await send_message(user_id, "❌ پیام یافت نشد.")
        return

    await send_message(m["from_user"],
        f"↩️ <b>پاسخ به پیام ناشناس شما:</b>\n\n『 {text} 』")
    clear_state(user_id)
    await send_message(user_id, "✅ پاسخ ارسال شد!")
