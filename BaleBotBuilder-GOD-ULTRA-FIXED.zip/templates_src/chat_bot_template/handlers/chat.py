import asyncio
import time
from database.db import (
    get_user, update_user, add_coins, deduct_coins,
    is_blocked, get_setting, get_coins
)
from utils.http_client import send_message, send_photo, send_document, send_audio, send_video, send_voice, send_sticker, answer_callback_query
from utils.states import get_state, set_state, clear_state, get_data_key, update_data, STATES
from utils.chat_manager import (
    add_to_queue, find_match, start_chat, get_partner, end_chat,
    is_in_chat, get_chat_info, get_chat_duration, remove_from_all_queues,
    add_chat_request, get_chat_request, remove_chat_request
)
from utils.helpers import format_other_profile, get_texts
from keyboards.builders import (
    chat_keyboard, leave_confirm_inline, connect_inline,
    inline_kb, main_keyboard, user_profile_view_inline, chat_request_inline
)
from config import (
    CHAT_COST_RANDOM, CHAT_COST_GENDER, CHAT_SUCCESS_REWARD,
    CHAT_SUCCESS_MIN_SECONDS, CHAT_CANCEL_FREE_SECONDS, ADMIN_IDS
)
from database.db import get_admins


async def handle_connect(user_id: int, settings: dict):
    texts = get_texts(settings)
    await send_message(user_id,
        "🔍 <b>اتصال به ناشناس</b>\n\n"
        "می‌خواهید دقیقاً با چه کسی صحبت کنید؟\n"
        "یکی از گزینه‌های زیر را انتخاب کنید 👇",
        connect_inline(texts)
    )


async def handle_search_callback(user_id: int, data: str, callback_id: str, settings: dict):
    await answer_callback_query(callback_id)

    if is_in_chat(user_id):
        await send_message(user_id, "⚠️ شما هم‌اکنون در حال چت هستید!")
        return

    search_type = data.split(":")[1]
    user = await get_user(user_id)

    cost_random = int(await get_setting("cost_random", str(CHAT_COST_RANDOM)))
    cost_gender = int(await get_setting("cost_gender", str(CHAT_COST_GENDER)))

    if search_type in ("girl", "boy"):
        if cost_gender > 0:
            ok = await deduct_coins(user_id, cost_gender)
            if not ok:
                await send_message(user_id,
                    f"❌ <b>سکه کافی ندارید!</b>\n\n"
                    f"جستجو با جنسیت: <b>{cost_gender} سکه</b>\n"
                    f"موجودی شما: <b>{user['coins']} سکه</b>"
                )
                return

    if search_type == "nearest":
        if not user.get("latitude"):
            await send_message(user_id,
                "📍 <b>موقعیت مکانی ثبت نشده!</b>\n\n"
                "برای یافتن نزدیک‌ترین فرد، ابتدا موقعیت مکانی خود را در پروفایل ثبت کنید."
            )
            return
        from database.db import get_nearby_users
        nearby = await get_nearby_users(user["latitude"], user["longitude"], exclude_id=user_id, limit=5)
        if not nearby:
            await send_message(user_id, "😔 در حال حاضر کسی در نزدیکی شما آنلاین نیست.")
            return
        target = nearby[0]
        partner_id = target["user_id"]
        if await is_blocked(partner_id, user_id) or await is_blocked(user_id, partner_id):
            await send_message(user_id, "❌ امکان اتصال به این کاربر وجود ندارد.")
            return
        from utils.helpers import haversine
        dist = haversine(user["latitude"], user["longitude"], target["latitude"], target["longitude"])
        await _connect_two(user_id, partner_id, "nearest", settings)
        return

    partner_id = find_match(user_id, search_type,
                             province=user.get("province") if search_type == "province" else None,
                             gender=user.get("gender"))

    if partner_id:
        await _connect_two(user_id, partner_id, search_type, settings)
    else:
        add_to_queue(user_id, search_type,
                     province=user.get("province"),
                     gender=user.get("gender"))
        set_state(user_id, STATES["SEARCHING"], search_type=search_type)
        await send_message(user_id,
            "🔄 <b>در حال جستجو...</b>\n\n"
            "منتظر بمانید تا یک کاربر مناسب پیدا شود 🕵️",
            inline_kb([[{"text": "❌ لغو جستجو", "callback_data": "cancel_search"}]])
        )
        asyncio.create_task(_wait_for_match(user_id, search_type, settings))


async def _wait_for_match(user_id: int, search_type: str, settings: dict):
    for _ in range(120):
        await asyncio.sleep(2)
        if get_state(user_id) != STATES["SEARCHING"]:
            return
        partner_id = find_match(user_id, search_type)
        if partner_id:
            await _connect_two(user_id, partner_id, search_type, settings)
            return
    remove_from_all_queues(user_id)
    clear_state(user_id)
    await send_message(user_id,
        "😔 <b>کاربری پیدا نشد.</b>\n\nلطفاً بعداً دوباره امتحان کنید."
    )


async def _connect_two(user1_id: int, user2_id: int, chat_type: str, settings: dict):
    import time as _time
    import aiosqlite
    from config import DB_PATH
    texts = get_texts(settings)
    admins = await get_admins()
    all_admins = list(set(ADMIN_IDS + admins))

    start_chat(user1_id, user2_id, chat_type)
    clear_state(user1_id)
    clear_state(user2_id)

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO chats (user1_id, user2_id, started_at, status, chat_type) VALUES (?,?,?,?,?)",
            (user1_id, user2_id, int(_time.time()), "active", chat_type)
        )
        await db.commit()

    msg = (
        "✨ <b>به یک ناشناس وصل شدید!</b>\n\n"
        "💬 الان می‌تونید چت کنید.\n"
        "📎 ارسال عکس، فایل و صوت هم پشتیبانی می‌شود.\n"
        "🔒 هویت شما کاملاً محفوظ است."
    )
    kb = chat_keyboard(texts)
    await send_message(user1_id, msg, kb)
    await send_message(user2_id, msg, kb)


async def handle_chat_message(user_id: int, msg: dict, settings: dict):
    partner_id = get_partner(user_id)
    if not partner_id:
        return False

    if await is_blocked(partner_id, user_id):
        return True

    text = msg.get("text")
    photo = msg.get("photo")
    document = msg.get("document")
    audio = msg.get("audio")
    video = msg.get("video")
    voice = msg.get("voice")
    sticker = msg.get("sticker")
    caption = msg.get("caption", "")

    try:
        if text:
            await send_message(partner_id, f"💬 {text}")
        elif photo:
            file_id = photo[-1]["file_id"]
            await send_photo(partner_id, file_id, caption or None)
        elif document:
            await send_document(partner_id, document["file_id"], caption or None)
        elif audio:
            await send_audio(partner_id, audio["file_id"], caption or None)
        elif video:
            await send_video(partner_id, video["file_id"], caption or None)
        elif voice:
            await send_voice(partner_id, voice["file_id"])
        elif sticker:
            await send_sticker(partner_id, sticker["file_id"])
    except Exception:
        pass

    return True


async def handle_leave_chat(user_id: int, callback_id: str, settings: dict):
    if callback_id:
        await answer_callback_query(callback_id)
    await send_message(user_id,
        "🚪 <b>ترک چت</b>\n\nآیا مطمئن هستید که می‌خواهید چت را ترک کنید؟",
        leave_confirm_inline()
    )


async def handle_leave_confirm(user_id: int, data: str, callback_id: str, settings: dict):
    await answer_callback_query(callback_id)
    if data == "leave_confirm:no":
        await send_message(user_id, "✅ برگشتید به چت!")
        return

    partner_id, duration = end_chat(user_id)
    texts = get_texts(settings)
    admins = await get_admins()
    all_admins = list(set(ADMIN_IDS + admins))
    is_admin_u = user_id in all_admins
    is_admin_p = partner_id in all_admins if partner_id else False

    import time as _t2, aiosqlite
    from config import DB_PATH as _db
    async with aiosqlite.connect(_db) as db:
        await db.execute(
            "UPDATE chats SET status='ended', ended_at=? WHERE (user1_id=? OR user2_id=?) AND status='active'",
            (int(_t2.time()), user_id, user_id)
        )
        await db.commit()

    if duration < CHAT_CANCEL_FREE_SECONDS:
        cost_gender = int(await get_setting("cost_gender", str(CHAT_COST_GENDER)))
        if cost_gender > 0:
            await add_coins(user_id, cost_gender)


    await send_message(user_id,
        "👋 <b>چت به پایان رسید.</b>\n\nتا چت بعدی! 😊",
        main_keyboard(is_admin_u, texts)
    )
    clear_state(user_id)

    if partner_id:
        await send_message(partner_id,
            "👋 <b>مخاطب شما چت را ترک کرد.</b>\n\nمی‌تونی دوباره جستجو کنی! 🔍",
            main_keyboard(is_admin_p, texts)
        )
        clear_state(partner_id)

        if duration >= CHAT_SUCCESS_MIN_SECONDS:
            reward = int(await get_setting("chat_success_reward", str(CHAT_SUCCESS_REWARD)))
            if reward > 0:
                await add_coins(user_id, reward)
                await add_coins(partner_id, reward)
                await send_message(user_id,
                    f"🎁 <b>چت موفق!</b> +{reward} سکه دریافت کردید 🪙"
                )
                await send_message(partner_id,
                    f"🎁 <b>چت موفق!</b> +{reward} سکه دریافت کردید 🪙"
                )


async def handle_view_partner_profile(user_id: int, callback_id: str, settings: dict):
    if callback_id:
        await answer_callback_query(callback_id)
    partner_id = get_partner(user_id)
    if not partner_id:
        await send_message(user_id, "❌ شما در حال چت نیستید.")
        return
    partner = await get_user(partner_id)
    if not partner:
        return

    text = (
        "👤 <b>پروفایل مخاطب</b>\n\n"
        f"• <b>نام:</b> {partner.get('full_name', 'ناشناس')}\n"
        f"• <b>سن:</b> {partner.get('age', '؟')}\n"
        f"• <b>جنسیت:</b> {partner.get('gender', 'نامشخص')}\n"
        f"• <b>استان:</b> {partner.get('province', 'نامشخص')}\n"
    )
    if partner.get("bio"):
        text += f"\n📝 {partner['bio']}"

    await send_message(partner_id,
        "👁️ <b>مخاطب شما پروفایلتان را مشاهده کرد!</b>"
    )
    await send_message(user_id, text)


async def handle_chat_request(user_id: int, target_id: int, callback_id: str, settings: dict):
    await answer_callback_query(callback_id)

    cost = int(await get_setting("cost_profile_request", "3"))
    if cost > 0:
        ok = await deduct_coins(user_id, cost)
        if not ok:
            user = await get_user(user_id)
            await send_message(user_id,
                f"❌ <b>سکه کافی ندارید!</b>\n\n"
                f"درخواست چت: <b>{cost} سکه</b>\n"
                f"موجودی شما: <b>{user['coins']} سکه</b>"
            )
            return

    if await is_blocked(target_id, user_id):
        if cost > 0:
            await add_coins(user_id, cost)
        await send_message(user_id, "❌ نمی‌توانید به این کاربر درخواست ارسال کنید.")
        return

    sender = await get_user(user_id)
    uid = sender.get("referral_code", "???")
    add_chat_request(user_id, target_id)

    await send_message(target_id,
        f"💬 <b>درخواست چت جدید!</b>\n\n"
        f"از طرف: /user_{uid}\n\n"
        f"⏳ ۲ دقیقه فرصت دارید تا پاسخ دهید.",
        chat_request_inline(user_id)
    )
    await send_message(user_id, "✅ <b>درخواست چت ارسال شد!</b>\n\nمنتظر پاسخ بمانید...")


async def handle_accept_chat(user_id: int, from_id: int, callback_id: str, settings: dict):
    await answer_callback_query(callback_id)
    req = get_chat_request(user_id)
    if not req or req["from_user"] != from_id:
        await send_message(user_id, "❌ درخواست منقضی شده است.")
        return
    remove_chat_request(user_id)
    await _connect_two(user_id, from_id, "profile", settings)
    cost = int(await get_setting("cost_profile_request", "3"))


async def handle_reject_chat(user_id: int, from_id: int, callback_id: str, settings: dict):
    await answer_callback_query(callback_id)
    remove_chat_request(user_id)
    cost = int(await get_setting("cost_profile_request", "3"))
    if cost > 0:
        await add_coins(from_id, cost)
    await send_message(user_id, "✅ درخواست رد شد.")
    await send_message(from_id,
        "❌ <b>درخواست چت شما رد شد.</b>\n\n"
        + (f"🪙 <b>{cost} سکه</b> به حسابتان برگشت." if cost > 0 else "")
    )
