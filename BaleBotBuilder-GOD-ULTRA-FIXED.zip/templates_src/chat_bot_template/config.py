import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN    = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN")
ADMIN_IDS    = [int(x) for x in os.getenv("ADMIN_IDS", "123456789").split(",")]
BOT_USERNAME = os.getenv("BOT_USERNAME", "your_bot")
BASE_URL     = f"https://tapi.bale.ai/bot{BOT_TOKEN}"
DB_PATH      = os.getenv("DB_PATH", "bot.db")

DEFAULT_TEXTS = {
    "btn_connect":           "🔗 به یه ناشناس وصلم کن!",
    "btn_nearby":            "📍 افراد نزدیک من",
    "btn_guide":             "🤔 راهنما",
    "btn_profile":           "👤 پروفایل",
    "btn_coins":             "💰 سکه",
    "btn_anon_link":         "📩 لینک ناشناس من",
    "btn_referral":          "🚶 معرفی به دوستان (سکه رایگان)",
    "btn_admin":             "⚙️ پنل ادمین",
    "btn_random":            "🎲 جستجوی تصادفی",
    "btn_girl":              "👧 دختر",
    "btn_boy":               "👦 پسر",
    "btn_same_province":     "🏙️ هم‌استانی",
    "btn_nearest":           "📌 نزدیک‌ترین فرد به من",
    "btn_view_location":     "🗺️ مشاهده موقعیت مکانی من",
    "btn_view_likes":        "❤️ مشاهده لایک‌های من",
    "btn_edit_profile":      "✏️ ویرایش پروفایل",
    "btn_blocked_list":      "🚫 لیست بلاک‌شده‌ها",
    "btn_directs":           "💬 پیام‌های دایرکت",
    "btn_change_name":       "📝 تغییر نام",
    "btn_change_photo":      "🖼️ تغییر عکس پروفایل",
    "btn_change_bio":        "📄 تغییر بیوگرافی",
    "btn_change_gender":     "⚧️ تغییر جنسیت",
    "btn_change_province":   "🏘️ تغییر استان",
    "btn_change_location":   "📡 ارسال / تغییر موقعیت مکانی",
    "btn_view_chat_profile": "👁️ مشاهده پروفایل مخاطب",
    "btn_leave_chat":        "🚪 ترک چت",
    "btn_nearby_girls":      "👧 دخترهای نزدیک",
    "btn_nearby_boys":       "👦 پسرهای نزدیک",
    "btn_free_coins":        "🎁 سکه رایگان",
}

PROVINCES = [
    "آذربایجان شرقی","آذربایجان غربی","اردبیل","اصفهان","البرز",
    "ایلام","بوشهر","تهران","چهارمحال و بختیاری","خراسان جنوبی",
    "خراسان رضوی","خراسان شمالی","خوزستان","زنجان","سمنان",
    "سیستان و بلوچستان","فارس","قزوین","قم","کردستان",
    "کرمان","کرمانشاه","کهگیلویه و بویراحمد","گلستان","گیلان",
    "لرستان","مازندران","مرکزی","هرمزگان","همدان","یزد",
]

CHAT_COST_RANDOM         = 0
CHAT_COST_GENDER         = 2
CHAT_COST_PROFILE_REQ    = 3
DIRECT_MSG_COST          = 2
ANON_LINK_COST           = 3
GENDER_CHANGE_FREE_TIMES = 2
GENDER_CHANGE_COIN_COST  = 3
CHAT_SUCCESS_REWARD      = 1
CHAT_SUCCESS_MIN_SECONDS = 300
CHAT_CANCEL_FREE_SECONDS = 30
PROFILE_COMPLETE_REWARD  = 5
REFERRAL_JOIN_REWARD     = 10
REFERRAL_CHANNEL_REWARD  = 5
