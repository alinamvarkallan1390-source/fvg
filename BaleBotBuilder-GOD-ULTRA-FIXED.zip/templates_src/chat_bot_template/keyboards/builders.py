from config import DEFAULT_TEXTS, PROVINCES
from typing import List


def _t(s: dict, key: str) -> str:
    return s.get(key) or DEFAULT_TEXTS.get(key, key)


def back_keyboard() -> dict:
    return {"keyboard": [[{"text": "🔙 بازگشت به منو"}]], "resize_keyboard": True}


def main_keyboard(is_admin: bool = False, s: dict = None) -> dict:
    s = s or {}
    rows = [
        [{"text": _t(s, "btn_connect")}],
        [{"text": _t(s, "btn_nearby")},   {"text": _t(s, "btn_guide")}],
        [{"text": _t(s, "btn_coins")},    {"text": _t(s, "btn_profile")}],
        [{"text": _t(s, "btn_anon_link")},{"text": _t(s, "btn_referral")}],
    ]
    if is_admin:
        rows.append([{"text": _t(s, "btn_admin")}])
    return {"keyboard": rows, "resize_keyboard": True}


def chat_keyboard(s: dict = None) -> dict:
    s = s or {}
    return {"keyboard": [[
        {"text": _t(s, "btn_view_chat_profile")},
        {"text": _t(s, "btn_leave_chat")},
    ]], "resize_keyboard": True}


def location_keyboard() -> dict:
    return {"keyboard": [
        [{"text": "📡 ارسال موقعیت مکانی دقیق", "request_location": True}],
        [{"text": "🔙 بازگشت به منو"}],
    ], "resize_keyboard": True}


def remove_keyboard() -> dict:
    return {"remove_keyboard": True}


def inline_kb(rows: List[List[dict]]) -> dict:
    return {"inline_keyboard": rows}


def connect_inline(s: dict = None) -> dict:
    s = s or {}
    return inline_kb([
        [{"text": _t(s, "btn_random"),        "callback_data": "search:random"}],
        [{"text": _t(s, "btn_girl"),          "callback_data": "search:girl"},
         {"text": _t(s, "btn_boy"),           "callback_data": "search:boy"}],
        [{"text": _t(s, "btn_same_province"), "callback_data": "search:province"}],
        [{"text": _t(s, "btn_nearest"),       "callback_data": "search:nearest"}],
    ])


def profile_inline(s: dict = None) -> dict:
    s = s or {}
    return inline_kb([
        [{"text": _t(s, "btn_view_location"), "callback_data": "profile:location"},
         {"text": _t(s, "btn_view_likes"),    "callback_data": "profile:likes"}],
        [{"text": _t(s, "btn_edit_profile"),  "callback_data": "profile:edit"}],
        [{"text": _t(s, "btn_blocked_list"),  "callback_data": "profile:blocked"},
         {"text": _t(s, "btn_directs"),       "callback_data": "profile:directs"}],
    ])


def edit_profile_inline(s: dict = None) -> dict:
    s = s or {}
    return inline_kb([
        [{"text": _t(s, "btn_change_name"),      "callback_data": "edit:name"}],
        [{"text": _t(s, "btn_change_photo"),     "callback_data": "edit:photo"}],
        [{"text": _t(s, "btn_change_bio"),       "callback_data": "edit:bio"}],
        [{"text": _t(s, "btn_change_gender"),    "callback_data": "edit:gender"}],
        [{"text": _t(s, "btn_change_province"),  "callback_data": "edit:province"}],
        [{"text": _t(s, "btn_change_location"),  "callback_data": "edit:location"}],
    ])


def gender_inline() -> dict:
    return inline_kb([[
        {"text": "👧 دختر", "callback_data": "set_gender:دختر"},
        {"text": "👦 پسر",  "callback_data": "set_gender:پسر"},
    ]])


def provinces_inline() -> dict:
    rows = []
    for i in range(0, len(PROVINCES), 2):
        row = [{"text": PROVINCES[i], "callback_data": f"set_province:{PROVINCES[i]}"}]
        if i + 1 < len(PROVINCES):
            row.append({"text": PROVINCES[i+1], "callback_data": f"set_province:{PROVINCES[i+1]}"})
        rows.append(row)
    return inline_kb(rows)


def coins_inline(packages: list, s: dict = None) -> dict:
    s = s or {}
    rows = []
    for pkg in packages:
        rows.append([{
            "text": f"🪙 {pkg['title']} ← {pkg['coins']} سکه | {pkg['price']:,} تومن",
            "callback_data": f"buy:{pkg['id']}",
        }])
    rows.append([{"text": _t(s, "btn_free_coins"), "callback_data": "coins:free"}])
    return inline_kb(rows)


def payment_inline(order_id: int, amount: int, card: str, discount_applied: bool = False) -> dict:
    rows = []
    if not discount_applied:
        rows.append([{"text": "🏷️ اعمال کد تخفیف", "callback_data": f"discount:{order_id}"}])
    rows += [
        [{"text": f"📋 کپی مبلغ: {amount:,} تومن", "callback_data": f"copy_amount:{amount}"},
         {"text": "💳 کپی شماره کارت",               "callback_data": f"copy_card:{card}"}],
        [{"text": "✅ تایید پرداخت و ارسال رسید",     "callback_data": f"confirm_pay:{order_id}"}],
    ]
    return inline_kb(rows)


def nearby_gender_inline() -> dict:
    return inline_kb([[
        {"text": "👧 دخترهای نزدیک", "callback_data": "nearby:girl"},
        {"text": "👦 پسرهای نزدیک",  "callback_data": "nearby:boy"},
    ]])


def user_profile_view_inline(target_id: int, likes: int, cost_chat: int = 3) -> dict:
    return inline_kb([
        [{"text": "❤️ لایک کردن پروفایل",           "callback_data": f"like:{target_id}"}],
        [{"text": f"💬 درخواست چت ({cost_chat} سکه)", "callback_data": f"chat_req:{target_id}"}],
        [{"text": f"❤️ تعداد لایک‌ها: {likes}",       "callback_data": "noop"}],
        [{"text": "🚫 بلاک کردن",                    "callback_data": f"block:{target_id}"}],
        [{"text": "📨 پیام دایرکت (۲ سکه)",           "callback_data": f"direct:{target_id}"}],
    ])


def chat_request_inline(from_id: int) -> dict:
    return inline_kb([[
        {"text": "✅ تایید و ورود به چت", "callback_data": f"accept_chat:{from_id}"},
        {"text": "❌ رد",                 "callback_data": f"reject_chat:{from_id}"},
    ]])


def anon_inbox_inline(msg_id: int, can_block: bool = True) -> dict:
    rows = [[{"text": "↩️ پاسخ به این پیام", "callback_data": f"anon_reply:{msg_id}"}]]
    if can_block:
        rows.append([{"text": "🚫 بلاک فرستنده", "callback_data": f"anon_block:{msg_id}"}])
    return inline_kb(rows)


def direct_msg_inline(from_user: int, dm_id: int) -> dict:
    return inline_kb([
        [{"text": "↩️ پاسخ (رایگان)", "callback_data": f"reply_dm:{dm_id}:{from_user}"}],
        [{"text": "🚫 بلاک",           "callback_data": f"block:{from_user}"}],
    ])


def leave_confirm_inline() -> dict:
    return inline_kb([[
        {"text": "✅ بله، ترک می‌کنم", "callback_data": "leave:yes"},
        {"text": "❌ خیر",              "callback_data": "leave:no"},
    ]])


def order_admin_inline(order_id: int) -> dict:
    return inline_kb([
        [{"text": "✅ تایید",             "callback_data": f"ord_ok:{order_id}"},
         {"text": "❌ رد",                "callback_data": f"ord_rej:{order_id}"}],
        [{"text": "🪙 ارسال سکه دلخواه", "callback_data": f"ord_custom:{order_id}"}],
    ])


def broadcast_btn_inline() -> dict:
    return inline_kb([[
        {"text": "✅ بله، دکمه می‌خواهم", "callback_data": "bc:add_btn"},
        {"text": "❌ خیر",                 "callback_data": "bc:no_btn"},
    ]])


def admin_main_keyboard() -> dict:
    return {"keyboard": [
        [{"text": "📊 آمار آنلاین"},          {"text": "📣 پیام همگانی"}],
        [{"text": "🔁 فروارد همگانی"}],
        [{"text": "➕ افزودن کانال اجباری"},  {"text": "➖ حذف کانال اجباری"}],
        [{"text": "⬇️ دانلود دیتابیس"},       {"text": "⬆️ آپلود دیتابیس"}],
        [{"text": "👥 مدیریت ادمین‌ها"}],
        [{"text": "🎁 هدیه زیرمجموعه‌گیری"}, {"text": "👥 تنظیم زیرمجموعه‌گیری"}],
        [{"text": "🏆 جایزه تکمیل پروفایل"}],
        [{"text": "📦 افزودن بسته سکه"},      {"text": "🗑️ حذف بسته سکه"}],
        [{"text": "💳 مدیریت شماره کارت‌ها"}],
        [{"text": "⏳ پرداخت‌های تاییدنشده"}],
        [{"text": "🪙 سکه همگانی"},           {"text": "🪙 سکه با آیدی"}],
        [{"text": "🏷️ افزودن کد تخفیف"}],
        [{"text": "✏️ تغییر متن دکمه‌ها"}],
        [{"text": "💬 هزینه چت تصادفی"},      {"text": "💬 هزینه چت جنسیت"}],
        [{"text": "💬 هزینه درخواست پروفایل"},{"text": "🔗 هزینه لینک ناشناس"}],
        [{"text": "🔙 بازگشت به منو"}],
    ], "resize_keyboard": True}


def btn_list_inline(settings: dict) -> dict:
    rows = []
    for key, default_val in DEFAULT_TEXTS.items():
        cur = settings.get(key) or default_val
        rows.append([{"text": f"✏️ {cur}", "callback_data": f"edit_btn:{key}"}])
    return inline_kb(rows)
