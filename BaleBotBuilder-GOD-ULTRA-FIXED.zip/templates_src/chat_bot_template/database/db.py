import aiosqlite
import asyncio
import hashlib
import time
from config import DB_PATH


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                user_id INTEGER UNIQUE NOT NULL,
                username TEXT,
                full_name TEXT DEFAULT 'کاربر ربات',
                age INTEGER DEFAULT 99,
                gender TEXT DEFAULT 'نامشخص',
                province TEXT DEFAULT 'تهران',
                city TEXT DEFAULT 'تهران',
                bio TEXT,
                photo_file_id TEXT,
                coins INTEGER DEFAULT 0,
                likes INTEGER DEFAULT 0,
                latitude REAL,
                longitude REAL,
                is_banned INTEGER DEFAULT 0,
                is_silent INTEGER DEFAULT 0,
                referral_code TEXT UNIQUE,
                referred_by INTEGER,
                profile_completed INTEGER DEFAULT 0,
                gender_changes INTEGER DEFAULT 0,
                created_at INTEGER DEFAULT 0,
                last_seen INTEGER DEFAULT 0,
                is_online INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS chats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user1_id INTEGER NOT NULL,
                user2_id INTEGER NOT NULL,
                started_at INTEGER DEFAULT 0,
                ended_at INTEGER DEFAULT 0,
                status TEXT DEFAULT 'active',
                chat_type TEXT DEFAULT 'random'
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS chat_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_user INTEGER NOT NULL,
                to_user INTEGER NOT NULL,
                created_at INTEGER DEFAULT 0,
                status TEXT DEFAULT 'pending'
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS blocks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                blocker_id INTEGER NOT NULL,
                blocked_id INTEGER NOT NULL,
                created_at INTEGER DEFAULT 0,
                UNIQUE(blocker_id, blocked_id)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS direct_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_user INTEGER NOT NULL,
                to_user INTEGER NOT NULL,
                message TEXT,
                created_at INTEGER DEFAULT 0,
                is_read INTEGER DEFAULT 0,
                replied INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS anon_links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id INTEGER NOT NULL,
                link_code TEXT UNIQUE NOT NULL,
                created_at INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS anon_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                link_code TEXT NOT NULL,
                from_user INTEGER NOT NULL,
                owner_id INTEGER NOT NULL,
                message TEXT,
                file_id TEXT,
                file_type TEXT,
                created_at INTEGER DEFAULT 0,
                is_read INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS coin_packages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                coins INTEGER NOT NULL,
                price INTEGER NOT NULL,
                is_active INTEGER DEFAULT 1
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                package_id INTEGER,
                coins INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                discount_code TEXT,
                discount_percent INTEGER DEFAULT 0,
                final_amount INTEGER NOT NULL,
                receipt_file_id TEXT,
                tracking_code TEXT,
                transaction_time TEXT,
                status TEXT DEFAULT 'pending',
                reject_reason TEXT,
                created_at INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS discount_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                percent INTEGER NOT NULL,
                max_uses INTEGER DEFAULT -1,
                used_count INTEGER DEFAULT 0,
                expires_days INTEGER DEFAULT 30,
                created_at INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS join_channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_link TEXT NOT NULL,
                channel_username TEXT NOT NULL,
                button_text TEXT NOT NULL,
                is_active INTEGER DEFAULT 1
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE NOT NULL,
                added_at INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS bot_settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS likes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                liker_id INTEGER NOT NULL,
                liked_id INTEGER NOT NULL,
                created_at INTEGER DEFAULT 0,
                UNIQUE(liker_id, liked_id)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT UNIQUE NOT NULL,
                total_users INTEGER DEFAULT 0,
                new_users INTEGER DEFAULT 0,
                total_chats INTEGER DEFAULT 0
            )
        """)
        await db.commit()


async def get_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def create_user(user_id: int, username: str, full_name: str, referred_by: int = None):
    code = hashlib.md5(f"{user_id}{time.time()}".encode()).hexdigest()[:8]
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT OR IGNORE INTO users (user_id, username, full_name, referral_code, referred_by, created_at, last_seen, is_online)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1)
        """, (user_id, username, full_name, code, referred_by, int(time.time()), int(time.time())))
        await db.commit()


async def update_user(user_id: int, **kwargs):
    if not kwargs:
        return
    fields = ", ".join(f"{k} = ?" for k in kwargs)
    values = list(kwargs.values()) + [user_id]
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE users SET {fields} WHERE user_id = ?", values)
        await db.commit()


async def get_setting(key: str, default: str = ""):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT value FROM bot_settings WHERE key = ?", (key,)) as cur:
            row = await cur.fetchone()
            return row[0] if row else default


async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR REPLACE INTO bot_settings (key, value) VALUES (?, ?)", (key, value))
        await db.commit()


async def get_all_settings():
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT key, value FROM bot_settings") as cur:
            rows = await cur.fetchall()
            return {r[0]: r[1] for r in rows}


async def get_coins(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT coins FROM users WHERE user_id = ?", (user_id,)) as cur:
            row = await cur.fetchone()
            return row[0] if row else 0


async def add_coins(user_id: int, amount: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET coins = coins + ? WHERE user_id = ?", (amount, user_id))
        await db.commit()


async def deduct_coins(user_id: int, amount: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT coins FROM users WHERE user_id = ?", (user_id,)) as cur:
            row = await cur.fetchone()
            if not row or row[0] < amount:
                return False
        await db.execute("UPDATE users SET coins = coins - ? WHERE user_id = ?", (amount, user_id))
        await db.commit()
        return True


async def is_blocked(blocker_id: int, blocked_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT id FROM blocks WHERE blocker_id = ? AND blocked_id = ?", (blocker_id, blocked_id)) as cur:
            return await cur.fetchone() is not None


async def block_user(blocker_id: int, blocked_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO blocks (blocker_id, blocked_id, created_at) VALUES (?, ?, ?)",
                         (blocker_id, blocked_id, int(time.time())))
        await db.commit()


async def unblock_user(blocker_id: int, blocked_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?", (blocker_id, blocked_id))
        await db.commit()


async def get_blocked_list(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT u.user_id, u.full_name, u.username
            FROM blocks b JOIN users u ON b.blocked_id = u.user_id
            WHERE b.blocker_id = ?
        """, (user_id,)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_active_channels():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM join_channels WHERE is_active = 1") as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_coin_packages():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM coin_packages WHERE is_active = 1") as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_discount_code(code: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM discount_codes WHERE code = ? AND is_active = 1", (code,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def use_discount_code(code: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE discount_codes SET used_count = used_count + 1 WHERE code = ?", (code,))
        await db.commit()


async def create_order(user_id, package_id, coins, amount, discount_code, discount_percent, final_amount):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            INSERT INTO orders (user_id, package_id, coins, amount, discount_code, discount_percent, final_amount, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)
        """, (user_id, package_id, coins, amount, discount_code, discount_percent, final_amount, int(time.time())))
        await db.commit()
        return cur.lastrowid


async def update_order(order_id, **kwargs):
    fields = ", ".join(f"{k} = ?" for k in kwargs)
    values = list(kwargs.values()) + [order_id]
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE orders SET {fields} WHERE id = ?", values)
        await db.commit()


async def get_order(order_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_pending_orders():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT o.*, u.username, u.full_name FROM orders o
            JOIN users u ON o.user_id = u.user_id
            WHERE o.status = 'pending' ORDER BY o.created_at DESC
        """) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_anon_link(owner_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM anon_links WHERE owner_id = ? AND is_active = 1 ORDER BY id DESC LIMIT 1", (owner_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def create_anon_link(owner_id: int):
    import hashlib, time
    code = hashlib.md5(f"anon{owner_id}{time.time()}".encode()).hexdigest()[:10]
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO anon_links (owner_id, link_code, created_at) VALUES (?, ?, ?)",
                         (owner_id, code, int(time.time())))
        await db.commit()
    return code


async def save_anon_message(link_code, from_user, owner_id, message=None, file_id=None, file_type=None):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            INSERT INTO anon_messages (link_code, from_user, owner_id, message, file_id, file_type, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (link_code, from_user, owner_id, message, file_id, file_type, int(time.time())))
        await db.commit()
        return cur.lastrowid


async def get_anon_messages(owner_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT * FROM anon_messages WHERE owner_id = ? ORDER BY created_at DESC
        """, (owner_id,)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_anon_message(msg_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM anon_messages WHERE id = ?", (msg_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_nearby_users(lat: float, lon: float, gender: str = None, exclude_id: int = None, limit: int = 20):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        query = """
            SELECT *, 
            (6371000 * acos(
                cos(radians(?)) * cos(radians(latitude)) *
                cos(radians(longitude) - radians(?)) +
                sin(radians(?)) * sin(radians(latitude))
            )) AS distance
            FROM users
            WHERE latitude IS NOT NULL AND longitude IS NOT NULL
            AND is_online = 1 AND is_banned = 0
        """
        params = [lat, lon, lat]
        if gender:
            query += " AND gender = ?"
            params.append(gender)
        if exclude_id:
            query += " AND user_id != ?"
            params.append(exclude_id)
        query += " ORDER BY distance ASC LIMIT ?"
        params.append(limit)
        async with db.execute(query, params) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_total_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM users WHERE is_banned = 0") as cur:
            total_users = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM chats") as cur:
            total_chats = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM chats WHERE status = 'active'") as cur:
            active_chats = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM users WHERE is_online = 1 AND is_banned = 0") as cur:
            online_users = (await cur.fetchone())[0]
        async with db.execute("SELECT SUM(coins) FROM users WHERE is_banned = 0") as cur:
            total_coins = (await cur.fetchone())[0] or 0
        async with db.execute("""
            SELECT date, total_users FROM stats ORDER BY date DESC LIMIT 3
        """) as cur:
            growth = await cur.fetchall()
        return {
            "total_users": total_users,
            "total_chats": total_chats,
            "active_chats": active_chats,
            "online_users": online_users,
            "total_coins": total_coins,
            "growth": growth
        }


async def get_all_users_ids():
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT user_id FROM users WHERE is_banned = 0") as cur:
            return [r[0] for r in await cur.fetchall()]


async def get_user_by_referral(code: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE referral_code = ?", (code,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_like_count(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM likes WHERE liked_id = ?", (user_id,)) as cur:
            return (await cur.fetchone())[0]


async def like_user(liker_id: int, liked_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute("INSERT INTO likes (liker_id, liked_id, created_at) VALUES (?, ?, ?)",
                             (liker_id, liked_id, int(time.time())))
            await db.execute("UPDATE users SET likes = likes + 1 WHERE user_id = ?", (liked_id,))
            await db.commit()
            return True
        except Exception:
            return False


async def get_likers(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT u.user_id, u.full_name, u.username, l.created_at
            FROM likes l JOIN users u ON l.liker_id = u.user_id
            WHERE l.liked_id = ? ORDER BY l.created_at DESC
        """, (user_id,)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def save_direct(from_user: int, to_user: int, message: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            INSERT INTO direct_messages (from_user, to_user, message, created_at)
            VALUES (?, ?, ?, ?)
        """, (from_user, to_user, message, int(time.time())))
        await db.commit()
        return cur.lastrowid


async def get_directs(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT dm.*, u.full_name, u.username FROM direct_messages dm
            JOIN users u ON dm.from_user = u.user_id
            WHERE dm.to_user = ? ORDER BY dm.created_at DESC
        """, (user_id,)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_admins():
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT user_id FROM admins") as cur:
            return [r[0] for r in await cur.fetchall()]


async def add_admin(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO admins (user_id, added_at) VALUES (?, ?)", (user_id, int(time.time())))
        await db.commit()


async def remove_admin(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM admins WHERE user_id = ?", (user_id,))
        await db.commit()
