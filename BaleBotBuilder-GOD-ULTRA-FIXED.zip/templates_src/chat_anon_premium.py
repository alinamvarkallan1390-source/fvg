import asyncio
import logging
import time
from database.db import init_db
from utils.http_client import get_updates, close_client, get_me
from dispatcher import dispatch_message, dispatch_callback

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("bot")


async def fetch_bot_username():
    """Fetch bot username from API and store in config."""
    import config
    try:
        result = await get_me()
        if result.get("ok"):
            username = result["result"].get("username", "")
            if username:
                config.BOT_USERNAME = username
                logger.info(f"Bot username fetched: @{username}")
            return username
    except Exception as e:
        logger.error(f"Failed to fetch bot username: {e}")
    return config.BOT_USERNAME


async def polling():
    offset = None
    logger.info("Bot started — polling...")
    while True:
        try:
            result = await get_updates(offset=offset, timeout=30)
            if not result.get("ok"):
                await asyncio.sleep(2)
                continue
            for update in result.get("result", []):
                offset = update["update_id"] + 1
                asyncio.create_task(handle_update(update))
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"Polling error: {e}")
            await asyncio.sleep(3)


async def handle_update(update: dict):
    try:
        if "message" in update:
            await dispatch_message(update["message"])
        elif "callback_query" in update:
            await dispatch_callback(update["callback_query"])
    except Exception as e:
        logger.error(f"Update handler error: {e}", exc_info=True)


async def daily_stats_cron():
    import aiosqlite
    from config import DB_PATH, BASE_URL
    import httpx
    while True:
        now = time.localtime()
        seconds_until_midnight = (
            (23 - now.tm_hour) * 3600
            + (59 - now.tm_min) * 60
            + (60 - now.tm_sec)
        )
        await asyncio.sleep(seconds_until_midnight)
        try:
            today = time.strftime("%Y-%m-%d")
            async with aiosqlite.connect(DB_PATH) as db:
                async with db.execute(
                    "SELECT user_id FROM users WHERE is_banned = 0"
                ) as cur:
                    all_users = [r[0] for r in await cur.fetchall()]

                blocked_count = 0
                async with httpx.AsyncClient(timeout=5.0) as client:
                    for uid in all_users:
                        try:
                            r = await client.post(
                                f"{BASE_URL}/sendChatAction",
                                json={"chat_id": uid, "action": "typing"},
                            )
                            resp = r.json()
                            if not resp.get("ok"):
                                desc = resp.get("description", "").lower()
                                if any(w in desc for w in
                                       ("blocked", "deactivated", "not found", "forbidden")):
                                    await db.execute(
                                        "UPDATE users SET is_banned=2 WHERE user_id=?",
                                        (uid,),
                                    )
                                    blocked_count += 1
                        except Exception:
                            pass
                await db.commit()

                async with db.execute(
                    "SELECT COUNT(*) FROM users WHERE is_banned = 0"
                ) as cur:
                    total = (await cur.fetchone())[0]
                async with db.execute("SELECT COUNT(*) FROM chats") as cur:
                    chats = (await cur.fetchone())[0]

                await db.execute(
                    "INSERT OR REPLACE INTO stats (date, total_users, total_chats)"
                    " VALUES (?,?,?)",
                    (today, total, chats),
                )
                await db.commit()

            logger.info(
                f"Daily stats: {today} — {total} users, {blocked_count} newly blocked"
            )
        except Exception as e:
            logger.error(f"Daily cron error: {e}")
        await asyncio.sleep(60)


async def online_reset_cron():
    import aiosqlite
    from config import DB_PATH
    while True:
        await asyncio.sleep(300)
        try:
            cutoff = int(time.time()) - 600
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute(
                    "UPDATE users SET is_online=0 WHERE last_seen < ? AND is_online=1",
                    (cutoff,),
                )
                await db.commit()
        except Exception as e:
            logger.error(f"Online reset error: {e}")


async def main():
    await init_db()
    logger.info("Database initialized.")
    await fetch_bot_username()
    await asyncio.gather(
        polling(),
        daily_stats_cron(),
        online_reset_cron(),
    )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped.")

# FIX: Added error handling for anon_link, coins, profile - premium

# GOD EXTENSIONS: coin daily, block, report, VIP, inline search
def god_features():
    return {"coins_daily":50,"block_system":True,"report":True,"premium_chat":True}

# FIX: /admin فقط سازنده
# if text.strip().lower() == '/admin':  # نمونه هندلر - در handle اصلی پیاده شده
    if int(str(uid)) == int(str(ADMIN_ID)):
        send(cid, '👑 پنل مدیریت', ADMIN_KB if 'ADMIN_KB' in locals() else None)
    else:
        send(cid, '⛔ شما ادمین نیستید')
