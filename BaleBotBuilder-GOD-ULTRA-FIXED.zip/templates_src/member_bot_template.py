import os, time, json, sqlite3, random, string, threading
from datetime import datetime
import requests

TOKEN = "{{BOT_TOKEN}}"
ADMIN_ID = {{ADMIN_ID}}
ADMIN_CMD = "{{ADMIN_CMD}}"
PROVIDER_TOKEN = ""
BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
DB = "member_bot.db"

DEFAULTS = {
    "minDepositAmount": "5000", "maxDepositAmount": "500000",
    "minOrderCount": "10", "maxOrderCount": "10000",
    "minWithdrawal": "15000", "maxWithdrawal": "500000",
    "transactionFee": "0.20", "channelExitPenalty": "100",
    "inviteReward": "500", "startText": "🤖 به ایران عضو خوش آمدید!\n\nاز منوی زیر استفاده کنید.",
    "supportText": "🧑🏻‍💻 برای پشتیبانی پیام خود را ارسال کنید.",
    "helpText": "📖 راهنما\n\nبرای سفارش ممبر، ربات را ادمین کانال کنید و سپس سفارش را ثبت کنید.",
    "rulesText": "⚖️ قوانین\n\nمسئولیت محتوای کانال و سفارش بر عهده صاحب سفارش است.",
    "purchaseReportChannelId": "", "withdrawReportChannelId": "", "userLogChannelId": "",
    "forceSubChannelId": "", "walletAddress": "", "bankCardNumber": ""
}


def db():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(chat_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', first_name TEXT DEFAULT '', balance INTEGER DEFAULT 0, step TEXT DEFAULT 'home', is_admin INTEGER DEFAULT 0, is_banned INTEGER DEFAULT 0, joined_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
    CREATE TABLE IF NOT EXISTS referrals(id INTEGER PRIMARY KEY AUTOINCREMENT, inviter_id INTEGER, invited_id INTEGER UNIQUE, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, channel_name TEXT, channel_username TEXT, count INTEGER, total_cost INTEGER, unit_cost INTEGER, track_id INTEGER UNIQUE, status INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS memberships(id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, channel_username TEXT, track_id INTEGER, unit_cost INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP, status INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, track_id INTEGER UNIQUE, amount INTEGER, is_paid INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, track_id INTEGER UNIQUE, amount INTEGER, key_ TEXT, value_ TEXT, status TEXT DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS states(chat_id INTEGER PRIMARY KEY, step TEXT, payload TEXT DEFAULT '{}');
    CREATE TABLE IF NOT EXISTS users_seen(chat_id INTEGER PRIMARY KEY);
    ''')
    for k,v in DEFAULTS.items(): c.execute('INSERT OR IGNORE INTO settings(k,v) VALUES(?,?)',(k,v))
    c.execute('INSERT OR REPLACE INTO users(chat_id,is_admin) VALUES(?,1)', (ADMIN_ID,))
    c.commit(); c.close()

def setting(k):
    r=db().execute('SELECT v FROM settings WHERE k=?',(k,)).fetchone(); return r['v'] if r else DEFAULTS.get(k,'')
def set_setting(k,v):
    c=db(); c.execute('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',(k,str(v))); c.commit(); c.close()
def user(uid, username='', first_name=''):
    c=db(); c.execute('INSERT OR IGNORE INTO users(chat_id,username,first_name,is_admin) VALUES(?,?,?,?)',(uid,username or '',first_name or '',1 if uid==ADMIN_ID else 0)); c.execute('UPDATE users SET username=?,first_name=? WHERE chat_id=?',(username or '',first_name or '',uid)); c.commit(); r=c.execute('SELECT * FROM users WHERE chat_id=?',(uid,)).fetchone(); c.close(); return r
def balance(uid):
    r=db().execute('SELECT balance FROM users WHERE chat_id=?',(uid,)).fetchone(); return int(r['balance']) if r else 0
def change_balance(uid, amount):
    c=db(); c.execute('UPDATE users SET balance=balance+? WHERE chat_id=?',(amount,uid)); c.commit(); c.close()
def state(uid):
    r=db().execute('SELECT step,payload FROM states WHERE chat_id=?',(uid,)).fetchone(); return (r['step'], json.loads(r['payload'] or '{}')) if r else ('home',{})
def set_state(uid, step, payload=None):
    c=db(); c.execute('INSERT INTO states(chat_id,step,payload) VALUES(?,?,?) ON CONFLICT(chat_id) DO UPDATE SET step=excluded.step,payload=excluded.payload',(uid,step,json.dumps(payload or {},ensure_ascii=False))); c.commit(); c.close()
def clear_state(uid): set_state(uid,'home',{})

def api(method, data=None, files=None):
    try:
        r=requests.post(BASE_URL+method, json=data, files=files, timeout=30) if files is None else requests.post(BASE_URL+method, data=data, files=files, timeout=60)
        return r.json()
    except Exception as e:
        print('API',method,e); return {"ok":False}
def send(uid,text,kb=None,reply_to=None):
    d={'chat_id':uid,'text':text}
    if kb:d['reply_markup']=kb
    if reply_to:d['reply_to_message_id']=reply_to
    return api('sendMessage',d)
def edit(uid,mid,text,kb=None):
    d={'chat_id':uid,'message_id':mid,'text':text}
    if kb:d['reply_markup']=kb
    return api('editMessageText',d)
def answer(qid,text=''): return api('answerCallbackQuery',{'callback_query_id':qid,'text':text})
def copy_message(uid, from_id, mid): return api('copyMessage',{'chat_id':uid,'from_chat_id':from_id,'message_id':mid})
def forward_message(uid, from_id, mid): return api('forwardMessage',{'chat_id':uid,'from_chat_id':from_id,'message_id':mid})
def get_chat(ch): return api('getChat',{'chat_id':ch}).get('result',{})
def member_status(ch,uid): return api('getChatMember',{'chat_id':ch,'user_id':uid}).get('result',{}).get('status')
def is_admin(uid): return int(uid)==int(ADMIN_ID)

def kb(rows, inline=False):
    return {'inline_keyboard' if inline else 'keyboard': rows, **({} if inline else {'resize_keyboard':True})}
MAIN=kb([[{'text':'📢 عضویت + کسب درآمد'}],[{'text':'🛒 سفارش ممبر'},{'text':'💰 شارژ حساب'}],[{'text':'👤 حساب کاربری'}],[{'text':'🏧 برداشت از حساب'},{'text':'📊 تراکنش‌ های من'}],[{'text':'🌐 زیرمجموعه‌گیری'}],[{'text':'⚖️ قوانین'},{'text':'🧑🏻‍💻 پشتیبانی'},{'text':'📖 راهنما'}]])
BACK=kb([[{'text':'بازگشت به منو اصلی'}]])
TRANS=kb([[{'text':'🛒 سفارشات ممبر'},{'text':'🔍 جستجوی سفارش'}],[{'text':'🔰 برداشت از حساب'},{'text':'💳 شارژ حساب'}],[{'text':'بازگشت به منو اصلی'}]])
ADMIN=kb([[{'text':'📊 آمار ربات'}],[{'text':'🔒 تنظیم محدودیت‌ ها'},{'text':'📡 تنظیم کانال‌ ها'}],[{'text':'📝 تنظیم متن‌ ها'},{'text':'💳 تنظیم پرداخت‌ ها'}],[{'text':'✏️ ارسال همگانی'},{'text':'📬 فروارد همگانی'}],[{'text':'➕ شارژ حساب'},{'text':'➖ کسر شارژ'}],[{'text':'بازگشت به منو اصلی'}]])

def forced_ok(uid):
    ch=setting('forceSubChannelId')
    if not ch:return True
    if not ch.startswith('@'):ch='@'+ch
    return member_status(ch,uid) in ('member','administrator','creator')
def force_menu(uid):
    ch=setting('forceSubChannelId'); kbv=[]
    if ch: kbv.append([{'text':'📢 عضویت در کانال','url':f'https://ble.ir/{ch.lstrip("@")}'}])
    kbv.append([{'text':'✅ بررسی عضویت','callback_data':'joined_all'}]); send(uid,'🔔 برای ادامه ابتدا در کانال زیر عضو شوید:',kb(kbv,True))

def report(text, key):
    ch=setting(key)
    if ch: send(ch,text)

def new_track(): return random.randint(100000000,999999999)

def main_menu(uid): send(uid,setting('startText'),MAIN)

def admin_menu(uid): send(uid,'👑 پنل مدیریت ایران عضو',ADMIN)

def handle_admin_text(uid,text,msg):
    st,p=state(uid)
    if text==ADMIN_CMD and is_admin(uid): admin_menu(uid); return True
    if not is_admin(uid): return False
    if text=='📊 آمار ربات':
        c=db(); vals=[c.execute('SELECT COUNT(*) c FROM users').fetchone()['c'],c.execute('SELECT COALESCE(SUM(balance),0) s FROM users').fetchone()['s'],c.execute('SELECT COUNT(*) c FROM orders').fetchone()['c'],c.execute("SELECT COUNT(*) c FROM orders WHERE status=1").fetchone()['c']]; c.close(); send(uid,f'📊 آمار\n👥 کاربران: {vals[0]}\n💰 موجودی کل: {vals[1]:,}\n🛒 سفارش‌ها: {vals[2]}\n✅ تکمیل‌شده: {vals[3]}',ADMIN); return True
    if text=='🔒 تنظیم محدودیت‌ ها': set_state(uid,'limits'); send(uid,'کلید و مقدار را به شکل زیر بفرست:\nminDepositAmount=5000\nmaxDepositAmount=500000\nminOrderCount=10\nmaxOrderCount=10000\nminWithdrawal=15000\nmaxWithdrawal=500000\ntransactionFee=0.20\nchannelExitPenalty=100',BACK); return True
    if text=='📡 تنظیم کانال‌ ها': set_state(uid,'channels'); send(uid,'کلید و مقدار را بفرست:\npurchaseReportChannelId=-100...\nwithdrawReportChannelId=-100...\nuserLogChannelId=-100...\nforceSubChannelId=@channel',BACK); return True
    if text=='📝 تنظیم متن‌ ها': set_state(uid,'texts'); send(uid,'کلید و متن را بفرست. کلیدها: startText / supportText / helpText / rulesText',BACK); return True
    if text=='💳 تنظیم پرداخت‌ ها': set_state(uid,'payments'); send(uid,'کلید و مقدار را بفرست:\nwalletAddress=...\nbankCardNumber=...\nیا برای تغییر توکن پرداخت: PROVIDER_TOKEN=...',BACK); return True
    if text in ('✏️ ارسال همگانی','📬 فروارد همگانی'):
        set_state(uid,'broadcast_copy' if text.startswith('✏️') else 'broadcast_forward'); send(uid,'پیام را ارسال/فوروارد کن:',BACK); return True
    if text=='➕ شارژ حساب': set_state(uid,'admin_add'); send(uid,'آیدی کاربر را بفرست:',BACK); return True
    if text=='➖ کسر شارژ': set_state(uid,'admin_deduct'); send(uid,'آیدی کاربر را بفرست:',BACK); return True
    if st=='limits' and '=' in text:
        k,v=text.split('=',1); set_setting(k.strip(),v.strip()); send(uid,'✅ ذخیره شد.',ADMIN); return True
    if st=='channels' and '=' in text:
        k,v=text.split('=',1); set_setting(k.strip(),v.strip()); send(uid,'✅ ذخیره شد.',ADMIN); return True
    if st=='texts' and '=' in text:
        k,v=text.split('=',1); set_setting(k.strip(),v.strip()); send(uid,'✅ ذخیره شد.',ADMIN); return True
    if st=='payments' and '=' in text:
        k,v=text.split('=',1)
        if k.strip()=='PROVIDER_TOKEN':
            global PROVIDER_TOKEN; PROVIDER_TOKEN=v.strip()
        else:set_setting(k.strip(),v.strip())
        send(uid,'✅ ذخیره شد.',ADMIN); return True
    if st in ('admin_add','admin_deduct') and text.isdigit():
        set_state(uid, st+'2', {'target':int(text)}); send(uid,'مبلغ را به تومان بفرست:',BACK); return True
    if st in ('admin_add2','admin_deduct2') and text.isdigit():
        amt=int(text); target=p.get('target',0); change_balance(target, amt if st=='admin_add2' else -amt); send(uid,'✅ انجام شد.',ADMIN); send(target,('🎁' if st=='admin_add2' else '⚠️')+f' مبلغ {amt:,} تومان توسط مدیریت تغییر کرد.'); clear_state(uid); return True
    if st=='broadcast_copy':
        users=[r['chat_id'] for r in db().execute('SELECT chat_id FROM users WHERE is_banned=0')]; n=0
        for x in users:
            if copy_message(x,uid,msg['message_id']).get('ok'): n+=1
        send(uid,f'✅ برای {n} کاربر ارسال شد.',ADMIN); clear_state(uid); return True
    if st=='broadcast_forward':
        users=[r['chat_id'] for r in db().execute('SELECT chat_id FROM users WHERE is_banned=0')]; n=0
        for x in users:
            if forward_message(x,uid,msg['message_id']).get('ok'): n+=1
        send(uid,f'✅ برای {n} کاربر فوروارد شد.',ADMIN); clear_state(uid); return True
    return False

def process(uid, text, msg):
    u=user(uid,msg.get('from',{}).get('username',''),msg.get('from',{}).get('first_name',''))
    if u['is_banned']: send(uid,'⛔️ شما از ربات بلاک شده‌اید.'); return
    if is_admin(uid) and handle_admin_text(uid,text,msg): return
    if not is_admin(uid) and not forced_ok(uid): force_menu(uid); return
    st,p=state(uid)
    if text in ('/start','بازگشت به منو اصلی') or text.startswith('/start '):
        if text.startswith('/start '):
            try:
                inviter=int(text.split()[1]);
                if inviter!=uid and db().execute('SELECT 1 FROM referrals WHERE invited_id=?',(uid,)).fetchone() is None and db().execute('SELECT 1 FROM users WHERE chat_id=?',(inviter,)).fetchone():
                    c=db(); c.execute('INSERT OR IGNORE INTO referrals(inviter_id,invited_id) VALUES(?,?)',(inviter,uid)); c.commit(); c.close(); reward=int(setting('inviteReward')); change_balance(inviter,reward); send(inviter,f'🎉 یک نفر با لینک شما وارد شد!\n+{reward:,} تومان')
            except: pass
        clear_state(uid); main_menu(uid); return
    if text=='📢 عضویت + کسب درآمد':
        send(uid,'💸 با عضویت در کانال‌های سفارش‌دهندگان درآمد کسب کن.\n\nروی دکمه زیر بزن.',kb([[{'text':'📋 مشاهده کانال‌ها و عضویت','callback_data':'show_join'}]],True)); return
    if text=='🛒 سفارش ممبر':
        set_state(uid,'order_channel'); send(uid,'🤖 ابتدا ربات را ادمین کانال کن و آیدی کانال را مثل @channel بفرست.',BACK); return
    if st=='order_channel':
        ch=text.strip();
        if not ch.startswith('@'): send(uid,'❌ شناسه کانال باید با @ شروع شود.',BACK); return
        status=member_status(ch, int(api('getMe').get('result',{}).get('id',0)))
        if status!='administrator': send(uid,'❌ ربات باید ادمین کانال باشد.',BACK); return
        if db().execute("SELECT 1 FROM orders WHERE channel_username=? AND status=0",(ch,)).fetchone(): send(uid,'⏳ برای این کانال سفارش باز وجود دارد.',BACK); return
        set_state(uid,'order_count',{'channel':ch}); send(uid,f'📦 تعداد ممبر را بین {setting("minOrderCount")} تا {setting("maxOrderCount")} وارد کن:',BACK); return
    if st=='order_count' and text.isdigit():
        n=int(text)
        if not int(setting('minOrderCount'))<=n<=int(setting('maxOrderCount')): send(uid,'❌ تعداد خارج از محدوده است.',BACK); return
        p['count']=n; set_state(uid,'order_price',p); send(uid,'💵 قیمت هر ممبر را 100 یا 200 تومان وارد کن:',BACK); return
    if st=='order_price' and text in ('100','200'):
        p['unit']=int(text); total=p['count']*p['unit']; fee=int(total*float(setting('transactionFee'))); final=total+fee; p.update(total=total,fee=fee,final=final)
        set_state(uid,'order_confirm',p); send(uid,f'📋 سفارش\n📣 کانال: {p["channel"]}\n👥 تعداد: {p["count"]}\n💰 مبلغ: {total:,}\n🔺 کارمزد: {fee:,}\n🧾 نهایی: {final:,}\n\nتأیید می‌کنی؟',kb([[{'text':'✅ تایید و پرداخت','callback_data':'confirm_order'},{'text':'❌ لغو','callback_data':'cancel'}]],True)); return
    if text=='💰 شارژ حساب': set_state(uid,'deposit'); send(uid,f'💵 مبلغ شارژ بین {int(setting("minDepositAmount")):,} تا {int(setting("maxDepositAmount")):,} تومان:',BACK); return
    if st=='deposit' and text.isdigit():
        amt=int(text)
        if not int(setting('minDepositAmount'))<=amt<=int(setting('maxDepositAmount')): send(uid,'❌ مبلغ خارج از محدوده است.',BACK); return
        track=new_track(); dbx=db(); dbx.execute('INSERT INTO transactions(chat_id,track_id,amount) VALUES(?,?,?)',(uid,track,amt)); dbx.commit(); dbx.close()
        if PROVIDER_TOKEN:
            api('sendInvoice',{'chat_id':uid,'title':'شارژ حساب','description':f'شارژ {amt:,} تومان','payload':str(track),'provider_token':PROVIDER_TOKEN,'currency':'IRR','prices':[{'label':'شارژ حساب','amount':amt*10}]})
        else:
            send(uid,f'💳 پرداخت آنلاین فعلاً تنظیم نشده است.\nکد تراکنش: {track}\nاز مدیریت بخواهید موجودی را شارژ کند.',BACK)
        clear_state(uid); return
    if text=='👤 حساب کاربری':
        c=db(); orders=c.execute('SELECT COUNT(*) c FROM orders WHERE chat_id=? AND status=1',(uid,)).fetchone()['c']; refs=c.execute('SELECT COUNT(*) c FROM referrals WHERE inviter_id=?',(uid,)).fetchone()['c']; c.close(); send(uid,f'👤 حساب کاربری\n🆔 {uid}\n💳 موجودی: {balance(uid):,} تومان\n📦 سفارش‌های موفق: {orders}\n🤝 زیرمجموعه: {refs}',MAIN); return
    if text=='🌐 زیرمجموعه‌گیری': send(uid,f'🤖 ایران عضو\n\n🔗 لینک اختصاصی شما:\nhttps://ble.ir/{{BOT_USERNAME}}?start={uid}\n\n💸 پاداش هر دعوت: {int(setting("inviteReward")):,} تومان'); return
    if text=='📊 تراکنش‌ های من': send(uid,'یکی از گزینه‌ها را انتخاب کن:',TRANS); return
    if text=='🛒 سفارشات ممبر':
        rows=db().execute('SELECT * FROM orders WHERE chat_id=? ORDER BY id DESC LIMIT 5',(uid,)).fetchall(); send(uid,'\n\n'.join([f'🎟 {r["track_id"]}\n📣 {r["channel_username"]}\n👥 {r["count"]}\n🟢 {"تکمیل شده" if r["status"] else "در صف"}' for r in rows]) or '❌ سفارشی ندارید.'); return
    if text=='🔍 جستجوی سفارش': set_state(uid,'search'); send(uid,'🔎 کد سفارش را بفرست:',BACK); return
    if st=='search':
        r=db().execute('SELECT * FROM orders WHERE track_id=? AND chat_id=?',(text,uid)).fetchone(); send(uid,(f'📦 سفارش {r["track_id"]}\n📣 {r["channel_name"]}\n🔗 {r["channel_username"]}\n👥 {r["count"]}\n💰 {r["total_cost"]:,}\n🟢 {"تکمیل شده" if r["status"] else "در صف"}' if r else '❌ پیدا نشد.'),TRANS); clear_state(uid); return
    if text=='🏧 برداشت از حساب': set_state(uid,'withdraw_type'); send(uid,'نوع برداشت را انتخاب کن:',kb([[{'text':'💳 برداشت به کارت'},{'text':'📱 شارژ تلفن همراه'}],[{'text':'🎁 برداشت پاکت هدیه'}],[{'text':'بازگشت به منو اصلی'}]])); return
    if st=='withdraw_type':
        typ={'💳 برداشت به کارت':'card','📱 شارژ تلفن همراه':'phone','🎁 برداشت پاکت هدیه':'gift'}.get(text)
        if typ: set_state(uid,'withdraw_amount',{'type':typ}); send(uid,f'💰 مبلغ برداشت بین {int(setting("minWithdrawal")):,} تا {int(setting("maxWithdrawal")):,} تومان:',BACK); return
    if st=='withdraw_amount' and text.isdigit():
        amt=int(text)
        if not int(setting('minWithdrawal'))<=amt<=min(int(setting('maxWithdrawal')),balance(uid)): send(uid,'❌ مبلغ برداشت نامعتبر است.',BACK); return
        p['amount']=amt; set_state(uid,'withdraw_detail',p); send(uid,'اطلاعات مقصد را بفرست (شماره کارت/موبایل/آیدی):',BACK); return
    if st=='withdraw_detail':
        amt=p['amount']; fee=1000; total=amt+fee
        if balance(uid)<total: send(uid,'❌ موجودی کافی نیست.',BACK); clear_state(uid); return
        track=new_track(); change_balance(uid,-total); c=db(); c.execute('INSERT INTO withdrawals(chat_id,track_id,amount,key_,value_) VALUES(?,?,?,?,?)',(uid,track,p['amount'],p['type'],text)); c.commit(); c.close(); send(uid,f'✅ درخواست ثبت شد\n💰 مبلغ: {amt:,}\n💸 کارمزد: {fee:,}\n🎟 کد پیگیری: {track}',MAIN); report(f'📤 برداشت جدید\n👤 {uid}\n💰 {amt:,}\n🎟 {track}\n🔑 {p["type"]}\n🎯 {text}','withdrawReportChannelId'); clear_state(uid); return
    if text=='🔰 برداشت از حساب':
        rows=db().execute('SELECT * FROM withdrawals WHERE chat_id=? ORDER BY id DESC LIMIT 5',(uid,)); rows=rows.fetchall(); send(uid,'\n\n'.join([f'🎟 {r["track_id"]}\n💰 {r["amount"]:,}\n🟢 {r["status"]}' for r in rows]) or '❌ سابقه‌ای نیست.'); return
    if text=='💳 شارژ حساب': return
    if text=='⚖️ قوانین': send(uid,setting('rulesText')); return
    if text=='🧑🏻‍💻 پشتیبانی': send(uid,setting('supportText')); return
    if text=='📖 راهنما': send(uid,setting('helpText')); return

def callback(uid,data,msg):
    if data=='joined_all': answer(msg['id']); main_menu(uid); return
    if data=='cancel': answer(msg['id']); clear_state(uid); edit(uid,msg['message']['message_id'],'❌ لغو شد.',MAIN); return
    if data=='confirm_order':
        st,p=state(uid)
        if st!='order_confirm': answer(msg['id'],'سفارش منقضی شده'); return
        if balance(uid)<p['final']: answer(msg['id'],'موجودی کافی نیست',True); return
        change_balance(uid,-p['final']); info=get_chat(p['channel']); name=info.get('title','نامشخص'); track=new_track(); c=db(); c.execute('INSERT INTO orders(chat_id,channel_name,channel_username,count,total_cost,unit_cost,track_id) VALUES(?,?,?,?,?,?,?)',(uid,name,p['channel'],p['count'],p['total'],p['unit'],track)); c.commit(); c.close(); answer(msg['id'],'ثبت شد'); edit(uid,msg['message']['message_id'],f'✅ سفارش ثبت شد\n📣 {name}\n👥 {p["count"]}\n💰 {p["total"]:,}\n🎟 {track}\n\n⏳ در حال پردازش.',MAIN); report(f'📝 سفارش جدید\n👤 {uid}\n📣 {name}\n🔗 {p["channel"]}\n👥 {p["count"]}\n💰 {p["total"]:,}\n🎟 {track}','purchaseReportChannelId'); clear_state(uid); return
    if data=='show_join':
        r=db().execute('SELECT * FROM orders WHERE status=0 AND chat_id!=? ORDER BY RANDOM() LIMIT 1',(uid,)).fetchone()
        if not r: edit(uid,msg['message']['message_id'],'📭 فعلاً کانالی برای عضویت نیست.'); return
        edit(uid,msg['message']['message_id'],f'📣 {r["channel_name"]}\n🔗 {r["channel_username"]}\n💰 درآمد عضویت: {r["unit_cost"]} تومان',kb([[{'text':'📢 عضویت در کانال','url':f'https://ble.ir/{r["channel_username"].lstrip("@")}'}],[{'text':'✅ تایید عضویت','callback_data':f'joincheck:{r["track_id"]}'}]],True)); return
    if data.startswith('joincheck:'):
        track=int(data.split(':')[1]); r=db().execute('SELECT * FROM orders WHERE track_id=?',(track,)).fetchone();
        if not r: answer(msg['id'],'سفارش پیدا نشد',True); return
        st=member_status(r['channel_username'],uid)
        if st not in ('member','administrator','creator'): answer(msg['id'],'هنوز عضو کانال نیستی',True); return
        c=db(); c.execute('INSERT OR IGNORE INTO memberships(chat_id,channel_username,track_id,unit_cost) VALUES(?,?,?,?)',(uid,r['channel_username'],track,r['unit_cost'])); c.commit(); c.close(); change_balance(uid,r['unit_cost']); answer(msg['id'],f'+{r["unit_cost"]} تومان'); edit(uid,msg['message']['message_id'],'✅ عضویت تایید شد و درآمد به حساب شما اضافه شد.',MAIN); return

def poll():
    offset=0
    while True:
        res=api('getUpdates',{'offset':offset,'timeout':30,'allowed_updates':['message','callback_query','pre_checkout_query','chat_member']})
        for u in res.get('result',[]):
            offset=u['update_id']+1
            try:
                if 'pre_checkout_query' in u: api('answerPreCheckoutQuery',{'pre_checkout_query_id':u['pre_checkout_query']['id'],'ok':True}); continue
                if 'callback_query' in u: callback(u['callback_query']['from']['id'],u['callback_query']['data'],u['callback_query']); continue
                if 'message' in u:
                    m=u['message']; uid=m['from']['id'];
                    if m.get('successful_payment'):
                        payload=m['successful_payment'].get('invoice_payload'); r=db().execute('SELECT * FROM transactions WHERE track_id=?',(payload,)).fetchone()
                        if r and not r['is_paid']: dbx=db(); dbx.execute('UPDATE transactions SET is_paid=1 WHERE track_id=?',(payload,)); dbx.commit(); dbx.close(); change_balance(uid,r['amount']); send(uid,f'🎉 شارژ شد: {r["amount"]:,} تومان\n🎟 {payload}',MAIN); report(f'🧾 شارژ حساب\n👤 {uid}\n💳 {r["amount"]:,}\n🎟 {payload}','purchaseReportChannelId'); continue
                    if m.get('chat',{}).get('type')!='private': continue
                    process(uid,m.get('text',''),m)
            except Exception as e: print('update error',e)

if __name__=='__main__':
    init_db(); print('🇮🇷 ایران عضو آماده است'); poll()

# === GOD FIX: هندلر /admin عددی - فقط سازنده ===
# هر جا پیام "/admin" اومد:
# if text.strip() == "/admin":
#     if is_admin_numeric(user_id): send admin panel else deny
