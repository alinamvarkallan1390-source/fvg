#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
botfix_ext.py — هسته‌ی اصلاحات و قابلیت‌های جدید «ربات‌ساز حرفه‌ای بله»

این ماژول به صورت الحاقی (extension) روی main.py سوار می‌شود:
  install_extensions(globals())

بخش‌ها:
  1) موتور امن جایگزینی متغیرها (رفع باگ تداخل MAXWARN/COUNT/LINK/TIME/...)
  2) کتابخانه ۱۲۰+ قالب آماده + دامنه‌ی فعالیت (گروه / پیوی / هر دو)
  3) متغیرهای اختصاصی «مدیریت گروه» بر اساس مستندات رسمی docs.bale.ai
  4) متغیرهای سفارشی + اتصال دستور به متغیر (مثال: «قفل لینک» → zadlink)
  5) مدیریت دامنه‌ی دکمه‌ها (group / pv / both)
  6) رفع کامل ارسال همگانی
  7) رفع کامل حذف ربات (پاکسازی پروسه، فایل، دیتابیس، وب‌هوک)
  8) رفع routing callback ها، FSM، توابع API بله
"""
import os
import re
import json
import time
import html
import shutil
import signal
import sqlite3
import logging
import random
import subprocess
import threading
from datetime import datetime, timedelta
from functools import lru_cache

logger = logging.getLogger("botfix")

MOD = {}
_ctx = threading.local()

# =====================================================================
# 1) موتور امن جایگزینی متغیرها
# =====================================================================
_MARKED_CHARS = ("{", "<", "}")

@lru_cache(maxsize=32)
def _compile_var_patterns(keys_tuple):
    keys = list(keys_tuple)
    marked = sorted([k for k in keys if any(c in k for c in _MARKED_CHARS)], key=len, reverse=True)
    bare = sorted([k for k in keys if not any(c in k for c in _MARKED_CHARS)], key=len, reverse=True)
    # کلیدهای ساده (حروف لاتین) فقط با مرز کلمه‌ی ASCII جایگزین می‌شوند
    # → «TOP1COUNT» قربانی «COUNT» نمی‌شود و متن فارسی چسبیده هم مشکلی ندارد
    bare_pat = re.compile(
        r"(?<![A-Za-z0-9_])(?:" + "|".join(re.escape(k) for k in bare) + r")(?![A-Za-z0-9_])"
    ) if bare else None
    marked_pat = re.compile("|".join(re.escape(k) for k in marked)) if marked else None
    return marked_pat, bare_pat


def render_variables(text, variables, extra=None):
    """جایگزینی امن، بدون تداخل زیررشته‌ای، با مقادیر همیشه رشته‌ای."""
    if text is None:
        return ""
    text = str(text)
    if extra:
        variables = {**variables, **extra}
    if not variables:
        return text
    clean = {}
    for k, v in variables.items():
        if k is None:
            continue
        clean[str(k)] = "" if v is None else str(v)
    marked_pat, bare_pat = _compile_var_patterns(tuple(clean.keys()))
    if marked_pat:
        text = marked_pat.sub(lambda m: clean.get(m.group(0), m.group(0)), text)
    if bare_pat:
        text = bare_pat.sub(lambda m: clean.get(m.group(0), m.group(0)), text)
    return text


def normalize_command(text):
    """نرمال‌سازی دستورات فارسی/عربی/انگلیسی برای تطبیق دقیق."""
    if not text:
        return ""
    t = str(text).strip()
    t = t.replace("\u200c", " ").replace("\u200f", "").replace("\u200e", "")
    t = t.replace("ي", "ی").replace("ك", "ک").replace("أ", "ا").replace("إ", "ا")
    t = re.sub(r"^[/!#]+", "", t)
    t = re.sub(r"\s+", " ", t)
    return t.strip().lower()


def is_group_chat(chat_type=None, chat_id=None):
    if chat_type and str(chat_type).lower() in ("group", "supergroup", "channel"):
        return True
    try:
        return chat_id is not None and int(chat_id) < 0
    except (TypeError, ValueError):
        return False


def set_runtime_context(chat_id=None, chat_type=None, bot_id=None, active_templates=None):
    _ctx.chat_id = chat_id
    _ctx.chat_type = chat_type or "private"
    _ctx.bot_id = bot_id
    _ctx.active_templates = active_templates


def get_runtime_context():
    return {
        "chat_id": getattr(_ctx, "chat_id", None),
        "chat_type": getattr(_ctx, "chat_type", "private"),
        "bot_id": getattr(_ctx, "bot_id", None),
        "active_templates": getattr(_ctx, "active_templates", None),
    }


# =====================================================================
# 2) کتابخانه قالب‌ها — ۱۲ دسته × ۱۰ قالب = ۱۲۰ قالب آماده
# =====================================================================
CATEGORY_SPECS = [
    ("group", "👮 مدیریت گروه", [
        "قفل لینک", "قفل فوروارد", "ضد اسپم", "فیلتر کلمات", "خوشامدگویی",
        "قوانین گروه", "اخطار و اخراج", "پین و سنجاق", "لینک دعوت گروه", "آمار گروه",
    ], [
        ("📜 قوانین", "📜 قوانین «{subject}»\n👤 FIRSTNAME | 🆔 USERID\n📅 DATE ⏰ TIME"),
        ("👮 ادمین‌ها", "👮 مدیران گروه: ADMINS\nتعداد: GROUPADMINS | اعضا: GROUPMEMBERS"),
        ("📊 آمار", "📊 آمار GROUPNAME\n👥 اعضا: GROUPMEMBERS\n💬 پیام امروز: TODAYMSG | برتر: TOPUSER"),
        ("🔗 لینک گروه", "🔗 لینک دعوت: GROUPLINK\n👤 FIRSTNAME | 📅 DATE"),
        ("⚙️ وضعیت قفل", "⚙️ وضعیت «{subject}»: {state_var}\n🆔 GROUPID | 🤖 ISADMIN"),
    ], "group"),
    ("earn", "💰 کسب درآمد", [
        "زیرمجموعهگیری", "کیف پول", "برداشت وجه", "هدیه روزانه", "لیدربرد",
        "کد تخفیف", "جوین اجباری", "وظایف روزانه", "سکه و امتیاز", "درآمد کلی",
    ], [
        ("💎 شروع", "💎 {subject}\n👤 FIRSTNAME | 📅 DATE"),
        ("🔗 لینک من", "🔗 لینک اختصاصی: LINK\n👥 دعوت‌ها: COUNT | 💰 موجودی: BALANCE"),
        ("💰 موجودی", "💰 موجودی: BALANCE تومان\n🎁 امتیاز: SCORE | ⭐ لول: LEVEL"),
        ("🏆 برترین‌ها", "🏆 TOP1 — TOP1COUNT امتیاز\n🥈 TOP2 | 🥉 TOP3"),
        ("📚 راهنما", "📚 راهنمای «{subject}»\n⏰ TIME | 🤖 BOTFNAME"),
    ], "pv"),
    ("shop", "🛍️ فروشگاه", [
        "لیست محصولات", "سبد خرید", "پرداخت", "سفارشات من", "تخفیفها",
        "دستهبندی", "جستجوی محصول", "پشتیبانی فروش", "فایلهای دیجیتال", "فاکتور",
    ], [
        ("🛍 محصولات", "🛍 {subject}\n👤 FIRSTNAME | 📅 DATE"),
        ("🛒 سبد خرید", "🛒 سبد خرید FIRSTNAME\n💰 اعتبار: BALANCE"),
        ("💳 پرداخت", "💳 پرداخت امن «{subject}»\n📞 پشتیبانی: ADMINS"),
        ("📦 سفارشات", "📦 سفارشات FIRSTNAME\n🆔 USERID | ⏰ TIME"),
        ("🎧 پشتیبانی", "🎧 پشتیبانی فروش\n🤖 BOTFNAME | 🔗 BOTLINK"),
    ], "both"),
    ("game", "🎮 بازی و سرگرمی", [
        "سنگ کاغذ قیچی", "دوز", "حدس عدد", "مسابقه سریع", "لول و تجربه",
        "جدول امتیازات", "جوایز", "چالش روزانه", "گل یا پوچ", "بازی گروهی",
    ], [
        ("🎮 شروع بازی", "🎮 {subject} — سلام FIRSTNAME!\n🎲 شانس: RANDOM"),
        ("🏆 امتیازات", "🏆 امتیاز: SCORE | ⭐ لول: LEVEL | 🎯 XP"),
        ("🎁 جوایز", "🎁 جوایز «{subject}»\n💰 سکه: COIN | 📅 DATE"),
        ("👥 رقبا", "👥 TOP1 / TOP2 / TOP3\n🤖 BOTFNAME"),
        ("❓ راهنما", "❓ قوانین «{subject}»\n⏰ TIME"),
    ], "both"),
    ("edu", "📚 آموزش", [
        "برنامه درسی", "آزمون آنلاین", "جزوات", "تقویم آموزشی", "سوالات متداول",
        "ویدیوهای آموزشی", "تمرین روزانه", "نمرات", "معرفی دوره", "گواهی پایان",
    ], [
        ("📚 دروس", "📚 {subject}\n👤 FIRSTNAME | 📅 DATE"),
        ("📝 آزمون", "📝 آزمون «{subject}»\n⏰ TIME | 🎯 SCORE"),
        ("📄 جزوه", "📄 جزوات «{subject}»\n🤖 BOTFNAME"),
        ("📅 تقویم", "📅 DATE | 🕰 TIME\n📌 {subject}"),
        ("🎓 نمرات", "🎓 نمره: SCORE | ⭐ LEVEL | 👤 FIRSTNAME"),
    ], "both"),
    ("religion", "🕌 معنوی", [
        "اذکار روز", "حدیث روز", "آیات قرآن", "اوقات شرعی", "مناسبتها",
        "دعای روز", "زیارت", "احکام", "تسبیح", "سخن بزرگان",
    ], [
        ("🕌 ذکر روز", "🕌 ZEKR\n📅 DATE | 👤 FIRSTNAME"),
        ("📖 حدیث", "📖 HADITH-TITLE — HADITH-WHO\nHADITH-FA | 📚 HADITH-SRC"),
        ("🤲 دعا", "🤲 {subject}\n📅 DATE ⏰ TIME"),
        ("📿 تسبیح", "📿 {subject} — PRAYER"),
        ("🌙 مناسبت", "🌙 {subject}\n📅 DATE | 🗓 DAY"),
    ], "both"),
    ("news", "📰 اطلاعرسانی", [
        "اخبار فوری", "ورزشی", "اقتصادی", "تکنولوژی", "هواشناسی",
        "ارسال به کانال", "فوروارد خودکار", "زمانبندی پست", "آمار بازدید", "دستهبندی خبر",
    ], [
        ("📰 تیترها", "📰 {subject}\n📅 DATE | ⏰ TIME"),
        ("⚽ دسته", "⚽ {subject} — بهروزرسانی SERVERTIME"),
        ("📢 فوروارد", "📢 فوروارد خودکار «{subject}»\n🤖 BOTFNAME"),
        ("⏰ زمانبندی", "⏰ زمانبندی «{subject}»\n📅 DATE | 🕰 TIME"),
        ("📊 بازدید", "📊 آمار «{subject}»\n👥 MEMBERCOUNT | 👤 FIRSTNAME"),
    ], "both"),
    ("support", "🎧 پشتیبانی", [
        "ثبت تیکت", "پاسخ ادمین", "سوالات متداول", "تماس با ما", "وضعیت تیکت",
        "گزارش خطا", "درخواست مشاوره", "رضایتمندی", "ساعات پاسخگویی", "ارسال فایل",
    ], [
        ("🎧 تیکت", "🎧 {subject}\n👤 FIRSTNAME | 🆔 USERID"),
        ("📋 تیکت‌های من", "📋 تیکت‌های FIRSTNAME\n📅 DATE ⏰ TIME"),
        ("❓ سوالات", "❓ سوالات متداول «{subject}»\n🤖 BOTFNAME"),
        ("📞 تماس", "📞 پشتیبانی: ADMINS\n⏰ TIME | 📅 DATE"),
        ("⭐ رضایت", "⭐ بازخورد «{subject}»\n👤 FIRSTNAME | 🎯 SCORE"),
    ], "pv"),
    ("tools", "🧰 ابزارها", [
        "فونتساز", "لینک کوتاه", "ساخت QR", "مترجم", "محاسبهگر",
        "تاریخ و ساعت", "تبدیل واحد", "یادداشت", "رمز عبور", "کپچا",
    ], [
        ("🔤 ابزار", "🔤 {subject}\n👤 FIRSTNAME | 📅 DATE"),
        ("🔗 لینک", "🔗 «{subject}»\n🤖 BOTLINK | ⏰ TIME"),
        ("📝 نتیجه", "📝 نتیجه «{subject}»: RANDOM\n🆔 USERID"),
        ("📅 زمان", "📅 DATE | ⏰ TIME | 🗓 DAY\n🌙 MAHFA | 🍂 FASL"),
        ("❓ راهنما", "❓ راهنمای «{subject}»\n🤖 BOTFNAME"),
    ], "pv"),
    ("stats", "📊 آمار و مدیریت", [
        "آمار کاربران", "نمودار رشد", "پیامهای امروز", "کاربران فعال", "گزارش هفتگی",
        "پشتیبانگیری", "لاگها", "خروجی CSV", "نظرسنجی", "مقایسه دوره",
    ], [
        ("📊 آمار", "📊 {subject}\n👥 MEMBERCOUNT | 💬 TODAYMSG"),
        ("📈 رشد", "📈 «{subject}»\n📅 DATE | 👥 GROUPMEMBERS"),
        ("🆕 امروز", "🆕 کاربران امروز: COUNT\n⏰ TIME | 📅 DATE"),
        ("📤 خروجی", "📤 خروجی «{subject}»\n🤖 BOTFNAME | 🆔 BOTID"),
        ("⚙️ تنظیمات", "⚙️ تنظیمات «{subject}»\n👤 FIRSTNAME | 👮 ISADMIN"),
    ], "both"),
    ("giveaway", "🎁 قرعهکشی", [
        "قرعهکشی روزانه", "برندگان", "شانس من", "جوایز", "کد هدیه",
        "امتیاز شرکت", "قرعهکشی گروه", "اعلام نتیجه", "شرایط شرکت", "تاریخچه",
    ], [
        ("🎰 شرکت", "🎰 {subject}\n👤 FIRSTNAME | 🎲 RANDOM"),
        ("🏆 برندگان", "🏆 TOP1 / TOP2 / TOP3\n📅 DATE"),
        ("🎁 جوایز", "🎁 «{subject}»\n💰 COIN | ⭐ STREAK"),
        ("🎯 شانس", "🎯 شانس FIRSTNAME: RANDOM%\n👥 دعوت: COUNT"),
        ("📜 شرایط", "📜 شرایط «{subject}»\n🔗 LINK | ⏰ TIME"),
    ], "both"),
    ("personal", "🤖 ربات شخصی", [
        "پروفایل من", "تنظیمات", "درباره ربات", "راهنما", "منوی پیشرفته",
        "پیام شروع", "دکمههای من", "علاقهمندیها", "اعلانها", "حریم خصوصی",
    ], [
        ("👤 پروفایل", "👤 FIRSTNAME LASTNAME\n🆔 USERID | @USERNAME\n📅 عضویت: JOINDATE"),
        ("⚙️ تنظیمات", "⚙️ {subject}\n🤖 BOTFNAME | 📅 DATE"),
        ("ℹ️ درباره", "ℹ️ {subject}\n🔗 BOTLINK | 🆔 BOTID"),
        ("📚 راهنما", "📚 راهنمای «{subject}»\n⏰ TIME | 👤 FIRSTNAME"),
        ("🔔 اعلانها", "🔔 اعلان‌های «{subject}»\n📅 DATE ⏰ TIME"),
    ], "both"),
]

CUSTOM_VARIABLE_PRESETS = [
    {"name": "zadlink", "label": "ضد لینک", "action": "lock_link", "command_on": "قفل لینک",
     "command_off": "بازکردن لینک", "penalty": "delete", "scope": "group",
     "description": "با دستور «قفل لینک» فعال می‌شود و لینک‌های گروه حذف می‌شوند"},
    {"name": "zadforward", "label": "ضد فوروارد", "action": "lock_forward", "command_on": "قفل فوروارد",
     "command_off": "بازکردن فوروارد", "penalty": "delete", "scope": "group", "description": "جلوگیری از فوروارد"},
    {"name": "zadphoto", "label": "ضد عکس", "action": "lock_photo", "command_on": "قفل عکس",
     "command_off": "بازکردن عکس", "penalty": "delete", "scope": "group", "description": "جلوگیری از ارسال عکس"},
    {"name": "zadspam", "label": "ضد اسپم", "action": "lock_spam", "command_on": "قفل اسپم",
     "command_off": "بازکردن اسپم", "penalty": "warn", "scope": "group", "description": "محدودیت پیام پشت سر هم"},
    {"name": "welcome", "label": "خوشامدگویی", "action": "none", "command_on": "خوشامد روشن",
     "command_off": "خوشامد خاموش", "penalty": "delete", "scope": "group", "description": "پیام خوشامد اعضای جدید"},
]

BUILTIN_BAD_WORDS = ["کص", "کیر", "خارکصه", "حرومزاده", "حرومی", "مادرتو", "فحش", "asshole", "fuck you", "لعنتی"]


def build_template_library():
    """۱۲۰ قالب واقعی و قابل ویرایش — هر کدام دکمه، متن شروع و دامنه‌ی پیشفرض دارند."""
    library = {}
    for cat_key, cat_name, topics, button_specs, default_scope in CATEGORY_SPECS:
        for idx, subject in enumerate(topics, 1):
            key = f"{cat_key}_{idx:02d}"
            buttons = []
            for bi, (btitle, bcontent) in enumerate(button_specs):
                content = bcontent.replace("{subject}", subject).replace("{state_var}", "{zadlink}")
                buttons.append({
                    "title": btitle,
                    "type": "reply" if bi % 2 == 0 else "inline",
                    "row": bi // 2,
                    "action": "text",
                    "content": content,
                })
            library[key] = {
                "key": key,
                "name": f"{cat_name.split(' ')[0]} {subject}",
                "desc": f"قالب آماده «{subject}» — {len(buttons)} دکمه، قابل شخصیسازی، دامنه: {default_scope}",
                "category": cat_key,
                "category_name": cat_name,
                "kind": "library",
                "scope": default_scope,
                "buttons": buttons,
                "start_message": (
                    f"✨ سلام FIRSTNAME عزیز!\nبه قالب «{subject}» خوش آمدی 🎉\n"
                    f"📌 {cat_name}\n📅 DATE | ⏰ TIME | 🤖 BOTFNAME"
                ),
                "customizable": True,
            }
    return library


TEMPLATE_LIBRARY = build_template_library()
ALL_TEMPLATES = {}


def get_template(key):
    return ALL_TEMPLATES.get(key)


# =====================================================================
# 3) BaleAPI — رفع ۴۲۹/شبکه، متدهای رسمی مدیریت گروه، getUpdates درست
# =====================================================================
def _api_request(self, method, params=None, files=None, json_data=None):
    BaleAPIError = MOD["BaleAPIError"]
    url = self.api_url + method
    attempts = 3
    for attempt in range(attempts):
        try:
            if files:
                resp = self.session.post(url, data=params or json_data, files=files, timeout=self.timeout)
            elif json_data:
                resp = self.session.post(url, json=json_data, timeout=self.timeout)
            elif params:
                resp = self.session.post(url, json=params, timeout=self.timeout)
            else:
                resp = self.session.get(url, timeout=self.timeout)
            try:
                data = resp.json()
            except Exception:
                raise BaleAPIError(f"پاسخ نامعتبر از سرور بله: {getattr(resp, 'text', '')[:300]}")
            if not data.get("ok"):
                err_code = data.get("error_code")
                desc = data.get("description", "خطای نامشخص")
                if err_code == 429 and attempt < attempts - 1:
                    retry_after = (data.get("parameters") or {}).get("retry_after") or 2
                    logger.warning("Rate limited on %s, retry after %ss", method, retry_after)
                    time.sleep(min(float(retry_after) + 0.25, 30))
                    continue
                if isinstance(err_code, int) and err_code >= 500 and attempt < attempts - 1:
                    time.sleep(1 + attempt)
                    continue
                raise BaleAPIError(desc, error_code=err_code, description=desc)
            return data.get("result")
        except MOD["requests"].RequestException as e:
            if attempt < attempts - 1:
                logger.warning("Network error on %s (%s), retrying...", method, e)
                time.sleep(1 + attempt)
                continue
            logger.error("خطای شبکه در %s: %s", method, e)
            raise BaleAPIError(f"خطای شبکه: {e}")
    raise BaleAPIError("تعداد تلاش‌ها به پایان رسید")


def _api_get_updates(self, offset=None, limit=100, timeout=20):
    """مستندات: getUpdates با GET + query string (هر دو GET/POST پشتیبانی می‌شود)."""
    BaleAPIError = MOD["BaleAPIError"]
    params = {"limit": max(1, min(int(limit or 100), 100)), "timeout": int(timeout or 20)}
    if offset is not None:
        params["offset"] = offset
    url = self.api_url + "getUpdates"
    try:
        resp = self.session.get(url, params=params, timeout=(self.timeout or 30) + int(timeout or 20))
        data = resp.json()
        if not data.get("ok"):
            raise BaleAPIError(data.get("description", "خطا در getUpdates"))
        result = data.get("result")
        return result if isinstance(result, list) else []
    except MOD["requests"].RequestException as e:
        raise BaleAPIError(f"خطای شبکه در getUpdates: {e}")


def _api_send_message(self, chat_id, text, reply_markup=None, reply_to_message_id=None,
                      parse_mode=None, protect_content=None):
    text = "" if text is None else str(text)
    if not text.strip():
        return None
    payload = {"chat_id": chat_id, "text": text[:4096]}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    if reply_to_message_id:
        payload["reply_to_message_id"] = reply_to_message_id
    if parse_mode:
        payload["parse_mode"] = parse_mode
    if protect_content:
        payload["protect_content"] = True
    try:
        return self._request("sendMessage", json_data=payload)
    except MOD["BaleAPIError"] as e:
        if protect_content:
            payload.pop("protect_content", None)
            return self._request("sendMessage", json_data=payload)
        raise


def _install_group_methods(api_cls):
    """متدهای مستندشده‌ی docs.bale.ai برای مدیریت گروه."""
    def make(method, keys):
        def call(self, *args, **kwargs):
            payload = {}
            for i, k in enumerate(keys):
                if i < len(args):
                    payload[k] = args[i]
            for k in keys:
                if k in kwargs:
                    payload[k] = kwargs[k]
            payload = {k: v for k, v in payload.items() if v is not None}
            return self._request(method, json_data=payload)
        call.__name__ = method[0].lower() + method[1:]
        return call

    specs = {
        "getChat": ["chat_id"],
        "getChatMember": ["chat_id", "user_id"],
        "getChatAdministrators": ["chat_id"],
        "getChatMembersCount": ["chat_id"],
        "banChatMember": ["chat_id", "user_id"],
        "unbanChatMember": ["chat_id", "user_id", "only_if_banned"],
        "promoteChatMember": ["chat_id", "user_id", "can_change_info", "can_post_messages",
                              "can_edit_messages", "can_delete_messages", "can_manage_video_chats",
                              "can_invite_users", "can_restrict_members"],
        "pinChatMessage": ["chat_id", "message_id"],
        "unPinChatMessage": ["chat_id", "message_id"],
        "unpinAllChatMessages": ["chat_id"],
        "setChatTitle": ["chat_id", "title"],
        "setChatDescription": ["chat_id", "description"],
        "deleteChatPhoto": ["chat_id"],
        "createChatInviteLink": ["chat_id"],
        "revokeChatInviteLink": ["chat_id", "invite_link"],
        "exportChatInviteLink": ["chat_id"],
        "leaveChat": ["chat_id"],
        "deleteMessage": ["chat_id", "message_id"],
        "setWebhook": ["url"],
    }
    snake = {
        "getChat": "get_chat", "getChatMember": "get_chat_member",
        "getChatAdministrators": "get_chat_administrators",
        "getChatMembersCount": "get_chat_members_count",
        "banChatMember": "ban_chat_member", "unbanChatMember": "unban_chat_member",
        "promoteChatMember": "promote_chat_member", "pinChatMessage": "pin_chat_message",
        "unPinChatMessage": "unpin_chat_message", "unpinAllChatMessages": "unpin_all_chat_messages",
        "setChatTitle": "set_chat_title", "setChatDescription": "set_chat_description",
        "deleteChatPhoto": "delete_chat_photo", "createChatInviteLink": "create_chat_invite_link",
        "revokeChatInviteLink": "revoke_chat_invite_link", "exportChatInviteLink": "export_chat_invite_link",
        "leaveChat": "leave_chat", "deleteMessage": "delete_message", "setWebhook": "set_webhook",
    }
    for method, keys in specs.items():
        fn = make(method, keys)
        setattr(api_cls, snake[method], fn)
    # unban/pin aliases مورد انتظار کد قدیمی
    api_cls.unban_chat_member_alias = api_cls.unban_chat_member


# =====================================================================
# 4) کیبورد ربات کاربر — اعمال دامنه دکمه‌ها و قالب فعال
# =====================================================================
def build_user_bot_keyboard(buttons, parent_id=None, chat_type=None, active_templates=None):
    ctx = get_runtime_context()
    ctype = chat_type or ctx["chat_type"] or "private"
    chat_id = ctx["chat_id"]
    group = is_group_chat(ctype, chat_id)
    tpl_keys = active_templates if active_templates is not None else ctx["active_templates"]

    def visible(b):
        try:
            if (b.get("parent_id") == parent_id or (b.get("parent_id") is None and parent_id is None)) is False:
                return False
        except Exception:
            return False
        if b.get("is_hidden"):
            return False
        scope = (b.get("scope") or "both").lower()
        if scope == "off":
            return False
        if scope == "group" and not group:
            return False
        if scope == "pv" and group:
            return False
        tkey = b.get("template_key") or ""
        if tkey and tpl_keys is not None and tkey not in tpl_keys:
            return False
        return True

    filtered = [b for b in buttons if visible(b)]
    if not filtered:
        return None, None
    inline_rows, reply_rows = {}, {}
    for b in filtered:
        row = b.get("row") or 0
        (inline_rows if b.get("button_type") == "inline" else reply_rows).setdefault(row, []).append(b)

    reply_markup_inline = None
    if inline_rows:
        inline_kb = []
        for r in sorted(inline_rows):
            row_btns = []
            for btn in sorted(inline_rows[r], key=lambda x: x.get("position") or 0):
                if btn.get("action_type") == "url" and btn.get("url"):
                    row_btns.append({"text": btn["title"], "url": btn["url"]})
                elif btn.get("action_type") == "back":
                    row_btns.append({"text": btn["title"], "callback_data": f"back_{btn.get('parent_id') or 0}"})
                else:
                    # هر دکمه قالب، کالبک اختصاصی خودش را دارد (tcb_<id>)؛
                    # دکمههای دستی قدیمی همچنان btn_<id> میمانند.
                    row_btns.append({"text": btn["title"],
                                     "callback_data": btn.get("callback") or f"btn_{btn['id']}"})
            if row_btns:
                inline_kb.append(row_btns)
        if parent_id:
            inline_kb.append([{"text": "⬅️ بازگشت", "callback_data": f"back_{parent_id}"}])
        reply_markup_inline = {"inline_keyboard": inline_kb} if inline_kb else None

    reply_markup_reply = None
    if reply_rows:
        reply_kb = []
        for r in sorted(reply_rows):
            row = [{"text": btn["title"]} for btn in sorted(reply_rows[r], key=lambda x: x.get("position") or 0)]
            if row:
                reply_kb.append(row)
        if parent_id:
            reply_kb.append([{"text": "⬅️ بازگشت"}])
        reply_markup_reply = {"keyboard": reply_kb, "resize_keyboard": True} if reply_kb else None
    return reply_markup_inline, reply_markup_reply


# =====================================================================
# 5) دیتابیس — مهاجرت جداول + پاکسازی کامل هنگام حذف ربات
# =====================================================================
MIGRATIONS = [
    ("bot_buttons", "scope", "TEXT DEFAULT 'both'"),
    ("bot_buttons", "template_key", "TEXT DEFAULT ''"),
    ("bot_buttons", "callback", "TEXT DEFAULT ''"),
    ("bot_settings", "respond_unknown", "INTEGER DEFAULT 0"),
    ("bot_users", "chat_type", "TEXT DEFAULT 'private'"),
    ("bot_users", "chat_title", "TEXT"),
    ("bot_settings", "active_template_group", "TEXT DEFAULT ''"),
    ("bot_settings", "active_template_pv", "TEXT DEFAULT ''"),
    ("bot_settings", "group_config", "TEXT DEFAULT '{}'"),
    ("broadcasts", "target_scope", "TEXT DEFAULT 'all'"),
    ("broadcasts", "render_vars", "INTEGER DEFAULT 1"),
    ("bots", "workdir", "TEXT DEFAULT ''"),
]

NEW_TABLES = [
    """CREATE TABLE IF NOT EXISTS bot_variables (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bot_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        label TEXT DEFAULT '',
        kind TEXT DEFAULT 'toggle',
        value_on TEXT DEFAULT 'فعال ✅',
        value_off TEXT DEFAULT 'غیرفعال ❌',
        is_active INTEGER DEFAULT 0,
        command_on TEXT DEFAULT '',
        command_off TEXT DEFAULT '',
        scope TEXT DEFAULT 'group',
        admin_only INTEGER DEFAULT 1,
        action TEXT DEFAULT 'none',
        penalty TEXT DEFAULT 'delete',
        description TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(bot_id, name),
        FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
    )""",
    """CREATE TABLE IF NOT EXISTS bot_variable_state (
        bot_id INTEGER NOT NULL,
        chat_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        is_active INTEGER DEFAULT 0,
        value TEXT DEFAULT '',
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (bot_id, chat_id, name)
    )""",
    """CREATE TABLE IF NOT EXISTS bot_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bot_id INTEGER NOT NULL,
        template_key TEXT NOT NULL,
        scope TEXT DEFAULT 'both',
        active INTEGER DEFAULT 1,
        custom_json TEXT DEFAULT '{}',
        applied_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(bot_id, template_key),
        FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
    )""",
    """CREATE TABLE IF NOT EXISTS bot_processes (
        bot_id INTEGER PRIMARY KEY,
        pid INTEGER,
        workdir TEXT DEFAULT '',
        kind TEXT DEFAULT 'subprocess',
        started_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
    )""",
]

# تمام جداولی که ستون bot_id دارند (حتی آنهایی که FK CASCADE ندارند)
BOT_ID_TABLES = [
    "bot_users", "bot_buttons", "bot_settings", "bot_admins", "stats_daily",
    "broadcasts", "subscriptions", "scheduled_messages", "polls", "user_tags",
    "auto_replies", "short_links", "media_gallery", "custom_commands", "user_levels",
    "daily_bonus", "user_coins", "user_warns", "bot_templates_log", "ownership_transfers",
    "referrals", "bot_variables", "bot_variable_state", "bot_templates", "bot_processes",
    "broadcast_queue",  # استثنا: ستون broadcast_id دارد، جداگانه پاک می‌شود
]


def _init_db_patched(self):
    MOD["_orig_init_db"](self)
    with self.get_conn() as conn:
        for table, col, coldef in MIGRATIONS:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {coldef}")
            except sqlite3.OperationalError:
                pass  # ستون از قبل وجود دارد
        for ddl in NEW_TABLES:
            conn.execute(ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_btn_scope ON bot_buttons(bot_id, scope)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_var_bot ON bot_variables(bot_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tpl_bot ON bot_templates(bot_id, active)")
        try:
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_bcq_unique ON broadcast_queue(broadcast_id, chat_id)")
        except sqlite3.OperationalError:
            pass
        try:
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_var_cmd ON bot_variables(bot_id, command_on)")
        except sqlite3.OperationalError:
            pass
    logger.info("مهاجرت جداول اصلاحات انجام شد (scope/متغیرها/قالبها/پروسهها)")


def db_purge_bot(self, bot_id):
    """حذف کامل و اتمیک تمام ردیف‌های وابسته + آزادسازی فضای SQLite."""
    removed = {}
    with self.get_conn() as conn:
        # فرزندان بدون bot_id
        conn.execute("DELETE FROM bot_button_contents WHERE button_id IN (SELECT id FROM bot_buttons WHERE bot_id=?)", (bot_id,))
        conn.execute("DELETE FROM poll_votes WHERE poll_id IN (SELECT id FROM polls WHERE bot_id=?)", (bot_id,))
        conn.execute("DELETE FROM broadcast_queue WHERE broadcast_id IN (SELECT id FROM broadcasts WHERE bot_id=?)", (bot_id,))
        for table in BOT_ID_TABLES:
            if table == "broadcast_queue":
                continue
            try:
                cur = conn.execute(f"DELETE FROM {table} WHERE bot_id=?", (bot_id,))
                removed[table] = cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
            except sqlite3.OperationalError as e:
                logger.debug("purge skip %s: %s", table, e)
        cur = conn.execute("DELETE FROM bots WHERE id=?", (bot_id,))
        removed["bots"] = cur.rowcount
        try:
            conn.execute("DELETE FROM user_states WHERE bot_context=?", (bot_id,))
        except sqlite3.OperationalError:
            pass
    # آزادسازی واقعی فضای دیسک
    try:
        conn2 = sqlite3.connect(self.db_path, timeout=30)
        conn2.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        conn2.execute("VACUUM")
        conn2.close()
    except Exception as e:
        logger.debug("VACUUM after purge: %s", e)
    return removed


def db_delete_bot(self, bot_id):
    return self.purge_bot(bot_id)


def db_seed_variables(self, bot_id, only_if_empty=True):
    """متغیرهای نمونه (مهم: zadlink + دستور «قفل لینک») برای هر ربات."""
    with self.get_conn() as conn:
        if only_if_empty:
            row = conn.execute("SELECT COUNT(*) c FROM bot_variables WHERE bot_id=?", (bot_id,)).fetchone()
            if row and row["c"]:
                return 0
        n = 0
        for p in CUSTOM_VARIABLE_PRESETS:
            try:
                conn.execute("""INSERT OR IGNORE INTO bot_variables
                    (bot_id, name, label, kind, value_on, value_off, is_active, command_on,
                     command_off, scope, admin_only, action, penalty, description)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (bot_id, p["name"], p["label"], "toggle", "فعال ✅", "غیرفعال ❌", 0,
                     p["command_on"], p["command_off"], p["scope"], 1, p["action"],
                     p["penalty"], p["description"]))
                n += 1
            except sqlite3.IntegrityError:
                pass
    return n


def db_get_var(self, bot_id, name):
    return self.fetchone("SELECT * FROM bot_variables WHERE bot_id=? AND name=?", (bot_id, name))


def db_set_var_state(self, bot_id, chat_id, name, is_active, value):
    self.execute("""INSERT INTO bot_variable_state (bot_id, chat_id, name, is_active, value, updated_at)
                    VALUES (?,?,?,?,?,?)
                    ON CONFLICT(bot_id, chat_id, name) DO UPDATE SET
                      is_active=excluded.is_active, value=excluded.value, updated_at=excluded.updated_at""",
                 (bot_id, chat_id, name, int(bool(is_active)), value, datetime.now().isoformat()))


def db_get_var_state(self, bot_id, chat_id, name):
    return self.fetchone("SELECT * FROM bot_variable_state WHERE bot_id=? AND chat_id=? AND name=?",
                         (bot_id, chat_id, name))


def db_record_process(self, bot_id, pid, workdir, kind="subprocess"):
    self.execute("""INSERT INTO bot_processes (bot_id, pid, workdir, kind, started_at) VALUES (?,?,?,?,?)
                    ON CONFLICT(bot_id) DO UPDATE SET pid=excluded.pid, workdir=excluded.workdir,
                      kind=excluded.kind, started_at=excluded.started_at""",
                 (bot_id, pid, workdir, kind, datetime.now().isoformat()))
    self.execute("UPDATE bots SET workdir=? WHERE id=?", (workdir, bot_id))

# =====================================================================
# 6) تاریخ شمسی واقعی (بدون وابستگی خارجی) + اطلاعات گروه
# =====================================================================
JALALI_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
PERSIAN_WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سهشنبه", "چهارشنبه", "پنجشنبه", "جمعه"]


def gregorian_to_jalali(gy, gm, gd):
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + (365 * gy) + ((gy2 + 3) // 4) - ((gy2 + 99) // 100) + ((gy2 + 399) // 400) + gd + g_d_m[gm - 1]
    jy = -1595 + (33 * (days // 12053))
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    jm = 0
    while jm < 11 and days >= [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29][jm]:
        days -= [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29][jm]
        jm += 1
    return jy, jm + 1, days + 1


def jalali_now():
    n = datetime.now()
    jy, jm, jd = gregorian_to_jalali(n.year, n.month, n.day)
    return f"{jy:04d}/{jm:02d}/{jd:02d}", JALALI_MONTHS[jm - 1], PERSIAN_WEEKDAYS[(n.weekday() + 2) % 7]


def _s(v):
    return "" if v is None else str(v)


# =====================================================================
# 7) UserBotRuntime — متغیرها، مدیریت گروه، متغیرهای سفارشی، دامنه دکمه‌ها
# =====================================================================
def runtime_group_info(self, chat_id, chat=None):
    """اطلاعات واقعی گروه از متدهای رسمی docs.bale.ai + کش ۲ دقیقهای."""
    ctx = get_runtime_context()
    ctype = (chat or {}).get("type") or ctx.get("chat_type") or "private"
    group = is_group_chat(ctype, chat_id)
    empty = {
        "chat_type": ctype, "title": (chat or {}).get("title") or "", "username": (chat or {}).get("username") or "",
        "invite_link": "", "members": 0, "admins_count": 0, "admin_names": "ندارد",
        "my_status": "member", "is_admin": "خیر", "is_owner": "خیر", "bot_is_admin": "خیر",
        "admin_ids": [], "group": group,
    }
    if not group:
        return empty
    cache = getattr(self, "_group_cache", None)
    if cache is None:
        cache = self._group_cache = {}
    hit = cache.get(chat_id)
    if hit and time.time() - hit[0] < 120:
        return hit[1]
    info = dict(empty)
    try:
        c = self.api.get_chat(chat_id) or {}
        info["title"] = c.get("title") or c.get("first_name") or info["title"]
        info["username"] = c.get("username") or ""
        info["invite_link"] = c.get("invite_link") or ""
        info["chat_type"] = c.get("type") or ctype
    except Exception as e:
        logger.debug("getChat %s: %s", chat_id, e)
    try:
        info["members"] = int(self.api.get_chat_members_count(chat_id) or 0)
    except Exception:
        pass
    try:
        admins = self.api.get_chat_administrators(chat_id) or []
        ids, names = [], []
        for a in admins:
            if not isinstance(a, dict):
                continue
            u = a.get("user") or {}
            uid = u.get("id")
            if uid:
                ids.append(uid)
                names.append(u.get("first_name") or u.get("username") or str(uid))
        info["admin_ids"] = ids
        info["admins_count"] = len(ids) or (1 if admins else 0)
        info["admin_names"] = "، ".join(names[:8]) if names else "ندارد"
        bot_uid = (self.bot_info or {}).get("id")
        info["bot_is_admin"] = "بله" if bot_uid and bot_uid in ids else "خیر"
    except Exception as e:
        logger.debug("getChatAdministrators %s: %s", chat_id, e)
    # وضعیت عضویت «کاربر جاری» جداگانه در runtime_all_variables محاسبه میشود
    # (getChatMember باید user_id بگیرد، نه chat_id گروه)
    if not info["invite_link"]:
        try:
            info["invite_link"] = self.api.export_chat_invite_link(chat_id) or ""
        except Exception:
            pass
    cache[chat_id] = (time.time(), info)
    return info


def runtime_is_group_admin(self, chat_id, user_id, group=None):
    if group is None:
        group = is_group_chat(get_runtime_context().get("chat_type"), chat_id)
    if group:
        info = self.runtime_group_info(chat_id)
        if user_id in info.get("admin_ids", []):
            return True
    # مالک ربات (ثبتشده در دیتابیس رباتساز) همیشه مجاز است
    try:
        conn = self._get_db()
        row = conn.execute("SELECT owner_id FROM bots WHERE id=?", (self.bot_id,)).fetchone()
        conn.close()
        if row and row["owner_id"] == user_id:
            return True
    except Exception:
        pass
    return False


def runtime_all_variables(self, chat_id, user_info=None, chat=None):
    """نسخه‌ی اصلاحشده: بدون تداخل کلیدها، مقادیر واقعی، بخش اختصاصی مدیریت گروه."""
    ui = dict(user_info or {})
    now = datetime.now()
    jdate, jmonth, jweekday = jalali_now()
    bot_user = _s((self.bot_info or {}).get("username") or "")
    bot_fname = _s((self.bot_info or {}).get("first_name") or "ربات")
    link = f"ble.ir/{bot_user}?start=ref_{chat_id}" if bot_user else f"ble.ir/bot?start=ref_{chat_id}"

    first = _s(ui.get("first_name") or "کاربر")
    last = _s(ui.get("last_name") or "")
    username = _s(ui.get("username") or "")
    bio = _s(ui.get("bio") or "")
    phone = _s(ui.get("phone") or "")

    count = coin = warn = maxwarn = xp = level = 0
    joiner, joindate, jointime, botlist, topuser, todaymsg, membercount = "ندارد", jdate, now.strftime("%H:%M"), "ندارد", "ندارد", "0", 0
    rules = "قوانین گروه هنوز ثبت نشده است."
    try:
        conn = self._get_db()
        r = conn.execute("SELECT COUNT(*) c FROM referrals WHERE inviter_id=? AND bot_id=?", (chat_id, self.bot_id)).fetchone()
        count = r["c"] if r else 0
        r = conn.execute("SELECT coins FROM user_coins WHERE bot_id=? AND user_id=?", (self.bot_id, chat_id)).fetchone()
        coin = r["coins"] if r else 0
        r = conn.execute("SELECT warns, max_warn FROM user_warns WHERE bot_id=? AND user_id=?", (self.bot_id, chat_id)).fetchone()
        if r:
            warn, maxwarn = r["warns"] or 0, r["max_warn"] or 3
        else:
            maxwarn = 3
        r = conn.execute("SELECT xp, level FROM user_levels WHERE bot_id=? AND chat_id=?", (self.bot_id, chat_id)).fetchone()
        if r:
            xp, level = r["xp"] or 0, r["level"] or 1
        else:
            level = 1
        r = conn.execute("SELECT invited_by, subscribed_at FROM bot_users WHERE bot_id=? AND chat_id=?", (self.bot_id, chat_id)).fetchone()
        if r:
            joiner = _s(r["invited_by"]) if r["invited_by"] else "ندارد"
            sub = _s(r["subscribed_at"] or "")
            if len(sub) >= 16:
                joindate, jointime = sub[:10], sub[11:16]
        rows = conn.execute("SELECT bot_name FROM bots WHERE owner_id=?", (chat_id,)).fetchall()
        botlist = "، ".join([_s(x["bot_name"]) for x in rows if x["bot_name"]]) or "ندارد"
        r = conn.execute("SELECT COUNT(*) c FROM bot_users WHERE bot_id=?", (self.bot_id,)).fetchone()
        membercount = r["c"] if r else 0
        r = conn.execute("SELECT messages FROM stats_daily WHERE bot_id=? AND date=?",
                         (self.bot_id, now.strftime("%Y-%m-%d"))).fetchone()
        todaymsg = _s(r["messages"] if r else 0)
        r = conn.execute("""SELECT bu.first_name FROM user_levels ul JOIN bot_users bu
                            ON bu.bot_id=ul.bot_id AND bu.chat_id=ul.chat_id
                            WHERE ul.bot_id=? ORDER BY ul.xp DESC LIMIT 1""", (self.bot_id,)).fetchone()
        topuser = _s(r["first_name"]) if r else "ندارد"
        r = conn.execute("SELECT group_config FROM bot_settings WHERE bot_id=?", (self.bot_id,)).fetchone()
        if r and r["group_config"]:
            try:
                rules = json.loads(r["group_config"]).get("rules") or rules
            except Exception:
                pass
        conn.close()
    except Exception as e:
        logger.debug("variables db: %s", e)

    g = self.runtime_group_info(chat_id, chat)
    # وضعیت واقعی عضویتِ «فرستنده پیام» از getChatMember (docs.bale.ai)
    if g["group"]:
        try:
            m = self.api.get_chat_member(chat_id, ui.get("id") or chat_id) or {}
            st = m.get("status", "member")
            g["my_status"] = st
            g["is_admin"] = "بله" if st in ("administrator", "creator") else "خیر"
            g["is_owner"] = "بله" if st == "creator" else "خیر"
        except Exception:
            pass
    group_title = g["title"] or bot_fname
    group_link = g["invite_link"] or (f"ble.ir/{g['username']}" if g["username"] else "")

    base = {
        # 👤 کاربر
        "FIRSTNAME": first, "LASTNAME": last, "FULLNAME": f"{first} {last}".strip(),
        "USERID": str(chat_id), "CHATID": str(chat_id), "USERNAME": username,
        "MENTION": f"@{username}" if username else first, "BIO": bio, "PHONE": phone,
        "JOINER": joiner, "JOINDATE": joindate, "JOINTIME": jointime,
        "JOINDATEFA": joindate, "JOINDATEEN": joindate,
        # 🤖 ربات
        "BOTUSER": bot_user, "BOTFNAME": bot_fname, "BOTNAME": bot_fname,
        "BOTID": str(self.bot_id), "BOTLINK": f"ble.ir/{bot_user}" if bot_user else "",
        "BOTLIST": botlist, "MEMBERCOUNT": str(membercount), "VERSION": "GOD v10 FIXED",
        # ⏰ زمان
        "TIME": now.strftime("%H:%M:%S"), "HOUR": now.strftime("%H"), "MIN": now.strftime("%M"),
        "SEC": now.strftime("%S"), "CLOCK": now.strftime("%H:%M"),
        "DATE": jdate, "DATEEN": now.strftime("%Y/%m/%d"), "DAY": jweekday,
        "FASL": ["بهار", "بهار", "بهار", "تابستان", "تابستان", "تابستان", "پاییز", "پاییز", "پاییز", "زمستان", "زمستان", "زمستان"][now.month - 1],
        "MAHFA": jmonth, "MONTHNAME": jmonth, "SEASON": ["بهار", "بهار", "بهار", "تابستان", "تابستان", "تابستان", "پاییز", "پاییز", "پاییز", "زمستان", "زمستان", "زمستان"][now.month - 1],
        "YEAR": str(now.year), "MONTH": now.strftime("%m"), "DAYNUM": now.strftime("%d"),
        "TIMESTAMP": str(int(now.timestamp())), "TODAY": jdate, "NOW": now.strftime("%H:%M:%S"),
        "WEEKDAY": jweekday, "YESTERDAY": (now - timedelta(days=1)).strftime("%Y/%m/%d"),
        "TOMORROW": (now + timedelta(days=1)).strftime("%Y/%m/%d"),
        "SERVERDATE": jdate, "SERVERTIME": now.strftime("%H:%M"),
        # 🎯 امتیاز / دعوت
        "COUNT": str(count), "INVITECOUNT": str(count), "COIN": str(coin),
        "BALANCE": str(coin), "MONEY": str(coin), "CREDIT": str(coin), "POINT": str(coin),
        "SCORE": str(coin), "LEVEL": str(level), "XP": str(xp), "RANK": str(level),
        "LINK": link, "REFLINK": link, "INVITELINK": link, "MYLINK": link,
        "WARN": str(warn), "MAXWARN": str(maxwarn), "WARNLEFT": str(max(0, maxwarn - warn)),
        "TOTALWARNS": str(warn), "COINFA": f"{coin:,}", "COUNTFA": f"{count:,}", "BALANCEFA": f"{coin:,}",
        "EARNED": str(count * 2000), "TOTAL_EARNED": str(count * 2000), "WITHDRAWABLE": str(coin),
        "WITHDRAWMIN": "50000", "TASKCOUNT": "3", "DAILYREWARD": "500", "STREAK": "1",
        "TOP1": _s(topuser), "TOP1COUNT": str(count), "TOP2": "نفر دوم", "TOP3": "نفر سوم",
        "TOPUSER": _s(topuser), "TOPUSERCOUNT": str(xp), "TODAYMSG": todaymsg,
        "RANDOM": str(random.randint(1, 100)), "RANDOM100": str(random.randint(1, 100)),
        "RANDOM1000": str(random.randint(1, 1000)), "RANDOM20": str(random.randint(1, 20)),
        "BOTUPTIME": "24ساعته",
        # 👮 مدیریت گروه (مقادیر واقعی API بله)
        "GROUPID": str(chat_id), "GROUPNAME": group_title, "GROUPTITLE": group_title,
        "GROUPUSERNAME": g["username"], "GROUPLINK": group_link,
        "GROUPMEMBERS": str(g["members"] or membercount), "GROUPADMINS": str(g["admins_count"]),
        "ADMINS": g["admin_names"], "ADMINCOUNT": str(g["admins_count"]),
        "ISADMIN": g["is_admin"], "ISOWNER": g["is_owner"], "BOTISADMIN": g["bot_is_admin"],
        "MYSTATUS": g["my_status"], "CHATTYPE": g["chat_type"], "RULES": rules,
        "ISGROUP": "بله" if g["group"] else "خیر",
        # 🕌 و فان
        "ZEKR": ["یا رب العالمین", "یا ذالجلال والاکرام", "یا قاضی الحاجات", "یا ارحم الراحمین", "یا حی یا قیوم", "لا اله الا الله", "اللهم صل علی محمد"][now.weekday()],
        "HADITH-TITLE": "علم", "HADITH-WHO": "امام علی (ع)", "HADITH-AR": "العلم سلطان",
        "HADITH-FA": "علم قدرت است", "HADITH-SRC": "نهج البلاغه",
        "QURAN": "بسم الله الرحمن الرحیم", "PRAYER": "اللهم صل علی محمد",
        "FAL": "نیت کن...", "JOKE": "یه جوک باحال!", "QUOTE": "سخن بزرگان", "FACT": "آیا میدانستید؟",
        "NHEYVAN": ["موش", "گاو", "پلنگ", "خرگوش", "نهنگ", "مار", "اسب", "گوسفند", "میمون", "مرغ", "سگ", "خوک"][now.year % 12],
        "NBASTANI": ["حمل", "ثور", "جوزا", "سرطان", "اسد", "سنبله", "میزان", "عقرب", "قوس", "جدی", "دلو", "حوت"][now.month - 1],
    }

    vars_map = {}
    for k, v in base.items():
        vars_map[k] = _s(v)
        if re.match(r"^[A-Z][A-Z0-9_\-]*$", k):
            vars_map[f"<b>{k}</b>"] = _s(v)
        vars_map["{" + k.lower() + "}"] = _s(v)
    # نام‌های پرکاربرد قدیمی (سازگاری با قالبها)
    vars_map.update({
        "{name}": first, "{bot_name}": bot_fname, "{username}": username,
        "{user_id}": str(chat_id), "{chat_id}": str(chat_id), "{user}": first,
        "{FIRSTNAME}": first, "{LASTNAME}": last, "{COUNT}": str(count),
        "{COIN}": str(coin), "{LINK}": link, "{DATE}": jdate, "{TIME}": now.strftime("%H:%M:%S"),
        "{count}": str(count), "{coin}": str(coin), "{link}": link,
        "ایدی": str(chat_id), "نام کامل": f"{first} {last}".strip(),
    })

    # 🧩 متغیرهای سفارشی کاربر (مثال: zadlink)
    try:
        conn = self._get_db()
        rows = conn.execute("SELECT * FROM bot_variables WHERE bot_id=?", (self.bot_id,)).fetchall()
        conn.close()
        for v in rows:
            name = _s(v["name"])
            st = self.runtime_get_var_state(chat_id, name)
            active = bool(st["is_active"]) if st else bool(v["is_active"])
            value = _s(v["value_on"] if active else v["value_off"])
            upper = name.upper()
            for alias in (name, upper, f"{{{name}}}", f"{{{{{name}}}}}", f"<b>{upper}</b>", f"VAR_{upper}"):
                vars_map[alias] = value
            vars_map[f"{upper}_STATE"] = "فعال" if active else "غیرفعال"
    except Exception as e:
        logger.debug("custom vars: %s", e)
    return vars_map


def runtime_render(self, chat_id, text, user_info=None, chat=None):
    try:
        variables = self.runtime_all_variables(chat_id, user_info or {}, chat)
    except Exception as e:
        logger.debug("render vars fallback: %s", e)
        variables = {}
    return render_variables(text, variables)


def runtime_active_templates(self, chat_type):
    """کدام قالبها در گروه / پیوی فعالاند (از تنظیمات ربات)."""
    group = is_group_chat(chat_type)
    try:
        conn = self._get_db()
        s = conn.execute("SELECT active_template_group, active_template_pv FROM bot_settings WHERE bot_id=?",
                         (self.bot_id,)).fetchone()
        chosen = (s["active_template_group"] if group else s["active_template_pv"]) if s else ""
        rows = conn.execute("SELECT template_key, scope, active FROM bot_templates WHERE bot_id=? AND active=1",
                            (self.bot_id,)).fetchall()
        conn.close()
    except Exception:
        return None
    want = "group" if group else "pv"
    # 🎯 قانون طلایی: در هر دامنه حداکثر یک قالب فعال است.
    # اگر کاربر صریحاً یکی را انتخاب کرده، فقط همان؛ وگرنه آخرین قالب متصلشده.
    # این کار از قاطی شدن دکمهها/پاسخهای تکراری چند قالب جلوگیری میکند.
    matching = [r for r in rows if (r["scope"] or "both").lower() in ("both", want)]
    if chosen:
        matching = [r for r in matching if r["template_key"] == chosen]
    else:
        try:
            c2 = self._get_db()
            last = c2.execute(
                "SELECT template_key FROM bot_templates WHERE bot_id=? AND active=1 "
                "AND (scope='both' OR scope=?) ORDER BY applied_at DESC, id DESC LIMIT 1",
                (self.bot_id, want)).fetchone()
            c2.close()
            if last:
                matching = [r for r in matching if r["template_key"] == last["template_key"]]
            else:
                matching = matching[-1:]
        except Exception:
            matching = matching[-1:]
    return {r["template_key"] for r in matching[:1]}


def runtime_track_chat(self, chat_id, chat, message=None):
    ctype = (chat or {}).get("type") or ("group" if is_group_chat(None, chat_id) else "private")
    title = (chat or {}).get("title") or ""
    try:
        conn = self._get_db()
        conn.execute("UPDATE bot_users SET chat_type=?, chat_title=? WHERE bot_id=? AND chat_id=?",
                     (ctype, title, self.bot_id, chat_id))
        conn.commit()
        conn.close()
    except Exception:
        pass
    set_runtime_context(chat_id=chat_id, chat_type=ctype, bot_id=self.bot_id,
                        active_templates=self.runtime_active_templates(ctype))
    return ctype


BUILTIN_GROUP_COMMANDS = {
    "آمار گروه": "stats", "لینک گروه": "invite", "ادمینها": "admins",
    "قوانین": "rules", "آیدی من": "myid", "اطلاعات گروه": "stats",
}


def runtime_handle_custom_commands(self, chat_id, message, text, from_user, chat):
    """اتصال دستور به متغیر: «قفل لینک» → zadlink فعال میشود + دستورات مدیریت گروه."""
    user_id = (from_user or {}).get("id") or chat_id
    ctype = (chat or {}).get("type") or get_runtime_context().get("chat_type") or "private"
    group = is_group_chat(ctype, chat_id)
    cmd = normalize_command(text)
    if not cmd:
        return False
    try:
        conn = self._get_db()
        rows = [dict(r) for r in conn.execute("SELECT * FROM bot_variables WHERE bot_id=?", (self.bot_id,)).fetchall()]
        conn.close()
    except Exception:
        rows = []
    for v in rows:
        for target, command in ((1, v.get("command_on")), (0, v.get("command_off"))):
            if not command or normalize_command(command) != cmd:
                continue
            scope = (v.get("scope") or "both").lower()
            if scope == "group" and not group:
                self.api.send_message(chat_id, "⚠️ این دستور فقط در **گروه** قابل اجراست.")
                return True
            if scope == "pv" and group:
                self.api.send_message(chat_id, "⚠️ این دستور فقط در **پیوی** قابل اجراست.")
                return True
            if v.get("admin_only") and not self.runtime_is_group_admin(chat_id, user_id, group):
                self.api.send_message(chat_id, "⛔ فقط ادمینها میتوانند این دستور را اجرا کنند.")
                return True
            value = v.get("value_on") if target else v.get("value_off")
            try:
                conn = self._get_db()
                conn.execute("UPDATE bot_variables SET is_active=? WHERE id=?", (int(bool(target)), v["id"]))
                conn.commit()
                conn.close()
                self.runtime_set_var_state(chat_id, v["name"], bool(target), value)
            except Exception as e:
                logger.debug("set var state: %s", e)
            label = v.get("label") or v.get("name")
            msg = (f"{'✅' if target else '🔓'} متغیر `{v['name']}` ({label}) "
                   f"با دستور «{command}» {'فعال' if target else 'غیرفعال'} شد.\n"
                   f"📄 مقدار فعلی: {value}")
            if v.get("action", "none") != "none":
                msg += f"\n🛡 عملکرد: {v['action']} | مجازات: {v.get('penalty')}"
            self.api.send_message(chat_id, self.runtime_render(chat_id, msg, from_user, chat))
            return True

    # دستورات اختصاصی مدیریت گروه (بدون نیاز به تعریف متغیر)
    kind = BUILTIN_GROUP_COMMANDS.get(cmd)
    if kind:
        g = self.runtime_group_info(chat_id, chat)
        if kind == "stats":
            out = (f"📊 **آمار گروه**\n🏷 نام: {g['title'] or '---'}\n🆔 آیدی: `{chat_id}`\n"
                   f"👥 اعضا: {g['members']}\n👮 ادمینها: {g['admins_count']}\n"
                   f"🤖 ربات ادمین است: {g['bot_is_admin']}\n💬 پیام امروز: TODAYMSG")
        elif kind == "invite":
            out = f"🔗 لینک دعوت گروه:\n{g['invite_link'] or 'در دسترس نیست (ربات باید ادمین باشد)'}"
        elif kind == "admins":
            out = f"👮 مدیران گروه ({g['admins_count']} نفر):\n{g['admin_names']}"
        elif kind == "rules":
            out = f"📜 قوانین گروه:\nRULES"
        else:
            out = f"🆔 آیدی شما: `{user_id}`\n💬 آیدی چت: `{chat_id}`\n📌 نوع: {ctype}"
        self.api.send_message(chat_id, self.runtime_render(chat_id, out, from_user, chat))
        return True

    # دستورات ادمینی با ریپلای: بن / اخراج / اخطار / پین / حذف
    if group and cmd in ("بن", "اخراج", "اخطار", "پین", "سنجاق", "حذف پیام", "آنبن") and \
            self.runtime_is_group_admin(chat_id, user_id, group):
        reply = message.get("reply_to_message") or {}
        target = (reply.get("from") or {}).get("id")
        target_msg = reply.get("message_id") or message.get("message_id")
        if cmd in ("بن", "اخراج"):
            if not target:
                self.api.send_message(chat_id, "روی پیام کاربر ریپلای کنید.")
            else:
                self.api.ban_chat_member(chat_id, target)
                self.api.send_message(chat_id, "🚫 کاربر از گروه اخراج شد.")
        elif cmd == "آنبن":
            if target:
                self.api.unban_chat_member(chat_id, target, only_if_banned=True)
                self.api.send_message(chat_id, "✅ کاربر از حالت مسدود خارج شد.")
        elif cmd == "اخطار":
            if target:
                self._apply_warn(chat_id, target, message)
        elif cmd in ("پین", "سنجاق"):
            if target_msg:
                self.api.pin_chat_message(chat_id, target_msg)
                self.api.send_message(chat_id, "📌 پیام سنجاق شد.")
        elif cmd == "حذف پیام":
            if target_msg:
                self.api.delete_message(chat_id, target_msg)
        return True
    return False


def runtime_apply_warn(self, chat_id, user_id, message=None):
    try:
        conn = self._get_db()
        conn.execute("INSERT OR IGNORE INTO user_warns (bot_id, user_id, warns, max_warn) VALUES (?,?,0,3)",
                     (self.bot_id, user_id))
        conn.execute("UPDATE user_warns SET warns=warns+1 WHERE bot_id=? AND user_id=?", (self.bot_id, user_id))
        row = conn.execute("SELECT warns, max_warn FROM user_warns WHERE bot_id=? AND user_id=?",
                           (self.bot_id, user_id)).fetchone()
        conn.commit()
        conn.close()
        warns, mx = (row["warns"], row["max_warn"]) if row else (1, 3)
        if warns >= mx:
            try:
                self.api.ban_chat_member(chat_id, user_id)
            except Exception:
                pass
            self.api.send_message(chat_id, f"🚨 کاربر `{user_id}` به سقف اخطار ({mx}) رسید و اخراج شد.")
        else:
            self.api.send_message(chat_id, f"⚠️ اخطار به `{user_id}` | {warns}/{mx}")
    except Exception as e:
        logger.debug("warn: %s", e)


LINK_RE = re.compile(r"(https?://|www\.|ble\.ir/|t\.me/|@[A-Za-z0-9_]{4,})", re.I)


def _lock_violated(action, message, text):
    if action == "lock_link":
        return bool(LINK_RE.search(text or "")) or bool(message.get("caption") and LINK_RE.search(message["caption"]))
    if action == "lock_forward":
        return bool(message.get("forward_from") or message.get("forward_from_chat") or message.get("forward_date"))
    if action == "lock_photo":
        return bool(message.get("photo"))
    if action == "lock_video":
        return bool(message.get("video"))
    if action == "lock_document":
        return bool(message.get("document"))
    if action == "lock_audio":
        return bool(message.get("audio") or message.get("voice"))
    if action == "lock_contact":
        return bool(message.get("contact"))
    if action == "lock_hashtag":
        return "#" in (text or "")
    if action == "lock_profanity":
        return any(w in (text or "").lower() for w in BUILTIN_BAD_WORDS)
    if action == "lock_spam":
        return False  # جداگانه توسط شمارنده اسپم مدیریت میشود
    return False


def runtime_enforce_locks(self, chat_id, message, text, from_user, chat):
    group = is_group_chat((chat or {}).get("type") or get_runtime_context().get("chat_type"), chat_id)
    if not group:
        return False
    user_id = (from_user or {}).get("id") or chat_id
    if self.runtime_is_group_admin(chat_id, user_id, group):
        return False
    try:
        conn = self._get_db()
        rows = [dict(r) for r in conn.execute("SELECT * FROM bot_variables WHERE bot_id=?", (self.bot_id,)).fetchall()]
        conn.close()
    except Exception:
        rows = []
    active = []
    for v in rows:
        if (v.get("action") or "none") == "none":
            continue
        st = self.runtime_get_var_state(chat_id, v["name"])
        on = bool(st["is_active"]) if st else bool(v["is_active"])
        if on:
            active.append(v)
    if not active:
        return False
    # ضداسپم: ۵ پیام در ۱۰ ثانیه
    flood = getattr(self, "_flood", None)
    if flood is None:
        flood = self._flood = {}
    nowt = time.time()
    times = [t for t in flood.get((chat_id, user_id), []) if nowt - t < 10]
    times.append(nowt)
    flood[(chat_id, user_id)] = times
    spam = len(times) > 5

    for v in active:
        action = v.get("action")
        hit = spam if action == "lock_spam" else _lock_violated(action, message, text)
        if not hit:
            continue
        try:
            self.api.delete_message(chat_id, message.get("message_id"))
        except Exception:
            pass
        penalty = v.get("penalty") or "delete"
        name = (from_user or {}).get("first_name") or str(user_id)
        if penalty == "warn":
            self.runtime_apply_warn(chat_id, user_id, message)
        elif penalty in ("mute", "ban"):
            try:
                self.api.ban_chat_member(chat_id, user_id)
            except Exception:
                pass
            self.api.send_message(chat_id, f"🚫 {name} به دلیل نقض قفل «{v.get('label') or v['name']}» اخراج شد.")
        else:
            # جلوگیری از اسپم اخطار: حداکثر یک پیام در ۳۰ ثانیه برای هر کاربر
            last = getattr(self, "_lock_notice", {}).get((chat_id, user_id), 0)
            if nowt - last > 30:
                self._lock_notice = getattr(self, "_lock_notice", {})
                self._lock_notice[(chat_id, user_id)] = nowt
                self.api.send_message(chat_id, f"🔒 پیام حذف شد — قفل «{v.get('label') or v['name']}» فعال است.")
        return True
    return False


def runtime_handle_message(self, message):
    """جایگزین کامل handle_message ربات کاربر: FSM دستورات، قفلها، دامنه، متغیرها."""
    chat = message.get("chat", {}) or {}
    chat_id = chat.get("id")
    if chat_id is None:
        return
    from_user = message.get("from", {}) or {}
    user_id = from_user.get("id") or chat_id
    text = message.get("text") or ""
    caption = message.get("caption") or ""
    msg_id = message.get("message_id")

    # ضداسپم پایه
    try:
        nowt = time.time()
        f = getattr(self, "_base_flood", None) or {}
        key = (chat_id, user_id)
        f[key] = [t for t in f.get(key, []) if nowt - t < 10] + [nowt]
        self._base_flood = f
        if len(f[key]) > 8:
            return
    except Exception:
        pass

    try:
        self._ensure_bot_user(chat_id, from_user)
        self._update_last_seen(chat_id)
        self._inc_stat()
    except Exception:
        pass
    ctype = self.runtime_track_chat(chat_id, chat, message)

    # 👋 خوشامد اعضای جدید
    new_members = message.get("new_chat_members") or []
    if new_members and is_group_chat(ctype, chat_id):
        try:
            st = self.runtime_get_var_state(chat_id, "welcome")
            conn = self._get_db()
            vrow = conn.execute("SELECT is_active FROM bot_variables WHERE bot_id=? AND name='welcome'",
                                (self.bot_id,)).fetchone()
            conn.close()
            on = bool(st["is_active"]) if st else bool(vrow and vrow["is_active"])
            if on:
                wm = self._get_settings().get("welcome_message") or "سلام FIRSTNAME جان! 🎉 به GROUPNAME خوش آمدی."
                self.api.send_message(chat_id, self.runtime_render(chat_id, wm, from_user, chat))
        except Exception:
            pass
        return

    # 🧩 دستورات متغیرها (مثال «قفل لینک»)
    try:
        if self.runtime_handle_custom_commands(chat_id, message, text, from_user, chat):
            return
    except Exception as e:
        logger.debug("custom command: %s", e)
    # 🛡 اجرای قفلهای فعال گروه
    try:
        if self.runtime_enforce_locks(chat_id, message, text or caption, from_user, chat):
            return
    except Exception as e:
        logger.debug("locks: %s", e)

    settings = self._get_settings() or {}
    buttons = self._get_buttons()
    parent_id = self._get_user_parent(chat_id)

    if text.startswith("/start"):
        param = text.split(" ", 1)[1].strip() if " " in text else ""
        if param.startswith("ref_") or param.isdigit():
            try:
                rid = int(param.replace("ref_", ""))
                if rid != chat_id:
                    self._handle_referral(rid, chat_id)
            except Exception:
                pass
        # تبلیغ سراسری (با متغیرها)
        try:
            conn = self._get_db()
            ad = conn.execute("SELECT content, is_active FROM global_ads WHERE id=1").fetchone()
            conn.close()
            if ad and ad["is_active"] and ad["content"]:
                self.api.send_message(chat_id, "📢 " + self.runtime_render(chat_id, ad["content"], from_user, chat))
        except Exception:
            pass
        start_msg = settings.get("start_message") or "سلام FIRSTNAME عزیز 👋\nبه **BOTFNAME** خوش آمدید 🎉\nاز منوی زیر انتخاب کنید 👇"
        start_msg = self.runtime_render(chat_id, start_msg, from_user, chat)
        inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=None)
        if inline_kb:
            self.api.send_message(chat_id, start_msg, reply_markup=inline_kb)
            if reply_kb:
                self.api.send_message(chat_id, "از منوی زیر انتخاب کنید 👇", reply_markup=reply_kb)
        elif reply_kb:
            self.api.send_message(chat_id, start_msg, reply_markup=reply_kb)
        else:
            self.api.send_message(chat_id, start_msg)
        self._set_user_parent(chat_id, None)
        return

    if text == "⬅️ بازگشت":
        current = self._get_user_parent(chat_id)
        new_parent = self._get_button_parent(current) if current else None
        self._set_user_parent(chat_id, new_parent)
        inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=new_parent)
        msg = "منوی قبلی:" if new_parent else "🏠 منوی اصلی:"
        if inline_kb:
            self.api.send_message(chat_id, msg, reply_markup=inline_kb)
        elif reply_kb:
            self.api.send_message(chat_id, msg, reply_markup=reply_kb)
        else:
            self.api.send_message(chat_id, msg)
        return

    matched = self._find_button_by_title(text, parent_id)
    if matched:
        scope = (matched.get("scope") or "both").lower()
        if (scope == "group" and not is_group_chat(ctype, chat_id)) or (scope == "pv" and is_group_chat(ctype, chat_id)):
            self.api.send_message(chat_id, "🚫 این دکمه در این محیط فعال نیست.")
            return
        children = [b for b in buttons if b.get("parent_id") == matched["id"]]
        if children or matched.get("action_type") == "menu":
            self._set_user_parent(chat_id, matched["id"])
            inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=matched["id"])
            title = self.runtime_render(chat_id, matched.get("content_text") or f"📌 {matched['title']}", from_user, chat)
            if inline_kb:
                self.api.send_message(chat_id, title, reply_markup=inline_kb)
                if reply_kb:
                    self.api.send_message(chat_id, "انتخاب کنید:", reply_markup=reply_kb)
            elif reply_kb:
                self.api.send_message(chat_id, title, reply_markup=reply_kb)
            else:
                self.api.send_message(chat_id, title)
        else:
            self._execute_button_action(chat_id, matched, from_user=from_user, chat=chat)
        return

    # 📌 دستورات سفارشی تنظیمشده توسط سازنده ربات (جدول custom_commands)
    try:
        conn = self._get_db()
        customs = conn.execute(
            "SELECT command, response FROM custom_commands WHERE bot_id=? AND is_active=1",
            (self.bot_id,)).fetchall()
        conn.close()
        norm = (text or "").strip()
        for c in customs:
            if norm and norm.lower() == (c["command"] or "").strip().lower():
                self.api.send_message(chat_id, self.runtime_render(chat_id, c["response"] or "", from_user, chat))
                return
    except Exception:
        pass

    # پاسخ خودکار
    try:
        conn = self._get_db()
        autos = conn.execute("SELECT * FROM auto_replies WHERE bot_id=?", (self.bot_id,)).fetchall()
        conn.close()
        for a in autos:
            if (a["keyword"] or "").lower() in (text or "").lower():
                self.api.send_message(chat_id, self.runtime_render(chat_id, a["reply"], from_user, chat))
                return
    except Exception:
        pass

    # 🚫 قانون جدید: «فقط به دستورات تنظیمشده جواب بده»
    # هیچ پیام پیشفرض/نامعتبر/«متوجه نشدم» ارسال نمیشود مگر اینکه صاحب ربات
    # صریحاً گزینه «پاسخ به پیامهای ناشناخته» را روشن کرده باشد.
    respond_unknown = 0
    try:
        respond_unknown = int(settings.get("respond_unknown") or 0)
    except Exception:
        respond_unknown = 0
    if not respond_unknown:
        return

    default_msg = settings.get("default_message") or "دستور نامفهوم است. لطفا از منوی زیر استفاده کنید. 🤖"
    default_msg = self.runtime_render(chat_id, default_msg, from_user, chat)
    inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=parent_id)
    if inline_kb:
        self.api.send_message(chat_id, default_msg, reply_markup=inline_kb)
    elif reply_kb:
        self.api.send_message(chat_id, default_msg, reply_markup=reply_kb)
    else:
        self.api.send_message(chat_id, default_msg)


def runtime_handle_callback(self, query):
    """-wrapper: ست کردن دامنه چت + جلوگیری از اجرای دکمههای خارج از دامنه."""
    data = query.get("data", "") or ""
    message = query.get("message", {}) or {}
    chat = (message.get("chat") or query.get("from") or {})
    chat_id = chat.get("id") or (query.get("from") or {}).get("id")
    self.runtime_track_chat(chat_id, chat, message)
    # 🎯 کالبک اختصاصی قالبها: tcb_<button_id> → دقیقاً همان دکمه اجرا میشود
    # (برخلاف btn_ عمومی، هیچ تداخلی با دکمههای قالب دیگر/create-hand ندارد)
    q = query
    if data.startswith("tcb_"):
        try:
            btn_id = int(data[4:])
            q = dict(query)
            q["data"] = f"btn_{btn_id}"
            data = q["data"]
        except Exception:
            return
    if data.startswith("btn_"):
        try:
            btn_id = int(data.split("_")[1])
            btn = next((b for b in self._get_buttons() if b["id"] == btn_id), None)
            if btn:
                scope = (btn.get("scope") or "both").lower()
                group = is_group_chat((chat.get("type") or "private"), chat_id)
                if (scope == "group" and not group) or (scope == "pv" and group) or scope == "off":
                    try:
                        self.api.answer_callback_query(query.get("id"), "🚫 این دکمه در این محیط غیرفعال است", show_alert=True)
                    except Exception:
                        pass
                    return
        except Exception:
            pass
    return MOD["_orig_runtime_callback"](self, q)


def runtime_find_button_by_title(self, title, parent_id=None):
    """دستور اختصاصی دکمه (ستون command) هم بالاخره واقعاً کار میکند."""
    try:
        conn = self._get_db()
        if parent_id is None:
            rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND parent_id IS NULL",
                                (self.bot_id, title)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND parent_id=?",
                                (self.bot_id, title, parent_id)).fetchall()
        if not rows:
            rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? AND command=? AND command<>''",
                                (self.bot_id, title)).fetchall()
        if not rows:
            rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND button_type='reply'",
                                (self.bot_id, title)).fetchall()
        conn.close()
        return dict(rows[0]) if rows else None
    except Exception as e:
        logger.debug("find button: %s", e)
        return None


def runtime_execute_button_action(self, chat_id, button, from_user=None, chat=None):
    """اجرای اکشن دکمه — متغیرها یکبار و امن، PMGUARD، EditeMsg، مطالب اضافی، قفل."""
    action = button.get("action_type") or "text"
    content = button.get("content_text") or ""
    caption = button.get("caption") or ""
    file_id = button.get("file_id")
    url = button.get("url")
    chat = chat or {"type": get_runtime_context().get("chat_type", "private"), "id": chat_id}
    from_user = from_user or self._get_bot_user_info(chat_id)
    try:
        variables = self.runtime_all_variables(chat_id, from_user, chat)
    except Exception:
        variables = {}
    content = render_variables(content, variables)
    caption = render_variables(caption, variables)
    protect = False
    if "PMGUARD" in content:
        protect, content = True, content.replace("<code>PMGUARD</code>", "").replace("PMGUARD", "")
    if "PMGUARD" in caption:
        protect, caption = True, caption.replace("<code>PMGUARD</code>", "").replace("PMGUARD", "")

    children = self._get_buttons()
    inline_kb, _ = build_user_bot_keyboard(children, parent_id=button["id"])

    # قفل دکمه
    if button.get("is_locked"):
        ltype = button.get("lock_type")
        if ltype == "join":
            ch = (button.get("lock_channel") or "").lstrip("@")
            if ch:
                try:
                    m = self.api.get_chat_member(f"@{ch}", chat_id) or {}
                    if m.get("status") in ("left", "kicked", ""):
                        self.api.send_message(chat_id, self.runtime_render(chat_id,
                            button.get("lock_message") or f"🔒 برای استفاده باید در @{ch} عضو شوید", from_user, chat))
                        return
                except Exception:
                    pass
        elif ltype == "referral":
            need = int(button.get("lock_count") or 3)
            try:
                conn = self._get_db()
                r = conn.execute("SELECT COUNT(*) c FROM referrals WHERE inviter_id=? AND bot_id=?",
                                 (chat_id, self.bot_id)).fetchone()
                conn.close()
                have = r["c"] if r else 0
                if have < need:
                    self.api.send_message(chat_id, self.runtime_render(chat_id,
                        button.get("lock_message") or f"🔒 نیاز به {need} دعوت | شما: {have} نفر\nلینکت: LINK",
                        from_user, chat))
                    return
            except Exception:
                pass

    # EditeMsg(a|b|c)
    if content.strip().startswith("EditeMsg(") and content.strip().endswith(")"):
        parts = content.strip()[9:-1].split("|")
        if parts:
            msg = self.api.send_message(chat_id, parts[0], reply_markup=inline_kb)
            mid = (msg or {}).get("message_id") if isinstance(msg, dict) else None
            for pm in parts[1:]:
                time.sleep(0.7)
                if mid:
                    try:
                        self.api.edit_message_text(chat_id, mid, pm, reply_markup=inline_kb)
                    except Exception:
                        pass
            return

    # مطالب اضافی
    extra = []
    try:
        conn = self._get_db()
        extra = [dict(r) for r in conn.execute(
            "SELECT * FROM bot_button_contents WHERE button_id=? ORDER BY position", (button["id"],)).fetchall()]
        conn.close()
    except Exception:
        pass

    def send_main():
        kwargs = {"reply_markup": inline_kb if not extra else None}
        if protect:
            kwargs["protect_content"] = True
        return self.api.send_message(chat_id, content or "محتوایی تنظیم نشده", **kwargs)

    try:
        if action == "text":
            send_main()
            for ec in extra:
                ct = render_variables(ec.get("content_text") or "", variables)
                if ec.get("content_type") == "photo" and ec.get("file_id"):
                    self.api.send_photo(chat_id, ec["file_id"], caption=ct)
                elif ec.get("content_type") == "video" and ec.get("file_id"):
                    self.api.send_video(chat_id, ec["file_id"], caption=ct)
                else:
                    self.api.send_message(chat_id, ct or " ")
            if extra and inline_kb:
                self.api.send_message(chat_id, "انتخاب کنید 👇", reply_markup=inline_kb)
            return
        media = file_id or button.get("file_url")
        if action == "photo" and media:
            self.api.send_photo(chat_id, media, caption=caption or content or None, reply_markup=inline_kb)
        elif action == "video" and media:
            self.api.send_video(chat_id, media, caption=caption or content or None, reply_markup=inline_kb)
        elif action == "document" and media:
            self.api.send_document(chat_id, media, caption=caption or content or None, reply_markup=inline_kb)
        elif action == "audio" and file_id:
            self.api.send_audio(chat_id, file_id, caption=caption or None)
        elif action == "url" and url:
            self.api.send_message(chat_id, f"{content or button.get('title')}\n\n🔗 {url}", reply_markup=inline_kb)
        else:
            self.api.send_message(chat_id, content or caption or "محتوایی تنظیم نشده", reply_markup=inline_kb)
    except Exception as e:
        logger.error("خطا در اجرای اکشن دکمه %s: %s", button.get("id"), e)
        try:
            self.api.send_message(chat_id, content or "خطا در ارسال محتوا")
        except Exception:
            pass


def runtime_start(self, use_executor=None):
    """قبل از polling وبهاک قدیمی حذف شود وگرنه getUpdates خالی میماند."""
    try:
        self.api.delete_webhook()
    except Exception:
        pass
    return MOD["_orig_runtime_start"](self, use_executor=use_executor)

# =====================================================================
# 8) BotManager — جلوگیری از زنده ماندن / ریاستارت ربات حذفشده
# =====================================================================
def manager_start_bot(self, bot_id, token_encrypted):
    # 🔒 جلوگیری قطعی از پاسخهای تکراری: هر توکن دقیقاً یک Runtime زنده
    # (دو رانتایم با یک توکن هر دو همان آپدیتها را میگرفتند → پیام دوبل)
    import hashlib
    th = hashlib.sha256(str(token_encrypted or "").encode("utf-8")).hexdigest()
    with self.lock:
        owners = getattr(self, "_token_owners", None)
        if owners is None:
            owners = self._token_owners = {}
        prev = owners.get(th)
        if prev is not None and prev != bot_id:
            old = self.bots.get(prev)
            if old is not None:
                try:
                    old.stop()
                except Exception:
                    pass
                try:
                    self.bots.pop(prev, None)
                except Exception:
                    pass
        owners[th] = bot_id
    ok = MOD["_orig_manager_start_bot"](self, bot_id, token_encrypted)
    if ok:
        try:
            self._token_owners[th] = bot_id
        except Exception:
            pass
        try:
            self._deleted.discard(bot_id)
        except Exception:
            pass
        try:
            seed_vars_direct(self.db_path, bot_id)
        except Exception as e:
            logger.debug("seed variables: %s", e)
    return ok


def manager_stop_bot(self, bot_id):
    with self.lock:
        rt = self.bots.pop(bot_id, None)
        if rt:
            try:
                rt.stop()
            except Exception:
                pass
        try:
            owners = getattr(self, "_token_owners", None) or {}
            self._token_owners = {k: v for k, v in owners.items() if v != bot_id}
        except Exception:
            pass
    try:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.execute("UPDATE bots SET is_active=0, status='offline' WHERE id=?", (bot_id,))
        conn.commit()
        conn.close()
    except Exception:
        pass
    return True


def manager_remove_bot(self, bot_id):
    """حذف کامل از حافظه + جلوگیری قطعی از ریاستارت توسط مانیتور."""
    self.stop_bot(bot_id)
    deleted = getattr(self, "_deleted", None)
    if deleted is None:
        deleted = self._deleted = set()
    deleted.add(int(bot_id))
    with self.lock:
        self.bots.pop(int(bot_id), None)
    return True


def manager_monitor_loop(self):
    while self.running:
        time.sleep(60)
        try:
            conn = sqlite3.connect(self.db_path, timeout=30)
            conn.row_factory = sqlite3.Row
            bots = conn.execute("SELECT * FROM bots WHERE is_active=1 AND status='online'").fetchall()
            conn.close()
            deleted = getattr(self, "_deleted", set())
            for b in bots:
                bid = int(b["id"])
                if bid in deleted:
                    continue
                rt = self.bots.get(bid)
                if not rt or not rt.running:
                    logger.warning("ربات %s آفلاین است، ریاستارت...", bid)
                    self.start_bot(bid, b["token_encrypted"])
        except Exception as e:
            logger.error("خطا در مانیتور: %s", e)


def manager_load_all(self):
    import sqlite3 as _sq
    from datetime import datetime as _dt
    try:
        conn = _sq.connect(self.db_path, timeout=30)
        conn.row_factory = _sq.Row
        bots = conn.execute("SELECT * FROM bots WHERE is_active=1").fetchall()
        conn.close()
        deleted = getattr(self, "_deleted", set())
        count = 0
        for b in bots:
            bid = int(b["id"])
            if bid in deleted:
                continue
            try:
                exp = b["expires_at"]
                if exp and _dt.fromisoformat(exp) < _dt.now():
                    conn2 = _sq.connect(self.db_path, timeout=30)
                    conn2.execute("UPDATE bots SET is_active=0, status='offline' WHERE id=?", (bid,))
                    conn2.commit()
                    conn2.close()
                    continue
            except Exception:
                pass
            if self.start_bot(bid, b["token_encrypted"]):
                count += 1
            time.sleep(0.3)
        logger.info("%s ربات بازیابی و اجرا شدند", count)
    except Exception as e:
        logger.error("خطا در load_all_bots: %s", e)


# =====================================================================
# 9) ارسال همگانی — نسخه‌ی بازنویسیشده و بدون باگ
# =====================================================================
def build_broadcast_vars(db_path, bot_id, chat_id, bot_username=None):
    """متغیرهای همگانی به ازای هر گیرنده (بدون نیاز به runtime)."""
    n = datetime.now()
    jdate, _, _ = jalali_now()
    first, username, ctype = "کاربر", "", "private"
    try:
        conn = sqlite3.connect(db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        u = conn.execute("SELECT * FROM bot_users WHERE bot_id=? AND chat_id=?", (bot_id, chat_id)).fetchone()
        if u:
            first = u["first_name"] or "کاربر"
            username = u["username"] or ""
            ctype = u["chat_type"] or ("group" if int(chat_id) < 0 else "private")
        conn.close()
    except Exception:
        pass
    link = f"ble.ir/{bot_username}?start=ref_{chat_id}" if bot_username else f"ble.ir/bot?start=ref_{chat_id}"
    base = {
        "FIRSTNAME": first, "USERID": str(chat_id), "CHATID": str(chat_id),
        "USERNAME": username, "MENTION": f"@{username}" if username else first,
        "DATE": jdate, "DATEEN": n.strftime("%Y/%m/%d"), "TIME": n.strftime("%H:%M:%S"),
        "DAY": PERSIAN_WEEKDAYS[(n.weekday() + 2) % 7], "LINK": link, "REFLINK": link,
        "BOTUSER": bot_username or "", "BOTFNAME": bot_username or "ربات",
        "CHATTYPE": ctype, "ISGROUP": "بله" if is_group_chat(ctype, chat_id) else "خیر",
    }
    v = {}
    for k, val in base.items():
        v[k] = str(val)
        v[f"<b>{k}</b>"] = str(val)
        v["{" + k.lower() + "}"] = str(val)
    # متغیرهای سفارشی هم در همگانی قابل استفادهاند
    try:
        conn = sqlite3.connect(db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM bot_variables WHERE bot_id=?", (bot_id,)).fetchall()
        for r in rows:
            st = conn.execute("SELECT is_active FROM bot_variable_state WHERE bot_id=? AND chat_id=? AND name=?",
                              (bot_id, chat_id, r["name"])).fetchone()
            on = bool(st["is_active"]) if st else bool(r["is_active"])
            val = str(r["value_on"] if on else r["value_off"])
            name = r["name"]
            for alias in (name, name.upper(), f"{{{name}}}", f"{{{{{name}}}}}", f"<b>{name.upper()}</b>"):
                v[alias] = val
        conn.close()
    except Exception:
        pass
    return v


def broadcast_start(self, broadcast_id):
    if broadcast_id in self.workers and self.workers[broadcast_id].is_alive():
        return False
    try:
        conn = sqlite3.connect(self.db_path, timeout=30)
        row = conn.execute("SELECT status FROM broadcasts WHERE id=?", (broadcast_id,)).fetchone()
        conn.close()
        if row and row[0] in ("completed", "cancelled"):
            return False
    except Exception:
        pass
    self.stop_flags[broadcast_id] = False
    t = threading.Thread(target=self._run_broadcast, args=(broadcast_id,), daemon=True,
                         name=f"broadcast-{broadcast_id}")
    self.workers[broadcast_id] = t
    t.start()
    return True


def broadcast_stop(self, broadcast_id):
    self.stop_flags[broadcast_id] = True
    try:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.execute("UPDATE broadcasts SET status='cancelled', finished_at=? WHERE id=? AND status IN ('pending','running','paused')",
                     (datetime.now().isoformat(), broadcast_id))
        conn.commit()
        conn.close()
    except Exception:
        pass
    return True


def broadcast_stop_bot(self, bot_id):
    """هنگام حذف ربات، همه‌ی همگانیهای درحال اجرا متوقف شوند."""
    try:
        conn = sqlite3.connect(self.db_path, timeout=30)
        rows = conn.execute("SELECT id FROM broadcasts WHERE bot_id=? AND status IN ('pending','running','paused')",
                            (bot_id,)).fetchall()
        conn.close()
        for r in rows:
            self.stop_broadcast(r[0])
        return len(rows)
    except Exception:
        return 0


def broadcast_status(self, broadcast_id):
    try:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM broadcasts WHERE id=?", (broadcast_id,)).fetchone()
        conn.close()
        return dict(row) if row else None
    except Exception:
        return None


def broadcast_run(self, broadcast_id):
    conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        bc = conn.execute("SELECT * FROM broadcasts WHERE id=?", (broadcast_id,)).fetchone()
        if not bc:
            conn.close()
            return
        bot = conn.execute("SELECT * FROM bots WHERE id=?", (bc["bot_id"],)).fetchone()
        if not bot:
            conn.execute("UPDATE broadcasts SET status='failed', finished_at=? WHERE id=?",
                         (datetime.now().isoformat(), broadcast_id))
            conn.commit()
            conn.close()
            return
        if bc["status"] in ("completed", "cancelled"):
            conn.close()
            return
        token = MOD["decrypt_token"](bot["token_encrypted"])
        api = MOD["BaleAPI"](token, base_url=self.base_url)
        keyboard = None
        if bc["keyboard_json"]:
            try:
                keyboard = json.loads(bc["keyboard_json"])
            except Exception:
                keyboard = None
        conn.execute("UPDATE broadcasts SET status='running', started_at=? WHERE id=?",
                     (datetime.now().isoformat(), broadcast_id))
        conn.commit()
        queue = conn.execute("SELECT * FROM broadcast_queue WHERE broadcast_id=? AND status='pending' ORDER BY id",
                             (broadcast_id,)).fetchall()
        sent = int(bc["sent_count"] or 0)
        failed = int(bc["failed_count"] or 0)
        mtype = bc["message_type"] or "text"
        bot_username = bot["bot_username"] or ""

        for q in queue:
            if self.stop_flags.get(broadcast_id):
                break
            # اگر ربات حذف شد، ارسال متوقف شود
            if not conn.execute("SELECT 1 FROM bots WHERE id=?", (bc["bot_id"],)).fetchone():
                self.stop_flags[broadcast_id] = True
                break
            chat_id = q["chat_id"]
            v = build_broadcast_vars(self.db_path, bc["bot_id"], chat_id, bot_username)
            content = render_variables(bc["content"] or "", v)
            caption = render_variables(bc["caption"] or "", v)
            file_id = bc["file_id"]
            try:
                if mtype == "photo" and file_id:
                    api.send_photo(chat_id, file_id, caption=caption or content or None, reply_markup=keyboard)
                elif mtype == "video" and file_id:
                    api.send_video(chat_id, file_id, caption=caption or content or None, reply_markup=keyboard)
                elif mtype == "document" and file_id:
                    api.send_document(chat_id, file_id, caption=caption or content or None, reply_markup=keyboard)
                elif mtype == "audio" and file_id:
                    api.send_audio(chat_id, file_id, caption=caption or content or None)
                else:
                    api.send_message(chat_id, content or "📢", reply_markup=keyboard)
                conn.execute("UPDATE broadcast_queue SET status='sent', sent_at=? WHERE id=?",
                             (datetime.now().isoformat(), q["id"]))
                sent += 1
            except Exception as e:
                err = str(e)[:400]
                conn.execute("UPDATE broadcast_queue SET status='failed', error=? WHERE id=?", (err, q["id"]))
                failed += 1
                if "blocked" in err.lower() or "forbidden" in err.lower() or "403" in err:
                    try:
                        conn.execute("UPDATE bot_users SET is_blocked=1 WHERE bot_id=? AND chat_id=?",
                                     (bc["bot_id"], chat_id))
                    except Exception:
                        pass
            conn.execute("UPDATE broadcasts SET sent_count=?, failed_count=? WHERE id=?",
                         (sent, failed, broadcast_id))
            conn.commit()
            time.sleep(1.0 / self.rate_limit if self.rate_limit and self.rate_limit > 0 else 1.0)

        final = "cancelled" if self.stop_flags.get(broadcast_id) else "completed"
        conn.execute("UPDATE broadcasts SET status=?, sent_count=?, failed_count=?, finished_at=? WHERE id=?",
                     (final, sent, failed, datetime.now().isoformat(), broadcast_id))
        conn.commit()
        logger.info("Broadcast %s %s: %s sent, %s failed", broadcast_id, final, sent, failed)
        conn.close()
    except Exception as e:
        logger.exception("خطا در broadcast %s: %s", broadcast_id, e)
        try:
            conn.execute("UPDATE broadcasts SET status='failed', finished_at=? WHERE id=?",
                         (datetime.now().isoformat(), broadcast_id))
            conn.commit()
            conn.close()
        except Exception:
            pass

# =====================================================================
# 10) متغیرهای کمکی Builder
# =====================================================================
GROUP_VARIABLES_GUIDE = """👮 **بخش اختصاصی مدیریت گروه (متغیرها + دستورات)**

📊 **متغیرهای واقعی گروه (از API رسمی بله):**
`GROUPTITLE` / `GROUPNAME` عنوان گروه | `GROUPID` آیدی گروه
`GROUPUSERNAME` یوزرنیم | `GROUPLINK` لینک دعوت
`GROUPMEMBERS` تعداد اعضا | `GROUPADMINS` تعداد ادمینها | `ADMINS` اسامی ادمینها
`ISADMIN` آیا کاربر ادمین است | `ISOWNER` آیا مالک است | `MYSTATUS` وضعیت عضویت
`BOTISADMIN` آیا ربات ادمین گروه است | `CHATTYPE` نوع چت | `ISGROUP` گروه/پیوی
`RULES` قوانین گروه | `TODAYMSG` پیامهای امروز | `TOPUSER` فعالترین کاربر
`WARN` اخطارها | `MAXWARN` سقف اخطار | `WARNLEFT` باقیمانده

🧩 **متغیرهای سفارشی (دستور → متغیر):**
مثال: متغیر `zadlink` (ضد لینک)
• «**قفل لینک**» → `{zadlink}` = `فعال ✅` و لینکها حذف میشوند
• «**بازکردن لینک**» → `{zadlink}` = `غیرفعال ❌`
همان متغیر با `ZADLINK`، `{{zadlink}}` و `<b>ZADLINK</b>` هم کار میکند.
از پنل «🧩 متغیرها و دستورات» میتوانی نام، دستور، دامنه و مجازات را عوض کنی.

🛠 **دستورات آماده گروه (فقط ادمینها):**
`قفل لینک` / `بازکردن لینک` | `قفل فوروارد` | `قفل عکس` | `قفل اسپم`
`بن` / `اخراج` / `آنبن` / `اخطار` / `پین` / `حذف پیام` (با ریپلای)
`آمار گروه` | `لینک گروه` | `ادمینها` | `قوانین` | `آیدی من`

📌 متدهای استفادهشده (docs.bale.ai):
`getChat`, `getChatMember`, `getChatAdministrators`, `getChatMembersCount`,
`banChatMember`, `unbanChatMember`, `promoteChatMember`, `pinChatMessage`,
`deleteMessage`, `exportChatInviteLink`, `leaveChat`
⚠️ `restrictChatMember` در مستندات رسمی بله وجود ندارد؛ سکوت با `banChatMember` انجام میشود.
"""


def _owns(self, chat_id, bot_id):
    bot = self.db.get_bot(bot_id)
    return bool(bot and (bot["owner_id"] == chat_id or MOD["is_admin"](chat_id)))


def _keyboard(rows):
    return {"inline_keyboard": rows}


def _tail(data, prefix):
    return data[len(prefix):] if data.startswith(prefix) else ""


def _last_int(data):
    m = re.search(r"_(\d+)$", data or "")
    return int(m.group(1)) if m else None


def _safe_name(name):
    return bool(re.match(r"^[\w\u0600-\u06FF]{2,32}$", name or "", re.UNICODE))


def _settings_ensure(self, bot_id):
    self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id) VALUES (?)", (bot_id,))


def _scope_label(scope):
    return {"both": "🌐 هر دو", "group": "👥 گروه", "pv": "👤 پیوی", "off": "🚫 خاموش"}.get(scope, "🌐 هر دو")


# =====================================================================
# 11) کتابخانه قالبها — UI و اتصال یککلیکه
# =====================================================================
def cmd_library(self, chat_id, bot_id=None, msg_id=None):
    if bot_id:
        return show_library_categories(self, chat_id, bot_id, msg_id)
    bots = self.db.get_user_bots(chat_id)
    if not bots:
        self.send_message(chat_id, "📂 **کتابخانه قالبها**\n\nهنوز رباتی نساختهای. اول «🤖 ساخت ربات» بزن، بعد قالبها رو با یک کلیک به رباتت وصل کن.")
        return
    rows = [[{"text": f"📂 {b['bot_name'] or b['bot_username'] or b['id']}",
              "callback_data": f"libbot_{b['id']}"}] for b in bots]
    rows.append([{"text": "🤖 ساخت ربات با قالب", "callback_data": "create_ready"}])
    self.edit_or_send(chat_id, msg_id,
                      f"📂 **کتابخانه قالبها — {len(ALL_TEMPLATES)} قالب آماده**\n\n"
                      "کدام ربات را میخواهی قالبدار کنی؟ (بعدش مشخص میکنی کدام قالب در گروه و کدام در پیوی فعال باشد)",
                      reply_markup=_keyboard(rows))


def show_library_categories(self, chat_id, bot_id, msg_id=None):
    cats = {}
    for t in TEMPLATE_LIBRARY.values():
        cats.setdefault(t["category"], (t["category_name"], 0))
        name, n = cats[t["category"]]
        cats[t["category"]] = (name, n + 1)
    rows = []
    items = list(cats.items())
    for i in range(0, len(items), 2):
        row = []
        for k, (name, n) in items[i:i + 2]:
            row.append({"text": f"{name} ({n})", "callback_data": f"lib_cat_{k}_{bot_id}_0"})
        rows.append(row)
    rows.append([{"text": "⭐ قالبهای فولسورس (۱۴)", "callback_data": f"lib_cat_source_{bot_id}_0"}])
    rows.append([{"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}])
    self.edit_or_send(chat_id, msg_id,
                      f"📂 **کتابخانه قالبها**\n\n✅ {len(TEMPLATE_LIBRARY)} قالب آماده + ۱۴ قالب فولسورس\n"
                      "یک دسته انتخاب کن → قالب را ببین → **یک کلیک** وصل کن → دامنهاش (گروه/پیوی) را مشخص کن.",
                      reply_markup=_keyboard(rows))


def show_library_category(self, chat_id, cat, bot_id, page, msg_id=None):
    if cat == "source":
        entries = [(k, t) for k, t in ALL_TEMPLATES.items() if t.get("kind") != "library"]
    else:
        entries = [(k, t) for k, t in TEMPLATE_LIBRARY.items() if t["category"] == cat]
    per_page = 8
    pages = max(1, (len(entries) + per_page - 1) // per_page)
    page = max(0, min(int(page), pages - 1))
    chunk = entries[page * per_page:(page + 1) * per_page]
    rows = []
    for i in range(0, len(chunk), 2):
        row = []
        for k, t in chunk[i:i + 2]:
            row.append({"text": t["name"][:38], "callback_data": f"lib_view_{k}_{bot_id}"})
        rows.append(row)
    nav = []
    if page > 0:
        nav.append({"text": "⬅️ قبلی", "callback_data": f"lib_cat_{cat}_{bot_id}_{page-1}"})
    nav.append({"text": f"📄 {page+1}/{pages}", "callback_data": f"lib_cat_{cat}_{bot_id}_{page}"})
    if page < pages - 1:
        nav.append({"text": "بعدی ➡️", "callback_data": f"lib_cat_{cat}_{bot_id}_{page+1}"})
    rows.append(nav)
    rows.append([{"text": "⬅️ دستهها", "callback_data": f"lib_open_{bot_id}"}])
    title = cat if cat == "source" else next((c[1] for c in CATEGORY_SPECS if c[0] == cat), cat)
    self.edit_or_send(chat_id, msg_id, f"📂 **{title}** — {len(entries)} قالب\nصفحه {page+1} از {pages}:",
                      reply_markup=_keyboard(rows))


def show_library_template(self, chat_id, key, bot_id, msg_id=None):
    t = get_template(key)
    if not t:
        self.edit_or_send(chat_id, msg_id, "❌ قالب یافت نشد.")
        return
    attached = None
    if bot_id:
        attached = self.db.fetchone("SELECT * FROM bot_templates WHERE bot_id=? AND template_key=?", (bot_id, key))
    text = (f"🎨 **{t['name']}**\n{t.get('desc','')}\n\n"
            f"🔘 دکمهها: {len(t.get('buttons', []))} | 🌐 دامنه پیشفرض: {_scope_label(t.get('scope','both'))}\n"
            f"📌 وضعیت: {'✅ متصل' if attached else '➖ متصل نیست'}")
    if attached:
        text += f" | دامنه فعلی: {_scope_label(attached['scope'])}"
    rows = []
    if bot_id:
        rows.append([{"text": "✅ اتصال با یک کلیک", "callback_data": f"lib_attach_{key}_{bot_id}"}])
        if attached:
            rows.append([{"text": "👥 فقط گروه", "callback_data": f"lib_scope_{key}_{bot_id}_group"},
                         {"text": "👤 فقط پیوی", "callback_data": f"lib_scope_{key}_{bot_id}_pv"}])
            rows.append([{"text": "🌐 هر دو", "callback_data": f"lib_scope_{key}_{bot_id}_both"},
                         {"text": "🚫 غیرفعال", "callback_data": f"lib_scope_{key}_{bot_id}_off"}])
            rows.append([{"text": "⭐ فعال در گروه", "callback_data": f"lib_active_{key}_{bot_id}_group"},
                         {"text": "⭐ فعال در پیوی", "callback_data": f"lib_active_{key}_{bot_id}_pv"}])
            rows.append([{"text": "✏️ شخصیسازی", "callback_data": f"lib_custom_{key}_{bot_id}"},
                         {"text": "🗑 جدا کردن", "callback_data": f"lib_remove_{key}_{bot_id}"}])
    else:
        rows.append([{"text": "🚀 ساخت ربات با این قالب", "callback_data": f"use_template_{key}"}])
    rows.append([{"text": "⬅️ بازگشت", "callback_data": f"lib_cat_{t.get('category','source')}_{bot_id}_0"}])
    self.edit_or_send(chat_id, msg_id, text, reply_markup=_keyboard(rows))


def attach_template(self, chat_id, bot_id, key, scope=None, msg_id=None, silent=False):
    t = get_template(key)
    if not t:
        if not silent:
            self.send_message(chat_id, "❌ قالب یافت نشد.")
        return False
    if not _owns(self, chat_id, bot_id):
        if not silent:
            self.send_message(chat_id, "❌ دسترسی غیرمجاز.")
        return False
    scope = scope or t.get("scope", "both")
    if scope not in ("both", "group", "pv", "off"):
        scope = "both"
    try:
        with self.db.get_conn() as conn:
            conn.execute("""INSERT INTO bot_templates (bot_id, template_key, scope, active, applied_at)
                            VALUES (?,?,?,1,?)
                            ON CONFLICT(bot_id, template_key) DO UPDATE SET scope=excluded.scope,
                              active=1, applied_at=excluded.applied_at""",
                         (bot_id, key, scope, datetime.now().isoformat()))
            conn.execute("DELETE FROM bot_buttons WHERE bot_id=? AND template_key=?", (bot_id, key))
            for idx, b in enumerate(t.get("buttons", [])):
                cur = conn.execute("""INSERT INTO bot_buttons
                    (bot_id, title, button_type, parent_id, row, position, action_type, content_text,
                     scope, template_key, command)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                    (bot_id, b.get("title", f"دکمه {idx+1}"), b.get("type", "reply"), None,
                     b.get("row", 0), idx, b.get("action", "text"), b.get("content", ""),
                     scope, key, b.get("title", "")))
                # 🎯 کالبک اختصاصی و یکتا برای هر دکمه (fix: دکمهها دیگر btn_ عمومی نمیشوند)
                conn.execute("UPDATE bot_buttons SET callback=? WHERE id=?",
                             (f"tcb_{cur.lastrowid}", cur.lastrowid))
            conn.execute("INSERT OR IGNORE INTO bot_settings (bot_id) VALUES (?)", (bot_id,))
            conn.execute("UPDATE bot_settings SET start_message=COALESCE(NULLIF(start_message,''),?) WHERE bot_id=?",
                         (t.get("start_message") or MOD["DEFAULT_START_MESSAGE"], bot_id))
            # فقط یک قالب در هر دامنه فعال است → جلوگیری از قاطی شدن دکمههای چند قالب
            if scope in ("both", "group"):
                conn.execute("UPDATE bot_settings SET active_template_group=? WHERE bot_id=?", (key, bot_id))
            if scope in ("both", "pv"):
                conn.execute("UPDATE bot_settings SET active_template_pv=? WHERE bot_id=?", (key, bot_id))
            conn.execute("INSERT INTO bot_templates_log (bot_id, template) VALUES (?,?)", (bot_id, key))
        self.db.seed_variables(bot_id)
    except Exception as e:
        logger.exception("attach_template: %s", e)
        if not silent:
            self.send_message(chat_id, f"❌ خطا در اتصال قالب: {e}")
        return False
    if not silent:
        self.edit_or_send(chat_id, msg_id,
            f"✅ قالب **{t['name']}** با {len(t.get('buttons', []))} دکمه به ربات وصل شد.\n"
            f"🌐 دامنه: {_scope_label(scope)}\n\nاز «🎛 دامنه دکمهها» میتوانی تکتک دکمهها را گروهی/پیوی کنی.",
            reply_markup=_keyboard([[{"text": "🎛 دامنه دکمهها", "callback_data": f"scope_menu_{bot_id}"},
                                    {"text": "📂 کتابخانه", "callback_data": f"lib_open_{bot_id}"}]]))
    return True


def detach_template(self, chat_id, bot_id, key, msg_id=None):
    if not _owns(self, chat_id, bot_id):
        return
    with self.db.get_conn() as conn:
        conn.execute("DELETE FROM bot_buttons WHERE bot_id=? AND template_key=?", (bot_id, key))
        conn.execute("DELETE FROM bot_templates WHERE bot_id=? AND template_key=?", (bot_id, key))
        conn.execute("UPDATE bot_settings SET active_template_group='' WHERE bot_id=? AND active_template_group=?", (bot_id, key))
        conn.execute("UPDATE bot_settings SET active_template_pv='' WHERE bot_id=? AND active_template_pv=?", (bot_id, key))
    self.edit_or_send(chat_id, msg_id, f"🗑 قالب `{key}` جدا شد.",
                      reply_markup=_keyboard([[{"text": "⬅️ کتابخانه", "callback_data": f"lib_open_{bot_id}"}]]))


def set_template_scope(self, chat_id, bot_id, key, scope, msg_id=None):
    if not _owns(self, chat_id, bot_id) or scope not in ("both", "group", "pv", "off"):
        return
    with self.db.get_conn() as conn:
        conn.execute("UPDATE bot_templates SET scope=?, active=? WHERE bot_id=? AND template_key=?",
                     (scope, 0 if scope == "off" else 1, bot_id, key))
        conn.execute("UPDATE bot_buttons SET scope=? WHERE bot_id=? AND template_key=?", (scope, bot_id, key))
    self.edit_or_send(chat_id, msg_id, f"✅ دامنه قالب `{key}` → {_scope_label(scope)}",
                      reply_markup=_keyboard([[{"text": "⬅️ برگشت", "callback_data": f"lib_view_{key}_{bot_id}"}]]))


def set_active_template(self, chat_id, bot_id, key, target, msg_id=None):
    if not _owns(self, chat_id, bot_id) or target not in ("group", "pv"):
        return
    _settings_ensure(self, bot_id)
    col = "active_template_group" if target == "group" else "active_template_pv"
    # idempotent: کلیک روی «فعال کردن» همیشه همان قالب را فعال نگه میدارد
    # (نسخه قبلی toggle بود و چون attach خودش قالب را فعال میکرد، کلیک بعدی
    #  ناخواسته آن را خاموش میکرد ← باگ «قالب فعال گم شد»)
    new = key
    self.db.execute(f"UPDATE bot_settings SET {col}=? WHERE bot_id=?", (new, bot_id))
    where = "گروهها 👥" if target == "group" else "پیوی 👤"
    state = f"قالب `{new}`"
    self.edit_or_send(chat_id, msg_id, f"✅ قالب فعال در **{where}**: {state}",
                      reply_markup=_keyboard([[{"text": "⬅️ برگشت", "callback_data": f"lib_view_{key}_{bot_id}"}]]))


def cmd_templates_new(self, chat_id):
    self.send_message(chat_id,
        f"📂 **کتابخانه قالبها — {len(ALL_TEMPLATES)} قالب**\n\n"
        "• ۱۲ دسته × ۱۰ قالب آماده = ۱۲۰ قالب\n• ۱۴ قالب فولسورس (مدیریت گروه، فروشگاه، ارز، ...)\n"
        "• اتصال **یک کلیکی**، شخصیسازی متن و دکمهها\n• تعیین قالب فعال **گروه** و **پیوی** جداگانه\n\n"
        "از منوی «📂 کتابخانه قالبها» رباتت رو انتخاب کن 👇",
        reply_markup=_keyboard([[{"text": "📂 باز کردن کتابخانه", "callback_data": "libbot_0"}]]))


def apply_template_new(self, chat_id, bot_id, tmpl_key):
    return attach_template(self, chat_id, bot_id, tmpl_key, msg_id=None, silent=False)


def step_token_new(self, chat_id, text, mode="choice"):
    """کپی اصلاحشده step_token: منوی انتخاب قالب + در کتابخانه ۱۲۰ قالب."""
    token = text.strip()
    if not MOD["validate_token_format"](token):
        self.send_message(chat_id, "❌ فرمت توکن نامعتبر است.\nمثال: `123456789:ABCdef...`\nدوباره بفرست یا «❌ انصراف»",
                          reply_markup=MOD["cancel_keyboard"]())
        return True
    self.send_message(chat_id, "⏳ در حال بررسی توکن و اتصال به API بله...")
    result = MOD["validate_token"](token, self.base_url)
    if not result["ok"]:
        self.send_message(chat_id, f"❌ توکن نامعتبر یا خطا در اتصال:\n{result.get('error')}\nتوکن صحیح را بفرست.",
                          reply_markup=MOD["cancel_keyboard"]())
        return True
    info = result["info"]
    enc = MOD["encrypt_token"](token)
    if self.db.fetchone("SELECT * FROM bots WHERE token_encrypted=?", (enc,)):
        self.send_message(chat_id, "⚠️ این توکن قبلا ثبت شده است.")
        self.db.clear_user_step(chat_id)
        return True
    bot_username = info.get("username", "")
    bot_name = info.get("first_name", "")
    bot_id_api = info.get("id")
    if mode == "raw":
        return finish_bot_creation(self, chat_id, enc, bot_username, bot_name, bot_id_api, "raw", None)
    self.db.set_user_step(chat_id, "await_template_choice", {
        "token_enc": enc, "bot_username": bot_username, "bot_name": bot_name, "bot_id_api": bot_id_api})
    rows = []
    items = list(MOD["TEMPLATES"].items())
    for i in range(0, len(items), 2):
        row = []
        for k, v in items[i:i + 2]:
            row.append({"text": v["name"], "callback_data": f"use_template_{k}"})
        rows.append(row)
    rows.append([{"text": f"📂 کتابخانه {len(TEMPLATE_LIBRARY)} قالب آماده", "callback_data": "lib_create_0"}])
    rows.append([{"text": "🔧 قالب خام (بدون دکمه)", "callback_data": "use_template_raw"},
                 {"text": "❌ انصراف", "callback_data": "cancel_create"}])
    self.send_message(chat_id,
        f"✅ **توکن تایید شد!**\n🤖 {bot_name} (@{bot_username})\n🆔 {bot_id_api}\n\n"
        "🎨 حالا قالب را انتخاب کن (قالبها بعداً قابل ویرایش و جداسازی گروه/پیویاند):",
        reply_markup=_keyboard(rows))
    return True


def finish_bot_creation(self, chat_id, enc, bot_username, bot_name, bot_id_api, key, msg_id=None):
    """ساخت ربات + اتصال قالب + اجرای امن (پروسهها ثبت میشوند تا موقع حذف پاک شوند)."""
    step = self.db.get_user_step(chat_id)
    if step and step["step"] == "await_template_choice":
        enc = enc or step["data"]["token_enc"]
    if self.db.fetchone("SELECT * FROM bots WHERE token_encrypted=?", (enc,)):
        self.send_message(chat_id, "⚠️ این توکن قبلا ثبت شده است.")
        self.db.clear_user_step(chat_id)
        return True
    plan = self.db.fetchone("SELECT * FROM plans WHERE name='رایگان'") or self.db.fetchone("SELECT * FROM plans LIMIT 1")
    plan_id = plan["id"] if plan else 1
    expires = (datetime.now() + timedelta(days=plan["days"] if plan else 7)).isoformat()
    self.db.execute("""INSERT INTO bots (owner_id, token_encrypted, bot_username, bot_name, bot_id,
                       is_active, status, created_at, expires_at, plan_id)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (chat_id, enc, bot_username, bot_name, bot_id_api, 1, "offline",
                     datetime.now().isoformat(), expires, plan_id))
    bot_row = self.db.fetchone("SELECT * FROM bots WHERE owner_id=? ORDER BY id DESC LIMIT 1", (chat_id,))
    if not bot_row:
        self.send_message(chat_id, "❌ خطا در ساخت ربات، دوباره تلاش کن.")
        return True
    bot_db_id = bot_row["id"]
    t = get_template(key) if key not in (None, "raw") else None
    start_msg = (t or {}).get("start_message") or MOD["DEFAULT_START_MESSAGE"]
    self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id, start_message, welcome_message) VALUES (?,?,?)",
                    (bot_db_id, start_msg, MOD["DEFAULT_WELCOME_MESSAGE"]))
    self.db.seed_variables(bot_db_id)
    if t:
        attach_template(self, chat_id, bot_db_id, key, silent=True)

    deployed, ok = False, False
    tmpl_file = (t or {}).get("template")
    kind = (t or {}).get("kind")
    if tmpl_file and kind in ("python_single", "python_package"):
        try:
            import sys
            src = os.path.join("templates_src", tmpl_file)
            safe_user = re.sub(r"[^A-Za-z0-9_]", "_", bot_username or "bot")
            workdir = os.path.join("bots", f"{bot_db_id}_{safe_user}")
            if os.path.exists(src):
                os.makedirs(workdir, exist_ok=True)
                token_plain = MOD["decrypt_token"](enc)
                if kind == "python_package":
                    shutil.copytree(src, workdir, dirs_exist_ok=True)
                    for root, dirs, files in os.walk(workdir):
                        for fn in files:
                            if fn.endswith((".py", ".json", ".txt")):
                                fp = os.path.join(root, fn)
                                try:
                                    txt = open(fp, encoding="utf-8").read()
                                    txt = (txt.replace("{{BOT_TOKEN}}", token_plain)
                                              .replace("{{ADMIN_ID}}", str(chat_id))
                                              .replace("{{ADMIN_CMD}}", "/admin"))
                                    open(fp, "w", encoding="utf-8").write(txt)
                                except Exception:
                                    pass
                else:
                    txt = open(src, encoding="utf-8").read()
                    txt = (txt.replace("{{BOT_TOKEN}}", token_plain)
                              .replace("{{ADMIN_ID}}", str(chat_id))
                              .replace("{{ADMIN_CMD}}", "/admin"))
                    open(os.path.join(workdir, "main.py"), "w", encoding="utf-8").write(txt)
                proc = subprocess.Popen([sys.executable, "-X", "utf8", "main.py"], cwd=workdir,
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                        stdin=subprocess.DEVNULL, start_new_session=True)
                self.db.record_process(bot_db_id, proc.pid, workdir, "subprocess")
                self.db.execute("UPDATE bots SET status='online', is_active=1, workdir=? WHERE id=?",
                                (workdir, bot_db_id))
                deployed, ok = True, True
        except Exception as e:
            logger.exception("deploy template: %s", e)
    if not deployed:
        ok = self.bot_manager.start_bot(bot_db_id, enc)
        if ok:
            self.db.execute("UPDATE bots SET status='online', is_active=1 WHERE id=?", (bot_db_id,))
    self.db.clear_user_step(chat_id)
    if msg_id:
        try:
            self.api.delete_message(chat_id, msg_id)
        except Exception:
            pass
    tmpl_name = (t or {}).get("name", "قالب خام")
    self.send_message(chat_id,
        f"✅ **ربات ساخته شد** 🎉\n\n🤖 {bot_name}\n🔗 @{bot_username}\n🎨 {tmpl_name}\n"
        f"📅 انقضا: {expires[:10]} | {'🟢 آنلاین' if ok else '🔴 خطا در اجرا'}\n\n"
        "📂 کتابخانه قالبها / 🎛 دامنه دکمهها / 🧩 متغیرها و دستورات / 👮 مدیریت گروه",
        reply_markup=MOD["main_reply_keyboard"](is_admin=MOD["is_admin"](chat_id)))
    self.db.add_log("info", "builder", f"ربات {bot_username} با قالب {tmpl_name} ساخته شد")
    return True


def use_template_new(self, chat_id, key, msg_id=None):
    step = self.db.get_user_step(chat_id)
    if not step or step["step"] != "await_template_choice":
        self.db.set_user_step(chat_id, "await_token_ready")
        self.send_message(chat_id,
            "🤖 برای ساخت ربات با این قالب، اول **توکن ربات** را بفرست (از @botfather):",
            reply_markup=MOD["cancel_keyboard"]())
        return True
    d = step["data"]
    return finish_bot_creation(self, chat_id, d["token_enc"], d["bot_username"], d["bot_name"],
                               d["bot_id_api"], key, msg_id)


# =====================================================================
# 12) متغیرها و دستورات + مدیریت گروه + دامنه دکمهها (UI)
# =====================================================================
def cmd_pick_bot(self, chat_id, action, msg_id=None):
    bots = self.db.get_user_bots(chat_id)
    if not bots:
        self.send_message(chat_id, "🤷 هنوز رباتی نساختهای. اول «🤖 ساخت ربات» بزن.")
        return
    rows = [[{"text": f"🤖 {b['bot_name'] or b['bot_username'] or b['id']}",
              "callback_data": f"{action}bot_{b['id']}"}] for b in bots]
    self.edit_or_send(chat_id, msg_id, "ربات مورد نظر را انتخاب کن:", reply_markup=_keyboard(rows))


def show_vars_menu(self, chat_id, bot_id, msg_id=None):
    if not _owns(self, chat_id, bot_id):
        return
    self.db.seed_variables(bot_id)
    rows_db = self.db.fetchall("SELECT * FROM bot_variables WHERE bot_id=? ORDER BY id", (bot_id,))
    text = "🧩 **متغیرها و دستورات ربات**\n\nمتغیر بساز، به آن دستور وصل کن، دامنهاش را مشخص کن:\n"
    rows = []
    for v in rows_db:
        state = "🟢" if v["is_active"] else "🔴"
        text += (f"\n{state} `{v['name']}` — {v['label'] or 'بدون عنوان'}\n"
                 f"   ⌨️ «{v['command_on'] or '---'}» / «{v['command_off'] or '---'}» | {_scope_label(v['scope'])}\n"
                 f"   🛡 {v['action']} | مجازات: {v['penalty']}")
        rows.append([
            {"text": f"{state} {v['name']}", "callback_data": f"var_toggle_{v['id']}_{bot_id}"},
            {"text": "⌨️ دستور", "callback_data": f"var_cmd_{v['id']}_{bot_id}"},
            {"text": "🌐 دامنه", "callback_data": f"var_scopemenu_{v['id']}_{bot_id}"},
            {"text": "🗑", "callback_data": f"var_del_{v['id']}_{bot_id}"},
        ])
    rows.append([{"text": "➕ متغیر جدید", "callback_data": f"var_add_{bot_id}"},
                 {"text": "⚡ افزودن پریستها", "callback_data": f"var_preset_all_{bot_id}"}])
    rows.append([{"text": "📜 راهنمای مدیریت گروه", "callback_data": f"var_help_{bot_id}"},
                 {"text": "👮 پنل گروه", "callback_data": f"grp_menu_{bot_id}"}])
    rows.append([{"text": "⬅️ پنل ربات", "callback_data": f"panel_{bot_id}"}])
    self.edit_or_send(chat_id, msg_id, text, reply_markup=_keyboard(rows))


def show_var_scope_menu(self, chat_id, var_id, bot_id, msg_id=None):
    rows = [[{"text": "🌐 گروه + پیوی", "callback_data": f"var_scope_{var_id}_{bot_id}_both"},
             {"text": "👥 فقط گروه", "callback_data": f"var_scope_{var_id}_{bot_id}_group"}],
            [{"text": "👤 فقط پیوی", "callback_data": f"var_scope_{var_id}_{bot_id}_pv"},
             {"text": "⬅️ بازگشت", "callback_data": f"vars_menu_{bot_id}"}]]
    self.edit_or_send(chat_id, msg_id, "🌐 **دامنه فعالیت متغیر**\nدستور فعالسازی این متغیر کجا پاسخ بدهد؟",
                      reply_markup=_keyboard(rows))


def show_scope_menu(self, chat_id, bot_id, msg_id=None):
    if not _owns(self, chat_id, bot_id):
        return
    buttons = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=? ORDER BY row, position", (bot_id,))
    text = ("🎛 **مدیریت دامنه دکمهها**\n\n"
            "مشخص کن هر دکمه در **گروهها**، **پیوی** یا **هر دو** فعال باشد.\n"
            f"🔘 تعداد دکمهها: {len(buttons)}\n")
    cnt = {"both": 0, "group": 0, "pv": 0, "off": 0}
    rows = []
    for b in buttons:
        sc = (b["scope"] or "both").lower()
        cnt[sc] = cnt.get(sc, 0) + 1
        rows.append([{"text": f"{b['title'][:26]} | {_scope_label(sc)}",
                      "callback_data": f"scope_btn_{b['id']}_{bot_id}"}])
    text += f"\n🌐 هر دو: {cnt['both']} | 👥 گروه: {cnt['group']} | 👤 پیوی: {cnt['pv']} | 🚫 خاموش: {cnt['off']}"
    rows.append([{"text": "🌐 همه: هر دو", "callback_data": f"scope_all_both_{bot_id}"},
                 {"text": "👥 همه: گروه", "callback_data": f"scope_all_group_{bot_id}"}])
    rows.append([{"text": "👤 همه: پیوی", "callback_data": f"scope_all_pv_{bot_id}"},
                 {"text": "📂 دامنه قالبها", "callback_data": f"lib_open_{bot_id}"}])
    rows.append([{"text": "⬅️ پنل ربات", "callback_data": f"panel_{bot_id}"}])
    self.edit_or_send(chat_id, msg_id, text, reply_markup=_keyboard(rows))


def show_group_menu(self, chat_id, bot_id, msg_id=None):
    if not _owns(self, chat_id, bot_id):
        return
    vars_rows = self.db.fetchall("SELECT * FROM bot_variables WHERE bot_id=? AND action<>'none'", (bot_id,))
    try:
        conn = sqlite3.connect(self.db.db_path, timeout=30)
        groups = conn.execute("SELECT COUNT(*) c FROM bot_users WHERE bot_id=? AND chat_type IN ('group','supergroup','channel')", (bot_id,)).fetchone()[0]
        conn.close()
    except Exception:
        groups = 0
    text = (f"👮 **مدیریت گروه ربات #{bot_id}**\n\n👥 گروههای شناختهشده: {groups}\n"
            "🛡 قفلها (با دستور در گروه فعال/غیرفعال میشوند):\n")
    rows = []
    for v in vars_rows:
        state = "🟢 فعال" if v["is_active"] else "🔴 خاموش"
        text += f"\n{state} `{v['name']}` ← «{v['command_on'] or '---'}» | مجازات: {v['penalty']}"
        rows.append([{"text": f"{'🔓 خاموش' if v['is_active'] else '🔒 فعال'} {v['label'] or v['name']}",
                      "callback_data": f"grp_lock_{v['id']}_{bot_id}"}])
    rows.append([{"text": "📜 ثبت قوانین گروه", "callback_data": f"grp_rules_{bot_id}"},
                 {"text": "📖 راهنمای متغیرها", "callback_data": f"grp_help_{bot_id}"}])
    rows.append([{"text": "🧩 متغیرها و دستورات", "callback_data": f"vars_menu_{bot_id}"},
                 {"text": "🎛 دامنه دکمهها", "callback_data": f"scope_menu_{bot_id}"}])
    rows.append([{"text": "⬅️ پنل ربات", "callback_data": f"panel_{bot_id}"}])
    self.edit_or_send(chat_id, msg_id, text, reply_markup=_keyboard(rows))


def start_broadcast_new(self, chat_id, bot_id, msg_id=None):
    if not _owns(self, chat_id, bot_id):
        return
    bot = self.db.get_bot(bot_id)
    rows = [
        [{"text": "📝 متن", "callback_data": f"bc_type_text_{bot_id}"},
         {"text": "🖼 عکس", "callback_data": f"bc_type_photo_{bot_id}"}],
        [{"text": "🎥 ویدیو", "callback_data": f"bc_type_video_{bot_id}"},
         {"text": "📄 فایل", "callback_data": f"bc_type_document_{bot_id}"}],
        [{"text": "👥 گیرندگان: همه", "callback_data": f"bc_target_all_{bot_id}"}],
        [{"text": "📊 وضعیت آخرین ارسال", "callback_data": f"bc_status_{bot_id}"},
         {"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}],
    ]
    self.edit_or_send(chat_id, msg_id,
        f"📢 **ارسال همگانی — {bot['bot_name']}**\n\nنوع پیام را انتخاب کن، سپس متن/رسانه را بفرست.\n"
        "بعد از پیشنمایش میتوانی گیرندگان (همه/پیوی/گروه) و دکمه شیشهای را تنظیم کنی.",
        reply_markup=_keyboard(rows))


def bc_recipient_count(self, bot_id, target_scope):
    try:
        conn = sqlite3.connect(self.db.db_path, timeout=30)
        q = "SELECT COUNT(*) c FROM bot_users WHERE bot_id=? AND is_blocked=0"
        params = [bot_id]
        if target_scope == "pv":
            q += " AND (chat_type='private' OR chat_type IS NULL OR chat_type='')"
        elif target_scope == "group":
            q += " AND chat_type IN ('group','supergroup','channel')"
        c = conn.execute(q, params).fetchone()[0]
        conn.close()
        return c
    except Exception:
        return 0


def bc_preview(self, chat_id, data, msg_id=None):
    bot_id = data["bot_id"]
    target = data.get("target_scope", "all")
    total = bc_recipient_count(self, bot_id, target)
    mtype = data.get("message_type", "text")
    content = data.get("content") or ""
    kb_json = data.get("keyboard_json")
    preview = f"📢 **پیشنمایش پیام همگانی**\n\n📦 نوع: {mtype}\n"
    preview += (content[:600] if mtype == "text" else f"[{mtype}] {content[:400]}")
    if data.get("file_id"):
        preview += f"\n🆔 فایل: `{str(data['file_id'])[:30]}...`"
    if kb_json:
        try:
            btn = json.loads(kb_json)["inline_keyboard"][0][0]
            preview += f"\n🔘 دکمه: {btn.get('text')} → {btn.get('url') or btn.get('callback_data')}"
        except Exception:
            pass
    preview += (f"\n\n👥 گیرندگان ({ {'all':'همه','pv':'فقط پیوی','group':'فقط گروه'}.get(target,target) }): **{total} نفر**"
                f"\n⏱ زمان تقریبی: ~{total} ثانیه (1 پیام/ثانیه)")
    rows = [
        [{"text": "✅ تایید و ارسال", "callback_data": f"bc_confirm_{bot_id}"},
         {"text": "❌ انصراف", "callback_data": f"bc_cancel_{bot_id}"}],
        [{"text": "👤 فقط پیوی", "callback_data": f"bc_target_pv_{bot_id}"},
         {"text": "👥 فقط گروه", "callback_data": f"bc_target_group_{bot_id}"},
         {"text": "🌐 همه", "callback_data": f"bc_target_all_{bot_id}"}],
        [{"text": "➕ دکمه شیشهای", "callback_data": f"bc_addbtn_{bot_id}"},
         {"text": "🗑 حذف دکمه", "callback_data": f"bc_delbtn_{bot_id}"}],
    ]
    self.edit_or_send(chat_id, msg_id, preview, reply_markup=_keyboard(rows))


def step_broadcast_content_new(self, chat_id, message, text, data):
    bot_id = data["bot_id"]
    mtype = data.get("message_type", "text")
    file_id = None
    caption = None
    content = MOD["sanitize_text"](text, 4000)
    if message.get("photo"):
        file_id = (message["photo"][-1].get("file_id") if isinstance(message["photo"], list)
                   else message["photo"].get("file_id"))
        caption = message.get("caption") or ""
        content = caption or content
        mtype = "photo"
    elif message.get("video"):
        file_id = (message.get("video") or {}).get("file_id")
        caption, mtype = message.get("caption") or "", "video"
    elif message.get("document"):
        file_id = (message.get("document") or {}).get("file_id")
        caption, mtype = message.get("caption") or "", "document"
    elif message.get("audio"):
        file_id = (message.get("audio") or {}).get("file_id")
        mtype = "audio"
    if not content and not file_id:
        self.send_message(chat_id, "❌ محتوا خالی است. دوباره بفرست:", reply_markup=MOD["cancel_keyboard"]())
        return True
    data.update({"content": content, "file_id": file_id, "caption": caption,
                 "message_type": mtype, "bot_id": bot_id,
                 "target_scope": data.get("target_scope", "all")})
    self.db.set_user_step(chat_id, "await_broadcast_preview", data)
    bc_preview(self, chat_id, data)
    return True


def step_broadcast_button_new(self, chat_id, text, data):
    t = (text or "").strip()
    if t.lower() in ("حذف", "delete", "بدون دکمه", "off"):
        data.pop("keyboard_json", None)
        self.send_message(chat_id, "🗑 دکمه حذف شد.")
    else:
        parts = t.split("|", 1)
        if len(parts) != 2 or not parts[1].strip().startswith(("http://", "https://")):
            self.send_message(chat_id,
                "❌ فرمت اشتباه. مثال:\n`مشاهده سایت|https://ble.ir/channel`\nیا «حذف» برای بدون دکمه.",
                reply_markup=MOD["cancel_keyboard"]())
            return True
        title, url = parts[0].strip()[:60], parts[1].strip()
        data["keyboard_json"] = json.dumps({"inline_keyboard": [[{"text": title, "url": url}]]},
                                           ensure_ascii=False)
    self.db.set_user_step(chat_id, "await_broadcast_preview", data)
    bc_preview(self, chat_id, data)
    return True


def step_broadcast_preview_text(self, chat_id, text, data):
    data["content"] = MOD["sanitize_text"](text, 4000)
    self.db.set_user_step(chat_id, "await_broadcast_preview", data)
    bc_preview(self, chat_id, data)
    return True


def confirm_broadcast_new(self, chat_id, bot_id, msg_id=None):
    step = self.db.get_user_step(chat_id)
    if not step or step["step"] != "await_broadcast_preview":
        self.send_message(chat_id, "❌ اطلاعات ارسال یافت نشد / ارسال قبلاً آغاز شده است.")
        return
    d = step["data"]
    if int(d.get("bot_id") or bot_id) != int(bot_id) or not _owns(self, chat_id, bot_id):
        self.send_message(chat_id, "❌ دسترسی غیرمجاز.")
        return
    target = d.get("target_scope", "all")
    try:
        conn = sqlite3.connect(self.db.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        q = "SELECT chat_id FROM bot_users WHERE bot_id=? AND is_blocked=0"
        if target == "pv":
            q += " AND (chat_type='private' OR chat_type IS NULL OR chat_type='')"
        elif target == "group":
            q += " AND chat_type IN ('group','supergroup','channel')"
        users = conn.execute(q, (bot_id,)).fetchall()
        conn.close()
    except Exception:
        users = []
    if not users:
        self.edit_or_send(chat_id, msg_id, "❌ هیچ گیرندهای برای این دامنه پیدا نشد. ابتدا کاربران ربات /start بزنند.")
        return
    self.db.execute("""INSERT INTO broadcasts
        (bot_id, owner_id, message_type, content, file_id, caption, keyboard_json,
         target_type, target_scope, status, total_count, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (bot_id, chat_id, d.get("message_type", "text"), d.get("content") or "",
         d.get("file_id"), d.get("caption"), d.get("keyboard_json"),
         "all", target, "pending", len(users), datetime.now().isoformat()))
    bc_row = self.db.fetchone("SELECT * FROM broadcasts WHERE bot_id=? ORDER BY id DESC LIMIT 1", (bot_id,))
    bc_id = bc_row["id"]
    with self.db.get_conn() as conn:
        for u in users:
            conn.execute("INSERT OR IGNORE INTO broadcast_queue (broadcast_id, chat_id) VALUES (?,?)",
                         (bc_id, u["chat_id"]))
    started = self.broadcast_manager.start_broadcast(bc_id)
    self.db.set_user_step(chat_id, "await_broadcast_started", {"bot_id": bot_id, "broadcast_id": bc_id})
    rows = [[{"text": "⏹ توقف ارسال", "callback_data": f"bc_stop_{bc_id}"},
             {"text": "📊 وضعیت", "callback_data": f"bc_status_id_{bc_id}"}]]
    self.edit_or_send(chat_id, msg_id,
        f"{'🚀 ارسال همگانی آغاز شد!' if started else '⚠️ ارسال در صف قرار گرفت / قبلاً شروع شده'}\n"
        f"🆔 #{bc_id} | 👥 {len(users)} گیرنده | 🎯 {target}\n⏱ نرخ: ۱ پیام/ثانیه",
        reply_markup=_keyboard(rows))


def step_broadcast_keyboard_new(self, chat_id, text, data):
    """سازگاری با جریان قدیمی: تبدیل به پیشنمایش جدید."""
    if text and text.lower() not in ("بدون دکمه", "حذف"):
        return step_broadcast_button_new(self, chat_id, text, data)
    return bc_preview(self, chat_id, data) or True


# =====================================================================
# 13) حذف کامل ربات
# =====================================================================
def _dir_size(path):
    total = 0
    try:
        for root, dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
    except OSError:
        pass
    return total


def delete_bot_new(self, chat_id, bot_id, msg_id=None):
    bot = self.db.get_bot(bot_id)
    if not bot or (bot["owner_id"] != chat_id and not MOD["is_admin"](chat_id)):
        self.send_message(chat_id, "❌ دسترسی غیرمجاز.")
        return
    freed = 0
    killed = []
    # 1) توقف ارسالهای همگانی
    try:
        self.broadcast_manager.stop_bot_broadcasts(bot_id)
    except Exception:
        pass
    # 2) توقف پروسههای سابپروسس (قالبهای دیپلویشده)
    try:
        procs = self.db.fetchall("SELECT * FROM bot_processes WHERE bot_id=?", (bot_id,))
    except Exception:
        procs = []
    for p in procs:
        pid = p["pid"]
        if not pid:
            continue
        try:
            if os.name == "posix":
                try:
                    os.killpg(int(pid), signal.SIGTERM)
                except (ProcessLookupError, PermissionError, OSError):
                    os.kill(int(pid), signal.SIGTERM)
            else:
                os.kill(int(pid), signal.SIGTERM)
            killed.append(int(pid))
        except Exception:
            pass
    time.sleep(0.4)
    for pid in killed:
        try:
            if os.name == "posix":
                try:
                    os.killpg(pid, signal.SIGKILL)
                except Exception:
                    os.kill(pid, signal.SIGKILL)
            else:
                os.kill(pid, signal.SIGKILL)
        except Exception:
            pass
    # 3) وبهاک و اتصال توکن قطع شود
    try:
        api = MOD["BaleAPI"](MOD["decrypt_token"](bot["token_encrypted"]), base_url=self.base_url)
        api.delete_webhook()
    except Exception:
        pass
    # 4) حذف runtime از حافظه + جلوگیری از ریاستارت
    self.bot_manager.remove_bot(bot_id)
    # 5) پاکسازی فایلهای هاست
    paths = set()
    for p in procs:
        if p["workdir"]:
            paths.add(p["workdir"])
    if bot["workdir"]:
        paths.add(bot["workdir"])
    try:
        import glob
        for d in glob.glob(f"bots/{bot_id}_*") + glob.glob(f"bots/{bot_id}"):
            paths.add(d)
    except Exception:
        pass
    for d in list(paths):
        if d and os.path.exists(d):
            freed += _dir_size(d)
            try:
                shutil.rmtree(d, ignore_errors=True)
            except Exception:
                pass
    # 6) پاکسازی کامل دیتابیس + VACUUM
    removed = self.db.delete_bot(bot_id)
    # 7) تایید نهایی
    still_row = self.db.get_bot(bot_id)
    still_running = self.bot_manager.is_running(bot_id)
    alive_pids = []
    for pid in killed:
        try:
            os.kill(pid, 0)
            alive_pids.append(pid)
        except Exception:
            pass
    ok = (not still_row) and (not still_running) and (not alive_pids)
    txt = (f"{'✅' if ok else '⚠️'} **حذف ربات {bot['bot_name']}**\n\n"
           f"🛑 پروسههای متوقفشده: {len(killed)}\n"
           f"📁 پوشههای پاکشده: {len(paths)} | فضای آزادشده: {freed/1024:.1f} KB\n"
           f"🗄 ردیفهای دیتابیس پاکشده: {sum(v for v in (removed or {}).values() if isinstance(v,int))}\n"
           f"🔌 وبهاک حذف شد | 📢 همگانیها متوقف شدند\n"
           f"🔍 بررسی نهایی: ردیف {'❌ باقی' if still_row else '✅ پاک'} | "
           f"runtime {'❌ فعال' if still_running else '✅ متوقف'} | "
           f"پروسه {'❌ زنده' if alive_pids else '✅ مرده'}")
    self.edit_or_send(chat_id, msg_id, txt)
    self.send_main_menu(chat_id, "🗑 ربات بهطور کامل از سرور پاک شد و فضا آزاد گردید.")


# =====================================================================
# 14) منوها، FSM و روتینگ Callback
# =====================================================================
def main_reply_keyboard_new(is_admin=False):
    kb = [
        [{"text": "🤖 ساخت ربات"}, {"text": "⚙️ رباتهای من"}],
        [{"text": "🎛 مدیریت رباتها"}, {"text": "👥 زیرمجموعهگیری"}],
        [{"text": "📂 کتابخانه قالبها"}, {"text": "🧩 متغیرها و دستورات"}],
        [{"text": "👮 مدیریت گروه"}, {"text": "🎛 دامنه دکمهها"}],
        [{"text": "💎 اشتراک و تمدید"}, {"text": "💳 شارژ کیف پول"}],
        [{"text": "📊 آمار من"}, {"text": "💬 پشتیبانی"}],
        [{"text": "📚 راهنمای استفاده"}, {"text": "⚙️ تنظیمات"}],
    ]
    if is_admin:
        kb.append([{"text": "🛠 پنل ادمین"}])
    return {"keyboard": kb, "resize_keyboard": True, "is_persistent": True}


def bot_panel_keyboard_new(bot_id):
    kb = MOD["_orig_bot_panel_keyboard"](bot_id)
    rows = kb["inline_keyboard"]
    rows.append([{"text": "📂 کتابخانه قالبها", "callback_data": f"lib_open_{bot_id}"},
                 {"text": "🧩 متغیرها و دستورات", "callback_data": f"vars_menu_{bot_id}"}])
    rows.append([{"text": "👮 مدیریت گروه", "callback_data": f"grp_menu_{bot_id}"},
                 {"text": "🎛 دامنه دکمهها", "callback_data": f"scope_menu_{bot_id}"}])
    return kb


def buttons_menu_keyboard_new(bot_id):
    kb = MOD["_orig_buttons_menu_keyboard"](bot_id)
    kb["inline_keyboard"].insert(2, [{"text": "🎛 دامنه دکمهها (گروه/پیوی)", "callback_data": f"scope_menu_{bot_id}"}])
    return kb


def builder_handle_message(self, message):
    """FSM قبل از کلمات کلیدی (رفع باگ: متن همگانی «شارژ» مسیر کیف پول نمیرفت)."""
    chat_id = (message.get("chat") or {}).get("id")
    from_user = message.get("from") or {}
    text = message.get("text") or message.get("caption") or ""
    if not chat_id:
        return
    invited_by = None
    if text.startswith("/start"):
        parts = text.split()
        if len(parts) > 1 and parts[1].startswith("ref_"):
            try:
                invited_by = int(parts[1].replace("ref_", ""))
                if invited_by == chat_id:
                    invited_by = None
            except Exception:
                pass
    self.db.upsert_user(chat_id, from_user.get("username"), from_user.get("first_name"),
                        from_user.get("last_name"), invited_by)
    if text == "❌ انصراف":
        self.db.clear_user_step(chat_id)
        self.send_main_menu(chat_id, "❌ عملیات لغو شد.")
        return
    # === FSM در اولویت ===
    step_info = self.db.get_user_step(chat_id)
    if step_info and self.handle_step(chat_id, message, text, step_info):
        return
    t_lower = text.strip().lower().replace(" ", "").replace("\u200c", "")
    t = text.strip()
    if t.startswith("/start"):
        return self.cmd_start(chat_id, from_user)
    if t_lower in ["link", "لینک", "لينك", "ref", "رفرال", "لینکمن", "لینکدعوت"]:
        return self.send_referral_link(chat_id)
    if t_lower in ["متغیرها", "variables", "var", "متغیر", "vars"]:
        return self.send_message(chat_id, GROUP_VARIABLES_GUIDE)
    if "لینک دعوت" in t or "لینک رفرال" in t:
        return self.send_referral_link(chat_id)
    t_nospace = t_lower
    if any(k in t_nospace for k in ["خرید", "شارژ", "کیفپول", "buy", "wallet", "charge"]) or t in ["💳", "💰"]:
        return self.cmd_wallet(chat_id)
    if "ساخت ربات" in t:
        return self.cmd_create_bot(chat_id)
    if "رباتهای من" in t or "ربات های من" in t or "رباتهایمن" in t_nospace:
        return self.cmd_my_bots(chat_id)
    if "مدیریت ربات" in t:
        return self.cmd_manage_bots(chat_id)
    if "زیرمجموعه" in t:
        return self.cmd_referral(chat_id)
    if "اشتراک" in t or "تمدید" in t:
        return self.cmd_subscription(chat_id)
    if "آمار من" in t:
        return self.cmd_my_stats(chat_id)
    if "کتابخانه قالب" in t or "قالبهای آماده" in t or "قالب آماده" in t or t == "قالبها":
        return cmd_library(self, chat_id)
    if "متغیرها و دستورات" in t or "متغیر و دستور" in t:
        return cmd_pick_bot(self, chat_id, "var")
    if "مدیریت گروه" in t and "ربات" not in t:
        return cmd_pick_bot(self, chat_id, "grp")
    if "دامنه دکمه" in t:
        return cmd_pick_bot(self, chat_id, "scope")
    if "راهنما" in t:
        return self.cmd_help(chat_id)
    if "پشتیبانی" in t:
        return self.cmd_support(chat_id)
    if "تنظیمات" in t and "ربات" not in t:
        return self.cmd_settings(chat_id)
    if "قالب" in t and "آماده" in t:
        return self.cmd_templates(chat_id)
    if "پنل ادمین" in t or "مدیریت کل" in t:
        return self.cmd_admin(chat_id)
    if len(t) > 1 and not t.startswith("/"):
        return self.send_message(chat_id, f"متوجه نشدم: \"{t}\"\n\nاز منوی زیر استفاده کن 👇",
                                 reply_markup=MOD["main_reply_keyboard"](is_admin=MOD["is_admin"](chat_id)))
    return self.send_main_menu(chat_id)


def dispatch_new_callback(self, chat_id, data, msg_id, from_user):
    """روتینگ امن تمام callbackهای جدید/خراب — قبل از زنجیره قدیمی اجرا میشود."""
    try:
        # ---------- کتابخانه قالبها ----------
        if data.startswith("libbot_"):
            bid = int(data.split("_")[1])
            return cmd_library(self, chat_id, bid or None, msg_id) or True
        if data == "lib_create_0" or data.startswith("lib_create_"):
            page = int(data.split("_")[-1]) if data.split("_")[-1].isdigit() else 0
            return show_library_categories(self, chat_id, 0, msg_id) or True
        if data.startswith("lib_open_"):
            bid = int(data.split("_")[2])
            return show_library_categories(self, chat_id, bid, msg_id) or True
        if data.startswith("lib_cat_"):
            rest = _tail(data, "lib_cat_")
            m = re.match(r"^(\w+)_(\d+)_(\d+)$", rest)
            if m:
                return show_library_category(self, chat_id, m.group(1), int(m.group(2)), int(m.group(3)), msg_id) or True
        if data.startswith("lib_view_"):
            rest = _tail(data, "lib_view_")
            key, bid = rest.rsplit("_", 1)
            return show_library_template(self, chat_id, key, int(bid), msg_id) or True
        if data.startswith("lib_attach_"):
            rest = _tail(data, "lib_attach_")
            key, bid = rest.rsplit("_", 1)
            return attach_template(self, chat_id, int(bid), key, msg_id=msg_id) or True
        if data.startswith("lib_remove_"):
            rest = _tail(data, "lib_remove_")
            key, bid = rest.rsplit("_", 1)
            return detach_template(self, chat_id, int(bid), key, msg_id) or True
        if data.startswith("lib_scope_"):
            rest = _tail(data, "lib_scope_")
            m = re.match(r"^(.+)_(\d+)_(both|group|pv|off)$", rest)
            if m:
                return set_template_scope(self, chat_id, int(m.group(2)), m.group(1), m.group(3), msg_id) or True
        if data.startswith("lib_active_"):
            rest = _tail(data, "lib_active_")
            m = re.match(r"^(.+)_(\d+)_(group|pv)$", rest)
            if m:
                return set_active_template(self, chat_id, int(m.group(2)), m.group(1), m.group(3), msg_id) or True
        if data.startswith("lib_custom_"):
            rest = _tail(data, "lib_custom_")
            key, bid = rest.rsplit("_", 1)
            t = get_template(key)
            self.db.set_user_step(chat_id, "await_library_custom", {"bot_id": int(bid), "key": key})
            btns = "\n".join([f"{i+1}. {b['title']}" for i, b in enumerate((t or {}).get("buttons", []))])
            self.send_message(chat_id,
                f"✏️ **شخصیسازی قالب {t['name'] if t else key}**\n\n"
                "• برای تغییر **پیام شروع**: متن جدید را بفرست (متغیرها کار میکنند)\n"
                "• برای تغییر **متن یک دکمه**: `دکمه|شماره|متن جدید`\n"
                "• برای تغییر **عنوان دکمه**: `عنوان|شماره|عنوان جدید`\n"
                "• «پیشفرض» = برگشت به حالت اولیه\n\n" + (btns or "بدون دکمه"),
                reply_markup=MOD["cancel_keyboard"]())
            return True
        if data in ("tmpl_create", "tpl_create"):
            self.db.set_user_step(chat_id, "await_token_ready")
            self.send_message(chat_id, "🎁 توکن ربات را بفرست تا از کتابخانه قالبها انتخاب کنی:",
                              reply_markup=MOD["cancel_keyboard"]())
            return True
        if data.startswith("use_template_"):
            return use_template_new(self, chat_id, _tail(data, "use_template_"), msg_id)

        # ---------- متغیرها و دستورات ----------
        if data.startswith("varbot_"):
            return show_vars_menu(self, chat_id, int(data.split("_")[1]), msg_id) or True
        if data.startswith("vars_menu_"):
            return show_vars_menu(self, chat_id, int(data.split("_")[2]), msg_id) or True
        if data.startswith("vars_") and data.split("_")[-1].isdigit():
            return self.send_message(chat_id, GROUP_VARIABLES_GUIDE) or True
        if data.startswith("var_help_"):
            return self.send_message(chat_id, GROUP_VARIABLES_GUIDE) or True
        if data.startswith("var_add_"):
            bid = int(data.split("_")[2])
            self.db.set_user_step(chat_id, "await_var_name", {"bot_id": bid})
            self.send_message(chat_id,
                "🧩 **متغیر جدید**\n\nنام متغیر را بفرست (لاتین/فارسی، بدون فاصله):\n"
                "مثال: `zadlink` یا `قفل_لینک`\n\nسپس دستور فعالسازیاش را میگیری 👇",
                reply_markup=MOD["cancel_keyboard"]())
            return True
        if data.startswith("var_preset_"):
            rest = _tail(data, "var_preset_")
            preset, bid = rest.rsplit("_", 1)
            bid = int(bid)
            if not _owns(self, chat_id, bid):
                return True
            n = 0
            for p in CUSTOM_VARIABLE_PRESETS:
                if preset in ("all", p["name"], p["action"]):
                    try:
                        self.db.execute("""INSERT OR IGNORE INTO bot_variables
                            (bot_id,name,label,kind,value_on,value_off,is_active,command_on,command_off,
                             scope,admin_only,action,penalty,description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (bid, p["name"], p["label"], "toggle", "فعال ✅", "غیرفعال ❌", 0,
                             p["command_on"], p["command_off"], p["scope"], 1, p["action"], p["penalty"], p["description"]))
                        n += 1
                    except Exception:
                        pass
            return show_vars_menu(self, chat_id, bid, msg_id) or True
        if data.startswith("var_toggle_"):
            m = re.match(r"^var_toggle_(\d+)_(\d+)$", data)
            if m and _owns(self, chat_id, int(m.group(2))):
                bid, vid = int(m.group(2)), int(m.group(1))
                self.db.execute("UPDATE bot_variables SET is_active=1-is_active WHERE id=? AND bot_id=?", (vid, bid))
                self.db.execute("DELETE FROM bot_variable_state WHERE bot_id=? AND name=(SELECT name FROM bot_variables WHERE id=?)", (bid, vid))
                return show_vars_menu(self, chat_id, bid, msg_id) or True
        if data.startswith("var_cmd_"):
            m = re.match(r"^var_cmd_(\d+)_(\d+)$", data)
            if m:
                self.db.set_user_step(chat_id, "await_var_commands",
                                      {"bot_id": int(m.group(2)), "var_id": int(m.group(1))})
                self.send_message(chat_id,
                    "⌨️ **اتصال دستور به متغیر**\n\nدو دستور با `|` جدا کن:\n"
                    "`دستور فعال|دستور غیرفعال`\n\nمثال: `قفل لینک|بازکردن لینک`\n"
                    "یا فقط یک دستور بفرست (همان روشن/خاموش میکند).",
                    reply_markup=MOD["cancel_keyboard"]())
                return True
        if data.startswith("var_scopemenu_"):
            m = re.match(r"^var_scopemenu_(\d+)_(\d+)$", data)
            if m:
                return show_var_scope_menu(self, chat_id, int(m.group(1)), int(m.group(2)), msg_id) or True
        if data.startswith("var_scope_"):
            m = re.match(r"^var_scope_(\d+)_(\d+)_(both|group|pv)$", data)
            if not m:
                return show_var_scope_menu(self, chat_id, int(data.split("_")[2]), int(data.split("_")[3]), msg_id) or True
            if m and _owns(self, chat_id, int(m.group(2))):
                self.db.execute("UPDATE bot_variables SET scope=? WHERE id=? AND bot_id=?",
                                (m.group(3), int(m.group(1)), int(m.group(2))))
                return show_vars_menu(self, chat_id, int(m.group(2)), msg_id) or True
        if data.startswith("var_del_"):
            m = re.match(r"^var_del_(\d+)_(\d+)$", data)
            if m and _owns(self, chat_id, int(m.group(2))):
                self.db.execute("DELETE FROM bot_variables WHERE id=? AND bot_id=?", (int(m.group(1)), int(m.group(2))))
                self.db.execute("DELETE FROM bot_variable_state WHERE bot_id=? AND name=(SELECT name FROM bot_variables WHERE id=?)",
                                (int(m.group(2)), int(m.group(1))))
                return show_vars_menu(self, chat_id, int(m.group(2)), msg_id) or True
        if data.startswith("var_test_"):
            m = re.match(r"^var_test_(\d+)_(\d+)$", data)
            if m:
                v = self.db.fetchone("SELECT * FROM bot_variables WHERE id=?", (int(m.group(1)),))
                if v:
                    self.send_message(chat_id,
                        f"🧪 متغیر `{v['name']}`\nمقدار فعال: {v['value_on']}\nمقدار غیرفعال: {v['value_off']}\n\n"
                        f"در متن دکمهها از `{{ {v['name']} }}` یا `{v['name'].upper()}` استفاده کن.\n"
                        f"دستور فعالسازی: «{v['command_on']}»")
                return True

        # ---------- دامنه دکمهها ----------
        if data.startswith("scopebot_"):
            return show_scope_menu(self, chat_id, int(data.split("_")[1]), msg_id) or True
        if data.startswith("scope_menu_"):
            return show_scope_menu(self, chat_id, int(data.split("_")[2]), msg_id) or True
        if data.startswith("scope_btn_"):
            m = re.match(r"^scope_btn_(\d+)_(\d+)$", data)
            if m and _owns(self, chat_id, int(m.group(2))):
                b = self.db.fetchone("SELECT scope FROM bot_buttons WHERE id=?", (int(m.group(1)),))
                cycle = {"both": "group", "group": "pv", "pv": "off", "off": "both"}
                new = cycle.get((b["scope"] or "both").lower(), "both")
                self.db.execute("UPDATE bot_buttons SET scope=? WHERE id=?", (new, int(m.group(1))))
                return show_scope_menu(self, chat_id, int(m.group(2)), msg_id) or True
        if data.startswith("scope_all_"):
            m = re.match(r"^scope_all_(both|group|pv|off)_(\d+)$", data)
            if m and _owns(self, chat_id, int(m.group(2))):
                self.db.execute("UPDATE bot_buttons SET scope=? WHERE bot_id=?", (m.group(1), int(m.group(2))))
                return show_scope_menu(self, chat_id, int(m.group(2)), msg_id) or True
        if data.startswith("scope_tpl_"):
            m = re.match(r"^scope_tpl_(.+)_(\d+)_(both|group|pv|off)$", data)
            if m:
                return set_template_scope(self, chat_id, int(m.group(2)), m.group(1), m.group(3), msg_id) or True

        # ---------- مدیریت گروه ----------
        if data.startswith("grpbot_"):
            return show_group_menu(self, chat_id, int(data.split("_")[1]), msg_id) or True
        if data.startswith("grp_menu_"):
            return show_group_menu(self, chat_id, int(data.split("_")[2]), msg_id) or True
        if data.startswith("grp_help_"):
            return self.send_message(chat_id, GROUP_VARIABLES_GUIDE) or True
        if data.startswith("grp_lock_"):
            m = re.match(r"^grp_lock_(\d+)_(\d+)$", data)
            if m and _owns(self, chat_id, int(m.group(2))):
                bid, vid = int(m.group(2)), int(m.group(1))
                self.db.execute("UPDATE bot_variables SET is_active=1-is_active WHERE id=? AND bot_id=?", (vid, bid))
                self.db.execute("DELETE FROM bot_variable_state WHERE bot_id=? AND name=(SELECT name FROM bot_variables WHERE id=?)", (bid, vid))
                return show_group_menu(self, chat_id, bid, msg_id) or True
        if data.startswith("grp_rules_"):
            bid = int(data.split("_")[2])
            self.db.set_user_step(chat_id, "await_group_rules", {"bot_id": bid})
            self.send_message(chat_id, "📜 متن **قوانین گروه** را بفرست (با متغیر `RULES` قابل نمایش است):",
                              reply_markup=MOD["cancel_keyboard"]())
            return True
        if data.startswith("grp_stats_"):
            bid = int(data.split("_")[2])
            try:
                conn = sqlite3.connect(self.db.db_path, timeout=30)
                groups = conn.execute("SELECT COUNT(*) FROM bot_users WHERE bot_id=? AND chat_type IN ('group','supergroup','channel')", (bid,)).fetchone()[0]
                users = conn.execute("SELECT COUNT(*) FROM bot_users WHERE bot_id=?", (bid,)).fetchone()[0]
                conn.close()
            except Exception:
                groups = users = 0
            return self.edit_or_send(chat_id, msg_id,
                f"📊 **آمار گروههای ربات #{bid}**\n👥 گروهها: {groups}\n👤 کل کاربران: {users}\n\n"
                "متغیرهای `GROUPMEMBERS`, `GROUPADMINS`, `ISADMIN`, `RULES` در پیامها قابل استفادهاند.",
                reply_markup=_keyboard([[{"text": "⬅️ بازگشت", "callback_data": f"grp_menu_{bid}"}]])) or True

        # ---------- ارسال همگانی ----------
        if data.startswith("bc_target_"):
            m = re.match(r"^bc_target_(all|pv|group)_(\d+)$", data)
            if m:
                step = self.db.get_user_step(chat_id)
                if step and step["step"] == "await_broadcast_preview":
                    d = step["data"]
                    d["target_scope"] = m.group(1)
                    self.db.set_user_step(chat_id, "await_broadcast_preview", d)
                    return bc_preview(self, chat_id, d, msg_id) or True
        if data.startswith("bc_addbtn_"):
            bid = int(data.split("_")[2])
            step = self.db.get_user_step(chat_id)
            if step and step["step"] == "await_broadcast_preview":
                self.db.set_user_step(chat_id, "await_broadcast_button", step["data"])
                self.send_message(chat_id,
                    "🔘 **دکمه شیشهای همگانی**\n\nفرمت: `عنوان|لینک`\nمثال: `مشاهده کانال|https://ble.ir/channel`\n"
                    "یا «حذف» برای بدون دکمه.", reply_markup=MOD["cancel_keyboard"]())
            return True
        if data.startswith("bc_delbtn_"):
            step = self.db.get_user_step(chat_id)
            if step and step["step"] == "await_broadcast_preview":
                d = step["data"]
                d.pop("keyboard_json", None)
                self.db.set_user_step(chat_id, "await_broadcast_preview", d)
                return bc_preview(self, chat_id, d, msg_id) or True
        if data.startswith("bc_confirm_"):
            return confirm_broadcast_new(self, chat_id, int(data.split("_")[2]), msg_id) or True
        if data.startswith("bc_status_id_"):
            bc_id = int(data.split("_")[3])
            st = self.broadcast_manager.status(bc_id)
            if st:
                return self.edit_or_send(chat_id, msg_id,
                    f"📊 **همگانی #{bc_id}**\nوضعیت: {st['status']}\n"
                    f"✅ ارسال: {st['sent_count']} | ❌ خطا: {st['failed_count']} | 👥 کل: {st['total_count']}",
                    reply_markup=_keyboard([[{"text": "⏹ توقف", "callback_data": f"bc_stop_{bc_id}"}]])) or True
        if data.startswith("bc_status_"):
            bid = int(data.split("_")[2])
            row = self.db.fetchone("SELECT * FROM broadcasts WHERE bot_id=? ORDER BY id DESC LIMIT 1", (bid,))
            if row:
                return self.edit_or_send(chat_id, msg_id,
                    f"📊 آخرین همگانی #{row['id']}: {row['status']} | ✅ {row['sent_count']} / ❌ {row['failed_count']} / 👥 {row['total_count']}") or True
        if data.startswith("bc_stop_"):
            bc_id = int(data.split("_")[2])
            self.broadcast_manager.stop_broadcast(bc_id)
            return self.edit_or_send(chat_id, msg_id, f"⏹ ارسال همگانی #{bc_id} متوقف شد.") or True

        # ---------- رفع callbackهای قدیمی که قبل از catch-all گم میشدند ----------
        if data.startswith("btn_del_"):
            return self.show_button_list(chat_id, int(data.split("_")[2]), msg_id, delete_mode=True) or True
        if data.startswith("btn_reorder_"):
            return self.show_button_list(chat_id, int(data.split("_")[2]), msg_id, edit_mode=True) or True
    except Exception as e:
        logger.exception("dispatch callback %s: %s", data, e)
        try:
            self.send_message(chat_id, f"❌ خطا در پردازش دکمه: {e}")
        except Exception:
            pass
        return True
    return False


def builder_handle_callback(self, query):
    qid = query.get("id")
    data = query.get("data", "") or ""
    from_user = query.get("from") or {}
    message = query.get("message") or {}
    chat_id = (message.get("chat") or {}).get("id") or from_user.get("id")
    msg_id = message.get("message_id")
    try:
        self.api.answer_callback_query(qid)
    except Exception:
        pass
    if not chat_id or not data:
        return
    if dispatch_new_callback(self, chat_id, data, msg_id, from_user):
        return
    return MOD["_orig_builder_callback"](self, query)


NEW_STEPS = {
    "await_broadcast_preview": lambda s, c, m, t, d: step_broadcast_preview_text(s, c, t, d["data"]),
    "await_broadcast_button": lambda s, c, m, t, d: step_broadcast_button_new(s, c, t, d["data"]),
    "await_broadcast_started": lambda s, c, m, t, d: (s.db.clear_user_step(c), False)[1],
    "await_var_name": lambda s, c, m, t, d: step_var_name(s, c, t, d["data"]),
    "await_var_commands": lambda s, c, m, t, d: step_var_commands(s, c, t, d["data"]),
    "await_library_custom": lambda s, c, m, t, d: step_library_custom(s, c, t, d["data"]),
    "await_group_rules": lambda s, c, m, t, d: step_group_rules(s, c, t, d["data"]),
}


def builder_handle_step(self, chat_id, message, text, step_info):
    step = step_info["step"]
    if step in NEW_STEPS:
        return NEW_STEPS[step](self, chat_id, message, text, step_info)
    return MOD["_orig_builder_handle_step"](self, chat_id, message, text, step_info)


def step_var_name(self, chat_id, text, data):
    name = (text or "").strip()
    if not _safe_name(name):
        self.send_message(chat_id, "❌ نام نامعتبر. فقط حروف/عدد/_ (۲ تا ۳۲ کاراکتر، بدون فاصله):",
                          reply_markup=MOD["cancel_keyboard"]())
        return True
    bot_id = data["bot_id"]
    if not _owns(self, chat_id, bot_id):
        return True
    try:
        self.db.execute("""INSERT INTO bot_variables
            (bot_id,name,label,kind,value_on,value_off,is_active,command_on,command_off,scope,admin_only,action,penalty,description)
            VALUES (?,?,?,?,?,?,0,'','','both',1,'none','delete','متغیر سفارشی')""",
            (bot_id, name, name, "toggle", "فعال ✅", "غیرفعال ❌"))
    except Exception:
        self.send_message(chat_id, "⚠️ متغیری با این نام وجود دارد. نام دیگری بفرست:")
        return True
    row = self.db.fetchone("SELECT * FROM bot_variables WHERE bot_id=? AND name=?", (bot_id, name))
    self.db.set_user_step(chat_id, "await_var_commands", {"bot_id": bot_id, "var_id": row["id"]})
    self.send_message(chat_id,
        f"✅ متغیر `{name}` ساخته شد.\n\n⌨️ حالا **دستور فعالسازی** را بفرست:\n"
        "`دستور روشن|دستور خاموش`\nمثال: `قفل لینک|بازکردن لینک`\n\n"
        "همچنین میتوانی از پنل متغیرها `action` (قفل لینک و ...) و دامنهاش را تنظیم کنی.",
        reply_markup=MOD["cancel_keyboard"]())
    return True


def step_var_commands(self, chat_id, text, data):
    bot_id, var_id = data["bot_id"], data["var_id"]
    if not _owns(self, chat_id, bot_id):
        return True
    parts = [p.strip() for p in (text or "").split("|")]
    on = parts[0] if parts else ""
    off = parts[1] if len(parts) > 1 else on
    if not on:
        self.send_message(chat_id, "❌ دستور نمیتواند خالی باشد.", reply_markup=MOD["cancel_keyboard"]())
        return True
    self.db.execute("UPDATE bot_variables SET command_on=?, command_off=?, admin_only=1 WHERE id=? AND bot_id=?",
                    (on, off, var_id, bot_id))
    v = self.db.fetchone("SELECT * FROM bot_variables WHERE id=?", (var_id,))
    self.db.clear_user_step(chat_id)
    self.send_message(chat_id,
        f"✅ اتصال انجام شد:\n\n🧩 متغیر: `{v['name']}`\n"
        f"▶️ «{on}» → `{v['name']}` = {v['value_on']}\n"
        f"⏹ «{off}» → `{v['name']}` = {v['value_off']}\n\n"
        f"در پیامها از `{{{v['name']}}}` یا `{v['name'].upper()}` استفاده کن.\n"
        "💡 برای تبدیل به قفل واقعی (مثل ضد لینک) از «🧩 متغیرها و دستورات → ⚡ پریستها» استفاده کن.")
    return True


def step_library_custom(self, chat_id, text, data):
    bot_id, key = data["bot_id"], data["key"]
    if not _owns(self, chat_id, bot_id):
        return True
    t = get_template(key)
    if (text or "").strip() == "پیشفرض":
        attach_template(self, chat_id, bot_id, key, silent=True)
        self.send_message(chat_id, "✅ قالب به حالت پیشفرض برگشت.")
        return True
    m = re.match(r"^(دکمه|عنوان)\|(\d+)\|(.+)$", (text or "").strip(), re.S)
    if m:
        kind, idx, val = m.group(1), int(m.group(2)) - 1, m.group(3).strip()
        rows = self.db.fetchall("SELECT id FROM bot_buttons WHERE bot_id=? AND template_key=? ORDER BY position", (bot_id, key))
        if 0 <= idx < len(rows):
            col = "content_text" if kind == "دکمه" else "title"
            self.db.execute(f"UPDATE bot_buttons SET {col}=? WHERE id=?", (val[:4000], rows[idx]["id"]))
            with self.db.get_conn() as conn:
                conn.execute("UPDATE bot_templates SET custom_json=? WHERE bot_id=? AND template_key=?",
                             (json.dumps({"customized": True}, ensure_ascii=False), bot_id, key))
            self.send_message(chat_id, f"✅ {kind} شماره {idx+1} تغییر کرد.")
        else:
            self.send_message(chat_id, "❌ شماره دکمه نامعتبر است.")
        return True
    _settings_ensure(self, bot_id)
    self.db.execute("UPDATE bot_settings SET start_message=? WHERE bot_id=?", ((text or "")[:4000], bot_id))
    self.db.clear_user_step(chat_id)
    self.send_message(chat_id, "✅ پیام شروع قالب شخصیسازی شد (متغیرها همچنان کار میکنند).")
    return True


def step_group_rules(self, chat_id, text, data):
    bot_id = data["bot_id"]
    if not _owns(self, chat_id, bot_id):
        return True
    _settings_ensure(self, bot_id)
    row = self.db.fetchone("SELECT group_config FROM bot_settings WHERE bot_id=?", (bot_id,))
    cfg = {}
    if row and row["group_config"]:
        try:
            cfg = json.loads(row["group_config"])
        except Exception:
            pass
    cfg["rules"] = (text or "")[:4000]
    self.db.execute("UPDATE bot_settings SET group_config=? WHERE bot_id=?",
                    (json.dumps(cfg, ensure_ascii=False), bot_id))
    self.db.clear_user_step(chat_id)
    self.send_message(chat_id, "✅ قوانین گروه ذخیره شد. با متغیر `RULES` در هر پیامی نمایش بده.")
    return True


def show_button_list_new(self, chat_id, bot_id, msg_id=None, edit_mode=False, delete_mode=False):
    buttons = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=? ORDER BY row, position", (bot_id,))
    if not buttons:
        return self.edit_or_send(chat_id, msg_id, "📭 هیچ دکمهای یافت نشد. ابتدا دکمه اضافه کنید ➕",
                                 reply_markup=MOD["buttons_menu_keyboard"](bot_id))
    text = f"📋 **لیست دکمهها ({len(buttons)} عدد)**\n\n"
    rows = []
    for b in buttons:
        btype = "🔘" if b["button_type"] == "inline" else "⌨️"
        sc = _scope_label((b["scope"] or "both").lower())
        text += f"{btype} **{b['title']}** | {b['action_type']} | سطر {b['row']} | {sc}\n"
        prefix = "🗑" if delete_mode else "✏️"
        cb = f"delbtn_{b['id']}" if delete_mode else f"editbtn_{b['id']}"
        rows.append([{"text": f"{prefix} {b['title'][:30]}", "callback_data": cb},
                     {"text": sc, "callback_data": f"scope_btn_{b['id']}_{bot_id}"}])
    rows.append([{"text": "🎛 دامنه دکمهها", "callback_data": f"scope_menu_{bot_id}"},
                 {"text": "⬅️ بازگشت", "callback_data": f"buttons_{bot_id}"}])
    return self.edit_or_send(chat_id, msg_id, text, reply_markup=_keyboard(rows))


def start_edit_button_new(self, chat_id, btn_id, msg_id):
    btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
    if not btn:
        return
    kb = MOD["_orig_start_edit_button_keyboard"](btn, btn_id)
    kb["inline_keyboard"].insert(-1, [{"text": f"🎛 دامنه: {_scope_label((btn['scope'] or 'both').lower())}",
                                      "callback_data": f"scope_btn_{btn_id}_{btn['bot_id']}"}])
    hidden = "🔴 مخفی" if btn["is_hidden"] else "🟢 فعال"
    locked = f"🔒 قفل: {btn['lock_type'] or 'بدون'}" if btn["is_locked"] else "🔓 بدون قفل"
    text = (f"🔘 **مدیریت دکمه**\n\n📛 نام: {btn['title']}\n🔘 نوع: {btn['button_type']} | سطر {btn['row']}\n"
            f"🌐 دامنه: {_scope_label((btn['scope'] or 'both').lower())}\n"
            f"📄 مطلب: {(btn['content_text'] or '---')[:60]}\n⚙️ دستور: {btn['command'] or 'ندارد'}\n{hidden} | {locked}")
    return self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)


def start_edit_button_keyboard_orig(btn, btn_id):
    bot_id = btn["bot_id"]
    return {"inline_keyboard": [
        [{"text": "📤 ارسال مطلب", "callback_data": f"btn_sendcont_{btn_id}"}, {"text": "🗑 حذف مطلب", "callback_data": f"btn_delcont_{btn_id}"}],
        [{"text": "🔄 نوع ارسال", "callback_data": f"btn_sendtype_{btn_id}"}, {"text": "🧹 حذف همه مطالب", "callback_data": f"btn_delall_{btn_id}"}],
        [{"text": "✏️ تغییر نام دکمه", "callback_data": f"btn_rename_{btn_id}"}, {"text": "🗑 حذف دکمه", "callback_data": f"delbtn_{btn_id}"}],
        [{"text": "🔗 لینک دکمه", "callback_data": f"btn_link_{btn_id}"}, {"text": "↔️ انتقال دکمه", "callback_data": f"btn_move_{btn_id}"}],
        [{"text": "⚙️ تنظیم دستور", "callback_data": f"btn_cmd_{btn_id}"}, {"text": "🔒 قفل دکمه", "callback_data": f"btn_lock_{btn_id}"}],
        [{"text": "👁 مخفی/نمایش", "callback_data": f"btn_hide_{btn_id}"}, {"text": "📜 متغیرها", "callback_data": f"btn_vars_{btn_id}"}],
        [{"text": "⬅️ بازگشت", "callback_data": f"btn_list_{bot_id}"}],
    ]}


# =====================================================================
# 15) نصب الحاقات روی main.py
# =====================================================================
def install_extensions(globs):
    MOD.update(globs)
    # کتابخانه + ادغام با قالبهای فولسورس
    ALL_TEMPLATES.clear()
    for k, v in globs["TEMPLATES"].items():
        t = dict(v)
        t["key"] = k
        t.setdefault("scope", "both")
        t.setdefault("start_message", globs.get("DEFAULT_START_MESSAGE", ""))
        t.setdefault("kind", "python_single")
        ALL_TEMPLATES[k] = t
    ALL_TEMPLATES.update(TEMPLATE_LIBRARY)
    globs["ALL_TEMPLATES"] = ALL_TEMPLATES
    globs["TEMPLATE_LIBRARY"] = TEMPLATE_LIBRARY
    globs["render_variables"] = render_variables
    globs["normalize_command"] = normalize_command
    globs["GROUP_VARIABLES_GUIDE"] = GROUP_VARIABLES_GUIDE

    # --- BaleAPI
    api = globs["BaleAPI"]
    api._request = _api_request
    api.get_updates = _api_get_updates
    api.send_message = _api_send_message
    _install_group_methods(api)
    # حفظ متدهای قدیمی با نام درست
    api.unban_chat_member = api.unban_chat_member
    api.unpin_chat_message = api.unpin_chat_message

    # --- کیبوردها / منوها
    MOD["_orig_bot_panel_keyboard"] = globs["bot_panel_keyboard"]
    MOD["_orig_buttons_menu_keyboard"] = globs["buttons_menu_keyboard"]
    MOD["_orig_start_edit_button_keyboard"] = start_edit_button_keyboard_orig
    globs["build_user_bot_keyboard"] = build_user_bot_keyboard
    globs["main_reply_keyboard"] = main_reply_keyboard_new
    globs["bot_panel_keyboard"] = bot_panel_keyboard_new
    globs["buttons_menu_keyboard"] = buttons_menu_keyboard_new

    # --- Database
    db = globs["Database"]
    MOD["_orig_init_db"] = db.init_db
    db.init_db = _init_db_patched
    db.purge_bot = db_purge_bot
    db.delete_bot = db_delete_bot
    db.seed_variables = db_seed_variables
    db.get_var = db_get_var
    db.get_var_state = db_get_var_state
    db.set_var_state = db_set_var_state
    db.record_process = db_record_process

    # --- UserBotRuntime
    rt = globs["UserBotRuntime"]
    MOD["_orig_runtime_start"] = rt.start
    MOD["_orig_runtime_callback"] = rt.handle_callback
    rt.runtime_group_info = runtime_group_info
    rt.runtime_is_group_admin = runtime_is_group_admin
    rt.runtime_get_var_state = runtime_get_var_state
    rt.runtime_set_var_state = runtime_set_var_state
    rt.runtime_all_variables = runtime_all_variables
    rt._get_all_variables = runtime_all_variables
    rt.runtime_render = runtime_render
    rt.runtime_active_templates = runtime_active_templates
    rt.runtime_track_chat = runtime_track_chat
    rt.runtime_handle_custom_commands = runtime_handle_custom_commands
    rt.runtime_apply_warn = runtime_apply_warn
    rt.runtime_enforce_locks = runtime_enforce_locks
    rt.handle_message = runtime_handle_message
    rt.handle_callback = runtime_handle_callback
    rt._find_button_by_title = runtime_find_button_by_title
    rt._execute_button_action = runtime_execute_button_action
    rt.start = runtime_start
    MOD["UserBotRuntime"] = rt

    # --- BotManager
    bm = globs["BotManager"]
    MOD["_orig_manager_start_bot"] = bm.start_bot
    bm.start_bot = manager_start_bot
    bm.stop_bot = manager_stop_bot
    bm.remove_bot = manager_remove_bot
    bm._monitor_loop = manager_monitor_loop
    bm.load_all_bots = manager_load_all
    bm._deleted = set()

    # --- BroadcastManager
    bcm = globs["BroadcastManager"]
    bcm.start_broadcast = broadcast_start
    bcm.stop_broadcast = broadcast_stop
    bcm.stop_bot_broadcasts = broadcast_stop_bot
    bcm.status = broadcast_status
    bcm._run_broadcast = broadcast_run

    # --- BuilderBot
    bb = globs["BuilderBot"]
    MOD["_orig_builder_callback"] = bb.handle_callback
    MOD["_orig_builder_handle_step"] = bb.handle_step
    bb.handle_message = builder_handle_message
    bb.handle_callback = builder_handle_callback
    bb.handle_step = builder_handle_step
    bb.cmd_library = cmd_library
    bb.cmd_templates = cmd_templates_new
    bb.cmd_pick_bot = cmd_pick_bot
    bb.show_vars_menu = show_vars_menu
    bb.show_scope_menu = show_scope_menu
    bb.show_group_menu = show_group_menu
    bb.attach_template = attach_template
    bb.apply_template = apply_template_new
    bb.step_token = step_token_new
    bb.start_broadcast = start_broadcast_new
    bb.confirm_broadcast = confirm_broadcast_new
    bb.step_broadcast_content = step_broadcast_content_new
    bb.step_broadcast_keyboard = step_broadcast_keyboard_new
    bb.delete_bot = delete_bot_new
    bb.show_button_list = show_button_list_new
    bb.start_edit_button = start_edit_button_new
    bb.bc_preview = bc_preview
    bb.finish_bot_creation = finish_bot_creation
    bb.use_template_new = use_template_new
    MOD["BuilderBot"] = bb

    logger.info("✅ botfix_ext نصب شد: %s قالب | متغیرهای گروه | دامنه دکمهها | همگانی | حذف کامل", len(ALL_TEMPLATES))
    return True

# =====================================================================
# 16) وضعیت متغیرها در سطح UserBotRuntime (بدون آبجکت Database)
# =====================================================================
def runtime_get_var_state(self, chat_id, name):
    try:
        conn = self._get_db()
        row = conn.execute("SELECT * FROM bot_variable_state WHERE bot_id=? AND chat_id=? AND name=?",
                           (self.bot_id, chat_id, name)).fetchone()
        conn.close()
        return dict(row) if row else None
    except Exception:
        return None


def runtime_set_var_state(self, chat_id, name, is_active, value):
    try:
        conn = self._get_db()
        conn.execute("""INSERT INTO bot_variable_state (bot_id, chat_id, name, is_active, value, updated_at)
                        VALUES (?,?,?,?,?,?)
                        ON CONFLICT(bot_id, chat_id, name) DO UPDATE SET
                          is_active=excluded.is_active, value=excluded.value, updated_at=excluded.updated_at""",
                     (self.bot_id, chat_id, name, int(bool(is_active)), str(value or ""),
                      datetime.now().isoformat()))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.debug("runtime_set_var_state: %s", e)


def seed_vars_direct(db_path, bot_id):
    """نسخه سبک seed متغیرها برای BotManager (بدون ساخت آبجکت Database)."""
    try:
        conn = sqlite3.connect(db_path, timeout=30)
        row = conn.execute("SELECT COUNT(*) c FROM bot_variables WHERE bot_id=?", (bot_id,)).fetchone()
        if row and row[0]:
            conn.close()
            return 0
        n = 0
        for p in CUSTOM_VARIABLE_PRESETS:
            cur = conn.execute("""INSERT OR IGNORE INTO bot_variables
                (bot_id,name,label,kind,value_on,value_off,is_active,command_on,command_off,
                 scope,admin_only,action,penalty,description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (bot_id, p["name"], p["label"], "toggle", "فعال ✅", "غیرفعال ❌", 0,
                 p["command_on"], p["command_off"], p["scope"], 1, p["action"], p["penalty"], p["description"]))
            n += cur.rowcount or 0
        conn.commit()
        conn.close()
        return n
    except Exception as e:
        logger.debug("seed_vars_direct: %s", e)
        return 0
