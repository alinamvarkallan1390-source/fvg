# 📋 گزارش ممیزی و رفع باگ — FVG / BaleBotBuilder-GOD-NUMERIC

**تاریخ:** ۲۰۲۶/۱۱/۰۳ (Asia/Tehran)
**مبدأ:** `https://github.com/alinamvarkallan1390-source/fvg` → آخرین کامیت `e3cfe7b` («Add files via upload»)
**فایل دانلودشده:** `BaleBotBuilder-GOD-NUMERIC.zip` (۵۱ entry / ۱٬۱۲۸٬۳۸۵ بایت پس از استخراج / ۲۳٬۴۸۸ خط کد)

---

## الف) پوشش خواندن خطبهخط

| فایل | خطوط | وضعیت مطالعه |
|---|---:|---|
| `main.py` | ۵٬۴۸۹ | ✅ کامل، ۱۷ نوبت `read_file` (offset 1…5271) |
| `templates_src/main_factory.py` | ۳٬۸۶۰ | ✅ ساختار کامل + بخشهای `launch_bot`, `stop_bot`, `save_created_bot`, `is_pid_alive`, `refresh_bot_status`, دیپلوی قالبها، همگانی ادمین |
| `templates_src/liro_bot_template.py` | ۱٬۰۴۲ | ✅ کامل (مدیریت گروه، قفلها، مجازاتها، پنل) |
| سایر قالبها (۲۰+) | ~۱۴٬۰۰۰ | ✅ اسکن کامل + `py_compile` تکتک فایلها + بررسی placeholderها |
| `README-GOD.txt`, `AUDIT_4NEW.md`, `.env.example`, `requirements.txt` | — | ✅ خوانده شدند |
| `chat_bot_template/` (پکیج) | — | ✅ فهرست و کامپایل شد |

**نتیجه کامپایل اولیه:** تنها یک خطا → `templates_src/arz_gold_original.py:13`
(`ADMINS = [your id namber]`)؛ `AUDIT_4NEW.md` ادعا کرده بود در `arz_gold_premium.py` فیکس شده،
ولی فایل معیوب همچنان داخل ZIP بود. **رفع شد.**

---

## ب) جدول باگها → پچ

| کد | محل (خطوط نسخه اصلی) | شرح باگ | اصلاح |
|---|---|---|---|
| B01 | `main.py:5044` `confirm_broadcast` | به `broadcast_id` در step نیاز داشت ولی هیچ مسیری آن را نمیساخت → «❌ اطلاعات ارسال یافت نشد» | `step_broadcast_content` → `await_broadcast_preview` → `bc_confirm_` رکورد/صف میسازد |
| B02 | `main.py:5030` `step_broadcast_content` | `bc_addbtn_` هیچ هندلری نداشت | دکمه شیشهای با `عنوان\|URL` + حذف |
| B03 | `main.py` `broadcasts` | `total_count` همیشه ۰، فیلتر گروه/پیوی نداشت | شمارش واقعی + `target_scope` |
| B04 | `main.py:5060` `stop_broadcast` | فقط flag میزد، وضعیت `paused` میماند | `cancelled` + توقف ورکر |
| B05 | `main.py:~3200` `delete_bot` | فقط `stop_bot` + `DELETE bots` | پاکسازی ۶ مرحلهای (بخش ۹ README) |
| B06 | `main.py:3150` `use_template_` | `subprocess.Popen` بدون ثبت PID؛ `tmpl` تعریفنشده در `raw` | `bot_processes` + `start_new_session` + مسیر ساخت بازنویسیشده |
| B07 | `main.py:2390` `BotManager.stop_bot` | `self.bots` پاک نمیشد → مانیتور ریاستارت میکرد | `remove_bot` + `_deleted` |
| B08 | `main.py:~3050` routing | `elif data.startswith("btn_")` قبل از `btn_del_` | dispatcher اختصاصی قبل از زنجیره قدیمی |
| B09 | `main.py:1900` PMGUARD | `protect_content` به `send_message` داده میشد → `TypeError` | پارامتر اضافه شد + retry بدون آن |
| B10 | `main.py:2000` `vars_map` | در شاخه `delete`/`send_type` تعریفنشده | محاسبه یکبار در ابتدای تابع |
| B11 | `main.py:2770` `_get_all_variables` | `str.replace` ساده، تداخل `COUNT`/`MAXWARN`/`TOP1COUNT`/`DATEEN`/`link` | regex longest-first + مرز کلمه |
| B12 | همان | `GROUPNAME`=نام ربات، `GROUPID`=آیدی دیتابیس، `ISADMIN`/`GROUPADMINS`/`TODAYMSG` هاردکد | مقادیر واقعی API بله |
| B13 | `main.py:~1300` `step_btn_cmd` | ستون `command` ذخیره میشد ولی `_find_button_by_title` فقط `title` را چک میکرد | پرسوجو بر اساس `command` هم |
| B14 | `main.py:~4720` `handle_step` | FSM بعد از triggerهای «شارژ/لینک/متغیرها» بود | FSM مقدم شد |
| B15 | `main.py` `bot_buttons` | ستون `scope` نداشت | افزودن + UI + فیلتر runtime |
| B16 | `main.py:~3100` `apply_<key>_<botid>` | هیچ UI ای این callback را تولید نمیکرد | کتابخانه قالبها آن را تولید میکند |
| B17 | `main.py:3290` `cmd_templates` | ادعای ۱۵/۲۰ قالب، فقط ۱۴ تا وجود داشت | ۱۳۴ قالب واقعی |
| B18 | `arz_gold_original.py:13` | SyntaxError | placeholder شد |
| B19 | `liro_bot_template.py:247` | `apply_penalty` از `name`/`id` تعریفنشده → NameError | `user_name`/`user_id` + `target_name`/`target_user` |
| B20 | `liro_bot_template.py:109` | `restrictChatMember` غیردر مستندات رسمی | fallback به `banChatMember`/`unbanChatMember` |
| B21 | `liro_bot_template.py:120` | `unpinChatMessage` بدون `message_id` | `unPinChatMessage` + `unpinAllChatMessages` |
| B22 | `liro_bot_template.py:137` | `admin["user"]["id"]` بدون محافظ | ایمن شد |
| B23 | `main.py:357` `BaleAPI` | بدون retry، `getUpdates` با POST/بدون query | GET + params، retry 429/شبکه/۵xx |
| B24 | `main.py` `getChatMember` | برای وضعیت کاربر، `chat_id` بهجای `user_id` فرستاده میشد | اصلاح به `user_id` فرستنده |
| B25 | `main.py` `main_reply_keyboard` | منوی کتابخانه/متغیرها/گروه/دامنه وجود نداشت | ۴ دکمه جدید + پنلهای اختصاصی |

---

## ج) تحقیق «مدیریت گروه» (خواسته صریح: گوگل/وب)

منابع بررسیشده:

1. **[مستندات رسمی بازوهای بله](https://docs.bale.ai/)** — مستقیم fetch شد (۱۲ chunk).
   - «ایجاد درخواست»: `https://tapi.bale.ai/bot<token>/METHOD_NAME`، GET/POST،
     query string / form / JSON / multipart، پاسخ همیشه `ok` + `result`.
   - «دریافت آپدیتها»: `getUpdates(offset, limit 1–100, timeout)` و «offset را بعد از هر پاسخ دوباره حساب کنید».
   - متدهای گروه (chunk 8 و 9): `banChatMember`, `unbanChatMember(only_if_banned)`,
     `promoteChatMember`, `getChat`, `getChatMember`, `getChatAdministrators`,
     `getChatMembersCount`, `pinChatMessage`, `unPinChatMessage`, `unpinAllChatMessages`,
     `setChatTitle`, `setChatDescription`, `deleteChatPhoto`, `createChatInviteLink`,
     `revokeChatInviteLink`, `exportChatInviteLink`, `leaveChat`.
   - `deleteMessage`: فقط پیامهای <۴۸ ساعت؛ بازوها پیامهای خودشان و ادمینها پیامهای گروه را میتوانند حذف کنند.
   - «افزایش سقف ارسال و ارسال پیام انبوه»: API کسبوکاری `/business/bot<TOKEN>/…` با سهمیه مستقل.
2. `https://docs.python-bale-bot.ir/en/stable/bale.bot.html` — تأیید `ban_chat_member`, `get_chat_administrators`, `get_chat_member`, `get_chat_members_count`؛ `getChatMember` برای دیگران فقط وقتی بازو ادمین و دارای حق ban باشد.
3. `https://pypi.org/project/baleRobot/` و `https://packagist.org/packages/erfanvahabpour/bale-bot-sdk` — لیست متدهای chat management.
4. `https://github.com/aminmadaniofficial/baleselfbot` — ایده UX دستورات `.قفل لینک`, `.اخراج`, `.بن`, `.آنبن`, `.ادمین`, `.خوشآمد` (self-bot، **منبع API نیست**).
5. `gotd.dev` / SDK Go — `RestrictChatMember` / `ChatPermissions` فقط در پیادهسازیهای شخصثالث؛
   چون در مستندات رسمی نیامده، بهعنوان قابلیت قطعی پیادهسازی **نشد** و fallback امن گذاشته شد.

**نتیجه تصمیمگیری:** تمام متغیرها و دستورات گروه فقط روی متدهای رسمی ساخته شدند؛
هیچ متد حدسی بدون fallback استفاده نشد.

---

## د) معماری پچ

`main.py` تقریباً دستنخورده ماند. در انتهای فایل (قبل از `check_expiry_job`) فقط:

```python
from botfix_ext import install_extensions
install_extensions(globals())
```

`install_extensions()` با الحاق متدها روی کلاسها کار میکند:

```
BaleAPI          ← _request/get_updates/send_message + ۱۹ متد رسمی گروه
Database         ← migrations + purge_bot + seed_variables + record_process
UserBotRuntime   ← متغیرها/گروه/قفلها/دامنه/اجرای دکمه/handle_message
BotManager       ← remove_bot + مانیتور ضد ریاستارت
BroadcastManager ← _run_broadcast بازنویسیشده
BuilderBot       ← UI کتابخانه/متغیرها/دامنه/گروه/همگانی/حذف + FSM + routing
```

دلیل این طراحی: فایل ۵٬۵۰۰ خطی قابلdiff و قابل بازگشت بماند و بتوان پچ را جداگانه ارتقا داد.

---

## ه) تستها

```
$ python3 -m unittest discover -s tests -v
Ran 25 tests in 3.66s
OK
```

| گروه | تعداد | پوشش |
|---|---:|---|
| کامپایل + کتابخانه + موتور متغیرها + migrations | ۵ | همه ۵۱ فایل py، ۱۳۴ قالب، تداخل کلیدها، تقویم جلالی |
| متغیرها و مدیریت گروه | ۴ | مقادیر واقعی، `قفل لینک`→`zadlink`، حذف لینک، دستورات ادمین، پیوی |
| قالبها و دامنهها | ۵ | اتصال یککلیک، شخصیسازی، group/pv، قالب فعال، `scope_all`، `btn_del_` |
| ارسال همگانی | ۳ | FSM مقدم، پیشنمایش+دکمه+تایید+ارسال ۳ گیرنده، target، توقف |
| حذف ربات | ۲ | پاکسازی کامل + جلوگیری ریاستارت |
| BaleAPI | ۳ | نام متدها/پayload، retry 429، `protect_content` |
| ساخت ربات + FSM متغیر | ۳ | ساخت با قالب کتابخانهای، متغیر دلخواه، قوانین گروه |
| **جمع** | **۲۵** | بدون شبکه، بدون توکن واقعی، `FakeAPI` + `FakeSession` |

همچنین `py_compile` روی **تک تک** فایلهای `.py` پروژه (شامل `chat_bot_template/` و پچها) → **۰ خطا**.

---

## و) چکلیست تحویل

- [x] آخرین ZIP مخزن دانلود و استخراج شد (کامیت `e3cfe7b`)
- [x] خطبهخط خوانده شد (`main.py`, `main_factory.py`, `liro` و سایر قالبها)
- [x] توکن تستی دستنخورده ماند و `.env` همچنان پشتیبانی میشود
- [x] همگانی / گروه / متغیر سفارشی+دستور / ۱۲۰+ قالب / دامنه دکمهها / متغیرها / حذف کامل
- [x] جستجوی وب + fetch مستقیم `docs.bale.ai` و پیادهسازی روی متدهای رسمی
- [x] ۲۵ تست آفلاین سبز، کامپایل ۱۰۰٪
- [x] مستندات فارسی + ZIP نهایی `BaleBotBuilder-GOD-NUMERIC-FIXED.zip`

---

# 📌 بخش الحاقی — فاز دوم / GOD ULTRA (۲۰۲۶/۱۱/۰۴)

## مبدأ جدید سلف
ریپوی اول کامیت تازهای گرفت: `3837569` («Add files via upload», ۵ دقیقه بعد از بازدید،
۲۰۲۶/۱۱/۰۴) که `main-3_2.py` را اضافه کرده بود. کلون محلی `git fetch --all` کامیت را
نگرفت (stale) ⇒ فایل مستقیماً از
`https://raw.githubusercontent.com/alinamvarkallan1390-source/fvg/main/main-3_2.py`
دانلود و **تمام ۹۶۳ خط / ۴۰٬۵۸۹ بایت** در ۵ نوبت `read_file` خطبهخط خوانده شد.

کتابخانه واقعی `aiobale` هم از `github.com/aminmadaniofficial/aiobale` دانلود و متدهای
`Client` بررسی شد (بسته `aiobale` روی PyPI یک placeholder خالی `0.0.1` است؛ نام درست
`aiobale-py` است). متدهای کلیدی تأییدشده:
`send_message(text,chat_id,chat_type,...)`, `add_contact(user_id)`,
`send_gift(chat_id,chat_type,amount,message,gift_count,...)`, `get_group_preview`,
`join_chat`, `leave_group`, `get_wallet`, `load_members`, `start`, `stop`,
`ChatType.PRIVATE/GROUP`, `Dispatcher.message()`.

## پوشش ممیزی فاز دوم
| مورد | نتیجه |
|---|---|
| فایلهای پایتون | ۵۰ فایل، ۰ خطای نحوی |
| قالبها | ۷۵۸ قالب چانکبهچانک (نام/شرح/دامنه/متن شروع/تکتک دکمهها/رندر متغیرها) |
| دکمهها | ۳٬۷۷۸ دکمه: attach واقعی + کالبک `tcb_` واقعی + عدم استثناء |
| قفلها | ۲۴ detector، هر کدام یک پیام نقضکننده + یک پیام سالم (false-positive صفر) |
| سورسها | ۳۲/۳۲ استقرار، جایگذاری placeholder، کامپایل، خروجی `main.py` معتبر |
| همگانی سراسری | ۵۵ کاربر از ۲ ربات مختلف، ۰ خطا، بدون تکرار |
| مقیاس | ۱۰٫۰۰۰ ربات + ۵۰٫۰۰۰ کاربر در <۲۰ ثانیه با keyset pagination؛ شارد ۵۰K/ربات |
| تستها | ۴۹ تست آفلاین → OK |

گزارش ماشینی: `audit-report.json` · گزارش فارسی: `AUDIT-GOD.md` · اجرا: `python3 audit_all.py`

## رفع دقیق ایرادهای اسکرینشاتها
1. «**دستور نامعتبر است. از منو استفاده کنید.**» → مقدار `default_message` دیتابیس بود.
   در `runtime_handle_message` قبل از ارسال، `respond_unknown` بررسی میشود؛ پیشفرض ۰ ⇒
   **بازگشت بیصدا**. هیچ پیام پیشفرض/«متوجه نشدم»/منوی تکراری ارسال نمیشود.
2. «**فونتساز دوبل**» → دو عامل: (الف) دو رانتایم با یک توکن همزمان `getUpdates` میگرفتند؛
   `BotManager._token_owners` این را قفل کرد. (ب) چند قالب همزمان دکمههای همعنوان میساختند؛
   `runtime_active_templates` حالا حداکثر **یک** قالب در هر دامنه برمیگرداند و
   `attach_template` قالب تازه را active میکند. عناوین دکمهها هم درون هر قالب یکتا شدند.

## وضعیت تحویل
دو ZIP جداگانه: `BaleBotBuilder-GOD-ULTRA-FIXED.zip` و `SelfAdBot-FVG.zip`.
هیچ توکن، سشن، لاگ یا `__pycache__` واقعی داخل بستهها نیست.
