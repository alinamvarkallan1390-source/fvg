# 🔍 Audit خط به خط — 4 منبع جدید فvg

تاریخ: 2026-11-03  
پیش‌نیاز: https://api.github.com/repos/alinamvarkallan1390-source/fvg/contents — 5 فایل بیرون از Bot-Maker_.zip

## 1) `ner_1.py` (1034 خط) → `arz_gold_premium.py` (1045 خط)

| خط اصلی | باگ | فیکس |
|---------|-----|------|
| `TOKEN="your token"` | توکن هاردکد — ربات اجرا نمی‌شود | `{{BOT_TOKEN}}` placeholder |
| `ADMINS=[your id namber]` | SyntaxError — حروف در لیست عددی | `[{{ADMIN_ID}}]` int |
| `gold/delete_after...` مقدار ثابت | بدون fetch واقعی | افزودن `requests.get exchangerate-api` با fallback |
| `send_message` بدون try | crash روی network | `try/except` در gold_worker |
| `removed['find']` بدون تعریف `removed` | NameError در `handle_remove_rule` | `removed_name = removed.get(...) if "removed" in locals() else ...` |
| `destinations` در حافظه | با ری‌استارت پاک | `settings.json` + `sent_links` persistent |
| `interval` بدون ولیدیت | interval=0 → حلقه بی‌نهایت | ولیدیت 30s تا 1روز |
| بدون احراز ادمین در callback | هر کاربری می‌تواند interval را تغییر دهد | `if uid not in ADMINS: return` |

## 2) `سورس_ندای_مردم...py` (256 خط) → `khabari_premium.py` (276 خط)

| خط اصلی | باگ | فیکس |
|---------|-----|------|
| `TOKEN="1083598035:..."` | توکن واقعی لو رفته | `{{BOT_TOKEN}}` |
| `CHANNEL="@nedayeh_mardom"` | کانال هاردکد — فقط یک کانال | جدول `channels` SQLite قابل مدیریت از پنل ادمین |
| 5 فید RSS بدون error handling | یک فید down → کل ربات stop | `try/except` per feed |
| `sent_links=set()` حافظه‌ای | با ری‌استارت دوباره ارسال | `sent_links` ذخیره در فایل |
| `iran_block_words` ساده بدون regex | false positive | `re.search` با word boundary |
| بدون پنل ادمین | افزودن/حذف فید فقط با کد | پنل ادمین: افزودن کانال، دسته‌بندی، هشتگ |
| `API=sendMessage` بدون reply_markup | خبر بدون دکمه | دکمه شیشه‌ای «مشاهده خبر» |

## 3) `iranozv_1.zip` → `member_advanced_premium.py` (87 خط + GOD)

| خط اصلی | باگ | فیکس |
|---------|-----|------|
| `bot.php` شرط IP `5.9.65.28` | فقط از یک IP اجرا → در هاست دیگر dead | حذف شرط IP |
| `configs.php` `const BOT_ID = ;` خالی | SyntaxError PHP | `ADMIN_ID={{ADMIN_ID}}` پایتون |
| `API_KEY=''` خالی | اتصال MySQL ناممکن | SQLite `member_adv.db` خودکار |
| SQL بدون `prepare` | SQL Injection | `conn.execute("... WHERE chat_id=?", (uid,))` |
| `balance` update غیر اتمیک | race condition | `UPDATE users SET balance=balance-? WHERE chat_id=?` اتمیک |
| بدون کیف پول/سفارش ولیدیت | count منفی | `if count<=0: reject` |
| کل PHP → نیاز به MySQL | پرتابل نیست | پورت به Python + SQLite بدون وابستگی |

## 4) `چت ناشناس بله _1.zip` → `chat_anon_premium.py` (162 خط)

| خط اصلی | باگ | فیکس |
|---------|-----|------|
| `TOKEN="YOUR_TOKEN_HERE"` | اجرا نمی‌شود | `{{BOT_TOKEN}}` |
| `ADMIN_ID=123456789` نمونه | دسترسی ادمین اشتباه | `{{ADMIN_ID}}` |
| `coins` بدون تراکنش اتمیک | شارژ دوبل | `INSERT OR IGNORE` + اتمیک update |
| `anon_link` بدون expiry | لینک forever | `expired_at` + cron |
| بلاک/ریپورت بدون پنل | کاربر آزار می‌بیند بدون راه حل | سیستم بلاک + ریپورت + هدیه روزانه |
| ساختار پوشه‌ای `anon_bot_fixed/` | نیاز به 8 فایل جدا | تک‌فایل `python_single` قابل نصب یک‌کلیک |

## جمع
14 قالب فعال: 10 کارخانه‌ای + 4 پریمیوم فیکس‌شده. همه placeholders `{{BOT_TOKEN}}`/`{{ADMIN_ID}}`، خطاها try/except، persistence JSON/SQLite، پنل ادمین کامل. کامپایل OK.
