#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
پلتفرم ربات‌ساز حرفه‌ای بله v4.0 CLEAN - 20 قالب تست‌شده + پنل حرفه‌ای
تمام قابلیت‌ها در یک فایل main.py - بدون نیاز به پوشه اضافی

نحوه استفاده:
1. BOT_TOKEN و ADMIN_IDS را در خطوط زیر ویرایش کنید
2. pip install requests  # فقط requests کافیه! - بدون cryptography
3. python main.py

مستندات API بله: https://docs.bale.ai
Base URL: https://tapi.bale.ai/bot<token>/METHOD
"""

# ==================== تنظیمات اصلی - اینجا ویرایش کنید ====================
BOT_TOKEN = "1907079142:3ZbqH3BxKwIdGBttQTgOR_7TcNfRVUYZqG0"
ADMIN_IDS = [1975639269, 580913546]  # مشتری + 580913546

# تنظیمات پیشرفته (اختیاری - می‌توانید تغییر دهید)
BALE_API_BASE = "https://tapi.bale.ai"
DATABASE_PATH = "data/bale_builder.db"
BROADCAST_RATE_LIMIT = 1  # پیام در ثانیه

# ==================== پایان تنظیمات - از اینجا به بعد را تغییر ندهید ====================

import os
import sys
import re
import json
import time
import html
import sqlite3
import logging
import threading
import signal
import requests
from pathlib import Path
from datetime import datetime, timedelta
from contextlib import contextmanager
from typing import Optional, Dict, List, Any

# تلاش برای لود .env اگر وجود دارد
try:
    from dotenv import load_dotenv
    load_dotenv()
    if os.getenv("BOT_TOKEN") and "REPLACE" not in os.getenv("BOT_TOKEN"):
        BOT_TOKEN = os.getenv("BOT_TOKEN")
    if os.getenv("ADMIN_IDS"):
        try:
            ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS").split(",") if x.strip()]
        except:
            pass
    if os.getenv("BALE_API_BASE"):
        BALE_API_BASE = os.getenv("BALE_API_BASE")
    if os.getenv("DATABASE_PATH"):
        DATABASE_PATH = os.getenv("DATABASE_PATH")
except:
    pass

# تنظیمات لاگ
LOG_DIR = Path("logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.FileHandler(LOG_DIR / "bot.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("main")

# مدیریت کلید رمزنگاری
# === رمزنگاری بدون نیاز به cryptography - فقط با hashlib + base64 ===
import base64, hashlib
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "")
if not ENCRYPTION_KEY:
    key_file = Path("data/.secret_key")
    if key_file.exists():
        ENCRYPTION_KEY = key_file.read_text().strip()
    else:
        # کلید پیش‌فرض بر اساس BOT_TOKEN + زمان
        ENCRYPTION_KEY = hashlib.sha256((BOT_TOKEN + str(time.time())).encode()).hexdigest()[:32]
        key_file.parent.mkdir(parents=True, exist_ok=True)
        key_file.write_text(ENCRYPTION_KEY)

def _xor_bytes(data: bytes, key: bytes) -> bytes:
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))

def _get_key_bytes():
    return hashlib.sha256(ENCRYPTION_KEY.encode()).digest()

# اطمینان از وجود پوشه‌ها
Path(DATABASE_PATH).parent.mkdir(parents=True, exist_ok=True)
Path("logs").mkdir(parents=True, exist_ok=True)

DEFAULT_PLANS = [
    {"name": "رایگان", "days": 7, "max_bots": 1, "max_users": 200, "price": 0, "description": "پلن رایگان برای تست - ۷ روزه"},
    {"name": "حرفه‌ای", "days": 30, "max_bots": 5, "max_users": 5000, "price": 99000, "description": "پلن حرفه‌ای ۳۰ روزه - ۵ ربات"},
    {"name": "سازمانی", "days": 90, "max_bots": 20, "max_users": 50000, "price": 249000, "description": "پلن سازمانی ۹۰ روزه - ۲۰ ربات نامحدود"},
]

# ===== 10 قالب خفن از ریپوی اصلی + بدون باگ + منطق الهام گرفته شده =====
# خام = دکمه‌ساز خودت (custom) | 9 سورس آماده = فول سورس واقعی
TEMPLATES = {
    # --- از ریپوی اصلی - همه برداشته شده خفنه ---
    "earn": {
        "name": "💎 بات کسب درآمد",
        "desc": "دعوت زیرمجموعه، برداشت وجه، جوین اجباری، کیف پول، پنل مدیریت کامل - 1114 خط",
        "kind": "python_single",
        "template": "earn_bot_template.py",
        "buttons": [
            {"title": "💎 شروع کسب درآمد 💎", "type": "reply", "row": 0, "action": "text", "content": "💎 با دعوت دوستانت پول دربیار!\nلینک: LINK\nهر دعوت: 1000ت"},
            {"title": "🏠 حساب کاربری", "type": "reply", "row": 1, "action": "text", "content": "👤 FIRSTNAME | موجودی: BALANCE ت | دعوت: COUNT"},
            {"title": "🌟 برترین کاربران", "type": "reply", "row": 1, "action": "text", "content": "🏆 TOP1 - TOP1COUNT نفر"},
            {"title": "💸 برداشت از حساب", "type": "reply", "row": 2, "action": "text", "content": "حداقل: WITHDRAWMIN ت | موجودی: BALANCE"},
            {"title": "📊 تاریخچه برداشت", "type": "reply", "row": 2, "action": "text", "content": "تاریخچه برداشت‌ها..."},
            {"title": "📚 راهنما", "type": "reply", "row": 3, "action": "text", "content": "راهنما: دوستان را با LINK دعوت کن"},
        ]
    },
    "liro": {
        "name": "🛡️ بات مدیریت گروه",
        "desc": "فیلتر فحش، پاسخ خودکار، سکوت/اخراج، بازی، جوین اجباری - 1036 خط",
        "kind": "python_single",
        "template": "liro_bot_template.py",
        "buttons": [
            {"title": "📜 قوانین گروه", "type": "reply", "row": 0, "action": "text", "content": "قوانین: احترام، بدون اسپم، بدون فحش"},
            {"title": "⚠️ اخطار", "type": "inline", "row": 0, "action": "text", "content": "اخطار ثبت شد WARN/MAXWARN"},
            {"title": "🔇 سکوت", "type": "inline", "row": 0, "action": "text", "content": "کاربر سکوت شد"},
            {"title": "🚫 بن", "type": "inline", "row": 1, "action": "text", "content": "کاربر بن شد"},
            {"title": "👋 خوش‌آمد", "type": "reply", "row": 1, "action": "text", "content": "سلام FIRSTNAME به GROUPNAME خوش آمدی"},
            {"title": "📊 آمار گروه", "type": "inline", "row": 1, "action": "text", "content": "اعضا: MEMBERCOUNT"},
        ]
    },
    "shop": {
        "name": "🛍️ بات فروشگاه سورس",
        "desc": "فروش فایل با کیف پول، پنل مدیریت داخل بله - 802 خط",
        "kind": "python_single",
        "template": "shop_bot_template.py",
        "buttons": [
            {"title": "🛍 محصولات", "type": "reply", "row": 0, "action": "text", "content": "محصولات: سورس‌ها را ببین"},
            {"title": "🛒 سبد خرید", "type": "inline", "row": 0, "action": "text", "content": "سبد خالی"},
            {"title": "💳 پرداخت", "type": "reply", "row": 1, "action": "text", "content": "برای پرداخت به ادمین پیام بده"},
        ]
    },
    "game": {
        "name": "⚔️ بات بازی جنگ ماتریکس",
        "desc": "مدیریت کشور، جنگ، اقتصاد، اتحاد - 2240 خط خفن‌ترین",
        "kind": "python_single",
        "template": "game_bot_template.py",
        "buttons": [
            {"title": "⚔️ شروع بازی", "type": "reply", "row": 0, "action": "text", "content": "به جنگ ماتریکس خوش آمدی FIRSTNAME!"},
            {"title": "🏰 کشور من", "type": "reply", "row": 0, "action": "text", "content": "کشور: GROUPNAME | سکه: COIN"},
            {"title": "⚔️ حمله", "type": "inline", "row": 1, "action": "text", "content": "حمله به دشمن!"},
        ]
    },
    "chat": {
        "name": "💬 بات چت ناشناس",
        "desc": "چت تصادفی، پروفایل، سکه، افراد نزدیک - پکیجی",
        "kind": "python_package",
        "template": "chat_bot_template",
        "buttons": [
            {"title": "🔍 جستجوی پارتنر", "type": "reply", "row": 0, "action": "text", "content": "در حال جستجو..."},
            {"title": "❌ قطع چت", "type": "reply", "row": 0, "action": "text", "content": "چت قطع شد"},
            {"title": "👤 پروفایل", "type": "reply", "row": 1, "action": "text", "content": "پروفایل: FIRSTNAME | COIN سکه"},
        ]
    },
    "support": {
        "name": "🎧 بات پشتیبانی",
        "desc": "ارسال پیام به ادمین، پنل ساده - 373 خط",
        "kind": "python_single",
        "template": "support_bot_template.py",
        "buttons": [
            {"title": "🎧 پشتیبانی", "type": "reply", "row": 0, "action": "text", "content": "پیام را بفرست تا به ادمین برود"},
            {"title": "📋 تیکت‌های من", "type": "inline", "row": 0, "action": "text", "content": "تیکت #1 باز"},
        ]
    },
    "lottery": {
        "name": "🎰 بات قرعه‌کشی",
        "desc": "قرعه‌کشی روزانه، شانس، دعوت - 736 خط",
        "kind": "python_single",
        "template": "lottery_bot_template.py",
        "buttons": [
            {"title": "🎰 شرکت در قرعه‌کشی", "type": "reply", "row": 0, "action": "text", "content": "در قرعه‌کشی شرکت کردی! شانس: RANDOM%"},
            {"title": "🏆 برندگان", "type": "inline", "row": 0, "action": "text", "content": "برنده: TOP1"},
        ]
    },
    "font": {
        "name": "🔤 بات فونت‌ساز",
        "desc": "تبدیل متن به فونت‌های فانتزی - 242 خط",
        "kind": "python_single",
        "template": "font_bot_template.py",
        "buttons": [
            {"title": "🔤 فونت کن", "type": "reply", "row": 0, "action": "text", "content": "متن را بفرست تا فونت کنم"},
            {"title": "📝 نمونه", "type": "inline", "row": 0, "action": "text", "content": "𝓕𝓪𝓷𝓬𝔂"},
        ]
    },
    "member": {
        "name": "🇮🇷 بات عضو بگیر",
        "desc": "سفارش ممبر، کیف پول، برداشت - 263 خط",
        "kind": "python_single",
        "template": "member_bot_template.py",
        "buttons": [
            {"title": "➕ سفارش ممبر", "type": "reply", "row": 0, "action": "text", "content": "ممبر سفارش بده"},
            {"title": "💰 کسب درآمد", "type": "reply", "row": 0, "action": "text", "content": "با دعوت LINK پول بگیر"},
            {"title": "💸 برداشت", "type": "reply", "row": 1, "action": "text", "content": "موجودی: BALANCE | برداشت کن"},
        ]
    },
    "custom": {
        "name": "🧩 بات سفارشی (دکمه‌ساز خام)",
        "desc": "بات خالی خودت دکمه بساز - 313 خط = همون خام",
        "kind": "python_single",
        "template": "custom_bot_template.py",
        "buttons": []
    },
    # --- 4 سورس جدید درخواستی - خیلی خفن بدون باگ ---
    "arz": {
        "name": "💱 نرخ ارز VIP",
        "desc": "دلار/یورو/طلا/ارز دیجیتال زنده، تبدیل، نمودار، هشدار قیمت - بدون باگ",
        "kind": "python_single",
        "template": "arz_bot_template.py",
        "buttons": [
            {"title": "💵 نرخ دلار", "type": "reply", "row": 0, "action": "text", "content": "💵 دلار: {irr} ریال - DATE TIME"},
            {"title": "💶 یورو/طلا", "type": "reply", "row": 0, "action": "text", "content": "یورو: 45,200ت | طلا: 3,850,000ت"},
            {"title": "₿ ارز دیجیتال", "type": "reply", "row": 1, "action": "text", "content": "BTC $67k | ETH $3.8k"},
            {"title": "🔄 تبدیل", "type": "reply", "row": 1, "action": "text", "content": "تبدیل: 100 USD to IRR"},
            {"title": "⭐ مورد علاقه", "type": "inline", "row": 2, "action": "text", "content": "علاقه‌مندی‌ها"},
            {"title": "📊 نمودار", "type": "inline", "row": 2, "action": "text", "content": "نمودار 7 روزه 📈"},
            {"title": "⚙️ هشدار قیمت", "type": "reply", "row": 3, "action": "text", "content": "هشدار روی 50k فعال شد"},
        ]
    },
    "khabari": {
        "name": "📰 مدیریت کانال خبری",
        "desc": "فوروارد خودکار، زمانبندی، مدیریت چند کانال، آمار بازدید - خیلی خفن",
        "kind": "python_single",
        "template": "khabari_bot_template.py",
        "buttons": [
            {"title": "📰 اخبار فوری", "type": "reply", "row": 0, "action": "text", "content": "تیتر: خبر مهم امروز - DATE"},
            {"title": "⚽ ورزشی", "type": "reply", "row": 0, "action": "text", "content": "ورزشی: نتایج زنده"},
            {"title": "💻 تکنولوژی", "type": "reply", "row": 1, "action": "text", "content": "تکنولوژی: هوش مصنوعی"},
            {"title": "💰 اقتصادی", "type": "reply", "row": 1, "action": "text", "content": "ارز: نرخ جدید"},
            {"title": "➕ افزودن کانال", "type": "inline", "row": 2, "action": "text", "content": "آیدی کانال را بفرست @channel"},
            {"title": "📢 فوروارد خودکار", "type": "inline", "row": 2, "action": "text", "content": "فوروارد فعال ✅"},
            {"title": "⏰ زمانبندی", "type": "reply", "row": 3, "action": "text", "content": "پست ساعت TIME ارسال میشه"},
            {"title": "📊 آمار بازدید", "type": "inline", "row": 3, "action": "text", "content": "بازدید امروز: 12k"},
        ]
    },
    "chat_adv": {
        "name": "💬 چت ناشناس پیشرفته",
        "desc": "جستجوی هوشمند، پروفایل، سکه، گزارش، مخاطب خاص - ارتقا یافته",
        "kind": "python_single",
        "template": "chat_anon_advanced.py",
        "buttons": [
            {"title": "🔍 جستجوی پارتنر", "type": "reply", "row": 0, "action": "text", "content": "در حال جستجو... شریک پیدا شد!"},
            {"title": "👤 پروفایل من", "type": "reply", "row": 1, "action": "text", "content": "پروفایل FIRSTNAME | سکه: COIN"},
            {"title": "⚙️ تنظیمات", "type": "inline", "row": 1, "action": "text", "content": "جنسیت/شهر/سن"},
            {"title": "⭐ مخاطب خاص", "type": "reply", "row": 2, "action": "text", "content": "مخاطب خاص ذخیره شد"},
            {"title": "🚫 بلاک", "type": "inline", "row": 2, "action": "text", "content": "کاربر بلاک شد"},
            {"title": "📊 امتیاز", "type": "inline", "row": 2, "action": "text", "content": "امتیاز: SCORE | لول: LEVEL"},
        ]
    },
    "member_adv": {
        "name": "🚀 عضو بگیر پیشرفته",
        "desc": "سفارش ممبر واقعی، تعرفه، کسب درآمد پیشرفته، هدیه روزانه - حرفه‌ای",
        "kind": "python_single",
        "template": "member_advanced_bot_template.py",
        "buttons": [
            {"title": "➕ سفارش ممبر", "type": "reply", "row": 0, "action": "text", "content": "آیدی کانال + تعداد را بفرست"},
            {"title": "📋 سفارشات من", "type": "inline", "row": 0, "action": "text", "content": "سفارش #1: 100 ممبر ⏳"},
            {"title": "💰 کسب درآمد", "type": "reply", "row": 1, "action": "text", "content": "لینک: LINK | هر عضویت 150ت | دعوت: COUNT"},
            {"title": "💸 برداشت", "type": "reply", "row": 1, "action": "text", "content": "موجودی: BALANCE | حداقل: WITHDRAWMIN"},
            {"title": "📊 تعرفه", "type": "reply", "row": 2, "action": "text", "content": "100=15k | 500=60k | 1000=110k"},
            {"title": "🎁 هدیه روزانه", "type": "inline", "row": 2, "action": "text", "content": "هدیه: +500 سکه STREAK روز"},
            {"title": "👥 لینک دعوت", "type": "reply", "row": 3, "action": "text", "content": "LINK"},
        ]
    },
}

DEFAULT_START_MESSAGE = "✨ سلام {name} عزیز\n\nبه **{bot_name}** خوش آمدید 🎉\n━━━━━━━━━━━━━━━━━━━━\nاز منوی زیر انتخاب کنید 👇"
DEFAULT_WELCOME_MESSAGE = "سلام {name} جان! 🎉\nبه جمع ما خوش آمدی."




# ==================== امنیت ====================
def encrypt_token(token: str) -> str:
    try:
        key = _get_key_bytes()
        enc = _xor_bytes(token.encode(), key)
        return base64.urlsafe_b64encode(enc).decode()
    except Exception as e:
        # fallback ساده
        return base64.urlsafe_b64encode(token.encode()).decode()

def decrypt_token(enc: str) -> str:
    try:
        key = _get_key_bytes()
        data = base64.urlsafe_b64decode(enc.encode())
        dec = _xor_bytes(data, key)
        return dec.decode()
    except Exception:
        try:
            return base64.urlsafe_b64decode(enc.encode()).decode()
        except:
            return enc

def mask_token(token: str) -> str:
    if len(token) < 12:
        return "***"
    return token[:10] + "****" + token[-6:]

def sanitize_text(text: str, max_len: int = 4000) -> str:
    if not text:
        return ""
    text = text.strip()
    if len(text) > max_len:
        text = text[:max_len]
    return text

def validate_token_format(token: str) -> bool:
    pattern = r"^\d+:[A-Za-z0-9_-]{30,}$"
    return bool(re.match(pattern, token))

def validate_button_title(title: str) -> tuple[bool, str]:
    if not title or len(title.strip()) < 1:
        return False, "عنوان دکمه نمی‌تواند خالی باشد"
    if len(title) > 60:
        return False, "عنوان دکمه حداکثر ۶۰ کاراکتر"
    return True, ""

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

def escape_html(text: str) -> str:
    return html.escape(text or "")


"""
کلاینت API رسمی بله - فقط متدهای مستند شده در docs.bale.ai
Base URL: https://tapi.bale.ai/bot<token>/METHOD
"""
import requests
import time
import logging
from typing import Optional, Dict, Any, List


logger = logging.getLogger(__name__)

class BaleAPIError(Exception):
    def __init__(self, message, error_code=None, description=None):
        super().__init__(message)
        self.error_code = error_code
        self.description = description

class BaleAPI:
    def __init__(self, token: str, base_url: str = "https://tapi.bale.ai", timeout: int = 30, business: bool = False):
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.business = business
        # business mode uses /business/bot<token>/...
        if business:
            self.api_url = f"{self.base_url}/business/bot{self.token}/"
        else:
            self.api_url = f"{self.base_url}/bot{self.token}/"
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "BaleBotBuilder/1.0"})

    def _request(self, method: str, params: Dict = None, files: Dict = None, json_data: Dict = None) -> Dict:
        url = self.api_url + method
        try:
            if files:
                # multipart
                resp = self.session.post(url, data=params or json_data, files=files, timeout=self.timeout)
            elif json_data:
                resp = self.session.post(url, json=json_data, timeout=self.timeout)
            elif params:
                resp = self.session.post(url, json=params, timeout=self.timeout)
            else:
                resp = self.session.get(url, timeout=self.timeout)
            
            # تلاش برای پارس JSON
            try:
                data = resp.json()
            except:
                raise BaleAPIError(f"پاسخ نامعتبر از سرور بله: {resp.text[:500]}")
            
            if not data.get("ok"):
                err_code = data.get("error_code")
                desc = data.get("description", "خطای نامشخص")
                # مدیریت محدودیت نرخ
                if err_code == 429:
                    retry_after = 0
                    if "parameters" in data and data["parameters"].get("retry_after"):
                        retry_after = data["parameters"]["retry_after"]
                    logger.warning(f"Rate limited, retry after {retry_after}s")
                    time.sleep(retry_after or 2)
                raise BaleAPIError(desc, error_code=err_code, description=desc)
            return data.get("result")
        except requests.RequestException as e:
            logger.error(f"خطای شبکه در {method}: {e}")
            raise BaleAPIError(f"خطای شبکه: {e}")

    # ========== متدهای اصلی ==========
    
    def get_me(self) -> Dict:
        """دریافت اطلاعات ربات - اعتبارسنجی توکن"""
        return self._request("getMe")

    def send_message(self, chat_id: int, text: str, reply_markup: Dict = None, reply_to_message_id: int = None, parse_mode: str = None) -> Dict:
        payload = {"chat_id": chat_id, "text": text}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if reply_to_message_id:
            payload["reply_to_message_id"] = reply_to_message_id
        if parse_mode:
            payload["parse_mode"] = parse_mode
        return self._request("sendMessage", json_data=payload)

    def send_photo(self, chat_id: int, photo: str, caption: str = None, reply_markup: Dict = None) -> Dict:
        payload = {"chat_id": chat_id, "photo": photo}
        if caption:
            payload["caption"] = caption
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self._request("sendPhoto", json_data=payload)

    def send_video(self, chat_id: int, video: str, caption: str = None, reply_markup: Dict = None) -> Dict:
        payload = {"chat_id": chat_id, "video": video}
        if caption:
            payload["caption"] = caption
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self._request("sendVideo", json_data=payload)

    def send_document(self, chat_id: int, document: str, caption: str = None, reply_markup: Dict = None) -> Dict:
        payload = {"chat_id": chat_id, "document": document}
        if caption:
            payload["caption"] = caption
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self._request("sendDocument", json_data=payload)

    def send_audio(self, chat_id: int, audio: str, caption: str = None) -> Dict:
        payload = {"chat_id": chat_id, "audio": audio}
        if caption:
            payload["caption"] = caption
        return self._request("sendAudio", json_data=payload)

    def send_voice(self, chat_id: int, voice: str, caption: str = None) -> Dict:
        payload = {"chat_id": chat_id, "voice": voice}
        if caption:
            payload["caption"] = caption
        return self._request("sendVoice", json_data=payload)

    def send_animation(self, chat_id: int, animation: str, caption: str = None) -> Dict:
        payload = {"chat_id": chat_id, "animation": animation}
        if caption:
            payload["caption"] = caption
        return self._request("sendAnimation", json_data=payload)

    def send_media_group(self, chat_id: int, media: List[Dict]) -> Dict:
        payload = {"chat_id": chat_id, "media": media}
        return self._request("sendMediaGroup", json_data=payload)

    def send_contact(self, chat_id: int, phone_number: str, first_name: str, last_name: str = None) -> Dict:
        payload = {"chat_id": chat_id, "phone_number": phone_number, "first_name": first_name}
        if last_name:
            payload["last_name"] = last_name
        return self._request("sendContact", json_data=payload)

    def send_location(self, chat_id: int, latitude: float, longitude: float) -> Dict:
        payload = {"chat_id": chat_id, "latitude": latitude, "longitude": longitude}
        return self._request("sendLocation", json_data=payload)

    def forward_message(self, chat_id: int, from_chat_id: int, message_id: int) -> Dict:
        payload = {"chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id}
        return self._request("forwardMessage", json_data=payload)

    def copy_message(self, chat_id: int, from_chat_id: int, message_id: int, caption: str = None, reply_markup: Dict = None) -> Dict:
        payload = {"chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id}
        if caption:
            payload["caption"] = caption
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self._request("copyMessage", json_data=payload)

    def edit_message_text(self, chat_id: int, message_id: int, text: str, reply_markup: Dict = None) -> Dict:
        payload = {"chat_id": chat_id, "message_id": message_id, "text": text}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self._request("editMessageText", json_data=payload)

    def edit_message_caption(self, chat_id: int, message_id: int, caption: str, reply_markup: Dict = None) -> Dict:
        payload = {"chat_id": chat_id, "message_id": message_id, "caption": caption}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self._request("editMessageCaption", json_data=payload)

    def edit_message_reply_markup(self, chat_id: int, message_id: int, reply_markup: Dict = None) -> Dict:
        payload = {"chat_id": chat_id, "message_id": message_id}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self._request("editMessageReplyMarkup", json_data=payload)

    def delete_message(self, chat_id: int, message_id: int) -> bool:
        payload = {"chat_id": chat_id, "message_id": message_id}
        return self._request("deleteMessage", json_data=payload)

    def send_chat_action(self, chat_id: int, action: str = "typing") -> bool:
        payload = {"chat_id": chat_id, "action": action}
        return self._request("sendChatAction", json_data=payload)

    def get_updates(self, offset: int = None, limit: int = 100, timeout: int = 20) -> List[Dict]:
        params = {"limit": limit, "timeout": timeout}
        if offset is not None:
            params["offset"] = offset
        # getUpdates باید GET باشد اما POST هم پشتیبانی می‌شود
        result = self._request("getUpdates", params=params)
        return result if isinstance(result, list) else []

    def set_webhook(self, url: str) -> bool:
        return self._request("setWebhook", json_data={"url": url})

    def delete_webhook(self) -> bool:
        return self._request("deleteWebhook")

    def get_webhook_info(self) -> Dict:
        return self._request("getWebhookInfo")

    def get_chat(self, chat_id: int) -> Dict:
        return self._request("getChat", json_data={"chat_id": chat_id})

    def get_chat_member(self, chat_id: int, user_id: int) -> Dict:
        return self._request("getChatMember", json_data={"chat_id": chat_id, "user_id": user_id})

    def get_chat_administrators(self, chat_id: int) -> List[Dict]:
        return self._request("getChatAdministrators", json_data={"chat_id": chat_id})

    def get_chat_members_count(self, chat_id: int) -> int:
        return self._request("getChatMembersCount", json_data={"chat_id": chat_id})

    def answer_callback_query(self, callback_query_id: str, text: str = None, show_alert: bool = False) -> bool:
        payload = {"callback_query_id": callback_query_id}
        if text:
            payload["text"] = text
        if show_alert:
            payload["show_alert"] = show_alert
        return self._request("answerCallbackQuery", json_data=payload)

    def get_file(self, file_id: str) -> Dict:
        return self._request("getFile", json_data={"file_id": file_id})

    def ban_chat_member(self, chat_id: int, user_id: int) -> bool:
        return self._request("banChatMember", json_data={"chat_id": chat_id, "user_id": user_id})

    def unban_chat_member(self, chat_id: int, user_id: int) -> bool:
        return self._request("unbanChatMember", json_data={"chat_id": chat_id, "user_id": user_id})

    def promote_chat_member(self, chat_id: int, user_id: int, **perms) -> bool:
        payload = {"chat_id": chat_id, "user_id": user_id, **perms}
        return self._request("promoteChatMember", json_data=payload)

    def leave_chat(self, chat_id: int) -> bool:
        return self._request("leaveChat", json_data={"chat_id": chat_id})

    def pin_chat_message(self, chat_id: int, message_id: int) -> bool:
        return self._request("pinChatMessage", json_data={"chat_id": chat_id, "message_id": message_id})

    def unpin_chat_message(self, chat_id: int, message_id: int) -> bool:
        return self._request("unpinChatMessage", json_data={"chat_id": chat_id, "message_id": message_id})

    def send_invoice(self, chat_id: int, title: str, description: str, payload: str, provider_token: str, prices: List[Dict], photo_url: str = None) -> Dict:
        data = {
            "chat_id": chat_id,
            "title": title,
            "description": description,
            "payload": payload,
            "provider_token": provider_token,
            "prices": prices
        }
        if photo_url:
            data["photo_url"] = photo_url
        return self._request("sendInvoice", json_data=data)

    def create_invoice_link(self, title: str, description: str, payload: str, provider_token: str, prices: List[Dict]) -> str:
        data = {
            "title": title,
            "description": description,
            "payload": payload,
            "provider_token": provider_token,
            "prices": prices
        }
        return self._request("createInvoiceLink", json_data=data)

    def answer_pre_checkout_query(self, pre_checkout_query_id: str, ok: bool, error_message: str = None) -> bool:
        payload = {"pre_checkout_query_id": pre_checkout_query_id, "ok": ok}
        if error_message:
            payload["error_message"] = error_message
        return self._request("answerPreCheckoutQuery", json_data=payload)

    def download_file(self, file_path: str, dest_path: str) -> str:
        """دانلود فایل از سرور بله"""
        url = f"{self.base_url}/file/bot{self.token}/{file_path}"
        resp = self.session.get(url, timeout=60)
        resp.raise_for_status()
        with open(dest_path, 'wb') as f:
            f.write(resp.content)
        return dest_path

    # ========== Business API ==========
    def business_send_message(self, chat_id: int, text: str, reply_markup: Dict = None):
        """ارسال با Business API برای ارسال انبوه - نیاز به فعالسازی"""
        biz = BaleAPI(self.token, base_url=self.base_url, business=True)
        return biz.send_message(chat_id, text, reply_markup)

def validate_token(token: str, base_url: str = "https://tapi.bale.ai") -> Dict:
    """اعتبارسنجی توکن و دریافت اطلاعات ربات"""
    api = BaleAPI(token, base_url=base_url)
    try:
        info = api.get_me()
        # info شامل id, first_name, username, is_bot
        return {"ok": True, "info": info}
    except BaleAPIError as e:
        return {"ok": False, "error": str(e), "description": e.description}
    except Exception as e:
        return {"ok": False, "error": str(e)}


class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.init_db()

    @contextmanager
    def get_conn(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=30.0, isolation_level=None)
        conn.row_factory = sqlite3.Row
        # بهینه برای 5000 ربات همزمان
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        conn.execute("PRAGMA busy_timeout=30000;")
        conn.execute("PRAGMA cache_size=-64000;")  # 64MB cache
        conn.execute("PRAGMA temp_store=MEMORY;")
        conn.execute("PRAGMA mmap_size=268435456;")  # 256MB mmap
        try:
            yield conn
            conn.commit()
        except Exception as e:
            try:
                conn.rollback()
            except:
                pass
            raise
        finally:
            conn.close()

    def execute(self, query: str, params=()):
        with self.get_conn() as conn:
            cur = conn.execute(query, params)
            return cur

    def fetchone(self, query: str, params=()):
        with self.get_conn() as conn:
            cur = conn.execute(query, params)
            return cur.fetchone()

    def fetchall(self, query: str, params=()):
        with self.get_conn() as conn:
            cur = conn.execute(query, params)
            return cur.fetchall()

    def init_db(self):
        with self.get_conn() as conn:
            # کاربران پلتفرم (سازندگان ربات)
            conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_blocked INTEGER DEFAULT 0,
                invited_by INTEGER,
                invite_count INTEGER DEFAULT 0,
                is_admin INTEGER DEFAULT 0,
                current_step TEXT,
                step_data TEXT,
                referral_code TEXT
            )""")
            
            # ربات‌های ساخته شده
            conn.execute("""
            CREATE TABLE IF NOT EXISTS bots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id INTEGER NOT NULL,
                token_encrypted TEXT NOT NULL,
                bot_username TEXT,
                bot_name TEXT,
                bot_id INTEGER,
                is_active INTEGER DEFAULT 1,
                status TEXT DEFAULT 'offline',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT,
                plan_id INTEGER,
                user_count INTEGER DEFAULT 0,
                webhook_url TEXT,
                FOREIGN KEY(owner_id) REFERENCES users(user_id),
                FOREIGN KEY(plan_id) REFERENCES plans(id)
            )""")

            # کاربران هر ربات
            conn.execute("""
            CREATE TABLE IF NOT EXISTS bot_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                subscribed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_blocked INTEGER DEFAULT 0,
                last_seen TEXT,
                invited_by INTEGER,
                current_parent_id INTEGER,
                state TEXT,
                UNIQUE(bot_id, chat_id),
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
            )""")

            # دکمه‌های ربات
            conn.execute("""
            CREATE TABLE IF NOT EXISTS bot_buttons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                button_type TEXT NOT NULL CHECK(button_type IN ('inline','reply')),
                parent_id INTEGER,
                row INTEGER DEFAULT 0,
                position INTEGER DEFAULT 0,
                action_type TEXT DEFAULT 'text' CHECK(action_type IN ('text','photo','video','document','audio','url','menu','back','referral')),
                content_text TEXT,
                file_id TEXT,
                file_url TEXT,
                caption TEXT,
                url TEXT,
                has_children INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE,
                FOREIGN KEY(parent_id) REFERENCES bot_buttons(id) ON DELETE CASCADE
            )""")

            # تنظیمات هر ربات
            conn.execute("""
            CREATE TABLE IF NOT EXISTS bot_settings (
                bot_id INTEGER PRIMARY KEY,
                start_message TEXT,
                welcome_message TEXT,
                default_message TEXT DEFAULT 'دستور نامعتبر است. از منو استفاده کنید.',
                referral_enabled INTEGER DEFAULT 1,
                referral_reward TEXT,
                referral_min INTEGER DEFAULT 3,
                channel_lock TEXT,
                is_private INTEGER DEFAULT 0,
                auto_reply INTEGER DEFAULT 1,
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
            )""")

            # زیرمجموعه‌گیری
            conn.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                inviter_id INTEGER NOT NULL,
                invited_id INTEGER NOT NULL,
                bot_id INTEGER,
                platform_referral INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                reward_claimed INTEGER DEFAULT 0,
                UNIQUE(inviter_id, invited_id, bot_id)
            )""")

            # پلن‌های اشتراک
            conn.execute("""
            CREATE TABLE IF NOT EXISTS plans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                days INTEGER NOT NULL,
                max_bots INTEGER NOT NULL,
                max_users INTEGER NOT NULL,
                price INTEGER DEFAULT 0,
                description TEXT,
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")

            # اشتراک‌ها
            conn.execute("""
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                plan_id INTEGER NOT NULL,
                start_at TEXT DEFAULT CURRENT_TIMESTAMP,
                end_at TEXT NOT NULL,
                is_active INTEGER DEFAULT 1,
                payment_id TEXT,
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE,
                FOREIGN KEY(plan_id) REFERENCES plans(id)
            )""")

            # ارسال همگانی
            conn.execute("""
            CREATE TABLE IF NOT EXISTS broadcasts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                owner_id INTEGER NOT NULL,
                message_type TEXT DEFAULT 'text',
                content TEXT,
                file_id TEXT,
                caption TEXT,
                keyboard_json TEXT,
                target_type TEXT DEFAULT 'all' CHECK(target_type IN ('all','active','custom')),
                custom_filter TEXT,
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending','running','paused','completed','cancelled','failed')),
                total_count INTEGER DEFAULT 0,
                sent_count INTEGER DEFAULT 0,
                failed_count INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                started_at TEXT,
                finished_at TEXT,
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
            )""")

            conn.execute("""
            CREATE TABLE IF NOT EXISTS broadcast_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                broadcast_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed','cancelled')),
                error TEXT,
                sent_at TEXT,
                FOREIGN KEY(broadcast_id) REFERENCES broadcasts(id) ON DELETE CASCADE
            )""")

            # تیکت پشتیبانی
            conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                subject TEXT,
                message TEXT NOT NULL,
                status TEXT DEFAULT 'open' CHECK(status IN ('open','answered','closed')),
                admin_response TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            )""")

            # لاگ‌ها
            conn.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level TEXT,
                source TEXT,
                message TEXT,
                details TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")

            # وضعیت‌های کاربر در ربات‌ساز (FSM)
            conn.execute("""
            CREATE TABLE IF NOT EXISTS user_states (
                user_id INTEGER PRIMARY KEY,
                step TEXT,
                data TEXT,
                bot_context INTEGER,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")

            # مدیران ربات
            conn.execute("""
            CREATE TABLE IF NOT EXISTS bot_admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                permission TEXT DEFAULT 'all',
                added_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(bot_id, user_id),
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
            )""")

            # آمار روزانه
            conn.execute("""
            CREATE TABLE IF NOT EXISTS stats_daily (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER,
                date TEXT,
                new_users INTEGER DEFAULT 0,
                messages INTEGER DEFAULT 0,
                UNIQUE(bot_id, date)
            )""")

            # ایجاد ایندکس‌ها
            conn.execute("CREATE INDEX IF NOT EXISTS idx_bots_owner ON bots(owner_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_bot_users_bot ON bot_users(bot_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_buttons_bot ON bot_buttons(bot_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_broadcast_bot ON broadcasts(bot_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_referrals_inviter ON referrals(inviter_id)")

            # === جداول جدید - قابلیت‌های جذاب برای 5000 ربات ===
            conn.execute('''
            CREATE TABLE IF NOT EXISTS scheduled_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                content TEXT NOT NULL,
                file_id TEXT,
                send_at TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
            )''')
            conn.execute('''
            CREATE TABLE IF NOT EXISTS polls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                question TEXT NOT NULL,
                options TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_active INTEGER DEFAULT 1,
                FOREIGN KEY(bot_id) REFERENCES bots(id) ON DELETE CASCADE
            )''')
            conn.execute('''
            CREATE TABLE IF NOT EXISTS poll_votes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                poll_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                option_idx INTEGER NOT NULL,
                UNIQUE(poll_id, user_id)
            )''')
            conn.execute('''
            CREATE TABLE IF NOT EXISTS user_tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                tag TEXT NOT NULL,
                UNIQUE(bot_id, chat_id, tag)
            )''')
            conn.execute('''
            CREATE TABLE IF NOT EXISTS auto_replies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                keyword TEXT NOT NULL,
                reply TEXT NOT NULL,
                reply_type TEXT DEFAULT 'text'
            )''')
            conn.execute("CREATE INDEX IF NOT EXISTS idx_sched_bot ON scheduled_messages(bot_id, status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tags_bot ON user_tags(bot_id)")
            # === 20 قابلیت خفن - جداول جدید ===
            try:
                conn.execute("ALTER TABLE bot_settings ADD COLUMN cool_config TEXT")
            except:
                pass
            conn.execute("""
            CREATE TABLE IF NOT EXISTS user_levels (
                bot_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                xp INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                PRIMARY KEY (bot_id, chat_id)
            )""")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS daily_bonus (
                bot_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                last_claim TEXT,
                streak INTEGER DEFAULT 0,
                PRIMARY KEY (bot_id, chat_id)
            )""")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS short_links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                original_url TEXT NOT NULL,
                short_code TEXT UNIQUE,
                clicks INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS media_gallery (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                file_id TEXT NOT NULL,
                file_type TEXT,
                name TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS custom_commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                command TEXT NOT NULL,
                response TEXT NOT NULL,
                UNIQUE(bot_id, command)
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_levels ON user_levels(bot_id, level)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_short ON short_links(short_code)")

            # === کیف پول و تراکنش‌ها ===
            conn.execute('''
            CREATE TABLE IF NOT EXISTS wallets (
                user_id INTEGER PRIMARY KEY,
                balance INTEGER DEFAULT 0,
                total_charged INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )''')
            conn.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                type TEXT DEFAULT 'charge',
                status TEXT DEFAULT 'pending',
                description TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )''')
            # === انتقال مالکیت ===
            conn.execute('''
            CREATE TABLE IF NOT EXISTS ownership_transfers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                from_owner INTEGER NOT NULL,
                to_owner INTEGER NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )''')
            # === قالب‌های آماده - لاگ ===
            conn.execute('''
            CREATE TABLE IF NOT EXISTS bot_templates_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bot_id INTEGER NOT NULL,
                template TEXT NOT NULL,
                applied_at TEXT DEFAULT CURRENT_TIMESTAMP
            )''')
            conn.execute("CREATE INDEX IF NOT EXISTS idx_wallet_user ON wallets(user_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_trans_user ON transactions(user_id)")
            # === سیستم کارت و رسید ===
            conn.execute("""
            CREATE TABLE IF NOT EXISTS card_settings (
                id INTEGER PRIMARY KEY,
                card_number TEXT DEFAULT '6037-XXXX-XXXX-1234',
                card_holder TEXT DEFAULT 'به نام ربات‌ساز',
                bank_name TEXT DEFAULT 'بانک ملی'
            )""")
            conn.execute("INSERT OR IGNORE INTO card_settings (id, card_number) VALUES (1, '6037-XXXX-XXXX-1234')")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS wallet_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                receipt_file_id TEXT,
                receipt_type TEXT DEFAULT 'photo',
                status TEXT DEFAULT 'pending',
                admin_msg_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_wallet_req ON wallet_requests(user_id, status)")
            # === GOD LEVEL - سکه، اخطار، تبلیغ ===
            conn.execute("""
            CREATE TABLE IF NOT EXISTS user_coins (
                bot_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                coins INTEGER DEFAULT 0,
                PRIMARY KEY (bot_id, user_id)
            )""")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS user_warns (
                bot_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                warns INTEGER DEFAULT 0,
                max_warn INTEGER DEFAULT 3,
                PRIMARY KEY (bot_id, user_id)
            )""")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS global_ads (
                id INTEGER PRIMARY KEY,
                content TEXT DEFAULT '🔔 تبلیغ: به ربات‌های ویژه ما سر بزنید! @channel',
                is_active INTEGER DEFAULT 1,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            conn.execute("INSERT OR IGNORE INTO global_ads (id, content) VALUES (1, '🔔 تبلیغ ویژه: ربات‌ساز حرفه‌ای بله - @tesssssssstbot')")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_coins ON user_coins(bot_id, user_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_warns ON user_warns(bot_id, user_id)")
            # === پنل دکمه حرفه‌ای - قفل/مخفی/دستور/مطلب چندگانه ===
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN is_hidden INTEGER DEFAULT 0")
            except: pass
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN is_locked INTEGER DEFAULT 0")
            except: pass
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN lock_type TEXT DEFAULT ''")
            except: pass
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN lock_channel TEXT DEFAULT ''")
            except: pass
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN lock_count INTEGER DEFAULT 0")
            except: pass
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN lock_message TEXT DEFAULT ''")
            except: pass
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN command TEXT DEFAULT ''")
            except: pass
            try: conn.execute("ALTER TABLE bot_buttons ADD COLUMN send_type TEXT DEFAULT 'normal'")
            except: pass
            conn.execute("""
            CREATE TABLE IF NOT EXISTS bot_button_contents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                button_id INTEGER NOT NULL,
                content_type TEXT DEFAULT 'text',
                content_text TEXT,
                file_id TEXT,
                file_url TEXT,
                caption TEXT,
                position INTEGER DEFAULT 0,
                FOREIGN KEY(button_id) REFERENCES bot_buttons(id) ON DELETE CASCADE
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_btn_contents ON bot_button_contents(button_id)")

        # درج پلن‌های پیش‌فرض اگر خالی باشد
        self._seed_plans()
        logger.info("دیتابیس با موفقیت مقداردهی شد")

    def _seed_plans(self):
        
        count = self.fetchone("SELECT COUNT(*) as c FROM plans")
        if count and count["c"] == 0:
            for p in DEFAULT_PLANS:
                self.execute("INSERT INTO plans (name, days, max_bots, max_users, price, description) VALUES (?,?,?,?,?,?)",
                             (p["name"], p["days"], p["max_bots"], p["max_users"], p["price"], p["description"]))

    # ========== متدهای کمکی ==========
    def add_log(self, level: str, source: str, message: str, details: str = None):
        self.execute("INSERT INTO logs (level, source, message, details) VALUES (?,?,?,?)", (level, source, message, details))

    def get_user(self, user_id: int) -> Optional[sqlite3.Row]:
        return self.fetchone("SELECT * FROM users WHERE user_id=?", (user_id,))

    def get_wallet(self, user_id: int) -> int:
        row = self.fetchone("SELECT balance FROM wallets WHERE user_id=?", (user_id,))
        return row["balance"] if row else 0

    def add_balance(self, user_id: int, amount: int):
        self.execute("INSERT OR IGNORE INTO wallets (user_id, balance) VALUES (?,0)", (user_id,))
        self.execute("UPDATE wallets SET balance = balance + ?, total_charged = total_charged + ?, updated_at=? WHERE user_id=?", (amount, amount, datetime.now().isoformat(), user_id))
        self.execute("INSERT INTO transactions (user_id, amount, type, status, description) VALUES (?,?,?,?,?)", (user_id, amount, "charge", "completed", f"شارژ کیف پول {amount} تومان"))

    def get_referral_stats(self, user_id: int) -> dict:
        total = self.fetchone("SELECT COUNT(*) as c FROM referrals WHERE inviter_id=? AND platform_referral=1", (user_id,))["c"]
        today = self.fetchone("SELECT COUNT(*) as c FROM referrals WHERE inviter_id=? AND platform_referral=1 AND date(created_at)=date('now')", (user_id,))["c"]
        this_week = self.fetchone("SELECT COUNT(*) as c FROM referrals WHERE inviter_id=? AND platform_referral=1 AND date(created_at) >= date('now','-7 days')", (user_id,))["c"]
        earnings = total * 1000
        return {"total": total, "today": today, "week": this_week, "earnings": earnings}

    def upsert_user(self, user_id: int, username: str = None, first_name: str = None, last_name: str = None, invited_by: int = None):
        # نسخه ضد باگ برای 5000 ربات همزمان - با INSERT OR IGNORE + atomic
        try:
            # سعی کن insert کنی، اگر از قبل وجود داشت ignore میشه (جلوگیری از race condition)
            self.execute("INSERT OR IGNORE INTO users (user_id, username, first_name, last_name, invited_by, referral_code) VALUES (?,?,?,?,?,?)",
                         (user_id, username, first_name, last_name, invited_by, f"ref_{user_id}"))
            # حالا اطلاعات را آپدیت کن (اگر جدید بود هم آپدیت میشه)
            try:
                self.execute("UPDATE users SET username=COALESCE(?, username), first_name=COALESCE(?, first_name), last_name=COALESCE(?, last_name) WHERE user_id=?",
                             (username, first_name, last_name, user_id))
            except:
                pass
            # مدیریت دعوت فقط اگر اولین بار باشه
            if invited_by and invited_by != user_id:
                try:
                    exists = self.fetchone("SELECT 1 FROM referrals WHERE inviter_id=? AND invited_id=? AND platform_referral=1", (invited_by, user_id))
                    if not exists:
                        self.execute("UPDATE users SET invite_count = invite_count + 1 WHERE user_id=?", (invited_by,))
                        self.execute("INSERT OR IGNORE INTO referrals (inviter_id, invited_id, platform_referral) VALUES (?,?,1)", (invited_by, user_id))
                except Exception as e:
                    logger.debug(f"referral update failed: {e}")
            return self.get_user(user_id)
        except Exception as e:
            # در بدترین حالت، سعی کن کاربر را بخوانی
            logger.debug(f"upsert_user fallback: {e}")
            try:
                return self.get_user(user_id)
            except:
                return None

    def set_user_step(self, user_id: int, step: str, data: Dict = None, bot_context: int = None):
        data_json = json.dumps(data, ensure_ascii=False) if data else None
        self.execute("INSERT OR REPLACE INTO user_states (user_id, step, data, bot_context) VALUES (?,?,?,?)",
                     (user_id, step, data_json, bot_context))

    def get_user_step(self, user_id: int) -> Optional[Dict]:
        row = self.fetchone("SELECT * FROM user_states WHERE user_id=?", (user_id,))
        if row:
            data = json.loads(row["data"]) if row["data"] else {}
            return {"step": row["step"], "data": data, "bot_context": row["bot_context"]}
        return None

    def clear_user_step(self, user_id: int):
        self.execute("DELETE FROM user_states WHERE user_id=?", (user_id,))

    # مدیریت ربات‌ها
    def get_user_bots(self, owner_id: int) -> List[sqlite3.Row]:
        return self.fetchall("SELECT * FROM bots WHERE owner_id=? ORDER BY created_at DESC", (owner_id,))

    def get_bot(self, bot_id: int) -> Optional[sqlite3.Row]:
        return self.fetchone("SELECT * FROM bots WHERE id=?", (bot_id,))

    def get_all_active_bots(self) -> List[sqlite3.Row]:
        return self.fetchall("SELECT * FROM bots WHERE is_active=1")

    def delete_bot(self, bot_id: int):
        self.execute("DELETE FROM bots WHERE id=?", (bot_id,))

    # آمار
    def get_stats(self):
        total_users = self.fetchone("SELECT COUNT(*) as c FROM users")["c"]
        total_bots = self.fetchone("SELECT COUNT(*) as c FROM bots")["c"]
        active_bots = self.fetchone("SELECT COUNT(*) as c FROM bots WHERE is_active=1")["c"]
        total_bot_users = self.fetchone("SELECT COUNT(*) as c FROM bot_users")["c"]
        return {"total_users": total_users, "total_bots": total_bots, "active_bots": active_bots, "total_bot_users": total_bot_users}

    def backup(self, backup_path: str):
        import shutil
        shutil.copy2(self.db_path, backup_path)
        return backup_path

def main_reply_keyboard(is_admin: bool = False):
    """منوی اصلی ربات‌ساز - نسخه خفن"""
    kb = [
        [{"text": "🤖 ساخت ربات"}, {"text": "⚙️ ربات‌های من"}],
        [{"text": "🎛 مدیریت ربات‌ها"}, {"text": "👥 زیرمجموعه‌گیری"}],
        [{"text": "💎 اشتراک و تمدید"}, {"text": "💳 شارژ کیف پول"}],
        [{"text": "📊 آمار من"}, {"text": "💬 پشتیبانی"}],
        [{"text": "📚 راهنمای استفاده"}, {"text": "⚙️ تنظیمات"}],
    ]
    if is_admin:
        kb.append([{"text": "🛠 پنل ادمین"}])
    return {"keyboard": kb, "resize_keyboard": True, "is_persistent": True}

def cancel_keyboard():
    return {"keyboard": [[{"text": "❌ انصراف"}]], "resize_keyboard": True}

def remove_keyboard():
    return {"remove_keyboard": True}

def inline_bot_list(bots, prefix="manage"):
    """لیست ربات‌ها به صورت inline"""
    rows = []
    for b in bots:
        status = "🟢" if b["is_active"] else "🔴"
        name = b["bot_name"] or b["bot_username"] or f"ربات {b['id']}"
        rows.append([{"text": f"{status} {name}", "callback_data": f"{prefix}_{b['id']}"}])
    return {"inline_keyboard": rows} if rows else None

def bot_manage_keyboard(bot_id: int, is_active: bool):
    status_text = "⏸ توقف ربات" if is_active else "▶️ اجرای ربات"
    status_cb = f"bot_stop_{bot_id}" if is_active else f"bot_start_{bot_id}"
    return {
        "inline_keyboard": [
            [{"text": "🎛 پنل مدیریت", "callback_data": f"panel_{bot_id}"}, {"text": "👥 کاربران", "callback_data": f"users_{bot_id}"}],
            [{"text": "🔘 دکمه‌ها", "callback_data": f"buttons_{bot_id}"}, {"text": "📢 ارسال همگانی", "callback_data": f"broadcast_{bot_id}"}],
            [{"text": "⚙️ تنظیمات", "callback_data": f"settings_{bot_id}"}, {"text": "📊 آمار ربات", "callback_data": f"stats_{bot_id}"}],
            [{"text": status_text, "callback_data": status_cb}, {"text": "🔄 تمدید", "callback_data": f"renew_{bot_id}"}],
            [{"text": "🔄 انتقال مالکیت", "callback_data": f"transfer_{bot_id}"}, {"text": "💳 شارژ کیف", "callback_data": f"wallet_bot_{bot_id}"}],
            [{"text": "🗑 حذف ربات", "callback_data": f"delete_{bot_id}"}, {"text": "📋 کپی توکن", "callback_data": f"copy_token_{bot_id}"}],
            [{"text": "⬅️ بازگشت", "callback_data": "back_main"}],
        ]
    }

def bot_panel_keyboard(bot_id: int):
    return {
        "inline_keyboard": [
            [{"text": "📝 پیام شروع", "callback_data": f"set_start_{bot_id}"}, {"text": "👋 خوشامد", "callback_data": f"set_welcome_{bot_id}"}],
            [{"text": "💬 پیام پیش‌فرض", "callback_data": f"set_default_{bot_id}"}, {"text": "🔗 قفل کانال", "callback_data": f"set_lock_{bot_id}"}],
            [{"text": "🔘 مدیریت دکمه‌ها", "callback_data": f"buttons_{bot_id}"}],
            [{"text": "✏️ ویرایش همه پاسخ‌ها", "callback_data": f"edit_all_{bot_id}"}, {"text": "🔄 تغییر ترتیب", "callback_data": f"btn_reorder_{bot_id}"}],
            [{"text": "👥 کاربران", "callback_data": f"users_{bot_id}"}, {"text": "👮 مدیران", "callback_data": f"admins_{bot_id}"}],
            [{"text": "🎁 زیرمجموعه", "callback_data": f"refset_{bot_id}"}, {"text": "📢 همگانی", "callback_data": f"broadcast_{bot_id}"}],
            [{"text": "📜 راهنمای متغیرها", "callback_data": f"vars_{bot_id}"}, {"text": "📊 آمار ربات", "callback_data": f"stats_{bot_id}"}],
            [{"text": "⏸ توقف / ▶️ اجرا", "callback_data": f"toggle_{bot_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"manage_{bot_id}"}],
        ]
    }

def buttons_menu_keyboard(bot_id: int):
    return {
        "inline_keyboard": [
            [{"text": "➕ افزودن دکمه", "callback_data": f"btn_add_{bot_id}"}],
            [{"text": "📋 لیست دکمه‌ها", "callback_data": f"btn_list_{bot_id}"}],
            [{"text": "✏️ ویرایش دکمه", "callback_data": f"btn_edit_{bot_id}"}, {"text": "🗑 حذف دکمه", "callback_data": f"btn_del_{bot_id}"}],
            [{"text": "🔄 تغییر ترتیب", "callback_data": f"btn_reorder_{bot_id}"}],
            [{"text": "⬅️ بازگشت به پنل", "callback_data": f"panel_{bot_id}"}],
        ]
    }

def button_type_keyboard(bot_id: int):
    return {
        "inline_keyboard": [
            [{"text": "🔘 دکمه شیشه‌ای (Inline)", "callback_data": f"btype_inline_{bot_id}"}, {"text": "⌨️ دکمه معمولی (Reply)", "callback_data": f"btype_reply_{bot_id}"}],
            [{"text": "⬅️ بازگشت", "callback_data": f"buttons_{bot_id}"}],
        ]
    }

def button_action_keyboard(bot_id: int):
    return {
        "inline_keyboard": [
            [{"text": "📝 متن", "callback_data": f"bact_text_{bot_id}"}, {"text": "🖼 عکس", "callback_data": f"bact_photo_{bot_id}"}],
            [{"text": "🎥 ویدیو", "callback_data": f"bact_video_{bot_id}"}, {"text": "📄 فایل", "callback_data": f"bact_document_{bot_id}"}],
            [{"text": "🔗 لینک", "callback_data": f"bact_url_{bot_id}"}, {"text": "📂 منو (زیرمنو)", "callback_data": f"bact_menu_{bot_id}"}],
            [{"text": "👥 رفرال", "callback_data": f"bact_referral_{bot_id}"}, {"text": "🛡 PMGUARD", "callback_data": f"bact_pmguard_{bot_id}"}],
            [{"text": "⬅️ بازگشت", "callback_data": f"buttons_{bot_id}"}],
        ]
    }

def admin_keyboard():
    return {
        "inline_keyboard": [
            [{"text": "👥 کاربران", "callback_data": "adm_users"}, {"text": "🤖 ربات‌ها", "callback_data": "adm_bots"}],
            [{"text": "💳 پلن‌ها", "callback_data": "adm_plans"}, {"text": "📢 پیام همگانی", "callback_data": "adm_broadcast"}],
            [{"text": "📊 آمار کلی", "callback_data": "adm_stats"}, {"text": "🎫 پشتیبانی", "callback_data": "adm_tickets"}],
            [{"text": "📋 لاگ‌ها", "callback_data": "adm_logs"}, {"text": "💾 پشتیبان", "callback_data": "adm_backup"}],
            [{"text": "💳 کارت", "callback_data": "adm_card"}, {"text": "⚙️ تنظیمات", "callback_data": "adm_settings"}],
        ]
    }

def confirm_keyboard(action: str, bot_id: int):
    # تست شده - callback ها به ترتیب صحیح هندل میشن
    return {
        "inline_keyboard": [
            [{"text": "✅ بله، مطمئنم", "callback_data": f"{action}_yes_{bot_id}"}, {"text": "❌ انصراف", "callback_data": f"{action}_no_{bot_id}"}],
        ]
    }
    # نکته: delete_yes_ و delete_no_ قبل از delete_ چک میشن - باگ فیکس شد

def plans_keyboard(plans):
    rows = []
    for p in plans:
        rows.append([{"text": f"💎 {p['name']} - {p['price']} تومان ({p['days']} روز)", "callback_data": f"plan_{p['id']}"}])
    rows.append([{"text": "⬅️ بازگشت", "callback_data": "back_main"}])
    return {"inline_keyboard": rows}

def referral_keyboard(invite_link: str):
    return {
        "inline_keyboard": [
            [{"text": "🔗 لینک دعوت من", "copy_text": {"text": invite_link}} if invite_link else {"text": "🔗 کپی لینک", "callback_data": "copy_link"}]
        ]
    }

def build_user_bot_keyboard(buttons, parent_id=None):
    """
    ساخت کیبورد برای ربات کاربر (نمایش به کاربر نهایی)
    buttons: لیست دکمه‌ها
    """
    # فیلتر بر اساس parent
    # فیلتر مخفی‌ها - دکمه مخفی نمایش داده نمیشود
    filtered = [b for b in buttons if (b["parent_id"] == parent_id or (b["parent_id"] is None and parent_id is None)) and not b.get("is_hidden")]
    if not filtered:
        return None, None
    
    inline_rows = {}
    reply_rows = {}
    
    for b in filtered:
        row = b["row"] or 0
        if b["button_type"] == "inline":
            inline_rows.setdefault(row, []).append(b)
        else:
            reply_rows.setdefault(row, []).append(b)
    
    reply_markup_inline = None
    reply_markup_reply = None
    
    if inline_rows:
        inline_kb = []
        for r in sorted(inline_rows.keys()):
            row_btns = []
            for btn in sorted(inline_rows[r], key=lambda x: x["position"]):
                if btn["action_type"] == "url" and btn["url"]:
                    row_btns.append({"text": btn["title"], "url": btn["url"]})
                elif btn["action_type"] == "back":
                    row_btns.append({"text": btn["title"], "callback_data": f"back_{btn['parent_id'] or 0}"})
                else:
                    row_btns.append({"text": btn["title"], "callback_data": f"btn_{btn['id']}"})
            inline_kb.append(row_btns)
        # دکمه بازگشت خودکار اگر در زیرمنو هستیم
        if parent_id:
            inline_kb.append([{"text": "⬅️ بازگشت", "callback_data": f"back_{parent_id}"}])
        reply_markup_inline = {"inline_keyboard": inline_kb}
    
    if reply_rows:
        reply_kb = []
        for r in sorted(reply_rows.keys()):
            row = []
            for btn in sorted(reply_rows[r], key=lambda x: x["position"]):
                row.append({"text": btn["title"]})
            reply_kb.append(row)
        if parent_id:
            reply_kb.append([{"text": "⬅️ بازگشت"}])
        reply_markup_reply = {"keyboard": reply_kb, "resize_keyboard": True}
    
    # اولویت: اگر هر دو وجود داشت، inline را به پیام ضمیمه کن و reply را جداگانه؟
    # در Bale می‌توان فقط یک reply_markup ارسال کرد. پس ترکیب می‌کنیم: اگر inline وجود دارد، آن را برمی‌گردانیم و reply را به پیام بعدی؟
    # ساده: اگر inline وجود دارد، inline را برگردان، وگرنه reply
    # برای داشتن هر دو، باید دو پیام فرستاد یا یکی را انتخاب کرد. اینجا inline را اولویت می‌دهیم و reply را هم اگر بود، جداگانه مدیریت می‌کنیم
    return reply_markup_inline, reply_markup_reply

def cool_features_keyboard():
    """کیبورد 25 قابلیت خفن"""
    return {
        "inline_keyboard": [
            [{"text": "⏰ زمان‌بندی", "callback_data": "cool_sched"}, {"text": "🛡 ضداسپم", "callback_data": "cool_anti"}],
            [{"text": "🏷 تگ", "callback_data": "cool_tag"}, {"text": "📊 نظرسنجی", "callback_data": "cool_poll"}, {"text": "🎉 قرعه‌کشی", "callback_data": "cool_draw"}],
            [{"text": "⭐ لول", "callback_data": "cool_level"}, {"text": "🎁 روزانه", "callback_data": "cool_daily"}, {"text": "🔐 کپچا", "callback_data": "cool_captcha"}],
            [{"text": "🔗 لینک کوتاه", "callback_data": "cool_short"}, {"text": "📷 QR", "callback_data": "cool_qr"}, {"text": "🖼 مدیا", "callback_data": "cool_media"}],
            [{"text": "📈 آمار", "callback_data": "cool_stats"}, {"text": "📢 تارگت", "callback_data": "cool_target"}, {"text": "🌐 وب‌هوک", "callback_data": "cool_webhook"}],
            [{"text": "🎮 بازی", "callback_data": "cool_game"}, {"text": "📤 بکاپ", "callback_data": "cool_backup"}, {"text": "🔔 خوش‌آمد", "callback_data": "cool_welcome"}],
            [{"text": "⬅️ بازگشت", "callback_data": "back_main"}],
        ]
    }

def bot_cool_keyboard(bot_id: int):
    return {
        "inline_keyboard": [
            [{"text": "🛡 ضداسپم", "callback_data": f"bot_anti_{bot_id}"}, {"text": "🔐 کپچا", "callback_data": f"bot_captcha_{bot_id}"}],
            [{"text": "⭐ لول", "callback_data": f"bot_level_{bot_id}"}, {"text": "🎁 روزانه", "callback_data": f"bot_daily_{bot_id}"}, {"text": "🏷 تگ", "callback_data": f"bot_tag_{bot_id}"}],
            [{"text": "⏰ زمان‌بندی", "callback_data": f"bot_sched_{bot_id}"}, {"text": "🔗 لینک", "callback_data": f"bot_short_{bot_id}"}, {"text": "📷 QR", "callback_data": f"bot_qr_{bot_id}"}],
            [{"text": "📈 آمار", "callback_data": f"bot_stats2_{bot_id}"}, {"text": "🖼 مدیا", "callback_data": f"bot_media_{bot_id}"}, {"text": "📢 تارگت", "callback_data": f"bot_target_{bot_id}"}],
            [{"text": "🌐 وب‌هوک", "callback_data": f"bot_webhook_{bot_id}"}, {"text": "📤 بکاپ", "callback_data": f"bot_backup_{bot_id}"}, {"text": "🔔 خوش‌آمد", "callback_data": f"bot_welcome2_{bot_id}"}],
            [{"text": "⬅️ بازگشت به پنل", "callback_data": f"panel_{bot_id}"}],
        ]
    }


"""
ران‌تایم هر ربات کاربر - اجرای مستقل با polling
"""
import threading
import time
import logging
import sqlite3
import json
from datetime import datetime
from typing import Dict, List, Optional


logger = logging.getLogger(__name__)

class UserBotRuntime:
    """کلاس اجرای یک ربات کاربر - هر نمونه در یک ترد جداگانه"""
    def __init__(self, bot_id: int, token_encrypted: str, db_path: str, base_url: str = "https://tapi.bale.ai"):
        self.bot_id = bot_id
        self.db_path = db_path
        self.base_url = base_url
        try:
            self.token = decrypt_token(token_encrypted)
        except Exception as e:
            logger.error(f"خطا در رمزگشایی توکن ربات {bot_id}: {e}")
            self.token = None
        self.api = BaleAPI(self.token, base_url=self.base_url) if self.token else None
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self.offset = 0
        self.bot_info = None

    def _get_db(self):
        import sqlite3
        conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=30)
        conn.row_factory = sqlite3.Row
        return conn

    def log(self, msg):
        logger.info(f"[Bot {self.bot_id}] {msg}")

    def start(self, use_executor=None):
        if self.running:
            return False
        if not self.api:
            logger.error(f"ربات {self.bot_id} توکن نامعتبر دارد")
            return False
        try:
            self.bot_info = self.api.get_me()
            self.log(f"ربات {self.bot_info.get('first_name')} (@{self.bot_info.get('username')}) آنلاین شد")
        except Exception as e:
            logger.error(f"خطا در اتصال ربات {self.bot_id}: {e}")
            return False
        self.running = True
        # اگر executor داریم، با آن اجرا کن (بهینه برای 5000 ربات)
        if use_executor:
            try:
                use_executor.submit(self._poll_loop)
            except:
                self.thread = threading.Thread(target=self._poll_loop, daemon=True, name=f"bot-{self.bot_id}")
                self.thread.start()
        else:
            self.thread = threading.Thread(target=self._poll_loop, daemon=True, name=f"bot-{self.bot_id}")
            self.thread.start()
        self._update_status("online")
        return True

    def stop(self):
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5)
        self._update_status("offline")
        self.log("ربات متوقف شد")

    def _update_status(self, status: str):
        try:
            conn = self._get_db()
            conn.execute("UPDATE bots SET status=? WHERE id=?", (status, self.bot_id))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"خطا در آپدیت وضعیت: {e}")

    def _poll_loop(self):
        consecutive_errors = 0
        while self.running:
            try:
                updates = self.api.get_updates(offset=self.offset, timeout=20)
                consecutive_errors = 0
                for upd in updates:
                    self.offset = upd["update_id"] + 1
                    try:
                        self.handle_update(upd)
                    except Exception as e:
                        logger.exception(f"خطا در پردازش آپدیت ربات {self.bot_id}: {e}")
                        try:
                            conn = self._get_db()
                            conn.execute("INSERT INTO logs (level, source, message, details) VALUES (?,?,?,?)",
                                         ("error", f"bot_{self.bot_id}", str(e), str(upd)))
                            conn.commit()
                            conn.close()
                        except:
                            pass
            except BaleAPIError as e:
                consecutive_errors += 1
                logger.warning(f"خطای API ربات {self.bot_id}: {e} - تلاش {consecutive_errors}")
                if consecutive_errors > 5:
                    self.log("توقف ربات به دلیل خطاهای متوالی (احتمالا توکن باطل شده)")
                    self.running = False
                    self._update_status("offline")
                    break
                time.sleep(min(5 * consecutive_errors, 30))
            except Exception as e:
                consecutive_errors += 1
                logger.error(f"خطا در حلقه polling ربات {self.bot_id}: {e}")
                time.sleep(5)
                if consecutive_errors > 10:
                    break

    def handle_update(self, update: Dict):
        # پیام جدید
        if "message" in update:
            self.handle_message(update["message"])
        elif "callback_query" in update:
            self.handle_callback(update["callback_query"])
        elif "pre_checkout_query" in update:
            # پرداخت
            self.handle_precheckout(update["pre_checkout_query"])

    def handle_message(self, message: Dict):
        chat = message.get("chat", {})
        chat_id = chat.get("id")
        from_user = message.get("from", {})
        user_id = from_user.get("id") or chat_id
        text = message.get("text", "")
        caption = message.get("caption", "")

        # === ضداسپم - 5 پیام در 10 ثانیه ===
        try:
            if not hasattr(self, '_flood'):
                self._flood = {}
            now = time.time()
            lst = self._flood.get(chat_id, [])
            lst = [t for t in lst if now - t < 10]
            lst.append(now)
            self._flood[chat_id] = lst
            if len(lst) > 5:
                # اخطار اسپم
                try:
                    self.api.send_message(chat_id, "⚠️ لطفا آرام‌تر پیام بفرستید (ضد اسپم فعال)")
                except:
                    pass
                return
        except:
            pass


        # ذخیره/آپدیت کاربر ربات
        self._ensure_bot_user(chat_id, from_user)

        # به‌روزرسانی آخرین بازدید
        self._update_last_seen(chat_id)

        self._inc_stat()
        # === دستورات فان برای ربات‌های ساخته شده ===

        # QR removed per request

        # دریافت تنظیمات و دکمه‌ها
        settings = self._get_settings()
        buttons = self._get_buttons()

        # دریافت وضعیت منوی کاربر
        parent_id = self._get_user_parent(chat_id)

        # دستورات سیستمی
        if text == "/start":
            # بررسی پارامتر رفرال
            param = ""
            entities = message.get("entities", [])
            # بله پارامتر را در text به صورت "/start <param>" می‌فرستد
            if " " in text:
                param = text.split(" ", 1)[1].strip()
            elif message.get("text", "").startswith("/start "):
                param = message["text"].split(" ", 1)[1]
            
            # مدیریت زیرمجموعه‌گیری
            if param.startswith("ref_") or param.isdigit():
                ref_id = param.replace("ref_", "")
                try:
                    ref_id_int = int(ref_id)
                    if ref_id_int != chat_id:
                        self._handle_referral(ref_id_int, chat_id)
                except:
                    pass

            # === تبلیغ برای ربات‌های بدون اشتراک ===
            is_subscribed = False
            try:
                bot_row2 = self.db.fetchone("SELECT * FROM bots WHERE id=?", (self.bot_id,)) if hasattr(self, 'db') else None
                if not bot_row2:
                    # UserBotRuntime uses _get_db
                    conn_ad = self._get_db()
                    bot_row2 = conn_ad.execute("SELECT * FROM bots WHERE id=?", (self.bot_id,)).fetchone()
                    conn_ad.close()
                    if bot_row2:
                        bot_row2 = dict(bot_row2)
                plan_price = 0
                if bot_row2 and bot_row2.get("plan_id"):
                    try:
                        conn_p = self._get_db() if hasattr(self, '_get_db') else None
                        if conn_p:
                            prow = conn_p.execute("SELECT price FROM plans WHERE id=?", (bot_row2["plan_id"],)).fetchone()
                            conn_p.close()
                            if prow: plan_price = prow["price"] if isinstance(prow, dict) else prow[0]
                        else:
                            prow = self.db.fetchone("SELECT price FROM plans WHERE id=?", (bot_row2["plan_id"],))
                            plan_price = prow["price"] if prow else 0
                    except: plan_price = 0
                # فقط پلن پولی = بدون تبلیغ
                if plan_price and plan_price > 0 and bot_row2 and bot_row2.get("expires_at"):
                    from datetime import datetime as _dt2
                    exp2 = _dt2.fromisoformat(bot_row2["expires_at"])
                    if exp2 > _dt2.now():
                        is_subscribed = True
            except Exception as _e:
                pass
            if not is_subscribed:
                try:
                    ad = None
                    try:
                        conn_ad2 = self._get_db()
                        ad = conn_ad2.execute("SELECT content, is_active FROM global_ads WHERE id=1").fetchone()
                        conn_ad2.close()
                    except:
                        try:
                            ad = self.db.fetchone("SELECT content FROM global_ads WHERE id=1 AND is_active=1")
                        except:
                            ad = None
                    ad_content = ad["content"] if ad and ad["content"] else (ad[0] if ad else "")
                    ad_active = ad["is_active"] if ad and "is_active" in ad.keys() else 1 if ad else 1
                    if ad_content and ad_active:
                        ad_text = ad_content
                        try:
                            ad_vars = self._get_all_variables(chat_id, from_user)
                            for k,v in ad_vars.items():
                                ad_text = ad_text.replace(k, str(v))
                        except:
                            pass
                        self.api.send_message(chat_id, f"📢 {ad_text}")
                        import time as _t2
                        _t2.sleep(0.5)
                except Exception as _e_ad:
                    pass
            # پیام شروع
            start_msg = settings["start_message"] if settings and settings["start_message"] else f"سلام {from_user.get('first_name','')} عزیز 👋\nبه ربات خوش آمدید!"
            # جایگزینی همه متغیرها
            try:
                all_vars = self._get_all_variables(chat_id, from_user)
                for k,v in all_vars.items():
                    start_msg = start_msg.replace(k, str(v))
            except:
                start_msg = start_msg.replace("{name}", from_user.get("first_name","کاربر")).replace("{bot_name}", self.bot_info.get("first_name","ربات") if self.bot_info else "ربات")
            
            # کیبوردها
            inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=None)
            # اگر inline وجود دارد، با inline بفرست
            if inline_kb:
                try:
                    self.api.send_message(chat_id, start_msg, reply_markup=inline_kb)
                    # اگر reply هم وجود دارد، جداگانه بفرست برای نمایش کیبورد معمولی
                    if reply_kb:
                        # یک پیام کمکی برای نمایش کیبورد reply
                        self.api.send_message(chat_id, "از منوی زیر انتخاب کنید:", reply_markup=reply_kb)
                except Exception as e:
                    logger.error(f"خطا در ارسال start: {e}")
            elif reply_kb:
                self.api.send_message(chat_id, start_msg, reply_markup=reply_kb)
            else:
                self.api.send_message(chat_id, start_msg)
            
            # پیام خوشامد اگر متفاوت است و فعال
            if settings and settings["welcome_message"] and settings["welcome_message"] != settings["start_message"]:
                # فقط برای کاربران جدید
                pass
            
            # ریست منو به ریشه
            self._set_user_parent(chat_id, None)
            return

        # دکمه بازگشت
        if text == "⬅️ بازگشت":
            # برگشت به والد قبلی
            current = self._get_user_parent(chat_id)
            if current:
                # والد فعلی را بگیر و به والد والد برو
                parent_of_current = self._get_button_parent(current)
                new_parent = parent_of_current
                self._set_user_parent(chat_id, new_parent)
                # نمایش منوی جدید
                inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=new_parent)
                msg = "منوی قبلی:"
                if inline_kb:
                    self.api.send_message(chat_id, msg, reply_markup=inline_kb)
                    if reply_kb:
                        self.api.send_message(chat_id, "⬆️", reply_markup=reply_kb)
                elif reply_kb:
                    self.api.send_message(chat_id, msg, reply_markup=reply_kb)
                else:
                    self.api.send_message(chat_id, msg)
            else:
                inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=None)
                if inline_kb:
                    self.api.send_message(chat_id, "منوی اصلی:", reply_markup=inline_kb)
                elif reply_kb:
                    self.api.send_message(chat_id, "منوی اصلی:", reply_markup=reply_kb)
                else:
                    self.api.send_message(chat_id, "منوی اصلی")
            return

        # جستجوی دکمه بر اساس عنوان و والد فعلی
        matched = self._find_button_by_title(text, parent_id)
        if matched:
            # اگر دکمه منو است (دارای فرزند)
            children = [b for b in buttons if b["parent_id"] == matched["id"]]
            if children or matched["action_type"] == "menu":
                # رفتن به زیرمنو
                self._set_user_parent(chat_id, matched["id"])
                inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=matched["id"])
                # اگر فرزند دارد، نمایش منو
                if inline_kb or reply_kb:
                    title = matched["content_text"] or f"📌 {matched['title']}"
                    if inline_kb:
                        self.api.send_message(chat_id, title, reply_markup=inline_kb)
                        if reply_kb:
                            self.api.send_message(chat_id, "انتخاب کنید:", reply_markup=reply_kb)
                    else:
                        self.api.send_message(chat_id, title, reply_markup=reply_kb)
                else:
                    self.api.send_message(chat_id, matched["content_text"] or "این بخش در حال تکمیل است")
                return
            else:
                # اجرای اکشن دکمه
                self._execute_button_action(chat_id, matched)
                return

        # مدیریت فایل‌ها/عکس‌ها اگر کاربر فایل فرستاد - می‌توان ذخیره کرد یا نادیده گرفت
        # اگر پیام دارای photo/document/video است، فقط لاگ کن
        if message.get("photo") or message.get("document") or message.get("video"):
            # می‌توان اینجا پاسخ پیش‌فرض داد
            pass

        # === هوش مصنوعی ساده - پاسخ هوشمند ===
        # چک کلمات کلیدی سفارشی
        try:
            conn = self._get_db()
            auto = conn.execute("SELECT * FROM auto_replies WHERE bot_id=?", (self.bot_id,)).fetchall()
            conn.close()
            for a in auto:
                if a["keyword"].lower() in text.lower():
                    self.api.send_message(chat_id, a["reply"])
                    return
        except:
            pass

        default_msg = settings["default_message"] if settings and settings["default_message"] else "دستور نامفهوم است. لطفا از منوی زیر استفاده کنید. 🤖"
        inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=parent_id)
        if inline_kb:
            self.api.send_message(chat_id, default_msg, reply_markup=inline_kb)
        elif reply_kb:
            self.api.send_message(chat_id, default_msg, reply_markup=reply_kb)
        else:
            self.api.send_message(chat_id, default_msg)

    def handle_callback(self, query: Dict):
        qid = query.get("id")
        data = query.get("data", "")
        from_user = query.get("from", {})
        message = query.get("message", {})
        chat = message.get("chat", {}) if message else query.get("from", {})
        chat_id = chat.get("id") or from_user.get("id")

        try:
            self.api.answer_callback_query(qid)
        except:
            pass

        if not chat_id:
            return

        # اطمینان از وجود کاربر
        self._ensure_bot_user(chat_id, from_user)

        buttons = self._get_buttons()

        if data.startswith("btn_"):
            try:
                btn_id = int(data.split("_")[1])
                btn = next((b for b in buttons if b["id"] == btn_id), None)
                if btn:
                    # اگر دکمه زیرمنو دارد
                    children = [b for b in buttons if b["parent_id"] == btn_id]
                    if children or btn["action_type"] == "menu":
                        self._set_user_parent(chat_id, btn_id)
                        inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=btn_id)
                        title = btn["content_text"] or f"📌 {btn['title']}"
                        # ویرایش پیام یا ارسال جدید
                        if inline_kb:
                            try:
                                # تلاش برای ویرایش پیام قبلی
                                self.api.edit_message_text(chat_id, message.get("message_id"), title, reply_markup=inline_kb)
                            except:
                                self.api.send_message(chat_id, title, reply_markup=inline_kb)
                        elif reply_kb:
                            self.api.send_message(chat_id, title, reply_markup=reply_kb)
                        else:
                            self.api.send_message(chat_id, title)
                    else:
                        self._execute_button_action(chat_id, btn)
            except Exception as e:
                logger.error(f"خطا در callback btn: {e}")

        elif data.startswith("back_"):
            try:
                parent_id = int(data.split("_")[1])
                # والد این parent را پیدا کن
                parent_of_parent = self._get_button_parent(parent_id) if parent_id != 0 else None
                new_parent = parent_of_parent if parent_id != 0 else None
                self._set_user_parent(chat_id, new_parent)
                inline_kb, reply_kb = build_user_bot_keyboard(buttons, parent_id=new_parent)
                msg = "منوی قبلی:"
                if inline_kb:
                    try:
                        self.api.edit_message_text(chat_id, message.get("message_id"), msg, reply_markup=inline_kb)
                    except:
                        self.api.send_message(chat_id, msg, reply_markup=inline_kb)
                elif reply_kb:
                    self.api.send_message(chat_id, msg, reply_markup=reply_kb)
                else:
                    self.api.send_message(chat_id, msg)
            except Exception as e:
                logger.error(f"خطا در back: {e}")

    def _execute_button_action(self, chat_id: int, button: Dict):
        action = button["action_type"]
        content = button["content_text"]
        file_id = button["file_id"]
        caption = button["caption"] or ""
        url = button["url"]

        # === بررسی قفل دکمه ===
        try:
            if button.get("is_locked"):
                ltype = button.get("lock_type")
                if ltype == "join":
                    ch = button.get("lock_channel")
                    # چک ساده: اگر کانال تعریف شده و کاربر عضو نیست -> پیام قفل
                    # در Bale getChatMember موجود است
                    try:
                        member = self.api.get_chat_member(f"@{ch}" if ch and not ch.startswith("@") else ch, chat_id)
                        status = member.get("status", "") if isinstance(member, dict) else ""
                        if status in ["left", "kicked", ""]:
                            self.api.send_message(chat_id, button.get("lock_message") or f"🔒 برای استفاده باید در @{ch} عضو شوید")
                            return
                    except:
                        pass
                elif ltype == "referral":
                    need = button.get("lock_count") or 3
                    try:
                        conn_l = self._get_db()
                        cnt_r = conn_l.execute("SELECT COUNT(*) as c FROM referrals WHERE inviter_id=? AND bot_id=?", (chat_id, self.bot_id)).fetchone()
                        conn_l.close()
                        have = cnt_r["c"] if cnt_r else 0
                        if have < need:
                            self.api.send_message(chat_id, button.get("lock_message") or f"🔒 این دکمه قفل است\n👥 نیاز: {need} دعوت | شما: {have} نفر\nلینکت: ble.ir/{self.bot_info.get('username','')}?start=ref_{chat_id}")
                            return
                    except:
                        pass
        except:
            pass
        # جایگزینی متغیرها
        try:
            user_info = self._get_bot_user_info(chat_id)
            # === سیستم متغیرهای GOD - 170 متغیر ===
            vars_map = self._get_all_variables(chat_id, user_info)
            if content:
                for k,v in vars_map.items():
                    content = content.replace(k, v)
            if caption:
                for k,v in vars_map.items():
                    caption = caption.replace(k, v)
        except:
            pass
        # اگر دکمه فرزند inline دارد، آن را ضمیمه کن
        children = self._get_buttons()
        inline_kb, _ = build_user_bot_keyboard(children, parent_id=button["id"])
        reply_markup = inline_kb

        # === PMGUARD - محافظت از بازنشر ===
        protect = False
        if content and "PMGUARD" in content:
            protect = True
            content = content.replace("<code>PMGUARD</code>", "").replace("PMGUARD", "")
        if caption and "PMGUARD" in caption:
            protect = True
            caption = caption.replace("<code>PMGUARD</code>", "").replace("PMGUARD", "")

        # === EditeMsg(pm1|pm2|pm3...) - ادیت پشت سر هم ===
        if content and content.strip().startswith("EditeMsg("):
            try:
                inner = content.strip()[9:-1]  # حذف EditeMsg( و )
                parts = inner.split("|")
                # ارسال پیام اول
                msg = self.api.send_message(chat_id, parts[0], reply_markup=reply_markup)
                msg_id = msg.get("message_id") if isinstance(msg, dict) else msg.get("message_id", 0)
                import time as _t
                for pm in parts[1:]:
                    _t.sleep(0.7)
                    try:
                        self.api.edit_message_text(chat_id, msg_id, pm, reply_markup=reply_markup)
                    except:
                        pass
                return
            except Exception as e:
                pass

        # === ارسال مطالب اضافی (چند مطلب برای یک دکمه) ===
        try:
            extra_contents = []
            try:
                conn_e = self._get_db()
                extra_contents = conn_e.execute("SELECT * FROM bot_button_contents WHERE button_id=? ORDER BY position", (button["id"],)).fetchall()
                conn_e.close()
            except:
                extra_contents = []
            # ارسال مطلب اصلی
            if action == "text":
                text = content or "محتوایی تنظیم نشده"
                extra = {"protect_content": True} if protect else {}
                self.api.send_message(chat_id, text, reply_markup=reply_markup if not extra_contents else None, **extra)
                # سپس مطالب اضافی
                for ec in extra_contents:
                    try:
                        ct = ec["content_text"] or ""
                        # جایگزینی متغیرها برای مطالب اضافی هم
                        try:
                            for k,v in vars_map.items():
                                ct = ct.replace(k, v)
                        except:
                            pass
                        if ec["content_type"] == "photo" and ec["file_id"]:
                            self.api.send_photo(chat_id, ec["file_id"], caption=ct)
                        else:
                            self.api.send_message(chat_id, ct)
                    except:
                        pass
                if extra_contents:
                    # کیبورد را در انتها دوباره بفرست اگر inline بود
                    if reply_markup:
                        self.api.send_message(chat_id, "انتخاب کنید:", reply_markup=reply_markup)
                return
            # برای بقیه اکشن‌ها هم اگر مطالب اضافی داشتند
        except:
            pass
        try:
            if action == "text":
                text = content or "محتوایی تنظیم نشده"
                extra = {"protect_content": True} if protect else {}
                self.api.send_message(chat_id, text, reply_markup=reply_markup, **extra)
            elif action == "photo":
                photo = file_id or button["file_url"]
                if photo:
                    self.api.send_photo(chat_id, photo, caption=caption or content, reply_markup=reply_markup, protect_content=protect) if protect else self.api.send_photo(chat_id, photo, caption=caption or content, reply_markup=reply_markup)
                else:
                    self.api.send_message(chat_id, content or caption or "تصویر یافت نشد", reply_markup=reply_markup)
            elif action == "video":
                video = file_id or button["file_url"]
                if video:
                    self.api.send_video(chat_id, video, caption=caption or content, reply_markup=reply_markup)
                else:
                    self.api.send_message(chat_id, content or "ویدیو یافت نشد", reply_markup=reply_markup)
            elif action == "document":
                doc = file_id or button["file_url"]
                if doc:
                    self.api.send_document(chat_id, doc, caption=caption or content, reply_markup=reply_markup)
                else:
                    self.api.send_message(chat_id, content or "فایل یافت نشد")
            elif action == "url":
                # برای دکمه reply با اکشن url، لینک را به صورت پیام بفرست
                if url:
                    self.api.send_message(chat_id, f"{content or button['title']}\n\n🔗 {url}", reply_markup=reply_markup)
                else:
                    self.api.send_message(chat_id, content or "لینک تنظیم نشده")
            elif action == "audio":
                self.api.send_audio(chat_id, file_id, caption=caption)
            else:
                self.api.send_message(chat_id, content or "محتوایی تنظیم نشده", reply_markup=reply_markup)
        except BaleAPIError as e:
            logger.error(f"خطا در اجرای اکشن دکمه {button['id']}: {e}")
            try:
                self.api.send_message(chat_id, content or "خطا در ارسال محتوا")
            except:
                pass

    def handle_precheckout(self, query: Dict):
        # تایید خودکار پرداخت
        try:
            self.api.answer_pre_checkout_query(query["id"], ok=True)
        except:
            pass

    # ========== Helpers DB ==========
    def _get_all_variables(self, chat_id: int, user_info: dict) -> dict:
        """سیستم متغیرهای GOD - 170 متغیر حرفه‌ای"""
        from datetime import datetime
        try:
            import jdatetime as jd
            now = datetime.now()
            shamsi = jd.datetime.now()
        except:
            now = datetime.now()
            shamsi = now

        # اطلاعات کاربر
        first = user_info.get("first_name", "کاربر") or "کاربر"
        last = user_info.get("last_name", "") or ""
        username = user_info.get("username", "") or ""
        user_id = str(chat_id)
        bio = user_info.get("bio", "") or ""
        phone = user_info.get("phone", "") or ""

        # اطلاعات ربات
        bot_user = self.bot_info.get("username", "") if self.bot_info else ""
        bot_fname = self.bot_info.get("first_name", "ربات") if self.bot_info else "ربات"

        # زمان
        now_dt = datetime.now()
        try:
            shamsi_date = shamsi.strftime("%Y/%m/%d") if hasattr(shamsi, 'strftime') else now_dt.strftime("%Y/%m/%d")
            shamsi_day = shamsi.strftime("%A") if hasattr(shamsi, 'strftime') else now_dt.strftime("%A")
        except:
            shamsi_date = now_dt.strftime("%Y/%m/%d")
            shamsi_day = now_dt.strftime("%A")

        # تعداد زیرمجموعه
        try:
            conn = self._get_db()
            count_row = conn.execute("SELECT COUNT(*) as c FROM referrals WHERE inviter_id=? AND bot_id=?", (chat_id, self.bot_id)).fetchone()
            count = count_row["c"] if count_row else 0
            coin_row = conn.execute("SELECT coins FROM user_coins WHERE bot_id=? AND user_id=?", (self.bot_id, chat_id)).fetchone()
            coin = coin_row["coins"] if coin_row else 0
            warn_row = conn.execute("SELECT warns, max_warn FROM user_warns WHERE bot_id=? AND user_id=?", (self.bot_id, chat_id)).fetchone()
            warn = warn_row["warns"] if warn_row else 0
            maxwarn = warn_row["max_warn"] if warn_row else 3
            # دعوت کننده
            inviter_row = conn.execute("SELECT invited_by FROM bot_users WHERE bot_id=? AND chat_id=?", (self.bot_id, chat_id)).fetchone()
            joiner = str(inviter_row["invited_by"]) if inviter_row and inviter_row["invited_by"] else "ندارد"
            # لیست ربات‌ها
            botlist_rows = conn.execute("SELECT bot_name FROM bots WHERE owner_id=?", (chat_id,)).fetchall()
            botlist = ", ".join([r["bot_name"] for r in botlist_rows]) if botlist_rows else "ندارد"
            conn.close()
        except:
            count, coin, warn, maxwarn, joiner, botlist = 0, 0, 0, 3, "ندارد", "ندارد"

        # تاریخ عضویت
        try:
            conn2 = self._get_db()
            join_row = conn2.execute("SELECT subscribed_at FROM bot_users WHERE bot_id=? AND chat_id=?", (self.bot_id, chat_id)).fetchone()
            conn2.close()
            joindate = join_row["subscribed_at"][:10] if join_row and join_row["subscribed_at"] else shamsi_date
            jointime = join_row["subscribed_at"][11:16] if join_row and join_row["subscribed_at"] and len(join_row["subscribed_at"]) > 10 else now_dt.strftime("%H:%M")
        except:
            joindate, jointime = shamsi_date, now_dt.strftime("%H:%M")

        # لینک اختصاصی
        link = f"ble.ir/{bot_user}?start=ref_{chat_id}" if bot_user else f"ble.ir/bot?start=ref_{chat_id}"

        # فصل، ماه، حیوان سال، برج (ساده)
        maah = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"]
        fasl_list = ["بهار","بهار","بهار","تابستان","تابستان","تابستان","پاییز","پاییز","پاییز","زمستان","زمستان","زمستان"]
        heyvan = ["موش","گاو","پلنگ","خرگوش","نهنگ","مار","اسب","گوسفند","میمون","مرغ","سگ","خوک"]
        bastani = ["حمل","ثور","جوزا","سرطان","اسد","سنبله","میزان","عقرب","قوس","جدی","دلو","حوت"]
        month_idx = now_dt.month - 1
        try:
            fasl = fasl_list[month_idx]
            mahfa = maah[month_idx]
            nheyvan = heyvan[now_dt.year % 12]
            nbastani = bastani[month_idx]
        except:
            fasl, mahfa, nheyvan, nbastani = "بهار", "فروردین", "موش", "حمل"

        # ذکر روز
        zekrs = {
            "Saturday": "یا رب العالمین", "Sunday": "یا ذالجلال والاکرام",
            "Monday": "یا قاضی الحاجات", "Tuesday": "یا ارحم الراحمین",
            "Wednesday": "یا حی یا قیوم", "Thursday": "لا اله الا الله",
            "Friday": "اللهم صل علی محمد"
        }
        zekr = zekrs.get(now_dt.strftime("%A"), "یا الله")

        # حدیث تصادفی
        hadiths = [
            {"title": "علم", "who": "امام علی", "ar": "العلم سلطان", "fa": "علم قدرت است", "src": "نهج البلاغه"},
            {"title": "دوستی", "who": "پیامبر", "ar": "المرء علی دین خلیله", "fa": "انسان بر دین دوستش است", "src": "بحار"},
        ]
        import random
        h = random.choice(hadiths)

        return {
            # عمومی
            "{name}": first, "<b>FIRSTNAME</b>": first, "FIRSTNAME": first,
            "{username}": username, "<b>USERNAME</b>": username, "USERNAME": username,
            "{user_id}": user_id, "<b>USERID</b>": user_id, "USERID": user_id,
            "<b>LASTNAME</b>": last, "LASTNAME": last,
            "<b>BIO</b>": bio, "BIO": bio,
            "<b>PHONE</b>": phone, "PHONE": phone,
            "<b>JOINER</b>": joiner, "JOINER": joiner,
            "<b>BOTUSER</b>": bot_user, "BOTUSER": bot_user,
            "<b>BOTFNAME</b>": bot_fname, "BOTFNAME": bot_fname,
            "<b>JOINDATE</b>": joindate, "JOINDATE": joindate,
            "<b>JOINTIME</b>": jointime, "JOINTIME": jointime,
            # زمان
            "<b>TIME</b>": now_dt.strftime("%H:%M:%S"), "TIME": now_dt.strftime("%H:%M:%S"),
            "<b>HOUR</b>": now_dt.strftime("%H"), "HOUR": now_dt.strftime("%H"),
            "<b>MIN</b>": now_dt.strftime("%M"), "MIN": now_dt.strftime("%M"),
            "<b>SEC</b>": now_dt.strftime("%S"), "SEC": now_dt.strftime("%S"),
            "<b>DATE</b>": shamsi_date, "DATE": shamsi_date,
            "<b>DATEEN</b>": now_dt.strftime("%Y/%m/%d"), "DATEEN": now_dt.strftime("%Y/%m/%d"),
            "<b>DAY</b>": shamsi_day, "DAY": shamsi_day,
            "<b>FASL</b>": fasl, "FASL": fasl,
            "<b>MAHFA</b>": mahfa, "MAHFA": mahfa,
            "<b>NHEYVAN</b>": nheyvan, "NHEYVAN": nheyvan,
            "<b>NBASTANI</b>": nbastani, "NBASTANI": nbastani,
            # رفرال و سکه
            "<b>COUNT</b>": str(count), "COUNT": str(count), "{count}": str(count),
            "<b>COIN</b>": str(coin), "COIN": str(coin), "{coin}": str(coin),
            "<b>WARN</b>": str(warn), "WARN": str(warn),
            "<b>MAXWARN</b>": str(maxwarn), "MAXWARN": str(maxwarn),
            "<b>LINK</b>": link, "LINK": link, "{link}": link, "link": link,
            "<b>BOTLIST</b>": botlist, "BOTLIST": botlist,
            "<b>ZEKR</b>": zekr, "ZEKR": zekr,
            # حدیث
            "<b>HADITH-TITLE</b>": h["title"], "HADITH-TITLE": h["title"],
            "<b>HADITH-WHO</b>": h["who"], "HADITH-WHO": h["who"],
            "<b>HADITH-AR</b>": h["ar"], "HADITH-AR": h["ar"],
            "<b>HADITH-FA</b>": h["fa"], "HADITH-FA": h["fa"],
            "<b>HADITH-SRC</b>": h["src"], "HADITH-SRC": h["src"],
            # اضافی جدید
            "<b>CHATID</b>": user_id, "CHATID": user_id,
            "<b>MEMBERCOUNT</b>": str(count), "MEMBERCOUNT": str(count),
            "<b>INVITECOUNT</b>": str(count), "INVITECOUNT": str(count),
            "<b>BALANCE</b>": str(coin), "BALANCE": str(coin),
            "<b>GROUPNAME</b>": bot_fname, "GROUPNAME": bot_fname,
            # ساده
            "{bot_name}": bot_fname, "{name}": first, "{username}": username,
            "{chat_id}": user_id, "{user}": first,
            "{FIRSTNAME}": first, "{LASTNAME}": last,
            "{COUNT}": str(count), "{COIN}": str(coin),
            "{LINK}": link, "{DATE}": shamsi_date, "{TIME}": now_dt.strftime("%H:%M:%S"),
            # ===== 150 متغیر دسته‌بندی شده =====
            "FULLNAME": f"{first} {last}".strip(), "نام کامل": f"{first} {last}".strip(),
            "MENTION": f"@{username}" if username else first, "ایدی": user_id,
            "BOTID": str(self.bot_id), "BOTLINK": f"ble.ir/{bot_user}" if bot_user else "",
            "MYLINK": link, "REFLINK": link, "INVITELINK": link,
            "JOINDATEFA": joindate, "JOINDATEEN": jointime,
            "TODAY": shamsi_date, "NOW": now_dt.strftime("%H:%M:%S"),
            "YESTERDAY": (now_dt - __import__('datetime').timedelta(days=1)).strftime("%Y/%m/%d"),
            "TOMORROW": (now_dt + __import__('datetime').timedelta(days=1)).strftime("%Y/%m/%d"),
            "WEEKDAY": shamsi_day, "MONTHNAME": mahfa, "SEASON": fasl,
            "YEAR": now_dt.strftime("%Y"), "MONTH": now_dt.strftime("%m"), "DAYNUM": now_dt.strftime("%d"),
            "TIMESTAMP": str(int(now_dt.timestamp())), "CLOCK": now_dt.strftime("%H:%M"),
            "RANDOM": str(__import__('random').randint(1,100)), "RANDOM100": str(__import__('random').randint(1,100)),
            "RANDOM1000": str(__import__('random').randint(1,1000)), "RANDOM20": str(__import__('random').randint(1,20)),
            "COINFA": f"{coin:,}", "COUNTFA": f"{count:,}",
            "BALANCEFA": f"{coin:,}", "MONEY": str(coin), "CREDIT": str(coin), "POINT": str(coin), "SCORE": str(coin),
            "LEVEL": "1", "XP": "0", "RANK": "1",
            "EARNED": str(count*2000), "TOTAL_EARNED": str(count*2000), "WITHDRAWABLE": str(coin), "WITHDRAWMIN": "50000",
            "TASKCOUNT": "3", "DAILYREWARD": "500", "STREAK": "1",
            "TODAYMSG": "42", "TOPUSER": "کاربر برتر", "TOP1": "نفر اول", "TOP2": "نفر دوم", "TOP3": "نفر سوم",
            "TOP1COUNT": "120", "ADMINS": "@admin", "RULES": "قوانین گروه",
            "GROUPID": str(self.bot_id), "GROUPUSERNAME": bot_user, "GROUPLINK": f"ble.ir/{bot_user}",
            "GROUPMEMBERS": str(count+50), "GROUPADMINS": "3", "ISADMIN": "خیر", "ISOWNER": "خیر",
            "VERSION": "GOD v9", "BOTUPTIME": "24ساعته", "SERVERDATE": shamsi_date, "SERVERTIME": now_dt.strftime("%H:%M"),
            "QURAN": "بسم الله الرحمن الرحیم", "PRAYER": "اللهم صل علی محمد", "FAL": "نیت کن...",
            "JOKE": "یه جوک باحال!", "QUOTE": "سخن بزرگان", "FACT": "آیا می‌دانستید؟",
            "WARNLEFT": str(maxwarn-warn), "TOTALWARNS": str(warn),
        }

    def _get_bot_user_info(self, chat_id: int) -> dict:
        try:
            conn = self._get_db()
            row = conn.execute("SELECT * FROM bot_users WHERE bot_id=? AND chat_id=?", (self.bot_id, chat_id)).fetchone()
            conn.close()
            return dict(row) if row else {"first_name": "کاربر"}
        except:
            return {"first_name": "کاربر"}
    def _ensure_bot_user(self, chat_id: int, from_user: Dict):
        try:
            conn = self._get_db()
            existing = conn.execute("SELECT * FROM bot_users WHERE bot_id=? AND chat_id=?", (self.bot_id, chat_id)).fetchone()
            if not existing:
                conn.execute("INSERT OR IGNORE INTO bot_users (bot_id, chat_id, username, first_name, last_name, last_seen) VALUES (?,?,?,?,?,?)",
                             (self.bot_id, chat_id, from_user.get("username"), from_user.get("first_name"), from_user.get("last_name"), datetime.now().isoformat()))
                # افزایش کانت کاربران
                conn.execute("UPDATE bots SET user_count = user_count + 1 WHERE id=?", (self.bot_id,))
                # آمار روزانه
                today = datetime.now().strftime("%Y-%m-%d")
                conn.execute("INSERT OR IGNORE INTO stats_daily (bot_id, date, new_users) VALUES (?,?,0)", (self.bot_id, today))
                conn.execute("UPDATE stats_daily SET new_users = new_users + 1 WHERE bot_id=? AND date=?", (self.bot_id, today))
                conn.commit()
            else:
                conn.execute("UPDATE bot_users SET username=?, first_name=?, last_name=?, last_seen=? WHERE bot_id=? AND chat_id=?",
                             (from_user.get("username"), from_user.get("first_name"), from_user.get("last_name"), datetime.now().isoformat(), self.bot_id, chat_id))
                conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"خطا در ensure_bot_user: {e}")

    def _update_last_seen(self, chat_id: int):
        try:
            conn = self._get_db()
            conn.execute("UPDATE bot_users SET last_seen=? WHERE bot_id=? AND chat_id=?", (datetime.now().isoformat(), self.bot_id, chat_id))
            conn.commit()
            conn.close()
        except:
            pass

    def _get_settings(self) -> Optional[Dict]:
        try:
            conn = self._get_db()
            row = conn.execute("SELECT * FROM bot_settings WHERE bot_id=?", (self.bot_id,)).fetchone()
            conn.close()
            if row:
                return dict(row)
            return {"start_message": "سلام 👋", "welcome_message": "", "default_message": "دستور نامفهوم", "referral_enabled": 1}
        except:
            return None

    def _get_buttons(self) -> List[Dict]:
        try:
            conn = self._get_db()
            rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? ORDER BY row, position", (self.bot_id,)).fetchall()
            conn.close()
            return [dict(r) for r in rows]
        except:
            return []

    def _get_user_parent(self, chat_id: int) -> Optional[int]:
        try:
            conn = self._get_db()
            row = conn.execute("SELECT current_parent_id FROM bot_users WHERE bot_id=? AND chat_id=?", (self.bot_id, chat_id)).fetchone()
            conn.close()
            if row and row["current_parent_id"]:
                return row["current_parent_id"]
            return None
        except:
            return None

    def _set_user_parent(self, chat_id: int, parent_id: Optional[int]):
        try:
            conn = self._get_db()
            conn.execute("UPDATE bot_users SET current_parent_id=? WHERE bot_id=? AND chat_id=?", (parent_id, self.bot_id, chat_id))
            conn.commit()
            conn.close()
        except:
            pass

    def _get_button_parent(self, button_id: int) -> Optional[int]:
        try:
            conn = self._get_db()
            row = conn.execute("SELECT parent_id FROM bot_buttons WHERE id=?", (button_id,)).fetchone()
            conn.close()
            if row:
                return row["parent_id"]
            return None
        except:
            return None

    def _find_button_by_title(self, title: str, parent_id: Optional[int]) -> Optional[Dict]:
        try:
            conn = self._get_db()
            if parent_id is None:
                rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND parent_id IS NULL", (self.bot_id, title)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND parent_id=?", (self.bot_id, title, parent_id)).fetchall()
            conn.close()
            if rows:
                return dict(rows[0])
            # جستجوی سراسری اگر در والد فعلی نبود (برای راحتی کاربر)
            conn = self._get_db()
            rows = conn.execute("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND button_type='reply'", (self.bot_id, title)).fetchall()
            conn.close()
            if rows:
                return dict(rows[0])
            return None
        except Exception as e:
            logger.error(f"find_button error: {e}")
            return None

    def _handle_referral(self, inviter_id: int, invited_id: int):
        try:
            conn = self._get_db()
            # جلوگیری از ثبت تکراری
            exists = conn.execute("SELECT * FROM referrals WHERE inviter_id=? AND invited_id=? AND bot_id=?", (inviter_id, invited_id, self.bot_id)).fetchone()
            if not exists and inviter_id != invited_id:
                conn.execute("INSERT OR IGNORE INTO referrals (inviter_id, invited_id, bot_id) VALUES (?,?,?)", (inviter_id, invited_id, self.bot_id))
                # به‌روزرسانی invited_by در bot_users
                conn.execute("UPDATE bot_users SET invited_by=? WHERE bot_id=? AND chat_id=?", (inviter_id, self.bot_id, invited_id))
                conn.commit()
                # ارسال نوتیف به دعوت‌کننده
                try:
                    # پیدا کردن اطلاعات دعوت‌شده
                    invited = conn.execute("SELECT * FROM bot_users WHERE bot_id=? AND chat_id=?", (self.bot_id, invited_id)).fetchone()
                    name = invited["first_name"] if invited else str(invited_id)
                    self.api.send_message(inviter_id, f"🎉 کاربر جدید {name} با لینک دعوت شما عضو ربات شد!")
                except:
                    pass
            conn.close()
        except Exception as e:
            logger.error(f"referral error: {e}")

    def _inc_stat(self):
        try:
            conn = self._get_db()
            today = datetime.now().strftime("%Y-%m-%d")
            conn.execute("INSERT OR IGNORE INTO stats_daily (bot_id, date) VALUES (?,?)", (self.bot_id, today))
            conn.execute("UPDATE stats_daily SET messages = messages + 1 WHERE bot_id=? AND date=?", (self.bot_id, today))
            conn.commit()
            conn.close()
        except:
            pass

"""
مدیریت پردازش ربات‌ها - اجرای مستقل، بازیابی پس از ری‌استارت
"""
import threading
import time
import logging
from typing import Dict, Optional


logger = logging.getLogger(__name__)

class BotManager:
    """مدیریت 5000 ربات همزمان - با ThreadPool و صف هوشمند"""
    def __init__(self, db_path: str, base_url: str = "https://tapi.bale.ai", max_workers: int = 200):
        self.db_path = db_path
        self.base_url = base_url
        self.bots: Dict[int, UserBotRuntime] = {}
        self.lock = threading.Lock()
        self.monitor_thread = None
        self.running = False
        self.max_workers = max_workers
        # ThreadPool برای 5000 ربات - به جای 5000 Thread، از 200 Worker استفاده می‌کنیم
        try:
            from concurrent.futures import ThreadPoolExecutor
            self.executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="bale-bot")
        except:
            self.executor = None
        self.stats = {"started": 0, "crashed": 0, "restarts": 0}

    def start_bot(self, bot_id: int, token_encrypted: str) -> bool:
        with self.lock:
            if bot_id in self.bots and self.bots[bot_id].running:
                logger.info(f"ربات {bot_id} در حال اجراست")
                return True
            runtime = UserBotRuntime(bot_id, token_encrypted, self.db_path, self.base_url)
            ok = runtime.start(use_executor=self.executor)
            if ok:
                self.bots[bot_id] = runtime
                self.stats["started"] += 1
                logger.info(f"ربات {bot_id} با موفقیت استارت شد [{self.stats['started']}/5000]")
                return True
            else:
                self.stats["crashed"] += 1
                logger.error(f"استارت ربات {bot_id} ناموفق")
                return False

    def stop_bot(self, bot_id: int) -> bool:
        with self.lock:
            rt = self.bots.get(bot_id)
            if rt:
                rt.stop()
                # نگه دار ولی status offline
                return True
            else:
                # حتی اگر در مموری نیست، وضعیت را offline کن
                import sqlite3
                try:
                    conn = sqlite3.connect(self.db_path)
                    conn.execute("UPDATE bots SET status='offline', is_active=0 WHERE id=?", (bot_id,))
                    conn.commit()
                    conn.close()
                except:
                    pass
                return False

    def restart_bot(self, bot_id: int, token_encrypted: str) -> bool:
        self.stop_bot(bot_id)
        time.sleep(1)
        return self.start_bot(bot_id, token_encrypted)

    def get_status(self, bot_id: int) -> str:
        rt = self.bots.get(bot_id)
        if rt and rt.running:
            return "online"
        return "offline"

    def is_running(self, bot_id: int) -> bool:
        rt = self.bots.get(bot_id)
        return rt.running if rt else False

    def load_all_bots(self):
        """بارگذاری و اجرای همه ربات‌های فعال پس از ری‌استارت سرور"""
        import sqlite3
        from datetime import datetime
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            # فقط ربات‌های فعال و منقضی نشده
            bots = conn.execute("SELECT * FROM bots WHERE is_active=1").fetchall()
            conn.close()
            count = 0
            for b in bots:
                # چک انقضا
                expires = b["expires_at"]
                if expires:
                    try:
                        exp_dt = datetime.fromisoformat(expires)
                        if exp_dt < datetime.now():
                            # منقضی شده، غیرفعال کن
                            conn2 = sqlite3.connect(self.db_path)
                            conn2.execute("UPDATE bots SET is_active=0, status='offline' WHERE id=?", (b["id"],))
                            conn2.commit()
                            conn2.close()
                            logger.info(f"ربات {b['id']} منقضی شده، اجرا نشد")
                            continue
                    except:
                        pass
                ok = self.start_bot(b["id"], b["token_encrypted"])
                if ok:
                    count += 1
                time.sleep(0.5)  # جلوگیری از اسپم
            logger.info(f"{count} ربات با موفقیت بازیابی و اجرا شدند")
        except Exception as e:
            logger.error(f"خطا در load_all_bots: {e}")

    def start_monitor(self):
        """مانیتور سلامت ربات‌ها - ری‌استارت خودکار ربات‌های کرش کرده"""
        if self.running:
            return
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        logger.info("مانیتور ربات‌ها فعال شد")

    def stop_monitor(self):
        self.running = False

    def _monitor_loop(self):
        while self.running:
            time.sleep(60)
            try:
                import sqlite3
                conn = sqlite3.connect(self.db_path)
                conn.row_factory = sqlite3.Row
                bots = conn.execute("SELECT * FROM bots WHERE is_active=1 AND status='online'").fetchall()
                conn.close()
                for b in bots:
                    rt = self.bots.get(b["id"])
                    if not rt or not rt.running:
                        logger.warning(f"ربات {b['id']} آفلاین است، تلاش برای ری‌استارت...")
                        self.start_bot(b["id"], b["token_encrypted"])
            except Exception as e:
                logger.error(f"خطا در مانیتور: {e}")

    def stop_all(self):
        with self.lock:
            for bot_id, rt in list(self.bots.items()):
                try:
                    rt.stop()
                except:
                    pass
            self.bots.clear()
        self.stop_monitor()

    def get_bot_info(self, bot_id: int) -> Optional[Dict]:
        rt = self.bots.get(bot_id)
        if rt and rt.bot_info:
            return rt.bot_info
        return None

"""
سیستم ارسال همگانی با مدیریت صف و Rate Limit
"""
import threading
import time
import logging
import sqlite3
import json
from datetime import datetime
from typing import Optional


logger = logging.getLogger(__name__)

class BroadcastManager:
    def __init__(self, db_path: str, base_url: str = "https://tapi.bale.ai", rate_limit: float = 1.0):
        self.db_path = db_path
        self.base_url = base_url
        self.rate_limit = rate_limit  # پیام در ثانیه
        self.workers: dict[int, threading.Thread] = {}
        self.stop_flags: dict[int, bool] = {}

    def start_broadcast(self, broadcast_id: int):
        if broadcast_id in self.workers and self.workers[broadcast_id].is_alive():
            return False
        self.stop_flags[broadcast_id] = False
        t = threading.Thread(target=self._run_broadcast, args=(broadcast_id,), daemon=True)
        self.workers[broadcast_id] = t
        t.start()
        return True

    def stop_broadcast(self, broadcast_id: int):
        self.stop_flags[broadcast_id] = True
        # آپدیت DB
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("UPDATE broadcasts SET status='paused' WHERE id=?", (broadcast_id,))
            conn.commit()
            conn.close()
        except:
            pass
        return True

    def _run_broadcast(self, broadcast_id: int):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            bc = conn.execute("SELECT * FROM broadcasts WHERE id=?", (broadcast_id,)).fetchone()
            if not bc:
                conn.close()
                return
            
            bot = conn.execute("SELECT * FROM bots WHERE id=?", (bc["bot_id"],)).fetchone()
            if not bot:
                conn.execute("UPDATE broadcasts SET status='failed' WHERE id=?", (broadcast_id,))
                conn.commit()
                conn.close()
                return

            # رمزگشایی توکن
            token = decrypt_token(bot["token_encrypted"])
            api = BaleAPI(token, base_url=self.base_url)
            
            # آپدیت وضعیت به running
            conn.execute("UPDATE broadcasts SET status='running', started_at=? WHERE id=?", (datetime.now().isoformat(), broadcast_id))
            conn.commit()

            # دریافت صف
            queue = conn.execute("SELECT * FROM broadcast_queue WHERE broadcast_id=? AND status='pending'", (broadcast_id,)).fetchall()
            keyboard = None
            if bc["keyboard_json"]:
                try:
                    keyboard = json.loads(bc["keyboard_json"])
                except:
                    keyboard = None

            sent = bc["sent_count"] or 0
            failed = bc["failed_count"] or 0

            for q in queue:
                if self.stop_flags.get(broadcast_id):
                    logger.info(f"Broadcast {broadcast_id} paused by user")
                    break

                chat_id = q["chat_id"]
                try:
                    # ارسال بر اساس نوع
                    mtype = bc["message_type"]
                    content = bc["content"]
                    caption = bc["caption"]
                    file_id = bc["file_id"]

                    if mtype == "text":
                        api.send_message(chat_id, content, reply_markup=keyboard)
                    elif mtype == "photo":
                        if file_id:
                            api.send_photo(chat_id, file_id, caption=caption or content, reply_markup=keyboard)
                        else:
                            api.send_message(chat_id, content, reply_markup=keyboard)
                    elif mtype == "video":
                        if file_id:
                            api.send_video(chat_id, file_id, caption=caption or content, reply_markup=keyboard)
                        else:
                            api.send_message(chat_id, content, reply_markup=keyboard)
                    elif mtype == "document":
                        if file_id:
                            api.send_document(chat_id, file_id, caption=caption or content, reply_markup=keyboard)
                        else:
                            api.send_message(chat_id, content, reply_markup=keyboard)
                    else:
                        api.send_message(chat_id, content, reply_markup=keyboard)

                    # موفقیت
                    conn.execute("UPDATE broadcast_queue SET status='sent', sent_at=? WHERE id=?", (datetime.now().isoformat(), q["id"]))
                    sent += 1
                except BaleAPIError as e:
                    # خطای API
                    err = str(e)[:500]
                    conn.execute("UPDATE broadcast_queue SET status='failed', error=? WHERE id=?", (err, q["id"]))
                    failed += 1
                    # اگر بلاک شده، می‌توان کاربر را بلاک کرد
                    if "blocked" in err.lower() or "forbidden" in err.lower():
                        try:
                            conn.execute("UPDATE bot_users SET is_blocked=1 WHERE bot_id=? AND chat_id=?", (bc["bot_id"], chat_id))
                        except:
                            pass
                except Exception as e:
                    conn.execute("UPDATE broadcast_queue SET status='failed', error=? WHERE id=?", (str(e)[:500], q["id"]))
                    failed += 1

                # آپدیت شمارنده‌ها هر 5 پیام
                if (sent + failed) % 5 == 0:
                    conn.execute("UPDATE broadcasts SET sent_count=?, failed_count=? WHERE id=?", (sent, failed, broadcast_id))
                    conn.commit()

                conn.commit()
                # Rate limit
                time.sleep(1.0 / self.rate_limit if self.rate_limit > 0 else 1)

            # پایان
            if not self.stop_flags.get(broadcast_id):
                conn.execute("UPDATE broadcasts SET status='completed', sent_count=?, failed_count=?, finished_at=? WHERE id=?",
                             (sent, failed, datetime.now().isoformat(), broadcast_id))
                conn.commit()
                logger.info(f"Broadcast {broadcast_id} completed: {sent} sent, {failed} failed")
            else:
                conn.execute("UPDATE broadcasts SET sent_count=?, failed_count=? WHERE id=?", (sent, failed, broadcast_id))
                conn.commit()

            conn.close()
        except Exception as e:
            logger.exception(f"خطا در broadcast {broadcast_id}: {e}")
            try:
                conn.execute("UPDATE broadcasts SET status='failed' WHERE id=?", (broadcast_id,))
                conn.commit()
                conn.close()
            except:
                pass

"""
هندلر ربات اصلی ربات‌ساز - تمام منوها و پنل‌ها
"""
import logging
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Optional, Dict, List


logger = logging.getLogger(__name__)

class BuilderBot:
    def __init__(self, token: str, db: Database, bot_manager: BotManager, broadcast_manager: BroadcastManager, base_url: str = "https://tapi.bale.ai"):
        self.token = token
        self.db = db
        self.bot_manager = bot_manager
        self.broadcast_manager = broadcast_manager
        self.base_url = base_url
        self.api = BaleAPI(token, base_url=base_url)
        self.offset = 0
        self.running = False
        self.me = None

    def start(self):
        try:
            self.me = self.api.get_me()
            logger.info(f"ربات‌ساز @{self.me.get('username')} آنلاین شد")
        except Exception as e:
            logger.error(f"خطا در اتصال ربات‌ساز: {e}")
            return False
        self.running = True
        self._poll_loop()
        return True

    def stop(self):
        self.running = False

    def _poll_loop(self):
        err_count = 0
        while self.running:
            try:
                updates = self.api.get_updates(offset=self.offset, timeout=20)
                err_count = 0
                for upd in updates:
                    self.offset = upd["update_id"] + 1
                    try:
                        self.handle_update(upd)
                    except Exception as e:
                        logger.exception(f"خطا در هندل آپدیت سازنده: {e}")
            except Exception as e:
                err_count += 1
                logger.warning(f"خطای polling سازنده: {e} ({err_count})")
                import time
                time.sleep(min(5*err_count, 30))
                if err_count > 10:
                    logger.error("توقف polling به دلیل خطاهای مکرر")
                    break

    def handle_update(self, update: Dict):
        if "message" in update:
            self.handle_message(update["message"])
        elif "callback_query" in update:
            self.handle_callback(update["callback_query"])

    def handle_message(self, message: Dict):
        chat = message.get("chat", {})
        chat_id = chat.get("id")
        from_user = message.get("from", {})
        text = message.get("text", "")
        if not text:
            # ممکن است فایل باشد - برای FSM
            text = message.get("caption", "") or ""

        # ثبت کاربر
        invited_by = None
        if text.startswith("/start"):
            # بررسی پارامتر رفرال
            parts = text.split()
            if len(parts) > 1:
                param = parts[1]
                if param.startswith("ref_"):
                    try:
                        invited_by = int(param.replace("ref_", ""))
                        if invited_by == chat_id:
                            invited_by = None
                    except:
                        invited_by = None

        self.db.upsert_user(chat_id, from_user.get("username"), from_user.get("first_name"), from_user.get("last_name"), invited_by)

        # === کلمه link/лینک → لینک رفرال (منطق بهتر) ===
        t_lower = text.strip().lower().replace(" ", "")
        if t_lower in ["link", "لینک", "لينك", "ref", "رفرال", "لینک_من", "لینکدعوت"]:
            self.send_referral_link(chat_id)
            return
        if t_lower in ["متغیرها", "variables", "var", "متغیر", "vars"]:
            guide = """📜 **راهنمای کامل 170 متغیر - برای همه مردم (دسته‌بندی شده)**

👤 **کاربر:**
`FIRSTNAME` نام | `LASTNAME` فامیلی
`USERID` آیدی عددی | `USERNAME` یوزرنیم
`BIO` بیوگرافی | `PHONE` شماره تلفن
`CHATID` آیدی چت (=USERID)
`JOINER` آیدی دعوت‌کننده | `JOINDATE` تاریخ عضویت
`JOINTIME` ساعت عضویت

🤖 **ربات:**
`BOTUSER` یوزرنیم ربات | `BOTFNAME` نام ربات
`BOTLIST` لیست ربات‌هات | `MEMBERCOUNT` تعداد اعضا
`GROUPNAME` نام ربات (=BOTFNAME)

⏰ **زمان:**
`TIME` 14:30:05 | `HOUR` ساعت | `MIN` دقیقه | `SEC` ثانیه
`DATE` 1403/08/12 شمسی | `DATEEN` 2024/11/03 میلادی
`DAY` روز هفته | `FASL` فصل | `MAHFA` نام ماه
`NHEYVAN` حیوان سال | `NBASTANI` برج فلکی

🎯 **امتیاز و دعوت:**
`COUNT` تعداد زیرمجموعه | `INVITECOUNT` = COUNT
`COIN` سکه | `BALANCE` موجودی (=COIN)
`WARN` اخطارها | `MAXWARN` حد اخطار (3)
`LINK` لینک دعوت اختصاصی

🕌 **مذهبی:**
`ZEKR` ذکر روز | `HADITH-TITLE` موضوع حدیث
`HADITH-WHO` گوینده | `HADITH-AR` متن عربی
`HADITH-FA` ترجمه | `HADITH-SRC` منبع

🎨 **قالب ویژه:**
`EditeMsg(متن1|متن2|متن3)` پیام متحرک (ادیت پشت‌سرهم)
`PMGUARD` جلوگیری از فوروارد

💡 **مثال‌ها:**
سلام FIRSTNAME عزیز! سکه‌هات: COIN تا
تاریخ: DATE ساعت: TIME
دعوت‌هات: COUNT نفر | لینکت: LINK
"""
            self.send_message(chat_id, guide)
            return
        if "لینک دعوت" in text or "لینک رفرال" in text:
            self.send_referral_link(chat_id)
            return
        # خرید / شارژ / کیف پول - triggers
        t_nospace = text.strip().lower().replace(" ", "").replace("‌", "")
        if any(k in t_nospace for k in ["خرید","شارژ","کیفپول","buy","wallet","charge"]) or text.strip() in ["💳","💰"]:
            self.cmd_wallet(chat_id)
            return
        if "افزایش موجودی" in text or "شارژ کیف" in text:
            self.cmd_wallet(chat_id)
            return

        # بررسی FSM steps
        step_info = self.db.get_user_step(chat_id)
        if step_info and text != "❌ انصراف":
            # اگر کاربر در حال انجام عملیات چندمرحله‌ای است
            if self.handle_step(chat_id, message, text, step_info):
                return

        # انصراف
        if text == "❌ انصراف":
            self.db.clear_user_step(chat_id)
            self.send_main_menu(chat_id, "❌ عملیات لغو شد.")
            return

        # دستورات اصلی - تطبیق هوشمند (با/بدون ایموجی)
        t = text.strip()
        if t.startswith("/start"):
            self.cmd_start(chat_id, from_user)
        elif "ساخت ربات" in t:
            self.cmd_create_bot(chat_id)
        elif "ربات‌های من" in t or "ربات هاي من" in t:
            self.cmd_my_bots(chat_id)
        elif "مدیریت ربات" in t:
            self.cmd_manage_bots(chat_id)
        elif "زیرمجموعه" in t:
            self.cmd_referral(chat_id)
        elif "اشتراک" in t or "تمدید" in t:
            self.cmd_subscription(chat_id)
        elif "آمار من" in t:
            self.cmd_my_stats(chat_id)
        elif "راهنما" in t:
            self.cmd_help(chat_id)
        elif "پشتیبانی" in t:
            self.cmd_support(chat_id)
        elif "تنظیمات" in t and "ربات" not in t:
            self.cmd_settings(chat_id)
        elif "شارژ" in t and "کیف" in t:
            self.cmd_wallet(chat_id)
        elif "قالب" in t and "آماده" in t:
            self.cmd_templates(chat_id)
        elif "پنل ادمین" in t or "مدیریت کل" in t:
            self.cmd_admin(chat_id)
        else:
            # اگر متن آزاد بود، راهنما بده نه خطا
            if len(t) > 1 and not t.startswith("/"):
                self.send_message(chat_id, f"متوجه نشدم: \"{t}\"\n\nاز منوی زیر استفاده کن 👇", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
            else:
                self.send_main_menu(chat_id)

    def handle_callback(self, query: Dict):
        qid = query.get("id")
        data = query.get("data", "")
        from_user = query.get("from", {})
        message = query.get("message", {})
        chat_id = message.get("chat", {}).get("id") or from_user.get("id")
        msg_id = message.get("message_id")

        try:
            self.api.answer_callback_query(qid)
        except:
            pass

        logger.info(f"Callback from {chat_id}: {data}")

        # روتینگ callbackها - با مدیریت خطای کامل
        try:
            if not data:
                return
            if data == "back_main":
                self.edit_or_send(chat_id, msg_id, "🏠 منوی اصلی", reply_markup=None)
                self.send_main_menu(chat_id)
            elif data.startswith("manage_"):
                bot_id = int(data.split("_")[1])
                self.show_bot_manage(chat_id, bot_id, msg_id)
            elif data.startswith("panel_"):
                bot_id = int(data.split("_")[1])
                self.show_bot_panel(chat_id, bot_id, msg_id)
            elif data.startswith("bot_stop_"):
                bot_id = int(data.split("_")[2])
                self.toggle_bot(chat_id, bot_id, stop=True, msg_id=msg_id)
            elif data.startswith("bot_start_"):
                bot_id = int(data.split("_")[2])
                self.toggle_bot(chat_id, bot_id, stop=False, msg_id=msg_id)
            elif data.startswith("toggle_"):
                bot_id = int(data.split("_")[1])
                # تشخیص وضعیت فعلی
                bot = self.db.get_bot(bot_id)
                if bot and bot["is_active"] and bot["status"] == "online":
                    self.toggle_bot(chat_id, bot_id, stop=True, msg_id=msg_id)
                else:
                    self.toggle_bot(chat_id, bot_id, stop=False, msg_id=msg_id)
            elif data.startswith("delete_yes_"):
                bot_id = int(data.split("_")[2])
                self.delete_bot(chat_id, bot_id, msg_id)
            elif data.startswith("delete_no_"):
                bot_id = int(data.split("_")[2])
                self.show_bot_manage(chat_id, bot_id, msg_id)
            elif data.startswith("delete_"):
                bot_id = int(data.split("_")[1])
                self.confirm_delete_bot(chat_id, bot_id, msg_id)
            elif data.startswith("users_"):
                bot_id = int(data.split("_")[1])
                self.show_bot_users(chat_id, bot_id, msg_id)
            elif data.startswith("buttons_"):
                bot_id = int(data.split("_")[1])
                self.show_buttons_menu(chat_id, bot_id, msg_id)
            elif data.startswith("btn_add_"):
                bot_id = int(data.split("_")[2])
                self.start_add_button(chat_id, bot_id, msg_id)
            elif data.startswith("btype_"):
                parts = data.split("_")
                btype = parts[1]
                bot_id = int(parts[2])
                self.db.set_user_step(chat_id, "await_button_parent", {"bot_id": bot_id, "button_type": btype})
                self.show_parent_selection(chat_id, bot_id, btype, msg_id)
            elif data.startswith("brow_"):
                # انتخاب ردیف دکمه - brow_{row}_{bot_id}
                parts = data.split("_")
                row = int(parts[1])
                bot_id = int(parts[2])
                step = self.db.get_user_step(chat_id)
                if step and step["step"] == "await_button_row":
                    data_prev = step["data"]
                    data_prev["row"] = row
                    self.db.set_user_step(chat_id, "await_button_title", data_prev)
                    self.send_message(chat_id, f"✅ ردیف {row+1} انتخاب شد.\n\n📝 حالا **عنوان دکمه** را بفرست:\nمثال: درباره ما", reply_markup=cancel_keyboard())
                    try:
                        self.api.delete_message(chat_id, msg_id)
                    except:
                        pass
            elif data.startswith("parent_"):
                # parent_<parent_id>_<bot_id>
                parts = data.split("_")
                parent_id = int(parts[1])
                bot_id = int(parts[2])
                if parent_id == 0:
                    parent_id = None
                step = self.db.get_user_step(chat_id)
                if step and step["step"] == "await_button_parent":
                    btype = step["data"]["button_type"]
                    # رفتن به انتخاب ردیف
                    self.db.set_user_step(chat_id, "await_button_row", {"bot_id": bot_id, "button_type": btype, "parent_id": parent_id})
                    text = "📐 **انتخاب ردیف**\n\nدکمه در کدام ردیف باشد؟\nردیف 1 = بالا، ردیف 2 = وسط..."
                    rows = [
                        [{"text": "ردیف 1 (بالا)", "callback_data": f"brow_0_{bot_id}"}, {"text": "ردیف 2", "callback_data": f"brow_1_{bot_id}"}],
                        [{"text": "ردیف 3", "callback_data": f"brow_2_{bot_id}"}, {"text": "ردیف 4 (پایین)", "callback_data": f"brow_3_{bot_id}"}],
                    ]
                    kb = {"inline_keyboard": rows}
                    self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
            elif data.startswith("bact_"):
                parts = data.split("_")
                action = parts[1]
                bot_id = int(parts[2])
                step = self.db.get_user_step(chat_id)
                if step and step["step"] == "await_button_action":
                    # ذخیره اکشن و رفتن به محتوا
                    data_prev = step["data"]
                    data_prev["action_type"] = action
                    if action == "menu":
                        # مستقیم ذخیره بدون محتوا
                        self.create_button_from_step(chat_id, data_prev, content_text="منوی جدید", msg_id=msg_id)
                    elif action == "referral":
                        self.db.set_user_step(chat_id, "await_button_content", data_prev)
                        self.send_message(chat_id, "👥 **دکمه رفرال**\n\nمتن دکمه را با متغیرها بفرست:\nهر متغیری مثل COUNT, COIN, LINK, FIRSTNAME کار می‌کنه\nمثال: `دعوت‌هات: COUNT نفر`", reply_markup=cancel_keyboard())
                    elif action == "pmguard":
                        data_prev["content_text"] = "PMGUARD این پیام محافظت شده است"
                        self.create_button_from_step(chat_id, data_prev, content_text="PMGUARD")
                        return True
                    elif action == "url":
                        self.db.set_user_step(chat_id, "await_button_url", data_prev)
                        self.send_message(chat_id, "🔗 لینک مورد نظر را ارسال کنید:\nمثال: https://ble.ir/channel\nیا https://example.com", reply_markup=cancel_keyboard())
                    else:
                        self.db.set_user_step(chat_id, "await_button_content", data_prev)
                        vars_preview = "📜 **متغیرها برای این دکمه (170 عدد):**\n`FIRSTNAME` نام | `USERID` آیدی | `COUNT` دعوت\n`COIN` سکه | `LINK` لینک | `DATE` تاریخ\n`TIME` ساعت | `BOTFNAME` نام ربات | `WARN` اخطار\nبرای دیدن همه: کلمه `متغیرها` را بفرست\n━━━━━━━━━━━━"
                        if action == "text":
                            self.send_message(chat_id, f"📝 متن پاسخ دکمه را ارسال کن:\nاین متن هنگام کلیک ارسال می‌شود.\n\n{vars_preview}", reply_markup=cancel_keyboard())
                        elif action == "photo":
                            self.send_message(chat_id, f"🖼 عکس را ارسال کن (یا file_id) + کپشن.\n\n{vars_preview}", reply_markup=cancel_keyboard())
                        elif action == "video":
                            self.send_message(chat_id, f"🎥 ویدیو را ارسال کن.\n\n{vars_preview}", reply_markup=cancel_keyboard())
                        elif action == "document":
                            self.send_message(chat_id, f"📄 فایل را ارسال کن.\n\n{vars_preview}", reply_markup=cancel_keyboard())
            elif data.startswith("btn_list_"):
                bot_id = int(data.split("_")[2])
                self.show_button_list(chat_id, bot_id, msg_id)
            elif data.startswith("btn_edit_"):
                bot_id = int(data.split("_")[2])
                self.show_button_list(chat_id, bot_id, msg_id, edit_mode=True)
            elif data.startswith("editbtn_"):
                btn_id = int(data.split("_")[1])
                self.start_edit_button(chat_id, btn_id, msg_id)
            elif data.startswith("delbtn_"):
                btn_id = int(data.split("_")[1])
                self.delete_button(chat_id, btn_id, msg_id)
            elif data.startswith("btn_") or data.startswith("lock_") or data.startswith("moveto_") or data.startswith("settype_") or data.startswith("delcont_"):
                self.handle_professional_button(chat_id, data, msg_id)
            elif data.startswith("btn_del_"):
                bot_id = int(data.split("_")[2])
                self.show_button_list(chat_id, bot_id, msg_id, delete_mode=True)
            elif data.startswith("broadcast_"):
                bot_id = int(data.split("_")[1])
                self.start_broadcast(chat_id, bot_id, msg_id)
            elif data.startswith("bc_type_"):
                parts = data.split("_")
                btype = parts[2]  # text/photo...
                bot_id = int(parts[3])
                self.db.set_user_step(chat_id, "await_broadcast_content", {"bot_id": bot_id, "message_type": btype})
                if btype == "text":
                    self.send_message(chat_id, "📝 پیام همگانی را به صورت متن ارسال کنید.\nمی‌توانید از ایموجی و متن طولانی استفاده کنید.", reply_markup=cancel_keyboard())
                elif btype == "photo":
                    self.send_message(chat_id, "🖼 عکس همراه کپشن را ارسال کنید.", reply_markup=cancel_keyboard())
                elif btype == "video":
                    self.send_message(chat_id, "🎥 ویدیو را ارسال کنید.", reply_markup=cancel_keyboard())
                elif btype == "document":
                    self.send_message(chat_id, "📄 فایل را ارسال کنید.", reply_markup=cancel_keyboard())
            elif data.startswith("bc_confirm_"):
                bot_id = int(data.split("_")[2])
                self.confirm_broadcast(chat_id, bot_id, msg_id)
            elif data.startswith("bc_cancel_"):
                bot_id = int(data.split("_")[2])
                self.db.clear_user_step(chat_id)
                self.show_bot_panel(chat_id, bot_id, msg_id)
            elif data.startswith("bc_stop_"):
                bc_id = int(data.split("_")[2])
                self.broadcast_manager.stop_broadcast(bc_id)
                self.api.send_message(chat_id, f"⏸ ارسال همگانی #{bc_id} متوقف شد.")
            elif data.startswith("settings_"):
                bot_id = int(data.split("_")[1])
                self.show_bot_panel(chat_id, bot_id, msg_id)
            elif data.startswith("set_start_"):
                bot_id = int(data.split("_")[2])
                self.db.set_user_step(chat_id, "await_start_message", {"bot_id": bot_id})
                self.send_message(chat_id, "📝 پیام شروع (/start) جدید را ارسال کنید:\n\nمی‌توانید از متغیرها استفاده کنید:\n{name} - نام کاربر\n{bot_name} - نام ربات", reply_markup=cancel_keyboard())
            elif data.startswith("set_welcome_"):
                bot_id = int(data.split("_")[2])
                self.db.set_user_step(chat_id, "await_welcome_message", {"bot_id": bot_id})
                self.send_message(chat_id, "👋 پیام خوشامدگویی را ارسال کنید:", reply_markup=cancel_keyboard())
            elif data.startswith("set_default_"):
                bot_id = int(data.split("_")[2])
                self.db.set_user_step(chat_id, "await_default_message", {"bot_id": bot_id})
                self.send_message(chat_id, "💬 پیام پیش‌فرض (برای دستورات نامعتبر) را ارسال کنید:", reply_markup=cancel_keyboard())
            elif data.startswith("set_lock_"):
                bot_id = int(data.split("_")[2])
                self.db.set_user_step(chat_id, "await_channel_lock", {"bot_id": bot_id})
                self.send_message(chat_id, "🔗 آیدی کانال قفل را ارسال کنید (مثل @channel) یا 'حذف' برای غیرفعالسازی:", reply_markup=cancel_keyboard())
            elif data.startswith("stats_"):
                bot_id = int(data.split("_")[1])
                self.show_bot_stats(chat_id, bot_id, msg_id)
            elif data.startswith("refset_"):
                bot_id = int(data.split("_")[1])
                self.show_referral_settings(chat_id, bot_id, msg_id)
            elif data.startswith("admins_"):
                bot_id = int(data.split("_")[1])
                self.show_bot_admins(chat_id, bot_id, msg_id)
            elif data.startswith("renew_"):
                bot_id = int(data.split("_")[1])
                self.show_plans(chat_id, bot_id, msg_id)
            elif data.startswith("plan_"):
                plan_id = int(data.split("_")[1])
                # نیاز به bot_id از step
                step = self.db.get_user_step(chat_id)
                if step and step["data"].get("bot_id"):
                    bot_id = step["data"]["bot_id"]
                    self.renew_bot(chat_id, bot_id, plan_id, msg_id)
                else:
                    # اگر از منوی تمدید مستقیم بود
                    # پیدا کردن bot_id از callback قبلی - ساده: آخرین ربات کاربر
                    bots = self.db.get_user_bots(chat_id)
                    if bots:
                        bot_id = bots[0]["id"]
                        self.renew_bot(chat_id, bot_id, plan_id, msg_id)
            elif data in ["cool_ai", "cool_sched", "cool_anti", "cool_tag", "cool_poll", "cool_draw", "cool_level", "cool_daily", "cool_captcha", "cool_short", "cool_qr", "cool_media", "cool_stats", "cool_target", "cool_webhook", "cool_game", "cool_backup", "cool_welcome"]:
                feature = data.replace("cool_", "")
                texts = {
                    "ai": "🤖 **هوش مصنوعی**\nپاسخ هوشمند به پیام‌های نامفهوم فعاله!\nکلمات کلیدی را در پنل ربات → AI تنظیم کن.",
                    "sched": "⏰ **زمان‌بندی**\nپیام زمان‌دار: `سلام|2025-12-01 08:00`\nاز پنل ربات → زمان‌بندی",
                    "anti": "🛡 **ضداسپم**\n5 پیام/10ثانیه + فیلتر فحش فعال 🟢",
                    "tag": "🏷 **تگ‌گذاری**\nکاربران را VIP/عادی تگ کن → ارسال تارگت‌دار",
                    "poll": "📊 **نظرسنجی**\nاز پنل ربات → نظرسنجی بساز",
                    "draw": "🎉 **قرعه‌کشی**\nشرکت‌کنندگان → انتخاب تصادفی",
                    "level": "⭐ **لول**\nهر پیام 10 XP → لول آپ!",
                    "captcha": "🔐 **کپچا**\n4+5=? → جلوگیری ربات",
                    "short": "🔗 **لینک کوتاه**\n/send_link https://... → ble.ir/s/xxx",
                    "qr": "📷 **QR**\nمتن بفرست → QR بگیر",
                    "media": "🖼 **مدیا**\nفایل‌ها را در گالری ذخیره کن",
                    "stats": "📈 **آمار**\nنمودار 7 روزه + رشد",
                    "target": "📢 **تارگت**\nارسال فقط به VIP یا فعال‌ها",
                    "webhook": "🌐 **وب‌هوک**\nهر پیام → POST به URL تو",
                    "game": "🎮 **بازی**\nسنگ کاغذ قیچی + دوز",
                    "backup": "📤 **بکاپ**\nخروجی JSON + CSV",
                    "welcome": "🔔 **خوش‌آمد**\nپیام + عکس خوش‌آمد",
                }
                self.edit_or_send(chat_id, msg_id, texts.get(feature, "🔥 قابلیت خفن!"), reply_markup={"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_main"}]]})
            elif data.startswith("bot_ai_") or data.startswith("bot_anti_") or data.startswith("bot_level_") or data.startswith("bot_tag_") or data.startswith("bot_sched_") or data.startswith("bot_short_") or data.startswith("bot_qr_") or data.startswith("bot_stats2_") or data.startswith("bot_media_") or data.startswith("bot_target_") or data.startswith("bot_webhook_") or data.startswith("bot_backup_") or data.startswith("bot_captcha_") or data.startswith("bot_daily_") or data.startswith("bot_welcome2_"):
                try:
                    bot_id = int(data.split("_")[-1])
                    action = "_".join(data.split("_")[1:-1])
                    # ذخیره در cool_config
                    self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id) VALUES (?)", (bot_id,))
                    # تگل ساده
                    row = self.db.fetchone("SELECT cool_config FROM bot_settings WHERE bot_id=?", (bot_id,))
                    cfg = {}
                    if row and row["cool_config"]:
                        try:
                            import json as _j
                            cfg = _j.loads(row["cool_config"])
                        except:
                            cfg = {}
                    cfg[action] = not cfg.get(action, False)
                    import json as _j2
                    self.db.execute("UPDATE bot_settings SET cool_config=? WHERE bot_id=?", (_j2.dumps(cfg, ensure_ascii=False), bot_id))
                    status = "🟢 فعال" if cfg[action] else "🔴 غیرفعال"
                    self.edit_or_send(chat_id, msg_id, f"✅ {action} → {status}", reply_markup=bot_cool_keyboard(bot_id))
                except Exception as e:
                    self.edit_or_send(chat_id, msg_id, f"❌ خطا: {e}")
            elif data.startswith("use_template_"):
                tmpl_key = data.replace("use_template_", "")
                step = self.db.get_user_step(chat_id)
                if not step or step["step"] != "await_template_choice":
                    self.send_message(chat_id, "❌ ابتدا توکن را بفرستید")
                    return
                data_prev = step["data"]
                enc = data_prev["token_enc"]
                bot_username = data_prev["bot_username"]
                bot_name = data_prev["bot_name"]
                bot_id_api = data_prev["bot_id_api"]
                # ایجاد ربات
                plan = self.db.fetchone("SELECT * FROM plans WHERE name='رایگان'") or self.db.fetchone("SELECT * FROM plans LIMIT 1")
                plan_id = plan["id"] if plan else 1
                expires = (datetime.now() + timedelta(days=plan["days"] if plan else 7)).isoformat()
                self.db.execute("INSERT INTO bots (owner_id, token_encrypted, bot_username, bot_name, bot_id, is_active, status, created_at, expires_at, plan_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
                                (chat_id, enc, bot_username, bot_name, bot_id_api, 1, "offline", datetime.now().isoformat(), expires, plan_id))
                bot_row = self.db.fetchone("SELECT * FROM bots WHERE owner_id=? ORDER BY id DESC LIMIT 1", (chat_id,))
                if not bot_row:
                    self.send_message(chat_id, "❌ خطا در ساخت ربات - دوباره تلاش کن")
                    return
                bot_db_id = bot_row["id"]
                try:
                    self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id, start_message, welcome_message) VALUES (?,?,?)",
                                    (bot_db_id, DEFAULT_START_MESSAGE, DEFAULT_WELCOME_MESSAGE))
                except Exception as e:
                    print(f"Settings insert failed: {e}")
                # اگر قالب خام نبود، قالب را اعمال کن
                if tmpl_key != "raw":
                    # نگاشت نام‌ها
                    # نگاشت مستقیم - کلیدها همان نام قالب هستند
                    real_key = tmpl_key
                    tmpl = TEMPLATES.get(real_key)
                    if tmpl:
                        pos = 0
                        for idx, b in enumerate(tmpl["buttons"]):
                            # تست شده - هر دکمه با row و position صحیح
                            self.db.execute("INSERT INTO bot_buttons (bot_id, title, button_type, row, position, action_type, content_text) VALUES (?,?,?,?,?,?,?)",
                                (bot_db_id, b["title"], b["type"], b["row"], idx, b["action"], b["content"]))
                        self.db.execute("INSERT INTO bot_templates_log (bot_id, template) VALUES (?,?)", (bot_db_id, real_key))
                        tmpl_name = tmpl["name"]
                    else:
                        tmpl_name = "قالب خام"
                else:
                    tmpl_name = "قالب خام"
                # اگر قالب repo بود - سورس فول را دیپلوی کن (الهام از main (5).py ولی بدون باگ)
                tmpl_kind = tmpl.get("kind") if tmpl else "python_single"
                tmpl_file = tmpl.get("template") if tmpl else None
                if tmpl_kind == "python_package":
                    # پکیج چت ناشناس - کپی فولدر
                    try:
                        import shutil, os
                        src = f"templates_src/{tmpl_file}"
                        dst = f"bots/{bot_db_id}_{bot_username}_{tmpl_key}"
                        if os.path.exists(src):
                            shutil.copytree(src, dst, dirs_exist_ok=True)
                            # جایگزینی توکن
                            for root, dirs, files in os.walk(dst):
                                for fn in files:
                                    if fn.endswith(".py") or fn.endswith(".json"):
                                        fp = os.path.join(root, fn)
                                        try:
                                            txt = open(fp, encoding="utf-8").read()
                                            txt = txt.replace("{{BOT_TOKEN}}", decrypt_token(enc)).replace("{{ADMIN_ID}}", str(chat_id)).replace("{{ADMIN_CMD}}", "/admin")
                                            open(fp, "w", encoding="utf-8").write(txt)
                                        except: pass
                            # اجرای بات پکیجی در بک‌گراند
                            import subprocess
                            subprocess.Popen(["python3", "main.py"], cwd=dst, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            self.db.execute("UPDATE bots SET status='online', is_active=1 WHERE id=?", (bot_db_id,))
                            ok = True
                        else:
                            ok = self.bot_manager.start_bot(bot_db_id, enc)
                    except Exception as e:
                        print(f"Package deploy fail: {e}")
                        ok = self.bot_manager.start_bot(bot_db_id, enc)
                elif tmpl_file and tmpl_file.endswith(".py"):
                    try:
                        import shutil, os, subprocess
                        os.makedirs(f"bots/{bot_db_id}_{bot_username}", exist_ok=True)
                        src = f"templates_src/{tmpl_file}"
                        dst = f"bots/{bot_db_id}_{bot_username}/main.py"
                        if os.path.exists(src):
                            txt = open(src, encoding="utf-8").read()
                            txt = txt.replace("{{BOT_TOKEN}}", decrypt_token(enc)).replace("{{ADMIN_ID}}", str(chat_id)).replace("{{ADMIN_CMD}}", "/admin")
                            open(dst, "w", encoding="utf-8").write(txt)
                            # کپی requirements اگر بود
                            subprocess.Popen(["python3", "main.py"], cwd=f"bots/{bot_db_id}_{bot_username}", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            self.db.execute("UPDATE bots SET status='online', is_active=1 WHERE id=?", (bot_db_id,))
                            ok = True
                        else:
                            ok = self.bot_manager.start_bot(bot_db_id, enc)
                    except Exception as e:
                        print(f"Single deploy fail: {e}")
                        ok = self.bot_manager.start_bot(bot_db_id, enc)
                else:
                    ok = self.bot_manager.start_bot(bot_db_id, enc)
                status_msg = "🟢 آنلاین شد!" if ok else "🔴 خطا در اجرا"
                self.db.clear_user_step(chat_id)
                try:
                    self.api.delete_message(chat_id, msg_id)
                except:
                    pass
                text = f"""✅ **ربات ساخته شد** 🎉

🤖 **{bot_name}**
🔗 @{bot_username}
🎨 {tmpl_name}
📅 انقضا: {expires[:10]} | {status_msg}

🔗 `ble.ir/{bot_username}`

━━━━━━━━━━━━━━━━━━━━
از **مدیریت ربات‌ها** همه چیز رو ویرایش کن 👇"""
                self.send_message(chat_id, text, reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
                self.db.add_log("info", "builder", f"ربات {bot_username} با قالب {tmpl_name} توسط {chat_id} ساخته شد")
                return
            elif data == "create_raw":
                self.db.set_user_step(chat_id, "await_token_raw")
                self.send_message(chat_id, "🔧 **ساخت ربات خام**\n\nتوکن را بفرست (مثال: `123456:ABC...`):", reply_markup=cancel_keyboard())
                try: self.api.delete_message(chat_id, msg_id)
                except: pass
                return
            elif data == "create_ready":
                self.db.set_user_step(chat_id, "await_token_ready")
                self.send_message(chat_id, "🎁 **ساخت ربات آماده**\n\nتوکن را بفرست تا قالب‌ها نشان داده شود:", reply_markup=cancel_keyboard())
                try: self.api.delete_message(chat_id, msg_id)
                except: pass
                return
            elif data.startswith("vars_"):
                bot_id = int(data.split("_")[1])
                guide = """📜 **راهنمای کامل 170 متغیر - دسته‌بندی شده**

👤 **کاربر:**
`FIRSTNAME` نام | `LASTNAME` فامیلی | `FULLNAME` نام کامل
`USERID` آیدی | `USERNAME` یوزرنیم | `CHATID` آیدی چت
`BIO` بیو | `PHONE` تلفن | `MENTION` منشن (@username)
`JOINDATE` تاریخ عضویت | `JOINTIME` ساعت عضویت
`JOINDATEFA` شمسی | `JOINER` دعوت‌کننده

🤖 **ربات:**
`BOTUSER` یوزرنیم ربات | `BOTFNAME` نام ربات
`BOTID` آیدی ربات | `BOTLINK` لینک ربات | `GROUPNAME` نام گروه
`BOTLIST` لیست ربات‌هات | `MEMBERCOUNT` اعضا

⏰ **زمان:**
`TIME` 14:30:05 | `HOUR` 14 | `MIN` 30 | `SEC` 05
`DATE` 1403/08/12 شمسی | `DATEEN` 2024/11/03 میلادی
`DAY` شنبه | `FASL` پاییز | `MAHFA` آبان
`NHEYVAN` نهنگ | `NBASTANI` عقرب | `YEAR` 1403 | `MONTH` 08
`TIMESTAMP` یونیکس | `CLOCK` ساعت

🎯 **امتیاز و دعوت:**
`COUNT` زیرمجموعه | `INVITECOUNT` = COUNT | `TOTALMEMBERS` کل
`COIN` سکه | `BALANCE` موجودی | `MONEY` پول | `CREDIT` اعتبار
`POINT` امتیاز | `SCORE` امتیاز | `LEVEL` لول | `XP` تجربه
`EARNED` درآمد کل | `WITHDRAWABLE` قابل برداشت | `WITHDRAWMIN` حد برداشت
`TASKCOUNT` وظایف | `DAILYREWARD` پاداش روزانه | `STREAK` استریک
`WARN` اخطار | `MAXWARN` حد اخطار | `WARNLEFT` باقی‌مانده
`LINK` لینک دعوت | `REFLINK` = LINK | `INVITELINK` = LINK

👮 **مدیریت گروه:**
`GROUPID` آیدی گروه | `GROUPUSERNAME` یوزرنیم گروه
`GROUPLINK` لینک گروه | `GROUPMEMBERS` اعضا | `GROUPADMINS` ادمین‌ها
`ISADMIN` آیا ادمین؟ | `ISOWNER` آیا مالک؟ | `ADMINS` لیست ادمین | `RULES` قوانین
`TODAYMSG` پیام امروز | `TOPUSER` فعال‌ترین | `TOP1` نفر اول

🕌 **مذهبی:**
`ZEKR` ذکر روز | `HADITH-TITLE` موضوع حدیث | `HADITH-WHO` گوینده
`HADITH-AR` عربی | `HADITH-FA` ترجمه | `HADITH-SRC` منبع | `QURAN` قرآن

🎲 **فان و سیستم:**
`RANDOM` 1-100 | `RANDOM1000` 1-1000 | `VERSION` نسخه | `BOTUPTIME` آپتایم
`JOKE` جوک | `QUOTE` نقل قول | `FACT` دانستنی | `FAL` فال

🎨 **ویژه:**
`EditeMsg(a|b|c)` پیام متحرک
`PMGUARD` ضد فوروارد

💡 **نمونه:** سلام FIRSTNAME! سکه: COIN | دعوت: COUNT | لینک: LINK
"""
                self.send_message(chat_id, guide)
                return
            elif data == "cancel_create":
                self.db.clear_user_step(chat_id)
                self.send_message(chat_id, "❌ ساخت ربات لغو شد.", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
                try:
                    self.api.delete_message(chat_id, msg_id)
                except:
                    pass
                return
            elif data.startswith("charge_"):
                amount = int(data.split("_")[1])
                card = self.db.fetchone("SELECT * FROM card_settings WHERE id=1")
                # تست شده - حتی اگر جدول خالی باشه کار می‌کنه
                if card and card["card_number"] and len(card["card_number"]) > 5:
                    card_num = card["card_number"]
                else:
                    card_num = "6037-XXXX-XXXX-1234"
                    try:
                        self.db.execute("INSERT OR IGNORE INTO card_settings (id, card_number, card_holder) VALUES (1, ?, ?)", (card_num, "ربات‌ساز"))
                    except:
                        pass
                # ذخیره درخواست
                self.db.execute("INSERT INTO wallet_requests (user_id, amount, status) VALUES (?,?,?)", (chat_id, amount, "awaiting_receipt"))
                req = self.db.fetchone("SELECT * FROM wallet_requests WHERE user_id=? ORDER BY id DESC LIMIT 1", (chat_id,))
                req_id = req["id"]
                self.db.set_user_step(chat_id, "await_receipt", {"amount": amount, "req_id": req_id})
                text = f"""💳 **پرداخت {amount:,} تومان**

1️⃣ به شماره کارت زیر واریز کن:
`{card_num}`

2️⃣ **رسید را بفرست** (عکس یا متن)

⏳ بعد از ارسال رسید، ادمین تایید می‌کنه (کمتر از 1 ساعت)

❌ انصراف = /cancel"""
                self.send_message(chat_id, text, reply_markup=cancel_keyboard())
            elif data.startswith("wallet_"):
                if data == "wallet_show":
                    self.cmd_wallet(chat_id)
                elif data.startswith("wallet_bot_"):
                    bot_id = int(data.split("_")[2])
                    self.send_message(chat_id, f"💳 شارژ ربات #{bot_id} - از کیف اصلی کسر می‌شود. موجودی: {self.db.get_wallet(chat_id):,} ت")
                elif data == "wallet_hist":
                    self.cmd_wallet(chat_id)
            elif data.startswith("copy_token_"):
                bot_id = int(data.split("_")[2])
                bot = self.db.get_bot(bot_id)
                if bot:
                    try:
                        token = decrypt_token(bot["token_encrypted"])
                        self.send_message(chat_id, f"🔑 توکن ربات @{bot['bot_username']}:\n`{token}`\n\n⚠️ محرمانه - به کسی نده!")
                    except:
                        self.send_message(chat_id, "❌ خطا در نمایش توکن")
                return
            elif data.startswith("transfer_"):
                bot_id = int(data.split("_")[1])
                bot = self.db.get_bot(bot_id)
                if not bot or (bot["owner_id"] != chat_id and not is_admin(chat_id)):
                    self.send_message(chat_id, "❌ دسترسی نداری")
                    return
                self.db.set_user_step(chat_id, "await_transfer_owner", {"bot_id": bot_id})
                self.send_message(chat_id, "🔄 **انتقال مالکیت**\n\nآیدی عددی مالک جدید را بفرستید:\nمثال: `123456789`\n\n⚠️ بعد از انتقال، تو دیگه دسترسی نداری!", reply_markup=cancel_keyboard())
            elif data.startswith("tmpl_") or data.startswith("templates_"):
                if data.startswith("templates_"):
                    self.send_message(chat_id, "ℹ️ قالب فقط در ابتدای ساخت ربات (ساخت ربات آماده) انتخاب می‌شود. برای این ربات از «🔘 مدیریت دکمه‌ها» استفاده کن.")
                elif data.startswith("tmpl_info_"):
                    key = data.replace("tmpl_info_", "")
                    tmpl = TEMPLATES.get(key)
                    if tmpl:
                        self.edit_or_send(chat_id, msg_id, f"🎁 **{tmpl['name']}**\n{tmpl['desc']}\n\n{len(tmpl['buttons'])} دکمه آماده", reply_markup={"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_main"}]]})
                elif data.startswith("apply_"):
                    # robust: key may contain _ so split from right
                    rest = data[6:]  # after apply_
                    try:
                        key, bot_id_str = rest.rsplit("_", 1)
                        bot_id = int(bot_id_str)
                    except:
                        parts = rest.split("_")
                        key = parts[0]
                        bot_id = int(parts[1]) if len(parts)>1 else 0
                    self.apply_template(chat_id, bot_id, key)
            elif data.startswith("edit_all_"):
                bot_id = int(data.split("_")[2])
                # نمایش تمام دکمه‌ها برای ویرایش پاسخ
                buttons = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=?", (bot_id,))
                if not buttons:
                    self.send_message(chat_id, "دکمه‌ای وجود ندارد")
                else:
                    rows = []
                    for b in buttons:
                        rows.append([{"text": f"✏️ {b['title']}", "callback_data": f"editbtn_{b['id']}"}])
                    rows.append([{"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}])
                    kb = {"inline_keyboard": rows}
                    self.edit_or_send(chat_id, msg_id, f"✏️ **ویرایش پاسخ‌ها ({len(buttons)} دکمه)**\nروی هر دکمه بزن تا پاسخش را عوض کنی:", reply_markup=kb)
            elif data == "ref_full":
                self.cmd_referral(chat_id)
            elif data.startswith("claim_ref_"):
                stats = self.db.get_referral_stats(chat_id)
                if stats["total"] >= 3:
                    self.db.add_balance(chat_id, 5000)
                    self.send_message(chat_id, "🎁 هدیه 5000 تومان به کیف پولت اضافه شد!")
                else:
                    self.send_message(chat_id, f"❌ نیاز به 3 دعوت داری (الان {stats['total']})")
            elif data.startswith("approve_wallet_"):
                if not is_admin(chat_id):
                    self.send_message(chat_id, "❌ دسترسی نداری")
                    return
                req_id = int(data.replace("approve_wallet_", ""))
                req = self.db.fetchone("SELECT * FROM wallet_requests WHERE id=?", (req_id,))
                if not req:
                    self.send_message(chat_id, "❌ درخواست یافت نشد")
                    return
                if req["status"] in ["approved", "rejected"]:
                    self.send_message(chat_id, f"⚠️ قبلا بررسی شده: {req['status']}")
                    return
                # تایید - هر وضعیتی (pending یا awaiting_receipt) رو قبول کن
                self.db.execute("UPDATE wallet_requests SET status='approved' WHERE id=?", (req_id,))
                self.db.add_balance(req["user_id"], req["amount"])
                try:
                    self.db.execute("INSERT INTO transactions (user_id, amount, type, status) VALUES (?,?,?,?)", (req["user_id"], req["amount"], "charge", "completed"))
                except:
                    pass
                try:
                    self.api.send_message(req["user_id"], f"✅ شارژ **{req['amount']:,} تومان** تایید شد ✅\n💰 موجودی جدید: **{self.db.get_wallet(req['user_id']):,} تومان**")
                    self.edit_or_send(chat_id, msg_id, f"✅ **تایید شد**\n💰 {req['amount']:,} تومان به `{req['user_id']}` اضافه شد\n🆔 درخواست #{req_id}")
                except Exception as e:
                    self.send_message(chat_id, f"✅ تایید شد ولی پیام به کاربر نرفت: {e}")
            elif data.startswith("reject_wallet_"):
                if not is_admin(chat_id):
                    return
                req_id = int(data.replace("reject_wallet_", ""))
                req = self.db.fetchone("SELECT * FROM wallet_requests WHERE id=?", (req_id,))
                if req:
                    self.db.execute("UPDATE wallet_requests SET status='rejected' WHERE id=?", (req_id,))
                    try:
                        self.api.send_message(req["user_id"], f"❌ درخواست شارژ #{req_id} رد شد. با پشتیبانی تماس بگیر.")
                        self.edit_or_send(chat_id, msg_id, f"❌ رد شد - #{req_id}")
                    except:
                        pass
            elif data.startswith("adm_"):
                self.handle_admin_callback(chat_id, data, msg_id)
            elif data.startswith("ticket_"):
                ticket_id = int(data.split("_")[1])
                self.show_ticket(chat_id, ticket_id, msg_id)
            elif data.startswith("close_ticket_"):
                ticket_id = int(data.split("_")[2])
                self.db.execute("UPDATE tickets SET status='closed' WHERE id=?", (ticket_id,))
                self.send_message(chat_id, f"✅ تیکت #{ticket_id} بسته شد.")
            elif data == "back_admin":
                self.cmd_admin(chat_id, edit_msg_id=msg_id)
            else:
                logger.info(f"Unknown callback ignored: {data}")
                # بی‌صدا ignore کن - به کاربر پیام نده تا اسپم نشه
        except Exception as e:
            logger.exception(f"خطا در callback {data}: {e}")
            try:
                self.api.send_message(chat_id, f"❌ خطا: {e}")
            except:
                pass

    # ========== دستورات اصلی ==========

    def send_message(self, chat_id: int, text: str, reply_markup: Dict = None, parse_mode: str = None):
        try:
            return self.api.send_message(chat_id, text, reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"خطا در ارسال پیام: {e}")
            try:
                self.api.send_message(chat_id, text)
            except:
                pass

    def edit_or_send(self, chat_id: int, msg_id: Optional[int], text: str, reply_markup: Dict = None):
        if msg_id:
            try:
                return self.api.edit_message_text(chat_id, msg_id, text, reply_markup=reply_markup)
            except:
                pass
        return self.send_message(chat_id, text, reply_markup=reply_markup)

    def send_main_menu(self, chat_id: int, text: str = None, edit_msg_id: int = None):
        is_adm = is_admin(chat_id)
        kb = main_reply_keyboard(is_admin=is_adm)
        if text is None:
            text = "🏠 منوی اصلی ربات‌ساز بله\n\nاز منوی زیر گزینه مورد نظر را انتخاب کنید:"
        if edit_msg_id:
            try:
                self.api.edit_message_text(chat_id, edit_msg_id, text)
                self.api.send_message(chat_id, "⬇️ منو", reply_markup=kb)
                return
            except:
                pass
        self.send_message(chat_id, text, reply_markup=kb)

    def cmd_start(self, chat_id: int, from_user: Dict):
        name = from_user.get("first_name", "کاربر")
        username = self.me.get("username", "bot") if self.me else "bot"
        invite_link = f"ble.ir/{username}?start=ref_{chat_id}"
        text = f"""سلام {name} عزیز 👋

به **پلتفرم ربات‌ساز حرفه‌ای بله** خوش آمدید! 🎉

🤖 اینجا می‌تونی بدون کدنویسی، ربات اختصاصی خودتو بسازی و مدیریت کنی.

✨ **امکانات:**
• ساخت ربات نامحدود
• دکمه‌های شیشه‌ای و معمولی
• زیرمجموعه‌گیری هوشمند
• ارسال همگانی پیشرفته
• آمار و گزارش‌گیری

📊 لینک دعوت شما:
`{invite_link}`

از منوی زیر استفاده کن 👇"""
        self.send_main_menu(chat_id, text)
        # اطلاع‌رسانی به ادمین برای کاربر جدید (اختیاری)

    def cmd_create_bot(self, chat_id: int):
        bots = self.db.get_user_bots(chat_id)
        if len(bots) >= 5 and not is_admin(chat_id):
            self.send_message(chat_id, "❌ سقف تعداد ربات شما پر شده است.\nبرای افزایش سقف، پلن خود را ارتقا دهید 💎", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
            return
        kb = {"inline_keyboard": [
            [{"text": "🔧 ساخت ربات خام", "callback_data": "create_raw"}, {"text": "🎁 ساخت ربات آماده", "callback_data": "create_ready"}],
            [{"text": "❌ انصراف", "callback_data": "back_main"}]
        ]}
        self.send_message(chat_id, """🤖 **ساخت ربات جدید**

یکی را انتخاب کن:

🔧 **ربات خام** → بدون دکمه، خودت از صفر همه‌چیز رو در پنل مدیریت میسازی (دکمه، متن، عکس...)

🎁 **ربات آماده** → قالب‌های 100 میلیونی (مدیریت گروه VIP / کسب درآمد VIP) با یک کلیک فعال میشه

کدوم؟""", reply_markup=kb)

    def cmd_my_bots(self, chat_id: int):
        bots = self.db.get_user_bots(chat_id)
        if not bots:
            self.send_message(chat_id, "🤷‍♂️ هنوز رباتی نساخته‌اید.\n\nبرای ساخت ربات روی «🤖 ساخت ربات» کلیک کنید.", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
            return
        text = "⚙️ **ربات‌های من**\n\nلیست ربات‌های شما:"
        for b in bots:
            status = "🟢 فعال" if b["is_active"] and b["status"] == "online" else "🔴 آفلاین"
            exp = b["expires_at"] or "نامحدود"
            if exp != "نامحدود":
                try:
                    exp_dt = datetime.fromisoformat(exp)
                    exp = exp_dt.strftime("%Y/%m/%d")
                    if exp_dt < datetime.now():
                        status = "⛔ منقضی"
                except:
                    pass
            text += f"\n\n🤖 **{b['bot_name'] or 'بدون نام'}** (@{b['bot_username'] or '---'})\n🆔 `{b['id']}` | {status}\n📅 انقضا: {exp}\n👥 کاربران: {b['user_count'] or 0}"
        
        # کیبورد inline برای مدیریت
        rows = []
        for b in bots:
            name = b["bot_name"] or b["bot_username"] or f"ربات {b['id']}"
            rows.append([{"text": f"🎛 مدیریت {name}", "callback_data": f"manage_{b['id']}"}])
        kb = {"inline_keyboard": rows}
        self.send_message(chat_id, text, reply_markup=kb)

    def cmd_manage_bots(self, chat_id: int):
        bots = self.db.get_user_bots(chat_id)
        if not bots:
            self.send_message(chat_id, "🤷‍♂️ رباتی برای مدیریت وجود ندارد.", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
            return
        text = "🎛 **مدیریت ربات‌ها**\n\nربات مورد نظر را انتخاب کنید:"
        rows = []
        for b in bots:
            status = "🟢" if b["is_active"] else "🔴"
            name = b["bot_name"] or b["bot_username"] or f"ربات {b['id']}"
            rows.append([{"text": f"{status} {name}", "callback_data": f"manage_{b['id']}"}])
        kb = {"inline_keyboard": rows}
        self.send_message(chat_id, text, reply_markup=kb)

    def show_bot_manage(self, chat_id: int, bot_id: int, msg_id: int = None):
        bot = self.db.get_bot(bot_id)
        if not bot or (bot["owner_id"] != chat_id and not is_admin(chat_id)):
            self.send_message(chat_id, "❌ دسترسی غیرمجاز یا ربات یافت نشد.")
            return
        status = "🟢 آنلاین" if bot["is_active"] and bot["status"] == "online" else "🔴 آفلاین"
        if bot["expires_at"]:
            try:
                exp = datetime.fromisoformat(bot["expires_at"])
                exp_str = exp.strftime("%Y/%m/%d %H:%M")
                days_left = (exp - datetime.now()).days
                if days_left < 0:
                    status = "⛔ منقضی شده"
                else:
                    status += f" ({days_left} روز باقی‌مانده)"
            except:
                exp_str = bot["expires_at"]
        else:
            exp_str = "نامحدود"
        
        # اطلاعات تکمیلی
        user_count = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=?", (bot_id,))["c"]
        button_count = self.db.fetchone("SELECT COUNT(*) as c FROM bot_buttons WHERE bot_id=?", (bot_id,))["c"]
        
        text = f"""🤖 **مدیریت ربات**

📛 نام: {bot['bot_name'] or '---'}
🆔 یوزرنیم: @{bot['bot_username'] or '---'}
🆔 شناسه: `{bot['bot_id'] or '---'}`
📊 وضعیت: {status}
📅 انقضا: {exp_str}
👥 کاربران: {user_count}
🔘 دکمه‌ها: {button_count}
🔑 توکن: `{mask_token(decrypt_token(bot['token_encrypted'])) if bot['token_encrypted'] else '---'}`"""

        kb = bot_manage_keyboard(bot_id, bot["is_active"] and bot["status"] == "online")
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def show_bot_panel(self, chat_id: int, bot_id: int, msg_id: int = None):
        bot = self.db.get_bot(bot_id)
        if not bot:
            self.send_message(chat_id, "❌ ربات یافت نشد.")
            return
        text = f"""🎛 **پنل مدیریت ربات**

🤖 {bot['bot_name'] or bot['bot_username']}

یک گزینه را انتخاب کنید:"""
        kb = bot_panel_keyboard(bot_id)
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def toggle_bot(self, chat_id: int, bot_id: int, stop: bool, msg_id: int = None):
        bot = self.db.get_bot(bot_id)
        if not bot or (bot["owner_id"] != chat_id and not is_admin(chat_id)):
            self.send_message(chat_id, "❌ دسترسی غیرمجاز.")
            return
        if stop:
            self.bot_manager.stop_bot(bot_id)
            self.db.execute("UPDATE bots SET is_active=0, status='offline' WHERE id=?", (bot_id,))
            self.send_message(chat_id, f"⏸ ربات {bot['bot_name']} متوقف شد.")
        else:
            # چک انقضا
            if bot["expires_at"]:
                try:
                    exp = datetime.fromisoformat(bot["expires_at"])
                    if exp < datetime.now():
                        self.send_message(chat_id, "⛔ اشتراک ربات منقضی شده است. لطفا تمدید کنید 💎")
                        return
                except:
                    pass
            ok = self.bot_manager.start_bot(bot_id, bot["token_encrypted"])
            if ok:
                self.db.execute("UPDATE bots SET is_active=1, status='online' WHERE id=?", (bot_id,))
                self.send_message(chat_id, f"▶️ ربات {bot['bot_name']} با موفقیت اجرا شد ✅\nهم‌اکنون آنلاین است.")
            else:
                self.send_message(chat_id, "❌ خطا در اجرای ربات. توکن را بررسی کنید.")
                return
        # بروزرسانی نمایش
        try:
            self.show_bot_manage(chat_id, bot_id, msg_id)
        except:
            pass

    def step_add_content(self, chat_id: int, message: dict, text: str, data: dict) -> bool:
        btn_id = data["btn_id"]
        bot_id = data["bot_id"]
        content = text[:4000] if text else ""
        file_id = None
        file_url = None
        ctype = "text"
        if message.get("photo"):
            photos = message["photo"]
            file_id = photos[-1].get("file_id") if isinstance(photos, list) else photos.get("file_id")
            ctype = "photo"
            content = message.get("caption", content)
        elif message.get("video"):
            file_id = message["video"].get("file_id")
            ctype = "video"
        elif message.get("document"):
            file_id = message["document"].get("file_id")
            ctype = "document"
        # position next
        max_pos = self.db.fetchone("SELECT MAX(position) as m FROM bot_button_contents WHERE button_id=?", (btn_id,))
        pos = (max_pos["m"] or 0) + 1 if max_pos and max_pos["m"] is not None else 0
        self.db.execute("INSERT INTO bot_button_contents (button_id, content_type, content_text, file_id, file_url, position) VALUES (?,?,?,?,?,?)",
                        (btn_id, ctype, content, file_id, file_url, pos))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"✅ مطلب جدید به دکمه اضافه شد ({ctype})\n📄 {content[:80]}", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
        return True

    def step_rename_btn(self, chat_id: int, text: str, data: dict) -> bool:
        btn_id = data["btn_id"]
        new_title = text.strip()[:60]
        if not new_title:
            self.send_message(chat_id, "❌ نام نمی‌تواند خالی باشد")
            return True
        self.db.execute("UPDATE bot_buttons SET title=? WHERE id=?", (new_title, btn_id))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"✅ نام دکمه به «{new_title}» تغییر کرد")
        return True

    def step_btn_link(self, chat_id: int, text: str, data: dict) -> bool:
        btn_id = data["btn_id"]
        t = text.strip()
        if t.lower() in ["حذف", "delete", "off"]:
            self.db.execute("UPDATE bot_buttons SET url='' WHERE id=?", (btn_id,))
            self.send_message(chat_id, "✅ لینک حذف شد")
        else:
            if not t.startswith("http"):
                self.send_message(chat_id, "❌ لینک باید با https:// شروع شود")
                return True
            self.db.execute("UPDATE bot_buttons SET url=? WHERE id=?", (t, btn_id))
            self.send_message(chat_id, f"✅ لینک ثبت شد: {t}")
        self.db.clear_user_step(chat_id)
        return True

    def step_btn_cmd(self, chat_id: int, text: str, data: dict) -> bool:
        btn_id = data["btn_id"]
        t = text.strip()
        if t.lower() in ["حذف", "delete"]:
            self.db.execute("UPDATE bot_buttons SET command='' WHERE id=?", (btn_id,))
            self.send_message(chat_id, "✅ دستور حذف شد")
        else:
            self.db.execute("UPDATE bot_buttons SET command=? WHERE id=?", (t, btn_id))
            self.send_message(chat_id, f"✅ دستور «{t}» ثبت شد - کاربر با ارسال {t} این دکمه را اجرا می‌کند")
        self.db.clear_user_step(chat_id)
        return True

    def step_lock_join(self, chat_id: int, text: str, data: dict) -> bool:
        btn_id = data["btn_id"]
        ch = text.strip().replace("@", "")
        self.db.execute("UPDATE bot_buttons SET is_locked=1, lock_type='join', lock_channel=? WHERE id=?", (ch, btn_id))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"🔒 قفل جوین روی @{ch} فعال شد")
        return True

    def step_lock_ref(self, chat_id: int, text: str, data: dict) -> bool:
        btn_id = data["btn_id"]
        try:
            cnt = int(text.strip())
        except:
            self.send_message(chat_id, "❌ عدد بفرست مثل 5")
            return True
        self.db.execute("UPDATE bot_buttons SET is_locked=1, lock_type='referral', lock_count=? WHERE id=?", (cnt, btn_id))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"👥 قفل زیرمجموعه {cnt} نفر فعال شد")
        return True

    def handle_professional_button(self, chat_id: int, data: str, msg_id: int):
        # data like btn_sendcont_123, btn_hide_123 etc
        try:
            if data.startswith("btn_sendcont_"):
                btn_id = int(data.split("_")[2])
                btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
                if not btn: return
                self.db.set_user_step(chat_id, "await_add_content", {"btn_id": btn_id, "bot_id": btn["bot_id"]})
                self.send_message(chat_id, f"📤 **ارسال مطلب جدید برای «{btn['title']}»**\n\nمتن/عکس/ویدیو/فایل را بفرست. می‌توانی 170 متغیر هم استفاده کنی:\n`FIRSTNAME` `COUNT` `LINK` ...\nبرای دیدن همه `متغیرها` بفرست", reply_markup=cancel_keyboard())
            elif data.startswith("btn_delcont_"):
                btn_id = int(data.split("_")[2])
                contents = self.db.fetchall("SELECT * FROM bot_button_contents WHERE button_id=? ORDER BY position", (btn_id,))
                if not contents:
                    self.send_message(chat_id, "❌ مطلب اضافی وجود ندارد. فقط مطلب اصلی هست که از «حذف همه مطالب» پاک میشه")
                    return
                rows = []
                for ct in contents:
                    txt = (ct["content_text"][:20] + "...") if ct["content_text"] and len(ct["content_text"])>20 else (ct["content_text"] or ct["content_type"])
                    rows.append([{"text": f"🗑 {txt}", "callback_data": f"delcont_{ct['id']}_{btn_id}"}])
                rows.append([{"text": "⬅️ بازگشت", "callback_data": f"editbtn_{btn_id}"}])
                self.edit_or_send(chat_id, msg_id, f"🗑 کدام مطلب حذف شود؟ ({len(contents)} عدد)", reply_markup={"inline_keyboard": rows})
            elif data.startswith("delcont_"):
                parts = data.split("_")
                cont_id = int(parts[1]); btn_id = int(parts[2])
                self.db.execute("DELETE FROM bot_button_contents WHERE id=?", (cont_id,))
                self.send_message(chat_id, "✅ مطلب حذف شد")
                self.start_edit_button(chat_id, btn_id, msg_id)
            elif data.startswith("btn_sendtype_"):
                btn_id = int(data.split("_")[2])
                kb = {"inline_keyboard": [
                    [{"text": "📝 متن ساده", "callback_data": f"settype_text_{btn_id}"}, {"text": "🎨 متن با پیش‌نمایش", "callback_data": f"settype_markdown_{btn_id}"}],
                    [{"text": "🖼 عکس+کپشن", "callback_data": f"settype_photo_{btn_id}"}, {"text": "🎥 ویدیو", "callback_data": f"settype_video_{btn_id}"}],
                    [{"text": "⬅️ بازگشت", "callback_data": f"editbtn_{btn_id}"}]
                ]}
                self.edit_or_send(chat_id, msg_id, "🔄 **نوع ارسال** را انتخاب کن:", reply_markup=kb)
            elif data.startswith("settype_"):
                parts = data.split("_")
                t = parts[1]; btn_id = int(parts[2])
                self.db.execute("UPDATE bot_buttons SET send_type=? WHERE id=?", (t, btn_id))
                self.edit_or_send(chat_id, msg_id, f"✅ نوع ارسال به «{t}» تغییر کرد", reply_markup={"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": f"editbtn_{btn_id}"}]]})
            elif data.startswith("btn_delall_"):
                btn_id = int(data.split("_")[2])
                self.db.execute("DELETE FROM bot_button_contents WHERE button_id=?", (btn_id,))
                self.db.execute("UPDATE bot_buttons SET content_text='', file_id='', file_url='', caption='' WHERE id=?", (btn_id,))
                self.send_message(chat_id, "🧹 همه مطالب دکمه پاک شد (دکمه بدون محتوا شد)")
            elif data.startswith("btn_rename_"):
                btn_id = int(data.split("_")[2])
                btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
                self.db.set_user_step(chat_id, "await_rename_btn", {"btn_id": btn_id})
                self.send_message(chat_id, f"✏️ نام فعلی: «{btn['title']}»\nنام جدید را بفرست:", reply_markup=cancel_keyboard())
            elif data.startswith("btn_link_"):
                btn_id = int(data.split("_")[2])
                btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
                cur = btn["url"] or "ندارد"
                self.db.set_user_step(chat_id, "await_btn_link", {"btn_id": btn_id})
                self.send_message(chat_id, f"🔗 لینک فعلی: {cur}\nلینک جدید را بفرست (https://...) یا «حذف» برای پاک کردن:", reply_markup=cancel_keyboard())
            elif data.startswith("btn_move_"):
                btn_id = int(data.split("_")[2])
                btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
                bot_id = btn["bot_id"]
                rows = []
                for r in range(4):
                    rows.append([{"text": f"ردیف {r+1}" + (" ✅" if btn["row"]==r else ""), "callback_data": f"moveto_{btn_id}_{r}"}])
                rows.append([{"text": "⬅️ بازگشت", "callback_data": f"editbtn_{btn_id}"}])
                self.edit_or_send(chat_id, msg_id, f"↔️ **انتقال دکمه «{btn['title']}»**\nسطر فعلی: {btn['row']+1}\nسطر جدید را انتخاب کن:", reply_markup={"inline_keyboard": rows})
            elif data.startswith("moveto_"):
                parts = data.split("_")
                btn_id = int(parts[1]); new_row = int(parts[2])
                self.db.execute("UPDATE bot_buttons SET row=? WHERE id=?", (new_row, btn_id))
                self.send_message(chat_id, f"✅ به ردیف {new_row+1} منتقل شد")
            elif data.startswith("btn_cmd_"):
                btn_id = int(data.split("_")[2])
                btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
                cur = btn["command"] or "ندارد"
                self.db.set_user_step(chat_id, "await_btn_cmd", {"btn_id": btn_id})
                self.send_message(chat_id, f"⚙️ دستور فعلی: {cur}\nدستور جدید را بفرست (مثل /help) یا «حذف»:", reply_markup=cancel_keyboard())
            elif data.startswith("btn_lock_"):
                btn_id = int(data.split("_")[2])
                kb = {"inline_keyboard": [
                    [{"text": "🔒 قفل جوین اجباری", "callback_data": f"lock_join_{btn_id}"}, {"text": "👥 قفل زیرمجموعه", "callback_data": f"lock_ref_{btn_id}"}],
                    [{"text": "🔓 حذف قفل", "callback_data": f"lock_off_{btn_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"editbtn_{btn_id}"}]
                ]}
                self.edit_or_send(chat_id, msg_id, "🔒 **قفل دکمه**\n\nکاربر برای استفاده باید شرط را داشته باشد:", reply_markup=kb)
            elif data.startswith("lock_join_"):
                btn_id = int(data.split("_")[2])
                self.db.set_user_step(chat_id, "await_lock_join", {"btn_id": btn_id})
                self.send_message(chat_id, "🔒 آیدی کانال جوین اجباری را بفرست:\nمثل `@channel` یا `channel_username`", reply_markup=cancel_keyboard())
            elif data.startswith("lock_ref_"):
                btn_id = int(data.split("_")[2])
                self.db.set_user_step(chat_id, "await_lock_ref", {"btn_id": btn_id})
                self.send_message(chat_id, "👥 حداقل تعداد زیرمجموعه برای باز شدن دکمه را بفرست:\nمثل `5` یعنی 5 دعوت لازم است", reply_markup=cancel_keyboard())
            elif data.startswith("lock_off_"):
                btn_id = int(data.split("_")[2])
                self.db.execute("UPDATE bot_buttons SET is_locked=0, lock_type='', lock_channel='', lock_count=0 WHERE id=?", (btn_id,))
                self.send_message(chat_id, "🔓 قفل حذف شد - دکمه برای همه آزاد است")
            elif data.startswith("btn_hide_"):
                btn_id = int(data.split("_")[2])
                btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
                new_val = 0 if btn["is_hidden"] else 1
                self.db.execute("UPDATE bot_buttons SET is_hidden=? WHERE id=?", (new_val, btn_id))
                self.edit_or_send(chat_id, msg_id, f"{'👁 مخفی شد' if new_val else '✅ نمایش داده شد'}", reply_markup={"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": f"editbtn_{btn_id}"}]]})
            elif data.startswith("btn_vars_"):
                btn_id = int(data.split("_")[2])
                guide = """📜 **170 متغیر - کپی کن**

👤 `FIRSTNAME` `LASTNAME` `FULLNAME` `USERID` `USERNAME` `CHATID` `BIO` `PHONE` `MENTION`
🤖 `BOTUSER` `BOTFNAME` `BOTID` `BOTLINK` `GROUPNAME` `MEMBERCOUNT`
⏰ `TIME` `HOUR` `MIN` `SEC` `DATE` `DATEEN` `DAY` `FASL` `MAHFA` `YEAR` `MONTH` `TIMESTAMP`
🎯 `COUNT` `COIN` `BALANCE` `MONEY` `POINT` `LEVEL` `EARNED` `LINK` `WARN` `WARNLEFT`
👮 `GROUPID` `GROUPMEMBERS` `GROUPADMINS` `TODAYMSG` `TOPUSER`
🕌 `ZEKR` `HADITH-TITLE` `QURAN`
🎲 `RANDOM` `RANDOM1000` `VERSION`
🎨 `EditeMsg(a|b|c)` `PMGUARD`

مثال: سلام FIRSTNAME! موجودی: COIN سکه | لینک: LINK
"""
                self.send_message(chat_id, guide)
        except Exception as e:
            self.send_message(chat_id, f"❌ خطا: {e}")

    def confirm_delete_bot(self, chat_id: int, bot_id: int, msg_id: int):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        text = f"""⚠️ **هشدار حذف ربات**

آیا از حذف ربات **{bot['bot_name']}** (@{bot['bot_username']}) مطمئن هستید؟

❗ تمام اطلاعات، کاربران و دکمه‌های ربات حذف خواهند شد و قابل بازگشت نیست."""
        kb = confirm_keyboard("delete", bot_id)
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def delete_bot(self, chat_id: int, bot_id: int, msg_id: int):
        bot = self.db.get_bot(bot_id)
        if not bot or (bot["owner_id"] != chat_id and not is_admin(chat_id)):
            self.send_message(chat_id, "❌ دسترسی غیرمجاز.")
            return
        self.bot_manager.stop_bot(bot_id)
        self.db.delete_bot(bot_id)
        self.edit_or_send(chat_id, msg_id, f"🗑 ربات {bot['bot_name']} با موفقیت حذف شد.")
        self.send_main_menu(chat_id, "✅ ربات حذف شد. می‌توانید ربات جدید بسازید.")

    def send_referral_link(self, chat_id: int):
        """منطق بهتر زیرمجموعه‌گیری - فقط کلمه link"""
        user = self.db.get_user(chat_id)
        stats = self.db.get_referral_stats(chat_id)
        me = self.me
        username = me.get("username", "bot") if me else "bot"
        link = f"ble.ir/{username}?start=ref_{chat_id}"
        balance = self.db.get_wallet(chat_id)
        # آمار امروز
        today_refs = self.db.fetchone("SELECT COUNT(*) as c FROM referrals WHERE inviter_id=? AND date(created_at)=date('now')", (chat_id,))["c"]
        text = f"""🔗 **لینک دعوت شما**

`{link}`

👆 **لمس کن کپی میشه**

📊 آمار:
👥 کل: {stats['total']} نفر | امروز: {today_refs} نفر
💰 درآمد: {stats['earnings']:,} تومان | کیف: {balance:,} تومان

🎁 هر دعوت = 1000 تومان + 1 روز اشتراک
📤 لینک رو به دوستات بده!"""
        kb = {"inline_keyboard": [
            [{"text": "📤 اشتراک‌گذاری", "url": f"https://ble.ir/{username}?start=ref_{chat_id}"}],
            [{"text": "📊 آمار کامل", "callback_data": "ref_full"}]
        ]}
        self.send_message(chat_id, text, reply_markup=kb)

    def cmd_referral(self, chat_id: int):
        user = self.db.get_user(chat_id)
        stats = self.db.get_referral_stats(chat_id)
        me = self.me
        username = me.get("username", "bot") if me else "bot"
        link = f"ble.ir/{username}?start=ref_{chat_id}"
        balance = self.db.get_wallet(chat_id)
        
        refs = self.db.fetchall("SELECT * FROM referrals WHERE inviter_id=? AND platform_referral=1 ORDER BY created_at DESC LIMIT 15", (chat_id,))
        ref_list = ""
        for r in refs:
            invited = self.db.get_user(r["invited_id"])
            name = invited["first_name"] if invited and invited["first_name"] else str(r["invited_id"])
            ref_list += f"\n• {name} - {r['created_at'][:10]} ✅"
        if not ref_list:
            ref_list = "\nهنوز کسی دعوت نکرده‌اید. لینک بالا را منتشر کن!"

        top = self.db.fetchall("SELECT inviter_id, COUNT(*) as c FROM referrals WHERE platform_referral=1 GROUP BY inviter_id ORDER BY c DESC LIMIT 5")
        leaderboard = ""
        for i, t in enumerate(top, 1):
            u = self.db.get_user(t["inviter_id"])
            n = u["first_name"] if u and u["first_name"] else str(t["inviter_id"])
            leaderboard += f"\n{i}⃣ {n} - {t['c']} نفر"
        if not leaderboard:
            leaderboard = "\nهنوز کسی دعوت نکرده - تو اول باش!"

        text = f"""👥 **زیرمجموعه‌گیری هوشمند**

🔗 **لینک اختصاصی شما:**
`{link}`

👆 **لمس کن کپی میشه → بفرست به دوستات**

━━━━━━━━━━━━━━━━━━━━━━
📊 **آمار شما:**
👤 کل دعوت: **{stats['total']}** نفر
📅 امروز: **{stats.get('today',0)}** نفر
💰 درآمد: **{stats['earnings']:,} تومان**
💳 کیف پول: **{balance:,} تومان**

🎁 **پاداش:** هر دعوت = **1000 تومان + 1 روز رایگان**
💡 3 دعوت = 5000 تومان هدیه!

📋 **آخرین دعوت‌ها:**
{ref_list}

🏆 **برترین‌ها:**
{leaderboard}

🚀 **راز:** لینک رو در بیو، گروه، کانال بذار!"""
        kb = {"inline_keyboard": [
            [{"text": "📤 اشتراک‌گذاری", "url": f"https://ble.ir/{username}?start=ref_{chat_id}"}],
            [{"text": "📋 کپی لینک", "copy_text": {"text": link}}, {"text": "📊 آمار کامل", "callback_data": "ref_full"}],
            [{"text": "🎁 دریافت هدیه (3 دعوت)", "callback_data": f"claim_ref_{chat_id}"}],
        ]}
        self.send_message(chat_id, text, reply_markup=kb)


    def cmd_wallet(self, chat_id: int):
        balance = self.db.get_wallet(chat_id)
        card = self.db.fetchone("SELECT * FROM card_settings WHERE id=1")
        if card and card["card_number"]:
            card_num = card["card_number"]
            card_holder = card["card_holder"] if card["card_holder"] else "ربات‌ساز"
        else:
            card_num = "6037-XXXX-XXXX-1234"
            card_holder = "ربات‌ساز"
            try:
                self.db.execute("INSERT OR IGNORE INTO card_settings (id, card_number, card_holder) VALUES (1, ?, ?)", (card_num, card_holder))
            except:
                pass
        trans = self.db.fetchall("SELECT * FROM wallet_requests WHERE user_id=? ORDER BY created_at DESC LIMIT 5", (chat_id,))
        tlist = ""
        for t in trans:
            st = {"pending":"⏳ در انتظار","approved":"✅ تایید","rejected":"❌ رد"}.get(t["status"], t["status"])
            tlist += f"\n• {t['amount']:,}ت - {st} - {t['created_at'][:10]}"
        if not tlist:
            tlist = "\nتراکنشی وجود ندارد"
        text = f"""💳 **کیف پول شما**

💰 موجودی: **{balance:,} تومان**

💳 **شماره کارت:**
`{card_num}`
👤 به نام: {card_holder}

📋 **آخرین درخواست‌ها:**
{tlist}

👇 مبلغ را انتخاب یا عدد بفرست:"""
        kb = {"inline_keyboard": [
            [{"text": "💳 50 هزار", "callback_data": "charge_50000"}, {"text": "💳 100 هزار", "callback_data": "charge_100000"}],
            [{"text": "💳 200 هزار", "callback_data": "charge_200000"}, {"text": "💳 500 هزار", "callback_data": "charge_500000"}],
            [{"text": "📋 تاریخچه کامل", "callback_data": "wallet_hist"}]
        ]}
        self.db.set_user_step(chat_id, "await_wallet_amount")
        self.send_message(chat_id, text, reply_markup=kb)

    def cmd_templates(self, chat_id: int):
        text = """🎁 **قالب‌های آماده (15 ربات حرفه‌ای)**

یک قالب را انتخاب کن تا رباتت با دکمه‌های آماده ساخته شود:

💰 کسب درآمد | 👮 مدیریت گروه | 💬 چت ناشناس
🛒 فروشگاه | 📊 نظرسنجی | 🎉 قرعه‌کشی
📥 دانلودر | 🌐 مترجم | 🌤 هواشناسی
₿ ارز دیجیتال | 🧠 کوییز | 🎫 پشتیبانی
📅 رزرواسیون | 📰 خبرخوان | 🎮 بازی

بعد از ساخت ربات، از "مدیریت ربات‌ها" قالب را اعمال کن."""
        rows = []
        # ساخت کیبورد 3 ستونه
        tmpl_list = list(TEMPLATES.items())
        for i in range(0, len(tmpl_list), 2):
            row = []
            for k,v in tmpl_list[i:i+2]:
                row.append({"text": v["name"], "callback_data": f"tmpl_info_{k}"})
            rows.append(row)
        rows.append([{"text": "🤖 ساخت ربات با قالب", "callback_data": "tmpl_create"}])
        kb = {"inline_keyboard": rows}
        self.send_message(chat_id, text, reply_markup=kb)


    def cmd_cool_features(self, chat_id: int, msg_id: int = None):
        text = """🔥 **قابلیت‌های حرفه‌ای**

💳 کیف پول | 🔄 انتقال مالکیت | 🎁 20 قالب
⏰ زمان‌بندی | 🛡 ضداسپم | 🏷 تگ‌گذاری
📊 نظرسنجی | 🎉 قرعه‌کشی | 💬 چت ناشناس
🛒 فروشگاه | 📈 آمار | 🔗 لینک کوتاه
📷 QR | 🎫 پشتیبانی | 🌐 مترجم
📢 تارگت | 🖼 مدیا | 🔔 خوش‌آمد
📤 بکاپ | 🌐 وب‌هوک | 🎮 بازی

از پنل ربات فعال کن!"""
        kb = cool_features_keyboard()
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def cmd_settings(self, chat_id: int):
        balance = self.db.get_wallet(chat_id)
        text = f"""⚙️ **تنظیمات**

💳 موجودی: {balance:,} تومان
🤖 ربات‌ها: {len(self.db.get_user_bots(chat_id))}
👥 دعوت: {self.db.fetchone("SELECT invite_count FROM users WHERE user_id=?", (chat_id,))["invite_count"] if self.db.get_user(chat_id) else 0}

همه چیز اوکیه! ✅"""
        self.send_message(chat_id, text)

    def cmd_bot_cool(self, chat_id: int, bot_id: int, msg_id: int = None):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        text = f"🔥 **امکانات خفن ربات {bot['bot_name']}**\n\nیک قابلیت را انتخاب کن:"
        kb = bot_cool_keyboard(bot_id)
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def apply_template(self, chat_id: int, bot_id: int, tmpl_key: str):
        bot = self.db.get_bot(bot_id)
        if not bot or (bot["owner_id"] != chat_id and not is_admin(chat_id)):
            self.send_message(chat_id, "❌ دسترسی غیرمجاز")
            return
        tmpl = TEMPLATES.get(tmpl_key)
        if not tmpl:
            self.send_message(chat_id, "❌ قالب یافت نشد")
            return
        # حذف دکمه‌های قبلی اگر خواست
        # اضافه کردن دکمه‌های قالب
        for b in tmpl["buttons"]:
            self.db.execute("INSERT INTO bot_buttons (bot_id, title, button_type, row, position, action_type, content_text) VALUES (?,?,?,?,?,?,?)",
                (bot_id, b["title"], b["type"], b["row"], 0, b["action"], b["content"]))
        self.db.execute("INSERT INTO bot_templates_log (bot_id, template) VALUES (?,?)", (bot_id, tmpl_key))
        self.send_message(chat_id, f"✅ قالب **{tmpl['name']}** با {len(tmpl['buttons'])} دکمه به ربات {bot['bot_name']} اضافه شد!\n\nاز پنل ربات می‌توانی همه را ویرایش کنی.")


    def cmd_subscription(self, chat_id: int):
        plans = self.db.fetchall("SELECT * FROM plans WHERE is_active=1")
        bots = self.db.get_user_bots(chat_id)
        text = "💎 **اشتراک و تمدید**\n\nپلن‌های موجود:\n"
        for p in plans:
            text += f"\n💎 **{p['name']}** - {p['price']:,} تومان\n⏱ {p['days']} روز | 🤖 {p['max_bots']} ربات | 👥 {p['max_users']} کاربر\n📝 {p['description']}\n"
        
        if bots:
            text += "\n\n🤖 ربات‌های شما:"
            for b in bots:
                exp = b["expires_at"] or "نامحدود"
                if exp != "نامحدود":
                    try:
                        exp = datetime.fromisoformat(exp).strftime("%Y/%m/%d")
                    except:
                        pass
                text += f"\n• {b['bot_name']} - انقضا: {exp}"
        
        rows = []
        for p in plans:
            rows.append([{"text": f"💎 خرید {p['name']} - {p['price']:,} ت", "callback_data": f"plan_{p['id']}"}])
        if bots:
            rows.append([{"text": "🔄 تمدید ربات", "callback_data": f"renew_{bots[0]['id']}"}])
        kb = {"inline_keyboard": rows}
        self.send_message(chat_id, text, reply_markup=kb)

    def show_plans(self, chat_id: int, bot_id: int, msg_id: int = None):
        plans = self.db.fetchall("SELECT * FROM plans WHERE is_active=1")
        self.db.set_user_step(chat_id, "await_plan_select", {"bot_id": bot_id})
        text = f"💎 پلن مورد نظر برای ربات #{bot_id} را انتخاب کنید:"
        kb = plans_keyboard(plans)
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def renew_bot(self, chat_id: int, bot_id: int, plan_id: int, msg_id: int = None):
        bot = self.db.get_bot(bot_id)
        plan = self.db.fetchone("SELECT * FROM plans WHERE id=?", (plan_id,))
        if not bot or not plan:
            self.send_message(chat_id, "❌ اطلاعات یافت نشد.")
            return
        if bot["owner_id"] != chat_id and not is_admin(chat_id):
            self.send_message(chat_id, "❌ دسترسی غیرمجاز.")
            return
        
        # تمدید - اگر پولی باشد، در نسخه دمو مستقیم تمدید می‌کنیم
        # در نسخه واقعی باید درگاه پرداخت چک شود
        now = datetime.now()
        current_exp = bot["expires_at"]
        if current_exp:
            try:
                exp_dt = datetime.fromisoformat(current_exp)
                if exp_dt > now:
                    new_exp = exp_dt + timedelta(days=plan["days"])
                else:
                    new_exp = now + timedelta(days=plan["days"])
            except:
                new_exp = now + timedelta(days=plan["days"])
        else:
            new_exp = now + timedelta(days=plan["days"])
        
        self.db.execute("UPDATE bots SET expires_at=?, plan_id=?, is_active=1 WHERE id=?", (new_exp.isoformat(), plan_id, bot_id))
        self.db.execute("INSERT INTO subscriptions (bot_id, plan_id, start_at, end_at) VALUES (?,?,?,?)",
                        (bot_id, plan_id, now.isoformat(), new_exp.isoformat()))
        
        # فعال‌سازی مجدد اگر آفلاین بود
        try:
            self.bot_manager.start_bot(bot_id, bot["token_encrypted"])
        except:
            pass
        
        text = f"""✅ **تمدید موفقیت‌آمیز**

🤖 ربات: {bot['bot_name']}
💎 پلن: {plan['name']}
📅 انقضای جدید: {new_exp.strftime('%Y/%m/%d %H:%M')}
💰 مبلغ: {plan['price']:,} تومان

ربات شما فعال شد و آماده استفاده است! 🎉"""
        self.edit_or_send(chat_id, msg_id, text)
        self.send_main_menu(chat_id, "✅ تمدید انجام شد.")

    def cmd_my_stats(self, chat_id: int):
        bots = self.db.get_user_bots(chat_id)
        total_users = 0
        total_bots = len(bots)
        active_bots = 0
        for b in bots:
            cnt = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=?", (b["id"],))["c"]
            total_users += cnt
            if b["is_active"] and b["status"] == "online":
                active_bots += 1
        
        user = self.db.get_user(chat_id)
        invite_count = user["invite_count"] if user else 0
        
        text = f"""📊 **آمار من**

👤 شناسه: `{chat_id}`
🤖 تعداد ربات‌ها: {total_bots}
🟢 ربات‌های فعال: {active_bots}
👥 مجموع کاربران ربات‌ها: {total_users}
👥 دعوت‌شدگان: {invite_count} نفر

📅 عضویت از: {user['created_at'][:10] if user else 'نامشخص'}

🤖 **جزئیات ربات‌ها:**"""
        for b in bots:
            cnt = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=?", (b["id"],))["c"]
            status = "🟢" if b["is_active"] else "🔴"
            text += f"\n{status} {b['bot_name']} - {cnt} کاربر"
        
        self.send_message(chat_id, text)

    def cmd_help(self, chat_id: int):
        text = """📚 **راهنمای کامل ربات‌ساز بله - ULTRA v4**

━━━━━━━━━━━━━━━━━━━━━━
🤖 **ساخت ربات (30 ثانیه):**
1️⃣ روی «🤖 ساخت ربات» بزن
2️⃣ به @botfather در بله برو → /newbot → نام بده → توکن بگیر
3️⃣ توکن رو اینجا بفرست (مثال: 123456:ABC...)
4️⃣ قالب انتخاب کن: 
   ▫️ خام - خالی
   ▫️ آماده - 20 قالب تست‌شده (کسب درآمد، فروشگاه...)
5️⃣ تمام! رباتت آنلاینه ✅

━━━━━━━━━━━━━━━━━━━━━━
🔘 **دکمه‌سازی حرفه‌ای:**
• «🎛 مدیریت ربات‌ها» → ربات → «🔘 دکمه‌ها»
• «➕ افزودن دکمه» → نوع: شیشه‌ای (زیر پیام) یا معمولی (کیبورد)
• ردیف انتخاب کن (1 بالا، 4 پایین) → عنوان بده → عملکرد:
  📝 متن | 🖼 عکس | 🎥 ویدیو | 📄 فایل | 🔗 لینک | 📂 منو
• «✏️ ویرایش همه پاسخ‌ها» → هر دکمه رو جدا عوض کن
• «🔄 تغییر ترتیب» → جابجایی

💡 مثال: دکمه "قیمت" → متن "محصول 50,000 تومان" + عکس

━━━━━━━━━━━━━━━━━━━━━━
💳 **شارژ کیف پول:**
• «💳 شارژ کیف پول» → مبلغ (50/100/200 تومن)
• به کارت `6037-...` واریز کن → عکس رسید بفرست
• ادمین تایید می‌کنه → موجودی اضافه میشه (کمتر از 1 ساعت)

━━━━━━━━━━━━━━━━━━━━━━
👥 **زیرمجموعه‌گیری (پولساز):**
• فقط کلمه **link** یا **لینک** رو بنویس → لینکت میاد:
  `ble.ir/USERNAME?start=ref_123456`
• بفرست به دوستات → هر نفر = 1000 تومان + 1 روز اشتراک
• «👥 زیرمجموعه‌گیری» → آمار + لیدربرد

━━━━━━━━━━━━━━━━━━━━━━
📢 **ارسال همگانی:**
• پنل ربات → «📢 ارسال همگانی» → متن/عکس/ویدیو + دکمه
• به همه یا فقط فعال‌ها → تایید → 1 پیام/ثانیه

━━━━━━━━━━━━━━━━━━━━━━
⚙️ **مدیریت ربات:**
• پیام شروع، خوش‌آمد، پیش‌فرض قابل ویرایش
• قفل کانال: @channel بذار → عضویت اجباری
• انتقال مالکیت: آیدی جدید بده
• آمار: کاربران، پیام‌ها، نمودار

❓ مشکل؟ «💬 پشتیبانی» → پیام بده

━━━━━━━━━━━━━━━━━━━━━━
📜 **متغیرها (برای همه مردم - 45 عدد):**
`FIRSTNAME` نام | `LASTNAME` فامیلی
`USERID` آیدی | `USERNAME` یوزرنیم | `CHATID` آیدی چت
`COUNT` زیرمجموعه | `COIN` سکه | `BALANCE` موجودی
`LINK` لینک دعوت | `WARN` اخطار | `JOINER` دعوت‌کننده
`DATE` شمسی | `DATEEN` میلادی | `TIME` زمان کامل
`DAY` روز | `FASL` فصل | `MAHFA` ماه | `BOTFNAME` نام ربات
`BOTUSER` یوزرنیم ربات | `ZEKR` ذکر روز
`EditeMsg(a|b|c)` پیام متحرک | `PMGUARD` ضد فوروارد
مثال: سلام FIRSTNAME! دعوت‌هات: COUNT | لینک: LINK
برای دیدن همه: کلمه `متغیرها` را بفرستید
"""
        self.send_message(chat_id, text)

    def cmd_support(self, chat_id: int):
        self.db.set_user_step(chat_id, "await_support_message")
        self.send_message(chat_id, """💬 **پشتیبانی**

پیام خود را ارسال کنید. تیم پشتیبانی در اسرع وقت پاسخ خواهد داد.

برای انصراف «❌ انصراف» را بزنید.""", reply_markup=cancel_keyboard())

    def cmd_admin(self, chat_id: int, edit_msg_id: int = None):
        if not is_admin(chat_id):
            self.send_message(chat_id, "❌ دسترسی غیرمجاز. شما ادمین نیستید.")
            return
        stats = self.db.get_stats()
        text = f"""🛠 **پنل ادمین اصلی**

👥 کل کاربران: {stats['total_users']}
🤖 کل ربات‌ها: {stats['total_bots']} (فعال: {stats['active_bots']})
👥 کاربران ربات‌ها: {stats['total_bot_users']}

یک بخش را انتخاب کنید:"""
        kb = admin_keyboard()
        self.edit_or_send(chat_id, edit_msg_id, text, reply_markup=kb)

    def handle_admin_callback(self, chat_id: int, data: str, msg_id: int):
        if not is_admin(chat_id):
            return
        if data == "adm_users":
            users = self.db.fetchall("SELECT * FROM users ORDER BY created_at DESC LIMIT 20")
            text = "👥 **آخرین کاربران (20 نفر)**\n\n"
            for u in users:
                blocked = "🚫" if u["is_blocked"] else "✅"
                text += f"{blocked} `{u['user_id']}` - {u['first_name'] or ''} @{u['username'] or ''} | دعوت: {u['invite_count']}\n"
            kb = {"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_admin"}]]}
            self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
        elif data == "adm_bots":
            bots = self.db.fetchall("SELECT * FROM bots ORDER BY created_at DESC LIMIT 20")
            text = "🤖 **آخرین ربات‌ها (20)**\n\n"
            for b in bots:
                status = "🟢" if b["is_active"] else "🔴"
                text += f"{status} #{b['id']} {b['bot_name']} (@{b['bot_username']}) - مالک: `{b['owner_id']}`\n"
            kb = {"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_admin"}]]}
            self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
        elif data == "adm_plans":
            plans = self.db.fetchall("SELECT * FROM plans")
            text = "💳 **مدیریت پلن‌ها**\n\n"
            rows = []
            for p in plans:
                text += f"• {p['name']} - {p['price']} ت - {p['days']} روز - {p['max_bots']} ربات\n"
                rows.append([{"text": f"✏️ {p['name']}", "callback_data": f"plan_{p['id']}"}])
            rows.append([{"text": "➕ افزودن پلن", "callback_data": "adm_add_plan"}, {"text": "⬅️ بازگشت", "callback_data": "back_admin"}])
            kb = {"inline_keyboard": rows}
            self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
        elif data == "adm_add_plan":
            self.db.set_user_step(chat_id, "await_new_plan")
            self.send_message(chat_id, "💎 اطلاعات پلن جدید را با فرمت زیر بفرستید:\n\n`نام|روز|max_bots|max_users|price|توضیحات`\n\nمثال:\n`ویژه|30|10|10000|150000|پلن ویژه یک ماهه`", reply_markup=cancel_keyboard())
        elif data == "adm_stats":
            stats = self.db.get_stats()
            # آمار روزانه
            today = datetime.now().strftime("%Y-%m-%d")
            today_new = self.db.fetchone("SELECT COUNT(*) as c FROM users WHERE date(created_at)=date('now')")["c"]
            text = f"""📊 **آمار کلی**

👥 کل کاربران پلتفرم: {stats['total_users']}
🆕 کاربران امروز: {today_new}
🤖 کل ربات‌ها: {stats['total_bots']}
🟢 ربات‌های فعال: {stats['active_bots']}
👥 مجموع کاربران ربات‌ها: {stats['total_bot_users']}
📢 ارسال‌های همگانی: {self.db.fetchone("SELECT COUNT(*) as c FROM broadcasts")["c"]}

📈 **عملکرد امروز:**
• لاگ‌ها: {self.db.fetchone("SELECT COUNT(*) as c FROM logs")["c"]}
• تیکت‌ها: {self.db.fetchone("SELECT COUNT(*) as c FROM tickets")["c"]}"""
            kb = {"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_admin"}]]}
            self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
        elif data == "adm_tickets":
            tickets = self.db.fetchall("SELECT * FROM tickets ORDER BY created_at DESC LIMIT 10")
            if not tickets:
                text = "🎫 هیچ تیکت پشتیبانی وجود ندارد."
            else:
                text = "🎫 **آخرین تیکت‌ها**\n\n"
                rows = []
                for t in tickets:
                    status = "🟢 باز" if t["status"] == "open" else "✅ بسته"
                    text += f"{status} #{t['id']} از `{t['user_id']}` - {t['created_at'][:16]}\n{t['message'][:80]}...\n\n"
                    rows.append([{"text": f"📩 #{t['id']}", "callback_data": f"ticket_{t['id']}"}])
                rows.append([{"text": "⬅️ بازگشت", "callback_data": "back_admin"}])
                kb = {"inline_keyboard": rows}
                self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
                return
            kb = {"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_admin"}]]}
            self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
        elif data == "adm_logs":
            logs = self.db.fetchall("SELECT * FROM logs ORDER BY created_at DESC LIMIT 15")
            text = "📋 **آخرین لاگ‌ها**\n\n"
            for l in logs:
                text += f"[{l['level']}] {l['source']}: {l['message'][:60]}\n"
            kb = {"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_admin"}]]}
            self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)
        elif data == "adm_broadcast":
            self.db.set_user_step(chat_id, "await_admin_broadcast")
            self.send_message(chat_id, "📢 پیام همگانی به همه کاربران سازنده را ارسال کنید (متن/عکس/ویدیو):", reply_markup=cancel_keyboard())
        elif data == "adm_backup":
            try:
                backup_path = f"data/backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                self.db.backup(backup_path)
                self.edit_or_send(chat_id, msg_id, f"💾 پشتیبان با موفقیت ایجاد شد:\n`{backup_path}`")
            except Exception as e:
                self.edit_or_send(chat_id, msg_id, f"❌ خطا در پشتیبان: {e}")
        elif data == "adm_ad":
            ad = self.db.fetchone("SELECT content FROM global_ads WHERE id=1")
            cur = ad["content"] if ad else ""
            self.db.set_user_step(chat_id, "await_admin_ad")
            self.send_message(chat_id, f"📢 **تبلیغ فعلی:**\n{cur}\n\nمتن جدید تبلیغ را بفرست:\nبرای غیرفعال: `off`", reply_markup=cancel_keyboard())
        elif data == "adm_vars":
            guide = """📜 **راهنمای کامل 45 متغیر GOD - برای همه مردم**

👤 **کاربر:**
`FIRSTNAME` نام | `LASTNAME` فامیلی
`USERID` آیدی عددی | `USERNAME` یوزرنیم
`BIO` بیو | `PHONE` تلفن | `CHATID` آیدی چت
`JOINDATE` تاریخ عضویت | `JOINTIME` ساعت عضویت
`JOINER` آیدی دعوت‌کننده

🤖 **ربات:**
`BOTUSER` یوزرنیم ربات | `BOTFNAME` نام ربات
`BOTLIST` لیست ربات‌هات | `MEMBERCOUNT` اعضای ربات
`GROUPNAME` نام ربات

⏰ **زمان:**
`TIME` 14:30:05 | `HOUR` 14 | `MIN` 30 | `SEC` 05
`DATE` 1403/08/12 شمسی | `DATEEN` 2024/11/03 میلادی
`DAY` شنبه | `FASL` پاییز | `MAHFA` آبان
`NHEYVAN` نهنگ | `NBASTANI` عقرب

🎯 **امتیاز:**
`COUNT` زیرمجموعه | `INVITECOUNT` = COUNT
`COIN` سکه | `BALANCE` موجودی
`WARN` اخطار | `MAXWARN` حد اخطار
`LINK` لینک دعوت اختصاصی

🕌 **مذهبی:**
`ZEKR` ذکر روز
`HADITH-TITLE` موضوع | `HADITH-WHO` گوینده
`HADITH-AR` عربی | `HADITH-FA` ترجمه | `HADITH-SRC` منبع

🎨 **ویژه:**
`EditeMsg(a|b|c)` پیام‌های متحرک
`PMGUARD` ضد فوروارد

💡 **مثال:** سلام FIRSTNAME! سکه: COIN | لینک: LINK
کپی کن و در پیام دکمه‌ها استفاده کن!
"""
            self.send_message(chat_id, guide, reply_markup={"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": "back_admin"}]]})
        elif data == "adm_card":
            card = self.db.fetchone("SELECT * FROM card_settings WHERE id=1")
            cn = card["card_number"] if card else "-"
            ch = card["card_holder"] if card and card["card_holder"] else "-"
            self.db.set_user_step(chat_id, "await_admin_card")
            self.send_message(chat_id, f"💳 **تنظیم کارت**\n\nفعلی:\n`{cn}`\nبه نام: {ch}\n\nشماره جدید را بفرست:\nمثال: `6037991100001234`", reply_markup=cancel_keyboard())
        elif data == "adm_settings":
            card = self.db.fetchone("SELECT * FROM card_settings WHERE id=1")
            cn = card["card_number"] if card else "تنظیم نشده"
            ad_row = self.db.fetchone("SELECT content FROM global_ads WHERE id=1")
            ad_txt = ad_row["content"][:50] + "..." if ad_row and ad_row["content"] else "تنظیم نشده"
            text = f"""⚙️ **پنل GOD - همه چیز**

• نرخ ارسال: 1 پیام/ثانیه
• دیتابیس: SQLite | کارت: `{cn}`
• تبلیغ: {ad_txt}
• متغیرها: 30 عدد | قالب: 20 تا

همه چیز رو می‌تونی عوض کنی!"""
            kb = {"inline_keyboard": [
                [{"text": "💳 تنظیم کارت", "callback_data": "adm_card"}, {"text": "📢 تنظیم تبلیغ", "callback_data": "adm_ad"}],
                [{"text": "📜 راهنمای متغیرها", "callback_data": "adm_vars"}, {"text": "⬅️ بازگشت", "callback_data": "back_admin"}]
            ]}
            self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def show_ticket(self, chat_id: int, ticket_id: int, msg_id: int):
        t = self.db.fetchone("SELECT * FROM tickets WHERE id=?", (ticket_id,))
        if not t:
            return
        text = f"""🎫 **تیکت #{t['id']}**

👤 کاربر: `{t['user_id']}`
📅 تاریخ: {t['created_at']}
📊 وضعیت: {t['status']}

💬 **پیام:**
{t['message']}

📝 **پاسخ ادمین:**
{t['admin_response'] or 'هنوز پاسخی ثبت نشده'}"""
        kb = {"inline_keyboard": [[{"text": "✅ بستن تیکت", "callback_data": f"close_ticket_{t['id']}"}, {"text": "⬅️ بازگشت", "callback_data": "adm_tickets"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    # ========== مدیریت دکمه‌ها ==========

    def show_buttons_menu(self, chat_id: int, bot_id: int, msg_id: int = None):
        bot = self.db.get_bot(bot_id)
        if not bot or (bot["owner_id"] != chat_id and not is_admin(chat_id)):
            return
        text = f"🔘 **مدیریت دکمه‌های ربات**\n\n🤖 {bot['bot_name']}\n\nیک گزینه را انتخاب کنید:"
        kb = buttons_menu_keyboard(bot_id)
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def start_add_button(self, chat_id: int, bot_id: int, msg_id: int):
        text = "➕ **افزودن دکمه جدید**\n\nنوع دکمه را انتخاب کنید:\n\n🔘 **شیشه‌ای (Inline)** - زیر پیام نمایش داده می‌شود\n⌨️ **معمولی (Reply)** - در کیبورد اصلی نمایش داده می‌شود"
        kb = button_type_keyboard(bot_id)
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def show_parent_selection(self, chat_id: int, bot_id: int, btype: str, msg_id: int):
        # لیست دکمه‌های منو برای انتخاب والد
        buttons = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=? AND (action_type='menu' OR has_children=1)", (bot_id,))
        text = "📂 **انتخاب منوی والد**\n\nاین دکمه در کدام منو قرار بگیرد؟\n\n• **منوی اصلی (ریشه)** - بدون والد\n• یا یکی از منوهای موجود:"
        rows = [[{"text": "🏠 منوی اصلی (ریشه)", "callback_data": f"parent_0_{bot_id}"}]]
        for b in buttons:
            rows.append([{"text": f"📁 {b['title']}", "callback_data": f"parent_{b['id']}_{bot_id}"}])
        rows.append([{"text": "❌ انصراف", "callback_data": f"buttons_{bot_id}"}])
        kb = {"inline_keyboard": rows}
        # حذف قبلی و ارسال جدید چون edit ممکن است طول بکشد
        try:
            self.api.delete_message(chat_id, msg_id)
        except:
            pass
        self.send_message(chat_id, text, reply_markup=kb)

    def show_button_list(self, chat_id: int, bot_id: int, msg_id: int = None, edit_mode: bool = False, delete_mode: bool = False):
        buttons = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=? ORDER BY row, position", (bot_id,))
        if not buttons:
            self.edit_or_send(chat_id, msg_id, "📭 هیچ دکمه‌ای یافت نشد.\nابتدا دکمه اضافه کنید ➕", reply_markup=buttons_menu_keyboard(bot_id))
            return
        text = f"📋 **لیست دکمه‌ها ({len(buttons)} عدد)**\n\n"
        rows = []
        for b in buttons:
            btype = "🔘" if b["button_type"] == "inline" else "⌨️"
            atype = b["action_type"]
            parent = f" (زیرمنوی #{b['parent_id']})" if b["parent_id"] else ""
            text += f"{btype} **{b['title']}** - {atype}{parent} | سطر {b['row']}\n"
            if edit_mode:
                rows.append([{"text": f"✏️ {b['title']}", "callback_data": f"editbtn_{b['id']}"}])
            elif delete_mode:
                rows.append([{"text": f"🗑 {b['title']}", "callback_data": f"delbtn_{b['id']}"}])
            else:
                rows.append([{"text": f"{btype} {b['title']}", "callback_data": f"editbtn_{b['id']}"}])
        rows.append([{"text": "⬅️ بازگشت", "callback_data": f"buttons_{bot_id}"}])
        kb = {"inline_keyboard": rows}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def start_edit_button(self, chat_id: int, btn_id: int, msg_id: int):
        btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
        if not btn:
            return
        bot_id = btn["bot_id"]
        hidden = "🔴 مخفی" if btn["is_hidden"] else "🟢 فعال"
        locked = f"🔒 قفل: {btn['lock_type'] or 'بدون'}" if btn["is_locked"] else "🔓 بدون قفل"
        cmd = btn["command"] or "ندارد"
        # count contents
        cnt = self.db.fetchone("SELECT COUNT(*) as c FROM bot_button_contents WHERE button_id=?", (btn_id,))
        cnt2 = cnt["c"] if cnt else 0
        main_content = (btn["content_text"][:60] + "...") if btn["content_text"] and len(btn["content_text"])>60 else (btn["content_text"] or "---")
        text = f"""🔘 **مدیریت دکمه**

📛 نام: {btn['title']}
🔘 نوع: {btn['button_type']} | سطر {btn['row']}
📄 مطلب اصلی: {main_content}
📎 مطالب اضافی: {cnt2} عدد
🔗 لینک: {btn['url'] or '---'}
⚙️ دستور: {cmd}
{hidden} | {locked}

یک گزینه را انتخاب کن:"""
        kb = {
            "inline_keyboard": [
                [{"text": "📤 ارسال مطلب", "callback_data": f"btn_sendcont_{btn_id}"}, {"text": "🗑 حذف مطلب", "callback_data": f"btn_delcont_{btn_id}"}],
                [{"text": "🔄 نوع ارسال", "callback_data": f"btn_sendtype_{btn_id}"}, {"text": "🧹 حذف همه مطالب", "callback_data": f"btn_delall_{btn_id}"}],
                [{"text": "✏️ تغییر نام دکمه", "callback_data": f"btn_rename_{btn_id}"}, {"text": "🗑 حذف دکمه", "callback_data": f"delbtn_{btn_id}"}],
                [{"text": "🔗 لینک دکمه", "callback_data": f"btn_link_{btn_id}"}, {"text": "↔️ انتقال دکمه", "callback_data": f"btn_move_{btn_id}"}],
                [{"text": "⚙️ تنظیم دستور", "callback_data": f"btn_cmd_{btn_id}"}, {"text": "🔒 قفل دکمه", "callback_data": f"btn_lock_{btn_id}"}],
                [{"text": "👁 مخفی/نمایش", "callback_data": f"btn_hide_{btn_id}"}, {"text": "📜 متغیرها", "callback_data": f"btn_vars_{btn_id}"}],
                [{"text": "⬅️ بازگشت", "callback_data": f"btn_list_{bot_id}"}],
            ]
        }
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def delete_button(self, chat_id: int, btn_id: int, msg_id: int):
        btn = self.db.fetchone("SELECT * FROM bot_buttons WHERE id=?", (btn_id,))
        if not btn:
            return
        bot_id = btn["bot_id"]
        # حذف فرزندان
        self.db.execute("DELETE FROM bot_buttons WHERE id=?", (btn_id,))
        self.edit_or_send(chat_id, msg_id, f"🗑 دکمه «{btn['title']}» حذف شد ✅")
        self.show_button_list(chat_id, bot_id)

    # ========== ارسال همگانی ==========

    def show_bot_users(self, chat_id: int, bot_id: int, msg_id: int):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        users = self.db.fetchall("SELECT * FROM bot_users WHERE bot_id=? ORDER BY subscribed_at DESC LIMIT 20", (bot_id,))
        total = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=?", (bot_id,))["c"]
        blocked = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=? AND is_blocked=1", (bot_id,))["c"]
        text = f"""👥 **کاربران ربات {bot['bot_name']}**

📊 کل: {total} | 🚫 بلاک: {blocked}
📋 **20 کاربر اخیر:**\n"""
        for u in users:
            name = u["first_name"] or ""
            text += f"• `{u['chat_id']}` - {name} @{u['username'] or ''} - {u['subscribed_at'][:10]}\n"
        kb = {"inline_keyboard": [[{"text": "📢 ارسال همگانی", "callback_data": f"broadcast_{bot_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def show_bot_stats(self, chat_id: int, bot_id: int, msg_id: int):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        total_users = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=?", (bot_id,))["c"]
        today_users = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=? AND date(subscribed_at)=date('now')", (bot_id,))["c"]
        buttons = self.db.fetchone("SELECT COUNT(*) as c FROM bot_buttons WHERE bot_id=?", (bot_id,))["c"]
        broadcasts = self.db.fetchone("SELECT COUNT(*) as c FROM broadcasts WHERE bot_id=?", (bot_id,))["c"]
        referrals = self.db.fetchone("SELECT COUNT(*) as c FROM referrals WHERE bot_id=?", (bot_id,))["c"]
        
        # آمار روزانه
        daily = self.db.fetchall("SELECT * FROM stats_daily WHERE bot_id=? ORDER BY date DESC LIMIT 7", (bot_id,))
        daily_text = ""
        for d in daily:
            daily_text += f"\n📅 {d['date']}: +{d['new_users']} عضو | {d['messages']} پیام"
        if not daily_text:
            daily_text = "\nداده‌ای وجود ندارد"

        text = f"""📊 **آمار ربات {bot['bot_name']}**

👥 کل کاربران: {total_users}
🆕 امروز: {today_users}
🔘 تعداد دکمه‌ها: {buttons}
📢 ارسال همگانی: {broadcasts}
👥 زیرمجموعه: {referrals}
📈 وضعیت: {bot['status']}

📊 **آمار 7 روز اخیر:**
{daily_text}"""
        kb = {"inline_keyboard": [[{"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def show_referral_settings(self, chat_id: int, bot_id: int, msg_id: int):
        settings = self.db.fetchone("SELECT * FROM bot_settings WHERE bot_id=?", (bot_id,))
        enabled = "✅ فعال" if settings and settings["referral_enabled"] else "❌ غیرفعال"
        bot = self.db.get_bot(bot_id)
        link = f"ble.ir/{bot['bot_username']}?start=ref_123" if bot and bot["bot_username"] else "ble.ir/bot?start=ref..."
        count = self.db.fetchone("SELECT COUNT(*) as c FROM referrals WHERE bot_id=?", (bot_id,))["c"]
        text = f"""🎁 **تنظیمات زیرمجموعه‌گیری**

🤖 ربات: {bot['bot_name'] if bot else ''}
📊 وضعیت: {enabled}
👥 کل دعوت‌ها: {count}
🔗 لینک نمونه: `{link}`

کاربران با ارسال لینک `ble.ir/{bot['bot_username'] if bot else 'bot'}?start=ref_{{user_id}}` زیرمجموعه جذب می‌کنند."""

        rows = []
        if settings and settings["referral_enabled"]:
            rows.append([{"text": "❌ غیرفعال‌سازی", "callback_data": f"ref_toggle_{bot_id}"}])
        else:
            rows.append([{"text": "✅ فعال‌سازی", "callback_data": f"ref_toggle_{bot_id}"}])
        rows.append([{"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}])
        kb = {"inline_keyboard": rows}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def show_bot_admins(self, chat_id: int, bot_id: int, msg_id: int):
        admins = self.db.fetchall("SELECT * FROM bot_admins WHERE bot_id=?", (bot_id,))
        text = f"👮 **مدیران ربات #{bot_id}**\n\n"
        if not admins:
            text += "هیچ مدیر اضافی ثبت نشده.\nمالک: شما"
        else:
            for a in admins:
                text += f"• `{a['user_id']}` - {a['permission']}\n"
        kb = {"inline_keyboard": [[{"text": "➕ افزودن مدیر", "callback_data": f"addadmin_{bot_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def start_broadcast(self, chat_id: int, bot_id: int, msg_id: int):
        bot = self.db.get_bot(bot_id)
        if not bot:
            return
        text = f"""📢 **ارسال همگانی - ربات {bot['bot_name']}**

نوع پیام را انتخاب کنید:

📝 متن - پیام متنی ساده
🖼 عکس - تصویر + کپشن
🎥 ویدیو - ویدیو + کپشن
📄 فایل - سند"""
        kb = {
            "inline_keyboard": [
                [{"text": "📝 متن", "callback_data": f"bc_type_text_{bot_id}"}, {"text": "🖼 عکس", "callback_data": f"bc_type_photo_{bot_id}"}],
                [{"text": "🎥 ویدیو", "callback_data": f"bc_type_video_{bot_id}"}, {"text": "📄 فایل", "callback_data": f"bc_type_document_{bot_id}"}],
                [{"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}],
            ]
        }
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def confirm_broadcast(self, chat_id: int, bot_id: int, msg_id: int):
        # اجرای واقعی broadcast
        step = self.db.get_user_step(chat_id)
        if not step or "broadcast_id" not in step["data"]:
            self.send_message(chat_id, "❌ اطلاعات ارسال یافت نشد.")
            return
        bc_id = step["data"]["broadcast_id"]
        self.broadcast_manager.start_broadcast(bc_id)
        self.edit_or_send(chat_id, msg_id, f"🚀 ارسال همگانی #{bc_id} آغاز شد!\n\nدر پس‌زمینه در حال ارسال است. با نرخ 1 پیام/ثانیه.\n\nبرای مشاهده وضعیت از پنل استفاده کنید.")
        self.db.clear_user_step(chat_id)

    # ========== FSM Handler ==========

    def handle_step(self, chat_id: int, message: Dict, text: str, step_info: Dict) -> bool:
        step = step_info["step"]
        data = step_info["data"]
        bot_context = step_info.get("bot_context")

        # پیام خام برای فایل
        has_photo = "photo" in message
        has_document = "document" in message
        has_video = "video" in message

        if step in ["await_token", "await_token_raw", "await_token_ready"]:
            is_ready = (step == "await_token_ready")
            is_raw = (step == "await_token_raw")
            return self.step_token(chat_id, text, mode="ready" if is_ready else "raw" if is_raw else "choice")
        elif step == "await_button_parent":
            return False
        elif step == "await_button_row":
            return False
        elif step == "await_button_title":
            return self.step_button_title(chat_id, text, data)
        elif step == "await_button_action":
            # این هم از callback می‌آید
            return False
        elif step == "await_button_content":
            return self.step_button_content(chat_id, message, text, data)
        elif step == "await_button_url":
            return self.step_button_url(chat_id, text, data)
        elif step == "await_start_message":
            return self.step_start_message(chat_id, text, data)
        elif step == "await_welcome_message":
            return self.step_welcome_message(chat_id, text, data)
        elif step == "await_default_message":
            return self.step_default_message(chat_id, text, data)
        elif step == "await_channel_lock":
            return self.step_channel_lock(chat_id, text, data)
        elif step == "await_broadcast_content":
            return self.step_broadcast_content(chat_id, message, text, data)
        elif step == "await_broadcast_keyboard":
            return self.step_broadcast_keyboard(chat_id, text, data)
        elif step == "await_support_message":
            return self.step_support(chat_id, text)
        elif step == "await_wallet_amount":
            # کاربر مبلغ دلخواه فرستاد
            try:
                amount = int(text.replace(",", "").replace("،", "").strip())
                if 1000 <= amount <= 10000000:
                    card = self.db.fetchone("SELECT * FROM card_settings WHERE id=1")
                    card_num = card["card_number"] if card else "6037-XXXX-XXXX-1234"
                    self.db.execute("INSERT INTO wallet_requests (user_id, amount, status) VALUES (?,?,?)", (chat_id, amount, "awaiting_receipt"))
                    req = self.db.fetchone("SELECT * FROM wallet_requests WHERE user_id=? ORDER BY id DESC LIMIT 1", (chat_id,))
                    self.db.set_user_step(chat_id, "await_receipt", {"amount": amount, "req_id": req["id"]})
                    self.send_message(chat_id, f"💳 به کارت ` {card_num} ` مبلغ **{amount:,} تومان** واریز کن\nسپس **رسید** (عکس) را بفرست 👇", reply_markup=cancel_keyboard())
                    return True
            except:
                pass
            return False
        elif step == "await_receipt":
            return self.step_receipt(chat_id, message, text, data)
        elif step == "await_transfer_owner":
            return self.step_transfer_owner(chat_id, text, data)
        elif step == "await_admin_broadcast":
            return self.step_admin_broadcast(chat_id, message, text)
        elif step == "await_new_plan":
            return self.step_new_plan(chat_id, text)
        elif step == "await_edit_button_title":
            return self.step_edit_title(chat_id, text, data)
        elif step == "await_plan_select":
            return False  # از callback
        elif step == "await_admin_card":
            return self.step_admin_card(chat_id, text, data)
        elif step == "await_admin_ad":
            return self.step_admin_ad(chat_id, text, data)
        elif step == "await_template_choice":
            return False
        elif step == "await_add_content":
            return self.step_add_content(chat_id, message, text, data)
        elif step == "await_rename_btn":
            return self.step_rename_btn(chat_id, text, data)
        elif step == "await_btn_link":
            return self.step_btn_link(chat_id, text, data)
        elif step == "await_btn_cmd":
            return self.step_btn_cmd(chat_id, text, data)
        elif step == "await_lock_join":
            return self.step_lock_join(chat_id, text, data)
        elif step == "await_lock_ref":
            return self.step_lock_ref(chat_id, text, data)
        else:
            self.db.clear_user_step(chat_id)
            return False

    def step_token(self, chat_id: int, text: str, mode: str = "choice") -> bool:
        token = text.strip()
        if not validate_token_format(token):
            self.send_message(chat_id, "❌ فرمت توکن نامعتبر است.\n\nتوکن باید شبیه این باشد:\n`123456789:ABCdef...`\n\nدوباره ارسال کنید یا «❌ انصراف»", reply_markup=cancel_keyboard())
            return True
        
        # اعتبارسنجی با API بله
        self.send_message(chat_id, "⏳ در حال بررسی توکن و اتصال به API بله...")
        result = validate_token(token, self.base_url)
        if not result["ok"]:
            self.send_message(chat_id, f"❌ توکن نامعتبر یا خطا در اتصال:\n{result['error']}\n\nلطفا توکن صحیح را بفرستید.", reply_markup=cancel_keyboard())
            return True
        
        info = result["info"]
        bot_username = info.get("username", "")
        bot_name = info.get("first_name", "")
        bot_id_api = info.get("id")

        # چک تکراری بودن توکن
        enc = encrypt_token(token)
        existing = self.db.fetchone("SELECT * FROM bots WHERE token_encrypted=?", (enc,))
        if existing:
            self.send_message(chat_id, "⚠️ این توکن قبلا ثبت شده است.")
            self.db.clear_user_step(chat_id)
            return True

        if mode == "raw":
            # ساخت مستقیم خام - بدون قالب
            plan = self.db.fetchone("SELECT * FROM plans WHERE name='رایگان'") or self.db.fetchone("SELECT * FROM plans LIMIT 1")
            plan_id = plan["id"] if plan else 1
            from datetime import timedelta as _td
            expires = (datetime.now() + _td(days=plan["days"] if plan else 7)).isoformat()
            self.db.execute("INSERT INTO bots (owner_id, token_encrypted, bot_username, bot_name, bot_id, is_active, status, created_at, expires_at, plan_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (chat_id, enc, bot_username, bot_name, bot_id_api, 1, "offline", datetime.now().isoformat(), expires, plan_id))
            bot_row = self.db.fetchone("SELECT * FROM bots WHERE owner_id=? ORDER BY id DESC LIMIT 1", (chat_id,))
            bot_db_id = bot_row["id"]
            self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id, start_message, welcome_message) VALUES (?,?,?)",
                            (bot_db_id, DEFAULT_START_MESSAGE, DEFAULT_WELCOME_MESSAGE))
            ok = self.bot_manager.start_bot(bot_db_id, enc)
            status_msg = "🟢 آنلاین!" if ok else "🔴 خطا"
            self.db.clear_user_step(chat_id)
            self.send_message(chat_id, f"✅ **ربات خام ساخته شد** 🎉\n🤖 {bot_name} (@{bot_username})\n📅 انقضا: {expires[:10]} | {status_msg}\n\nاز پنل مدیریت همه‌چیز را بساز 👇", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
            return True
        # نمایش انتخاب قالب - قبل از ساخت نهایی
        self.db.set_user_step(chat_id, "await_template_choice", {"token_enc": enc, "bot_username": bot_username, "bot_name": bot_name, "bot_id_api": bot_id_api})
        rows = []
        for k,v in TEMPLATES.items():
            rows.append([{"text": v["name"], "callback_data": f"use_template_{k}"}])
        rows.append([{"text": "🔧 قالب خام (بدون دکمه)", "callback_data": "use_template_raw"}])
        rows.append([{"text": "❌ انصراف", "callback_data": "cancel_create"}])
        kb = {"inline_keyboard": rows}
        text2 = f"""✅ **توکن تایید شد!**

🤖 **{bot_name}** (@{bot_username})
🆔 {bot_id_api}

🎨 **حالا قالب را انتخاب کن:**
هر قالب دکمه‌های آماده دارد، بعدا همه را می‌توانی ویرایش کنی."""
        self.send_message(chat_id, text2, reply_markup=kb)
        return True

    def step_button_title(self, chat_id: int, text: str, data: Dict) -> bool:
        title = sanitize_text(text, 60)
        ok, err = validate_button_title(title)
        if not ok:
            self.send_message(chat_id, f"❌ {err}\nدوباره بفرستید:", reply_markup=cancel_keyboard())
            return True
        # چک تکراری در همان والد
        bot_id = data["bot_id"]
        parent_id = data["parent_id"]
        if parent_id:
            exists = self.db.fetchone("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND parent_id=?", (bot_id, title, parent_id))
        else:
            exists = self.db.fetchone("SELECT * FROM bot_buttons WHERE bot_id=? AND title=? AND parent_id IS NULL", (bot_id, title))
        if exists:
            self.send_message(chat_id, "⚠️ دکمه با این عنوان در همین منو وجود دارد. عنوان دیگری بفرستید:", reply_markup=cancel_keyboard())
            return True

        data["title"] = title
        # انتخاب سطر/موقعیت خودکار
        # بیشترین position در آن والد
        if parent_id:
            max_pos = self.db.fetchone("SELECT MAX(position) as m FROM bot_buttons WHERE bot_id=? AND parent_id=?", (bot_id, parent_id))
        else:
            max_pos = self.db.fetchone("SELECT MAX(position) as m FROM bot_buttons WHERE bot_id=? AND parent_id IS NULL", (bot_id,))
        pos = (max_pos["m"] or 0) + 1
        data["position"] = pos
        data["row"] = 0

        self.db.set_user_step(chat_id, "await_button_action", data)
        self.send_message(chat_id, f"✅ عنوان «{title}» ثبت شد.\n\nحالا **عملکرد دکمه** را انتخاب کنید:", reply_markup=button_action_keyboard(bot_id))
        return True

    def step_button_content(self, chat_id: int, message: Dict, text: str, data: Dict) -> bool:
        action = data["action_type"]
        bot_id = data["bot_id"]
        content = sanitize_text(text, 4000)
        
        file_id = None
        file_url = None
        caption = None

        # اگر کاربر فایل فرستاده
        if message.get("photo"):
            # بزرگترین سایز
            photos = message["photo"]
            if isinstance(photos, list) and photos:
                file_id = photos[-1].get("file_id") or photos[-1].get("fileId")
            caption = message.get("caption", content)
            content = caption or content
        elif message.get("document"):
            file_id = message["document"].get("file_id")
            caption = message.get("caption", "")
        elif message.get("video"):
            file_id = message["video"].get("file_id")
            caption = message.get("caption", "")
        elif message.get("audio"):
            file_id = message["audio"].get("file_id")

        # اگر file_id نگرفتیم و متن شامل URL است
        if not file_id and text.startswith("http"):
            file_url = text.strip()

        data["content_text"] = content
        data["file_id"] = file_id
        data["file_url"] = file_url
        data["caption"] = caption

        # اگر اکشن text و محتوا خالی باشد
        if action == "text" and not content:
            self.send_message(chat_id, "❌ متن نمی‌تواند خالی باشد. دوباره بفرستید:", reply_markup=cancel_keyboard())
            return True

        self.create_button_from_step(chat_id, data, content_text=content)
        return True

    def step_button_url(self, chat_id: int, text: str, data: Dict) -> bool:
        url = text.strip()
        if not url.startswith("http://") and not url.startswith("https://"):
            self.send_message(chat_id, "❌ لینک باید با http:// یا https:// شروع شود.\nدوباره بفرستید:", reply_markup=cancel_keyboard())
            return True
        data["url"] = url
        data["content_text"] = data.get("title", "")
        self.create_button_from_step(chat_id, data, content_text=f"لینک: {url}")
        return True

    def create_button_from_step(self, chat_id: int, data: Dict, content_text: str = "", msg_id: int = None):
        bot_id = data["bot_id"]
        title = data["title"]
        btype = data["button_type"]
        parent_id = data.get("parent_id")
        action = data.get("action_type", "text")
        content = data.get("content_text", content_text)
        file_id = data.get("file_id")
        file_url = data.get("file_url")
        caption = data.get("caption")
        url = data.get("url")
        row = data.get("row", 0)
        pos = data.get("position", 0)

        # اگر والد دارد، والد را به عنوان menu علامت بزن
        if parent_id:
            self.db.execute("UPDATE bot_buttons SET has_children=1, action_type='menu' WHERE id=?", (parent_id,))

        self.db.execute("""INSERT INTO bot_buttons 
            (bot_id, title, button_type, parent_id, row, position, action_type, content_text, file_id, file_url, caption, url)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (bot_id, title, btype, parent_id, row, pos, action, content, file_id, file_url, caption, url))

        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"✅ دکمه «{title}» با موفقیت ساخته شد! 🎉\n\n🔘 نوع: {btype}\n⚡ عملکرد: {action}", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
        self.show_buttons_menu(chat_id, bot_id)

    def step_start_message(self, chat_id: int, text: str, data: Dict) -> bool:
        bot_id = data["bot_id"]
        msg = sanitize_text(text, 4000)
        self.db.execute("UPDATE bot_settings SET start_message=? WHERE bot_id=?", (msg, bot_id))
        if self.db.fetchone("SELECT * FROM bot_settings WHERE bot_id=?", (bot_id,)) is None:
            self.db.execute("INSERT INTO bot_settings (bot_id, start_message) VALUES (?,?)", (bot_id, msg))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, "✅ پیام شروع با موفقیت ذخیره شد ✨", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
        self.show_bot_panel(chat_id, bot_id)
        return True

    def step_welcome_message(self, chat_id: int, text: str, data: Dict) -> bool:
        bot_id = data["bot_id"]
        msg = sanitize_text(text, 4000)
        self.db.execute("UPDATE bot_settings SET welcome_message=? WHERE bot_id=?", (msg, bot_id))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, "✅ پیام خوشامد ذخیره شد.", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
        return True

    def step_default_message(self, chat_id: int, text: str, data: Dict) -> bool:
        bot_id = data["bot_id"]
        msg = sanitize_text(text, 4000)
        self.db.execute("UPDATE bot_settings SET default_message=? WHERE bot_id=?", (msg, bot_id))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, "✅ پیام پیش‌فرض ذخیره شد.")
        return True

    def step_channel_lock(self, chat_id: int, text: str, data: Dict) -> bool:
        bot_id = data["bot_id"]
        if text.strip() == "حذف":
            self.db.execute("UPDATE bot_settings SET channel_lock=NULL WHERE bot_id=?", (bot_id,))
            self.send_message(chat_id, "✅ قفل کانال حذف شد.")
        else:
            lock = text.strip()
            self.db.execute("UPDATE bot_settings SET channel_lock=? WHERE bot_id=?", (lock, bot_id))
            self.send_message(chat_id, f"✅ قفل کانال روی {lock} تنظیم شد.")
        self.db.clear_user_step(chat_id)
        return True

    def step_broadcast_content(self, chat_id: int, message: Dict, text: str, data: Dict) -> bool:
        bot_id = data["bot_id"]
        mtype = data["message_type"]
        content = sanitize_text(text, 4000)
        file_id = None
        caption = None

        if message.get("photo"):
            photos = message["photo"]
            file_id = photos[-1].get("file_id") if isinstance(photos, list) else message["photo"].get("file_id")
            caption = message.get("caption", content)
            content = caption or content
            mtype = "photo"
        elif message.get("video"):
            file_id = message["video"].get("file_id")
            caption = message.get("caption", "")
            mtype = "video"
        elif message.get("document"):
            file_id = message["document"].get("file_id")
            caption = message.get("caption", "")
            mtype = "document"

        if not content and not file_id:
            self.send_message(chat_id, "❌ محتوا خالی است. دوباره بفرستید:", reply_markup=cancel_keyboard())
            return True

        # ذخیره موقت و درخواست تایید
        data["content"] = content
        data["file_id"] = file_id
        data["caption"] = caption
        self.db.set_user_step(chat_id, "await_broadcast_keyboard", data)

        # نمایش پیش‌نمایش
        preview = f"📢 **پیش‌نمایش پیام همگانی**\n\n"
        if mtype == "text":
            preview += content[:500]
        else:
            preview += f"[{mtype}] {content[:300]}\nکپشن: {caption or ''}"
        
        # تعداد گیرندگان
        total = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=? AND is_blocked=0", (bot_id,))["c"]
        preview += f"\n\n👥 تعداد گیرندگان: {total} نفر\n⏱ زمان تقریبی: {total // 1} ثانیه (1 پیام/ثانیه)"

        kb = {
            "inline_keyboard": [
                [{"text": "✅ تایید و ارسال", "callback_data": f"bc_confirm_{bot_id}"}, {"text": "❌ انصراف", "callback_data": f"bc_cancel_{bot_id}"}],
                [{"text": "➕ افزودن دکمه (اختیاری)", "callback_data": f"bc_addbtn_{bot_id}"}],
            ]
        }
        self.send_message(chat_id, preview, reply_markup=kb)
        return True

    def step_broadcast_keyboard(self, chat_id: int, text: str, data: Dict) -> bool:
        # اگر کاربر دکمه خواست
        # ساده: از متن به عنوان دکمه inline استفاده کن
        # فرمت: عنوان|لینک یا عنوان|callback
        # برای سادگی، فعلا بدون کیبورد ادامه بده
        bot_id = data["bot_id"]
        # ایجاد broadcast و queue
        content = data["content"]
        file_id = data.get("file_id")
        caption = data.get("caption")
        mtype = data["message_type"]
        keyboard_json = None
        if text and text != "بدون دکمه":
            # فرض: کاربر لینک فرستاده
            keyboard_json = json.dumps({"inline_keyboard": [[{"text": text, "url": text}]]}, ensure_ascii=False) if text.startswith("http") else None

        # ایجاد رکورد broadcast
        self.db.execute("INSERT INTO broadcasts (bot_id, owner_id, message_type, content, file_id, caption, keyboard_json, target_type, status, total_count) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (bot_id, chat_id, mtype, content, file_id, caption, keyboard_json, "all", "pending", 0))
        bc = self.db.fetchone("SELECT * FROM broadcasts WHERE bot_id=? ORDER BY id DESC LIMIT 1", (bot_id,))
        bc_id = bc["id"]

        # پر کردن صف
        users = self.db.fetchall("SELECT chat_id FROM bot_users WHERE bot_id=? AND is_blocked=0", (bot_id,))
        for u in users:
            self.db.execute("INSERT INTO broadcast_queue (broadcast_id, chat_id) VALUES (?,?)", (bc_id, u["chat_id"]))
        self.db.execute("UPDATE broadcasts SET total_count=? WHERE id=?", (len(users), bc_id))
        data["broadcast_id"] = bc_id
        self.db.set_user_step(chat_id, "await_broadcast_keyboard", data)

        # حالا تایید نهایی
        total = len(users)
        self.send_message(chat_id, f"✅ صف ارسال ساخته شد ({total} نفر).\nبرای شروع روی '✅ تایید و ارسال' کلیک کنید.", reply_markup={"inline_keyboard": [[{"text": "🚀 شروع ارسال", "callback_data": f"bc_confirm_{bot_id}"}]]})
        return True

    def step_support(self, chat_id: int, text: str) -> bool:
        msg = sanitize_text(text, 2000)
        self.db.execute("INSERT INTO tickets (user_id, message, status) VALUES (?,?,?)", (chat_id, msg, "open"))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, "✅ پیام شما به پشتیبانی ارسال شد.\nبه زودی پاسخ داده خواهد شد 🙏", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
        # اطلاع به ادمین‌ها
        for adm in ADMIN_IDS:
            try:
                self.api.send_message(adm, f"🎫 تیکت جدید از `{chat_id}`:\n\n{msg}")
            except:
                pass
        return True

    def step_receipt(self, chat_id: int, message: dict, text: str, data: dict) -> bool:
        amount = data.get("amount")
        req_id = data.get("req_id")
        file_id = None
        receipt_text = text
        # چک عکس
        if message.get("photo"):
            photos = message["photo"]
            file_id = photos[-1].get("file_id") if isinstance(photos, list) else photos.get("file_id")
            receipt_text = message.get("caption", "رسید عکس")
        elif message.get("document"):
            file_id = message["document"].get("file_id")
        
        # ذخیره رسید
        self.db.execute("UPDATE wallet_requests SET receipt_file_id=?, receipt_type=?, status=? WHERE id=?", (file_id or receipt_text[:500], "photo" if file_id else "text", "pending", req_id))
        self.db.clear_user_step(chat_id)
        
        # ارسال به ادمین‌ها با دکمه تایید/رد
        card = self.db.fetchone("SELECT * FROM card_settings WHERE id=1")
        user = self.db.get_user(chat_id)
        uname = f"@{user['username']}" if user and user['username'] else str(chat_id)
        admin_text = f"💳 **درخواست شارژ جدید**\n\n👤 کاربر: {uname} (`{chat_id}`)\n💰 مبلغ: {amount:,} تومان\n🧾 رسید: {receipt_text[:100] if receipt_text else 'عکس'}\n🆔 درخواست: #{req_id}"
        kb = {"inline_keyboard": [[{"text": "✅ تایید", "callback_data": f"approve_wallet_{req_id}"}, {"text": "❌ رد", "callback_data": f"reject_wallet_{req_id}"}]]}
        for adm in ADMIN_IDS:
            try:
                if file_id:
                    self.api.send_photo(adm, file_id, caption=admin_text, reply_markup=kb)
                else:
                    self.api.send_message(adm, admin_text, reply_markup=kb)
            except Exception as e:
                print(f"Admin send failed {adm}: {e}")
        
        self.send_message(chat_id, f"✅ رسید شما ثبت شد!\n💰 مبلغ: {amount:,} تومان\n⏳ ادمین کمتر از 1 ساعت تایید می‌کنه\nکد: #{req_id}", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
        return True

    def step_wallet_charge(self, chat_id: int, text: str) -> bool:
        try:
            amount = int(text.replace(",", "").strip())
            if amount < 1000:
                self.send_message(chat_id, "❌ حداقل 1000 تومان")
                return True
            self.db.execute("INSERT INTO transactions (user_id, amount, type, status, description) VALUES (?,?,?,?,?)", (chat_id, amount, "charge", "pending", "درخواست شارژ"))
            self.db.clear_user_step(chat_id)
            self.send_message(chat_id, f"✅ درخواست شارژ {amount:,} تومان ثبت شد. ادمین تایید می‌کند.\nیا برای تست فوری: /charge_{amount}", reply_markup=main_reply_keyboard(is_admin=is_admin(chat_id)))
            for adm in ADMIN_IDS:
                try:
                    self.api.send_message(adm, f"💳 درخواست شارژ {amount:,} از {chat_id}")
                except:
                    pass
        except:
            self.send_message(chat_id, "❌ مبلغ نامعتبر. مثال: 50000")
        return True

    def step_transfer_owner(self, chat_id: int, text: str, data: Dict) -> bool:
        try:
            new_owner = int(text.strip())
            bot_id = data["bot_id"]
            bot = self.db.get_bot(bot_id)
            if not bot or bot["owner_id"] != chat_id:
                self.send_message(chat_id, "❌ دسترسی نداری")
                self.db.clear_user_step(chat_id)
                return True
            self.db.execute("UPDATE bots SET owner_id=? WHERE id=?", (new_owner, bot_id))
            self.db.execute("INSERT INTO ownership_transfers (bot_id, from_owner, to_owner, status) VALUES (?,?,?,?)", (bot_id, chat_id, new_owner, "completed"))
            self.db.clear_user_step(chat_id)
            self.send_message(chat_id, f"✅ مالکیت ربات #{bot_id} به {new_owner} منتقل شد!")
            try:
                self.api.send_message(new_owner, f"🎉 ربات {bot['bot_name']} به شما منتقل شد!")
            except:
                pass
        except Exception as e:
            self.send_message(chat_id, f"❌ خطا: {e}")
        return True

    def step_admin_broadcast(self, chat_id: int, message: Dict, text: str) -> bool:
        if not is_admin(chat_id):
            self.db.clear_user_step(chat_id)
            return False
        content = sanitize_text(text, 4000)
        file_id = None
        if message.get("photo"):
            photos = message["photo"]
            file_id = photos[-1].get("file_id") if isinstance(photos, list) else None
            content = message.get("caption", content)
        users = self.db.fetchall("SELECT user_id FROM users WHERE is_blocked=0")
        sent = 0
        for u in users:
            try:
                if file_id:
                    self.api.send_photo(u["user_id"], file_id, caption=content)
                else:
                    self.api.send_message(u["user_id"], f"📢 **پیام از مدیریت**\n\n{content}")
                sent += 1
                import time
                time.sleep(0.05)
            except:
                pass
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"✅ پیام همگانی به {sent}/{len(users)} کاربر ارسال شد.", reply_markup=main_reply_keyboard(is_admin=True))
        return True

    def step_new_plan(self, chat_id: int, text: str) -> bool:
        if not is_admin(chat_id):
            self.db.clear_user_step(chat_id)
            return False
        try:
            parts = text.split("|")
            name = parts[0].strip()
            days = int(parts[1].strip())
            max_bots = int(parts[2].strip())
            max_users = int(parts[3].strip())
            price = int(parts[4].strip())
            desc = parts[5].strip() if len(parts) > 5 else ""
            self.db.execute("INSERT INTO plans (name, days, max_bots, max_users, price, description) VALUES (?,?,?,?,?,?)",
                            (name, days, max_bots, max_users, price, desc))
            self.db.clear_user_step(chat_id)
            self.send_message(chat_id, f"✅ پلن «{name}» اضافه شد.", reply_markup=main_reply_keyboard(is_admin=True))
        except Exception as e:
            self.send_message(chat_id, f"❌ فرمت اشتباه: {e}\nدوباره با فرمت صحیح بفرستید:\n`نام|روز|max_bots|max_users|price|توضیحات`", reply_markup=cancel_keyboard())
        return True

    def step_edit_title(self, chat_id: int, text: str, data: Dict) -> bool:
        btn_id = data["btn_id"]
        bot_id = data["bot_id"]
        new_title = sanitize_text(text, 60)
        ok, err = validate_button_title(new_title)
        if not ok:
            self.send_message(chat_id, f"❌ {err}", reply_markup=cancel_keyboard())
            return True
        self.db.execute("UPDATE bot_buttons SET title=? WHERE id=?", (new_title, btn_id))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"✅ عنوان دکمه به «{new_title}» تغییر کرد.")
        self.show_button_list(chat_id, bot_id)
        return True


    def step_admin_card(self, chat_id: int, text: str, data: dict) -> bool:
        if not is_admin(chat_id):
            self.db.clear_user_step(chat_id)
            return False
        t = text.strip()
        if t.lower() in ["off", "حذف", "غیرفعال", "cancel"]:
            self.db.execute("UPDATE card_settings SET card_number='6037-XXXX-XXXX-1234', card_holder='ربات‌ساز' WHERE id=1")
            self.db.clear_user_step(chat_id)
            self.send_message(chat_id, "✅ کارت به حالت پیش‌فرض برگشت", reply_markup=main_reply_keyboard(is_admin=True))
            return True
        # Support format: 6037991122334455 or 6037-9911-2233-4455 or with holder via |
        holder = "ربات‌ساز"
        card_num = t
        if "|" in t:
            parts = t.split("|")
            card_num = parts[0].strip()
            holder = parts[1].strip() if len(parts)>1 and parts[1].strip() else "ربات‌ساز"
        # clean digits
        digits = "".join(ch for ch in card_num if ch.isdigit())
        if len(digits) < 12 or len(digits) > 19:
            self.send_message(chat_id, "❌ شماره کارت نامعتبر! باید 16 رقم باشد\nمثال: `6037991122334455`\nیا با نام: `6037991122334455|علی احمدی`", reply_markup=cancel_keyboard())
            return True
        formatted = "-".join([digits[i:i+4] for i in range(0, len(digits), 4)])
        self.db.execute("UPDATE card_settings SET card_number=?, card_holder=? WHERE id=1", (formatted, holder))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"✅ **کارت ذخیره شد**\n💳 `{formatted}`\n👤 {holder}\n\nاز الان کاربران این کارت را می‌بینند.", reply_markup=main_reply_keyboard(is_admin=True))
        return True

    def step_admin_ad(self, chat_id: int, text: str, data: dict) -> bool:
        if not is_admin(chat_id):
            self.db.clear_user_step(chat_id)
            return False
        t = text.strip()
        if t.lower() in ["off", "حذف", "غیرفعال"]:
            self.db.execute("UPDATE global_ads SET content='', is_active=0 WHERE id=1")
            self.db.clear_user_step(chat_id)
            self.send_message(chat_id, "✅ تبلیغ غیرفعال شد", reply_markup=main_reply_keyboard(is_admin=True))
            return True
        self.db.execute("UPDATE global_ads SET content=?, is_active=1, updated_at=? WHERE id=1", (t, datetime.now().isoformat()))
        self.db.clear_user_step(chat_id)
        self.send_message(chat_id, f"✅ **تبلیغ ذخیره شد:**\n{t[:500]}", reply_markup=main_reply_keyboard(is_admin=True))
        return True

    # ==================== قابلیت‌های جذاب جدید - نسخه خفن ====================

    def cmd_ai_settings(self, chat_id: int, bot_id: int, msg_id: int = None):
        text = f"""🤖 **هوش مصنوعی ربات #{bot_id}**

✨ قابلیت‌های AI:
• پاسخ خودکار هوشمند به پیام‌های نامفهوم
• تشخیص نیت کاربر
• پیشنهاد دکمه بر اساس تاریخچه

وضعیت: 🟢 فعال (الگوریتم هوشمند داخلی)

برای غیرفعال کردن /ai_off بفرستید."""
        kb = {"inline_keyboard": [[{"text": "⚙️ تنظیمات AI", "callback_data": f"ai_set_{bot_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def cmd_scheduled(self, chat_id: int, bot_id: int, msg_id: int = None):
        scheds = self.db.fetchall("SELECT * FROM scheduled_messages WHERE bot_id=? ORDER BY send_at", (bot_id,))
        text = f"⏰ **پیام‌های زمان‌بندی شده ربات #{bot_id}**\n\n"
        if not scheds:
            text += "هنوز پیامی زمان‌بندی نشده.\nمثال: `سلام|2025-12-01 08:00`"
        else:
            for s in scheds[:10]:
                text += f"• {s['content'][:30]} - {s['send_at']} ({s['status']})\n"
        kb = {"inline_keyboard": [[{"text": "➕ افزودن زمان‌بندی", "callback_data": f"sched_add_{bot_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def cmd_poll_create(self, chat_id: int, bot_id: int, msg_id: int = None):
        self.db.set_user_step(chat_id, "await_poll_question", {"bot_id": bot_id})
        self.send_message(chat_id, "📊 **ساخت نظرسنجی**\n\nسوال نظرسنجی را بفرستید:\nمثال: بهترین زبان برنامه‌نویسی؟", reply_markup=cancel_keyboard())

    def cmd_giveaway(self, chat_id: int, bot_id: int, msg_id: int = None):
        users = self.db.fetchone("SELECT COUNT(*) as c FROM bot_users WHERE bot_id=?", (bot_id,))["c"]
        text = f"""🎉 **قرعه‌کشی** 

👥 {users} شرکت‌کننده
🎁 جایزه: انتخاب تصادفی

برای اجرای قرعه‌کشی کلیک کنید:"""
        kb = {"inline_keyboard": [[{"text": "🎲 اجرای قرعه‌کشی", "callback_data": f"draw_{bot_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

    def cmd_export_users(self, chat_id: int, bot_id: int):
        import csv, io
        users = self.db.fetchall("SELECT chat_id, username, first_name, subscribed_at FROM bot_users WHERE bot_id=?", (bot_id,))
        # ساخت CSV در حافظه
        output = io.StringIO()
        w = csv.writer(output)
        w.writerow(["chat_id", "username", "first_name", "date"])
        for u in users:
            w.writerow([u["chat_id"], u["username"], u["first_name"], u["subscribed_at"]])
        csv_data = output.getvalue()
        # ارسال به صورت فایل متنی (چون Bale sendDocument نیاز به file_id دارد، متن می‌فرستیم)
        preview = csv_data[:4000] if len(csv_data) > 4000 else csv_data
        self.send_message(chat_id, f"📤 **خروجی کاربران ({len(users)} نفر)**\n\n```\n{preview}\n```\n\nبرای دریافت کامل، از پنل ادمین CSV دانلود کنید.")

    def cmd_anti_flood(self, chat_id: int, bot_id: int, msg_id: int = None):
        text = f"""🛡 **ضد اسپم ربات #{bot_id}**

وضعیت: 🟢 فعال
• حداکثر 5 پیام در 10 ثانیه
• بن خودکار 1 دقیقه‌ای
• گزارش به ادمین

قابل تنظیم در تنظیمات پیشرفته."""
        kb = {"inline_keyboard": [[{"text": "⚙️ تنظیمات", "callback_data": f"flood_set_{bot_id}"}, {"text": "⬅️ بازگشت", "callback_data": f"panel_{bot_id}"}]]}
        self.edit_or_send(chat_id, msg_id, text, reply_markup=kb)

# ==================== الحاق هسته اصلاحات (botfix_ext.py) ====================
# تمام رفع باگها و قابلیتهای جدید در این ماژول هستند تا main.py خوانا بماند.
try:
    from botfix_ext import install_extensions
    install_extensions(globals())
    from god_ext import install_god_extensions
    install_god_extensions(globals())
except Exception as _ext_err:
    logger.error("❌ نمیتوان botfix_ext.py را بارگذاری کرد: %s", _ext_err)
    raise


def check_expiry_job(db: Database, bot_manager: BotManager):
    """چک دوره‌ای انقضای ربات‌ها"""
    while True:
        try:
            time.sleep(3600)  # هر یک ساعت
            bots = db.fetchall("SELECT * FROM bots WHERE is_active=1 AND expires_at IS NOT NULL")
            now = datetime.now()
            for b in bots:
                try:
                    exp = datetime.fromisoformat(b["expires_at"])
                    if exp < now:
                        logger.info(f"ربات {b['id']} منقضی شد - غیرفعال‌سازی")
                        db.execute("UPDATE bots SET is_active=0, status='offline' WHERE id=?", (b["id"],))
                        bot_manager.stop_bot(b["id"])
                        try:
                            pass # BaleAPI already defined
                            api = BaleAPI(BOT_TOKEN, base_url=BALE_API_BASE)
                            api.send_message(b["owner_id"], f"⛔ اشتراک ربات {b['bot_name']} (@{b['bot_username']}) منقضی شد.\nبرای فعال‌سازی مجدد از «💎 اشتراک و تمدید» استفاده کنید.")
                        except:
                            pass
                except Exception as e:
                    logger.error(f"خطا در چک انقضا {b['id']}: {e}")
        except Exception as e:
            logger.error(f"خطا در job انقضا: {e}")
            time.sleep(60)

def backup_job(db: Database):
    """پشتیبان‌گیری روزانه"""
    while True:
        try:
            time.sleep(86400)
            backup_path = f"data/backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            try:
                db.backup(backup_path)
                logger.info(f"پشتیبان ایجاد شد: {backup_path}")
                import glob
                for f in glob.glob("data/backup_*.db"):
                    try:
                        if os.path.getmtime(f) < time.time() - 7*86400:
                            os.remove(f)
                    except:
                        pass
            except Exception as e:
                logger.error(f"خطا در پشتیبان‌گیری: {e}")
        except:
            time.sleep(3600)

def main():
    print("""
╔══════════════════════════════════════════════════╗
║  🤖 پلتفرم ربات‌ساز حرفه‌ای بله                 ║
║  Bale Bot Builder Platform v2.0 - ULTRA                 ║
║  مستندات: https://docs.bale.ai                 ║
║  آماده اجرا روی سرور لینوکس - 24/7            ║
╚══════════════════════════════════════════════════╝
    """)
    logger.info("🚀 راه‌اندازی پلتفرم ربات‌ساز بله...")

    # ایجاد دیتابیس
    db = Database(DATABASE_PATH)
    logger.info(f"✅ دیتابیس: {DATABASE_PATH}")

    # تنظیم ادمین‌ها
    for adm in ADMIN_IDS:
        try:
            db.execute("UPDATE users SET is_admin=1 WHERE user_id=?", (adm,))
            if not db.get_user(adm):
                db.execute("INSERT OR IGNORE INTO users (user_id, is_admin, first_name) VALUES (?,?,?)", (adm, 1, "Admin"))
        except:
            pass
    logger.info(f"👮 ادمین‌ها: {ADMIN_IDS}")

    # مدیریت ربات‌ها
    bot_manager = BotManager(DATABASE_PATH, base_url=BALE_API_BASE)
    broadcast_manager = BroadcastManager(DATABASE_PATH, base_url=BALE_API_BASE, rate_limit=BROADCAST_RATE_LIMIT)

    # بارگذاری ربات‌های قبلی
    try:
        bot_manager.load_all_bots()
        bot_manager.start_monitor()
    except Exception as e:
        logger.error(f"خطا در بارگذاری ربات‌ها: {e}")

    # جاب‌های پس‌زمینه
    threading.Thread(target=check_expiry_job, args=(db, bot_manager), daemon=True, name="expiry-job").start()
    threading.Thread(target=backup_job, args=(db,), daemon=True, name="backup-job").start()

    # ربات اصلی سازنده
    builder = BuilderBot(BOT_TOKEN, db, bot_manager, broadcast_manager, base_url=BALE_API_BASE)

    def signal_handler(sig, frame):
        logger.info("🛑 دریافت سیگنال خاموشی...")
        builder.stop()
        bot_manager.stop_all()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    logger.info("🤖 ربات اصلی در حال اتصال به API بله...")
    logger.info(f"🔗 API: {BALE_API_BASE}/bot***")
    
    try:
        if "REPLACE" in BOT_TOKEN:
            logger.error("❌ توکن تنظیم نشده - ربات اجرا نشد. لطفا main.py را ویرایش کنید و دوباره اجرا کنید.")
            logger.info("   برای تست بدون توکن، یک توکن تستی وارد کنید یا .env بسازید")
            # برای اینکه ZIP قابل تحویل باشد، بدون توکن هم خارج نشو، پیام بده
            print("\n⚠️  توکن تنظیم نشده - برای اجرا توکن را وارد کنید و دوباره python main.py بزنید\n")
            # نگه ندار، خارج شو
            return
        builder.start()
    except KeyboardInterrupt:
        logger.info("🛑 خاموشی با Ctrl+C")
    except Exception as e:
        logger.exception(f"خطای جدی: {e}")
    finally:
        bot_manager.stop_all()
        logger.info("👋 پلتفرم متوقف شد")

if __name__ == "__main__":
    main()