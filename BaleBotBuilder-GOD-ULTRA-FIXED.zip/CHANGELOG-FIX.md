# CHANGELOG — نسخه FIXED (۲۰۲۶/۱۱/۰۳)

## ✨ Added
- `botfix_ext.py`: هسته الحاقی تمام اصلاحات (۳٬۴۰۰ خط).
- **کتابخانه ۱۲۰ قالب آماده** در ۱۲ دسته + ۱۴ قالب فولسورس = ۱۳۴ قالب.
  اتصال یککلیک، شخصیسازی پیام شروع/متن/عنوان دکمهها، تعیین دامنه و قالب فعال گروه/پیوی.
- **بخش اختصاصی «👮 مدیریت گروه»**: متغیرهای واقعی، دستورات ادمینی، قفلها، مجازاتها، قوانین.
- **متغیرهای سفارشی + اتصال دستور**: جدول `bot_variables` / `bot_variable_state`،
  پریست `zadlink` با دستور «قفل لینک» / «بازکردن لینک».
- **🎛 مدیریت دامنه دکمهها**: `scope` = `both|group|pv|off` با UI تکی و گروهی.
- منوهای جدید: `📂 کتابخانه قالبها`, `🧩 متغیرها و دستورات`, `👮 مدیریت گروه`, `🎛 دامنه دکمهها`.
- پشتیبانی `target_scope` (همه/پیوی/گروه) و دکمه شیشهای در ارسال همگانی.
- متدهای رسمی `docs.bale.ai` در `BaleAPI` (getChat/getChatMember/getChatAdministrators/
  getChatMembersCount/ban/unban/promote/pin/unpin/invite/leave/deleteMessage).
- `bot_processes` برای ردیابی PID دیپلوی قالبها.
- `tests/test_fixes.py`: ۲۵ تست آفلاین، `README-FIX.md`, `FIX-REPORT.md`.

## 🐛 Fixed
- ارسال همگانی: مسیر تایید، صف، شمارنده، ۴۲۹، توقف، وضعیت، متغیرها بهازای گیرنده.
- حذف ربات: kill گروه پروسه، حذف وبهاک، حذف پوشهها، purge تمام جداول، `VACUUM`، ضد ریاستارت.
- موتور متغیرها: تداخل زیررشتهها، مقادیر هاردکد، تاریخ شمسی، `command` دکمهها.
- ترتیب FSM قبل از کلمات کلیدی.
- routing callbackهای `btn_del_`, `btn_reorder_`, `bc_addbtn_`, `bc_target_`, `bc_status_`.
- `PMGUARD` / `protect_content` TypeError، `vars_map` تعریفنشده، `tmpl` تعریفنشده.
- `getChatMember` با `user_id` اشتباه، `getUpdates` با GET/query، retry شبکه/429/5xx.
- `arz_gold_original.py:13` SyntaxError.
- `liro_bot_template.py`: NameError در `apply_penalty`، fallback سکوت، `unPinChatMessage`،
  `getChatAdministrators` ایمن، timeout و 429 در `send_request`.

## ⚠️ Notes
- توکن داخل `main.py` توکن **تستی** اعلامشده توسط کاربر است و تغییر نکرد؛ `.env` اولویت دارد.
- `restrictChatMember` در مستندات رسمی بله وجود ندارد → سکوت با `banChatMember` + fallback.
- `main_factory.py` کارخانه قدیمی و جدا از `main.py` است؛ صرفاً ممیزی شد.
- ارسال انبوه با سقف بالا → API کسبوکاری بله (`/business/bot<TOKEN>/sendMessage`).

---

# CHANGELOG — نسخه GOD ULTRA / فاز دوم (۲۰۲۶/۱۱/۰۴)

## ✨ Added
- `god_ext.py` (۱٬۶۹۱ خط): لایه فاز دوم، بعد از `botfix_ext` نصب میشود.
- **۶۲۴ قالب جدید** → مجموع **۷۵۸ قالب** (۱۲ دسته × ۱۰ موضوع × ۵ نسخه + ۲۴ پکیج قفل).
- **۲۴ قفل مهم گروه** با detector واقعی، دستور فارسی، مجازات و قالب اختصاصی؛
  ۲۹ پریست متغیر (۵ قدیمی + ۲۴ جدید، بدون تداخل `UNIQUE(bot_id,command_on)`).
- **همگانی سراسری ادمین**: جدول `global_broadcasts`، `GlobalBroadcastManager`،
  `iter_all_targets()` با keyset pagination، UI پنل ادمین (پیام جدید/وضعیت/توقف).
- **۳۲ سورس آماده** (۲۰ فایل واقعی ریپو + ۱۲ پکیج تولیدشده) با استقرار، جایگذاری
  توکن/ادمین، کامپایل تکتک فایلها و اجرای ایزوله در `bots/<id>_<user>/`.
- **فقط پاسخ به دستورات تنظیمشده**: ستون `bot_settings.respond_unknown` (پیشفرض ۰)،
  پنل «🎯 تنظیم پاسخها»، پشتیبانی `custom_commands.is_active`.
- **کالبک اختصاصی هر دکمه**: ستون `bot_buttons.callback` = `tcb_<id>` و مسیر اجرای
  اختصاصی در `runtime_handle_callback` (۳٬۷۷۸ دکمه تست شد).
- **۲۰ قابلیت GOD**: XP/لول، پاداش روزانه، استریک، کیف پول/انتقال، ضدتقلب رفرال،
  نظرسنجی (`pvote_`)، لینک کوتاه، آمار لحظهای، ممیزی `god_audit`،
  `GodScheduler`، شاردینگ `ShardedUserStore`، ایندکسهای ترکیبی.
- پنلها/منوها: `🌟 قابلیتهای GOD`، `🎯 تنظیم پاسخها`، `📚 سورسهای آماده`،
  `🌐 همگانی سراسری`، دکمههای پنل ادمین.
- `self_ad_bot/` — **سورس جداگانه «سلف تبلیغ گر اکانت»** بر اساس `main-3_2.py`
  (کامیت `3837569`) همراه `core.py`، `config.py`، پنل، ۱۱ تست و `README-SELF.md`.
- `tests/test_god_ext.py` (۱۳ تست)، `tests/test_self_ad.py` (۱۱ تست)،
  `audit_all.py` → `AUDIT-GOD.md` + `audit-report.json`.

## 🐛 Fixed
- **پاسخ «دستور نامعتبر است. از منو استفاده کنید.»** برای پیامهای تنظیمنشده حذف شد.
- **پاسخهای دوبل**: قفل توکن در `BotManager._token_owners` (جلوگیری از دو رانتایم
  روی یک توکن) + **حداکثر یک قالب فعال** در هر دامنه + حذف دکمههای تکراری.
- `set_active_template` از toggle به idempotent تبدیل شد (کلیک روی «فعال کردن»
  دیگر قالب را خاموش نمیکرد).
- `attach_template` حالا `command` و `callback` یکتا مینویسد و قالب تازه را در
  `active_template_group/pv` انتخاب میکند.
- `custom_commands` ستون `is_active` نداشت → اضافه شد؛ دستورات سفارشی واقعاً اجرا میشوند.
- `show_god_settings` روی `sqlite3.Row` کرش میکرد → `dict(row)`.
- نشت فایل (ResourceWarning) در استقرار سورسها → `Path.read_text/write_text`.
- ۱۴ باگ شناختهشده `main-3_2.py` در سلف رفع شد (توکن هاردکد، `admins=[]`، `.id`/`.bale`،
  positional `Client`, `client` تعریفنشده در `finally`, `sp[1]`, `message.edit_text`,
  shadow کردن `type`, `reply_document`, کشتن تسکها و ...).

## ✅ Verified
- `python3 -m unittest discover -s tests` → **Ran 49 tests … OK**
- `python3 audit_all.py` → ۵۰ فایل کامپایل / ۰ خطا، ۷۵۸ قالب، ۳٬۷۷۸ دکمه،
  ۳۲/۳۲ سورس OK، ۲۴/۲۴ detector قفل OK.
