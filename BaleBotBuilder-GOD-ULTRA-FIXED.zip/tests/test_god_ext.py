# -*- coding: utf-8 -*-
"""تستهای فاز دوم (GOD ULTRA): ممیزی چانکبهچانک/دکمهبهدکمه، قفلها، همگانی سراسری."""
import asyncio
import glob
import json
import os
import py_compile
import shutil
import sqlite3
import sys
import tempfile
import time
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

import main  # noqa: E402
import botfix_ext as ext  # noqa: E402
import god_ext as god  # noqa: E402
from test_fixes import BaseFixTest, FakeAPI, OWNER, GROUP_ID  # noqa: E402


class TestGodInventory(unittest.TestCase):
    def test_01_counts(self):
        self.assertGreaterEqual(len(ext.ALL_TEMPLATES), 758)
        self.assertGreaterEqual(len(god.GOD_TEMPLATES), 624)
        self.assertEqual(len(god.GROUP_LOCK_SPECS), 24)
        self.assertGreaterEqual(len(god.READY_SOURCES), 12)
        self.assertEqual(len(god.GOD_FEATURES), 20)
        self.assertEqual(len(ext.CUSTOM_VARIABLE_PRESETS), 29)  # ۵ پریست فاز اول + ۲۴ قفل

    def test_02_every_template_structurally_valid(self):
        """چانک به چانک: تکتک ۷۵۸ قالب، تکتک دکمهها، تکتک کاراکترها."""
        errors = []
        for key, t in ext.ALL_TEMPLATES.items():
            if not isinstance(key, str) or not key.strip():
                errors.append(f"{key}: key نامعتبر")
            is_library = t.get("kind") == "library"
            for field in ("name", "desc", "start_message", "scope"):
                if field not in t or t[field] in (None, "", []):
                    errors.append(f"{key}: {field} خالی")
            if is_library:
                if not t.get("buttons"):
                    errors.append(f"{key}: کتابخانه بدون دکمه")
                if not t.get("category"):
                    errors.append(f"{key}: category خالی")
            else:
                # ۱۴ قالب فولسورس ریپو: بهجای دکمه، فایل سورس دارند
                if not t.get("template") and key != "custom":
                    errors.append(f"{key}: فایل template خالی")
            scope = t.get("scope") or "both"
            if scope not in ("both", "group", "pv", "off"):
                errors.append(f"{key}: scope نامعتبر {scope}")
            titles = set()
            for i, b in enumerate(t.get("buttons") or []):
                if not b.get("title") or not str(b.get("title")).strip():
                    errors.append(f"{key}[{i}]: عنوان خالی")
                if b["title"] in titles:
                    errors.append(f"{key}[{i}]: عنوان تکراری {b['title']}")
                titles.add(b["title"])
                if not str(b.get("content") or "").strip():
                    errors.append(f"{key}[{i}]: محتوای خالی")
                if b.get("type") not in ("reply", "inline"):
                    errors.append(f"{key}[{i}]: type نامعتبر")
                if b.get("action") not in (None, "", "text", "menu", "back", "url"):
                    errors.append(f"{key}[{i}]: action نامعتبر")
                if not isinstance(b.get("row", 0), int):
                    errors.append(f"{key}[{i}]: row نامعتبر")
        self.assertEqual(errors[:20], [], f"خطاهای ساختاری: {len(errors)} → {errors[:20]}")
        # رندر امن: هیچ استثنایی برای هیچ متن قالبی نباید رخ دهد
        for key, t in ext.ALL_TEMPLATES.items():
            ext.render_variables(t["start_message"], {"FIRSTNAME": "علی", "GROUPNAME": "گروه"})
            for b in t["buttons"]:
                ext.render_variables(b["content"], {"FIRSTNAME": "علی", "zadlink": "فعال"})

    def test_03_all_24_lock_detectors(self):
        violating = {
            "lock_link": {"text": "https://ble.ir/x"},
            "lock_forward": {"forward_from": {"id": 1}},
            "lock_photo": {"photo": [{"file_id": "x"}]},
            "lock_video": {"video": {"file_id": "v"}},
            "lock_audio": {"audio": {"file_id": "a"}},
            "lock_voice": {"voice": {"file_id": "w"}},
            "lock_sticker": {"sticker": {"file_id": "s"}},
            "lock_gif": {"animation": {"file_id": "g"}},
            "lock_document": {"document": {"file_id": "d"}},
            "lock_contact": {"contact": {"phone": "1"}},
            "lock_location": {"location": {"latitude": 1}},
            "lock_poll": {"poll": {"question": "q"}},
            "lock_game": {"game": {"title": "g"}},
            "lock_bot": {"new_chat_members": [{"is_bot": True, "id": 2}]},
            "lock_badwords": {"text": "تو احمقی"},
            "lock_ads": {"text": "تخفیف ویژه فقط امروز، لینک زیر را کلیک کنید https://x.com"},
            "lock_arabic": {"text": "ThisIsAVeryLongLatinMessageForTest"},
            "lock_mention": {"text": "@all سلام"},
            "lock_hashtag": {"text": "سلام #تبلیغ"},
            "lock_caption": {"caption": "x" * 250},
            "lock_edit": {"edit_date": 123},
            "lock_service": {"new_chat_members": [{"id": 3}]},
            "lock_command": {"text": "/start"},
        }
        for key, label, on, off, penalty, desc in god.GROUP_LOCK_SPECS:
            action = "lock_" + key
            if action == "lock_spam":
                continue  # توسط شمارنده runtime مدیریت میشود
            msg = violating.get(action)
            self.assertIsNotNone(msg, f"نمونه نقض برای {action} تعریف نشده")
            self.assertTrue(god.god_lock_violated(action, msg, msg.get("text", "")),
                            f"{action} نقض را تشخیص نداد")
        # پیام سالم نباید هیچ قفلی (غیر از سرویسی/ویرایش) را فعال کند
        clean = {"text": "سلام دوستان، حالتون خوبه؟", "caption": ""}
        for key, *_ in god.GROUP_LOCK_SPECS:
            action = "lock_" + key
            if action in ("lock_spam",):
                continue
            self.assertFalse(god.god_lock_violated(action, clean, clean["text"]),
                             f"{action} روی پیام سالم falsepositive داد")

    def test_04_all_python_files_compile(self):
        bad = []
        for f in glob.glob(os.path.join(ROOT, "**", "*.py"), recursive=True):
            if "__pycache__" in f:
                continue
            try:
                py_compile.compile(f, doraise=True)
            except Exception as e:
                bad.append((f, str(e)[:200]))
        self.assertEqual(bad, [], f"خطای نحوی: {bad}")


class TestGodRuntime(BaseFixTest):
    def test_05_only_configured_commands_reply(self):
        """اسکرینشاتها: «آمار» → دستور نامعتبر / «فونتساز» دوبل. الان نباید باشد."""
        self.create_bot()
        rt = main.UserBotRuntime(1, "TESTTOKEN", self.db_path)
        rt.api = FakeAPI()
        unknown = {"message_id": 5, "chat": {"id": 7001, "type": "private"},
                   "from": {"id": 7001, "first_name": "کاربر"}, "text": "یک متن کاملاً ناشناخته"}
        before = len(FakeAPI.sent)
        rt.handle_message(unknown)
        self.assertEqual(len(FakeAPI.sent), before, "نباید هیچ پیام پیشفرضی ارسال شود")
        # با روشن کردن صریح صاحب ربات، پاسخ پیشفرض برمیگردد
        self.db.execute("UPDATE bot_settings SET respond_unknown=1 WHERE bot_id=1")
        rt.handle_message(dict(unknown, message_id=6))
        self.assertGreater(len(FakeAPI.sent), before)

    def test_06_single_active_template_no_duplicate_buttons(self):
        self.create_bot()
        self.builder.attach_template(OWNER, 1, "group_01", scope="both", silent=True)
        self.builder.attach_template(OWNER, 1, "tools_01", scope="both", silent=True)
        rows = self.db.fetchall("SELECT template_key, scope FROM bot_templates WHERE bot_id=1 AND active=1")
        rt = main.UserBotRuntime(1, "TESTTOKEN", self.db_path)
        for ctype in ("group", "private"):
            keys = rt.runtime_active_templates(ctype)
            self.assertEqual(len(keys), 1, f"در {ctype} فقط یک قالب باید فعال باشد: {keys}")
        # هیچ عنوان تکراریای در کیبورد نهایی وجود ندارد
        ext.set_runtime_context(chat_id=GROUP_ID, chat_type="group", bot_id=1,
                                active_templates=rt.runtime_active_templates("group"))
        buttons = rt._get_buttons()
        inline, reply = main.build_user_bot_keyboard(buttons, parent_id=None)
        titles = [b["text"] for row in (inline or {}).get("inline_keyboard", []) for b in row]
        titles += [b["text"] for row in (reply or {}).get("keyboard", []) for b in row]
        self.assertEqual(len(titles), len(set(titles)), f"دکمه تکراری: {titles}")

    def test_07_every_attached_button_has_unique_callback_and_works(self):
        """فریم به فریم: تمام ۷۵۸ قالب × تمام دکمهها، attach + کالبک واقعی."""
        self.create_bot()
        rt = main.UserBotRuntime(1, "TESTTOKEN", self.db_path)
        rt.api = FakeAPI()
        checked = 0
        errors = []
        for key in list(ext.ALL_TEMPLATES.keys()):
            try:
                with self.db.get_conn() as conn:
                    conn.execute("DELETE FROM bot_buttons WHERE bot_id=1")
                    conn.execute("DELETE FROM bot_templates WHERE bot_id=1")
                    conn.execute("UPDATE bot_settings SET active_template_group='', active_template_pv='' WHERE bot_id=1")
                ok = self.builder.attach_template(OWNER, 1, key, silent=True)
                if not ok:
                    errors.append(f"{key}: attach False")
                    continue
                btnrows = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=1")
                cbs = [r["callback"] for r in btnrows]
                if not cbs and not ext.ALL_TEMPLATES[key].get("buttons"):
                    continue   # قالب خام (custom) ذاتاً دکمهای ندارد
                if not cbs or any(not str(c).startswith("tcb_") for c in cbs):
                    errors.append(f"{key}: کالبک نامعتبر {cbs[:2]}")
                if len(set(cbs)) != len(cbs):
                    errors.append(f"{key}: کالبک تکراری")
                scope = ext.ALL_TEMPLATES[key].get("scope", "both")
                ctype = "group" if scope == "group" else "private"
                chat_id = GROUP_ID if ctype == "group" else 7009
                ext.set_runtime_context(chat_id=chat_id, chat_type=ctype, bot_id=1,
                                        active_templates={key})
                for r in btnrows:
                    q = {"id": f"q{checked}", "data": r["callback"],
                         "from": {"id": 7009, "first_name": "تست"},
                         "message": {"message_id": 10, "chat": {"id": chat_id, "type": ctype}}}
                    try:
                        rt.handle_callback(q)
                    except Exception as e:
                        errors.append(f"{key}/{r['id']}: {type(e).__name__}: {e}")
                    checked += 1
            except Exception as e:
                errors.append(f"{key}: {type(e).__name__}: {e}")
        self.assertEqual(errors[:15], [], f"{len(errors)} خطا در {checked} کالبک: {errors[:15]}")
        self.assertGreaterEqual(checked, 3000)

    def test_08_all_29_lock_presets_seeded(self):
        self.create_bot()
        god.god_db_seed_variables(self.db, 1)
        rows = self.db.fetchall("SELECT name, action FROM bot_variables WHERE bot_id=1")
        self.assertEqual(len({r["name"] for r in rows}), 29)
        actions = {r["action"] for r in rows}
        for key, *_ in god.GROUP_LOCK_SPECS:
            self.assertIn("lock_" + key, actions)

    def test_09_global_broadcast_hits_all_bots(self):
        """همگانی سراسری → کاربران «همه» رباتها، با صفحهبندی keyset."""
        self.create_bot(bot_id=1, username="bot1")
        self.db.execute("""INSERT INTO bots (id, owner_id, token_encrypted, bot_username,
            bot_name, is_active, status) VALUES (2,?, 'TOKEN2','bot2','دوم',1,'online')""", (OWNER,))
        self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id) VALUES (2)")
        with self.db.get_conn() as conn:
            conn.executemany("INSERT OR IGNORE INTO bot_users (bot_id, chat_id, is_blocked) VALUES (?,?,0)",
                             [(1, 10000 + i) for i in range(30)] +
                             [(2, 20000 + i) for i in range(25)])
        sent = []

        class SpyAPI:
            def __init__(self, token, base_url=None):
                self.token = token

            def send_message(self, chat_id, text, **kw):
                sent.append((self.token, chat_id))

        orig_api = main.BaleAPI
        orig_dec = main.decrypt_token
        try:
            main.BaleAPI = SpyAPI
            main.decrypt_token = lambda t: t
            mgr = god.GlobalBroadcastManager(self.builder)
            # ردیف کار را مستقیم میسازیم تا thread پسزمینه دوبار ارسال نکند
            c = mgr._conn()
            cur = c.execute("""INSERT INTO global_broadcasts (admin_id, content, target, status)
                               VALUES (?,?,?,'running')""", (OWNER, "پیام سراسری تست", "all"))
            jid = cur.lastrowid
            c.commit()
            c.close()
            mgr._run(jid, "پیام سراسری تست", "all")
            row = self.db.fetchone("SELECT * FROM global_broadcasts WHERE id=?", (jid,))
            self.assertEqual(row["sent"], 55)
            self.assertEqual(row["failed"], 0)
            self.assertIn("TOKEN2", {t for t, _ in sent})
        finally:
            main.BaleAPI = orig_api
            main.decrypt_token = orig_dec
        self.assertEqual(len(sent), 55)

    def test_10_iter_all_targets_keyset_and_scale(self):
        """۱۰٫۰۰۰ ربات + ۵۰٫۰۰۰ کاربر بدون بارگذاری در حافظه."""
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "scale.sqlite3")
            c = sqlite3.connect(path)
            c.execute("CREATE TABLE bots (id INTEGER PRIMARY KEY, is_active INTEGER, token_encrypted TEXT)")
            c.execute("CREATE TABLE bot_users (id INTEGER PRIMARY KEY AUTOINCREMENT, bot_id INTEGER, "
                      "chat_id INTEGER, is_blocked INTEGER DEFAULT 0)")
            c.executemany("INSERT INTO bots VALUES (?,1,?)",
                          [(i, f"T{i}") for i in range(1, 10001)])
            c.executemany("INSERT INTO bot_users (bot_id, chat_id) VALUES (?,?)",
                          [((i % 10000) + 1, 1_000_000 + i) for i in range(50000)])
            c.commit()
            c.close()
            t0 = time.time()
            items = list(god.iter_all_targets(path, batch=1000))
            elapsed = time.time() - t0
            self.assertEqual(len(items), 50000)
            self.assertLess(elapsed, 20, f"صفحهبندی خیلی کند: {elapsed}s")
            self.assertEqual(len({(x["bot_id"], x["chat_id"]) for x in items}), 50000)

    def test_11_shard_50k_users_per_bot(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(god, "SHARD_DIR", god.Path(tmp)):
                for i in range(50000):
                    if i % 5000 == 0:
                        pass
                c = god.ShardedUserStore.conn(77)
                c.executemany("INSERT INTO bot_users (chat_id) VALUES (?)",
                              [(1_000_000 + i,) for i in range(50000)])
                c.commit()
                c.close()
                self.assertEqual(god.ShardedUserStore.count(77), 50000)
                got = list(god.ShardedUserStore.iter_users(77, batch=1000))
                self.assertEqual(len(got), 50000)


class TestReadySources(BaseFixTest):
    def test_12_every_ready_source_deploys_and_compiles(self):
        """چانک به چانک: تکتک ۳۲ سورس، جایگذاری + کامپایل + خروجی معتبر."""
        self.create_bot()
        cwd = os.getcwd()
        tmp = tempfile.mkdtemp(prefix="god_deploy_")
        self.addCleanup(lambda: (os.chdir(cwd), shutil.rmtree(tmp, ignore_errors=True)))
        os.chdir(tmp)
        os.makedirs("bots", exist_ok=True)
        errors = []
        with patch("subprocess.Popen") as popen:
            popen.return_value.pid = 12345
            for s in god.READY_SOURCES:
                ok, workdir, bad = god.deploy_ready_source(
                    self.builder, 1, OWNER, "TESTTOKEN", "testbot", s)
                if not ok:
                    errors.append(f"{s['id']}: {bad[:2]}")
                    continue
                main_py = os.path.join(workdir, "main.py")
                if not os.path.exists(main_py):
                    errors.append(f"{s['id']}: main.py وجود ندارد")
                    continue
                from pathlib import Path as _P
                txt = _P(main_py).read_text(encoding="utf-8")
                for ph in ("{{BOT_TOKEN}}", "{{ADMIN_ID}}", "__GOD_TOKEN__", "__GOD_ADMIN__"):
                    if ph in txt:
                        errors.append(f"{s['id']}: placeholder باقیمانده {ph}")
                try:
                    py_compile.compile(main_py, doraise=True)
                except Exception as e:
                    errors.append(f"{s['id']}: compile {e}")
                shutil.rmtree(workdir, ignore_errors=True)
        self.assertEqual(errors[:20], [], f"{len(errors)} خطا: {errors[:20]}")

    def test_13_god_dispatch_all_callbacks_safe(self):
        self.create_bot()
        prefixes = ["rs_page_0", "gb_menu", "adm_global", "god_menu", "god_feat_F01",
                    "godpick", "godset_1", "cmdonly_1_0", "gvar_all_1", "gvar_locks_1"]
        for d in prefixes:
            try:
                god.god_dispatch(self.builder, OWNER, d, None, {"id": OWNER})
            except Exception as e:
                self.fail(f"کالبک {d} خطا داد: {e}")


if __name__ == "__main__":
    unittest.main()
