#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تستهای آفلاین نسخه اصلاحشده — بدون هیچ تماس شبکهای و بدون توکن واقعی.
اجرا:  python3 -m unittest discover -s tests -v
"""
import os
import sys
import json
import time
import glob
import shutil
import sqlite3
import tempfile
import subprocess
import unittest
import py_compile
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import main
import botfix_ext as ext

OWNER = 900100
ADMIN_USER = 555
NORMAL_USER = 666
GROUP_ID = -100500


class FakeResponse:
    def __init__(self, payload):
        self._payload = payload
        self.text = json.dumps(payload, ensure_ascii=False)

    def json(self):
        return self._payload


class FakeSession:
    def __init__(self):
        self.calls = []
        self.script = []

    def post(self, url, **kw):
        self.calls.append(("POST", url, kw))
        if self.script:
            return FakeResponse(self.script.pop(0))
        return FakeResponse({"ok": True, "result": {"message_id": 1}})

    def get(self, url, **kw):
        self.calls.append(("GET", url, kw))
        if self.script:
            return FakeResponse(self.script.pop(0))
        return FakeResponse({"ok": True, "result": []})


class FakeAPI:
    """شبیهساز API بله برای BuilderBot و UserBotRuntime."""
    sent = []
    deleted = []
    banned = []
    answered = []

    def __init__(self, *a, **kw):
        pass

    def send_message(self, chat_id, text, **kw):
        FakeAPI.sent.append((chat_id, str(text), kw))
        return {"message_id": 1000 + len(FakeAPI.sent)}

    def edit_message_text(self, chat_id, msg_id, text, **kw):
        FakeAPI.sent.append((chat_id, str(text), kw))
        return {"message_id": msg_id}

    def answer_callback_query(self, *a, **kw):
        FakeAPI.answered.append((a, kw))

    def delete_message(self, chat_id, message_id):
        FakeAPI.deleted.append((chat_id, message_id))
        return True

    def delete_webhook(self):
        return True

    def get_me(self):
        return {"id": 123, "username": "builder_bot", "first_name": "Builder"}

    def get_updates(self, **kw):
        return []

    # --- متدهای رسمی گROUP ---
    def get_chat(self, chat_id):
        return {"id": chat_id, "type": "supergroup", "title": "گروه تست",
                "username": "testgroup", "invite_link": "https://ble.ir/join/test"}

    def get_chat_members_count(self, chat_id):
        return 12

    def get_chat_administrators(self, chat_id):
        return [{"status": "administrator", "user": {"id": ADMIN_USER, "first_name": "ادمین"}},
                {"status": "creator", "user": {"id": 999, "first_name": "مالک"}}]

    def get_chat_member(self, chat_id, user_id):
        return {"status": "administrator" if user_id in (ADMIN_USER, 999) else "member"}

    def export_chat_invite_link(self, chat_id):
        return "https://ble.ir/join/test"

    def ban_chat_member(self, chat_id, user_id):
        FakeAPI.banned.append((chat_id, user_id))
        return True

    def unban_chat_member(self, *a, **kw):
        return True

    def pin_chat_message(self, *a, **kw):
        return True

    def send_photo(self, chat_id, photo, **kw):
        FakeAPI.sent.append((chat_id, "[photo]", kw))
        return {"message_id": 1}

    def send_video(self, chat_id, video, **kw):
        FakeAPI.sent.append((chat_id, "[video]", kw))
        return {"message_id": 1}

    def send_document(self, chat_id, document, **kw):
        FakeAPI.sent.append((chat_id, "[document]", kw))
        return {"message_id": 1}

    def send_audio(self, chat_id, audio, **kw):
        FakeAPI.sent.append((chat_id, "[audio]", kw))
        return {"message_id": 1}


class FakeRuntime:
    def __init__(self):
        self.running = True

    def stop(self):
        self.running = False


class BaseFixTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="botfix_test_")
        self.db_path = os.path.join(self.tmp, "test.sqlite3")
        self.db = main.Database(self.db_path)
        FakeAPI.sent, FakeAPI.deleted, FakeAPI.banned, FakeAPI.answered = [], [], [], []
        self._orig = {
            "BaleAPI": ext.MOD.get("BaleAPI"),
            "decrypt_token": ext.MOD.get("decrypt_token"),
            "encrypt_token": ext.MOD.get("encrypt_token"),
        }
        ext.MOD["BaleAPI"] = FakeAPI
        ext.MOD["decrypt_token"] = lambda t: t
        ext.MOD["encrypt_token"] = lambda t: t
        self.manager = main.BotManager(self.db_path)
        self.bcm = main.BroadcastManager(self.db_path, rate_limit=1000.0)
        self.builder = main.BuilderBot("TEST:TOKEN", self.db, self.manager, self.bcm)
        self.builder.api = FakeAPI()
        self._insert_user(OWNER)

    def tearDown(self):
        for k, v in self._orig.items():
            if v is not None:
                ext.MOD[k] = v
        try:
            self.manager.stop_monitor()
        except Exception:
            pass
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _insert_user(self, uid):
        self.db.execute("INSERT OR IGNORE INTO users (user_id, username, first_name) VALUES (?,?,?)",
                        (uid, f"user{uid}", "تست"))

    def create_bot(self, username="testbot", owner=OWNER, bot_id=1):
        self._insert_user(owner)
        self.db.execute("""INSERT INTO bots
            (id, owner_id, token_encrypted, bot_username, bot_name, bot_id, is_active, status,
             created_at, expires_at, plan_id)
            VALUES (?,?,?,?,?,?,1,'online',?,?,1)""",
            (bot_id, owner, "TESTTOKEN", username, "ربات تست", 123456,
             datetime.now().isoformat(), (datetime.now() + timedelta(days=7)).isoformat()))
        self.db.execute("INSERT OR IGNORE INTO bot_settings (bot_id) VALUES (?)", (bot_id,))
        self.db.seed_variables(bot_id)
        return bot_id

    def add_user(self, bot_id, chat_id, ctype="private", name="کاربر"):
        self.db.execute("""INSERT OR IGNORE INTO bot_users
            (bot_id, chat_id, first_name, chat_type, is_blocked) VALUES (?,?,?,?,0)""",
            (bot_id, chat_id, name, ctype))


class TestCompileAndLibrary(BaseFixTest):
    def test_01_all_python_files_compile(self):
        bad = []
        for f in glob.glob(os.path.join(ROOT, "**", "*.py"), recursive=True):
            try:
                py_compile.compile(f, doraise=True)
            except Exception as e:
                bad.append((f, str(e)[:200]))
        self.assertEqual(bad, [], f"فایلهای دارای خطای نحوی: {bad}")

    def test_02_template_library_over_100(self):
        # فاز دوم: کتابخانه به ۷۴۴+ قالب گسترش یافت («تا میتونی قالب اضافه کن»)
        self.assertGreaterEqual(len(ext.TEMPLATE_LIBRARY), 100)
        self.assertGreaterEqual(len(ext.TEMPLATE_LIBRARY), 600)
        self.assertGreaterEqual(len(main.ALL_TEMPLATES), 134)
        self.assertGreaterEqual(len({t["category"] for t in ext.TEMPLATE_LIBRARY.values()}), 11)
        for key, t in ext.TEMPLATE_LIBRARY.items():
            self.assertTrue(t["buttons"], key)
            self.assertTrue(t["start_message"], key)
            self.assertIn(t["scope"], ("group", "pv", "both"), key)
            for b in t["buttons"]:
                self.assertTrue(b["title"] and "content" in b, key)
        self.assertIn("liro", main.ALL_TEMPLATES)

    def test_03_variable_engine_no_substring_collision(self):
        v = {
            "COUNT": "7", "TOP1COUNT": "99", "MAXWARN": "3", "WARN": "1",
            "DATEEN": "2026/11/03", "DATE": "1405/08/12", "LINK": "ble.ir/x",
            "<b>COUNT</b>": "<b>7</b>", "{name}": "علی", "zadlink": "فعال ✅",
            "{zadlink}": "فعال ✅", "ZADLINK": "فعال ✅",
        }
        out = ext.render_variables(
            "COUNT / TOP1COUNT / MAXWARN / DATEEN / DATE / <b>COUNT</b> / {name} / {zadlink} / ZADLINK / لینکت", v)
        self.assertIn("7 / 99 / 3 / 2026/11/03 / 1405/08/12 / <b>7</b> / علی / فعال ✅ / فعال ✅", out)
        self.assertNotIn("7COUNT", out)
        self.assertIn("لینکت", out)  # «link» کوچک دیگر متن فارسی را خراب نمیکند

    def test_04_jalali_conversion(self):
        self.assertEqual(ext.gregorian_to_jalali(2026, 11, 3), (1405, 8, 12))
        self.assertIn("/", ext.jalali_now()[0])

    def test_05_database_migrations(self):
        with self.db.get_conn() as conn:
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(bot_buttons)")}
            self.assertIn("scope", cols)
            self.assertIn("template_key", cols)
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(bot_settings)")}
            self.assertIn("active_template_group", cols)
            self.assertIn("active_template_pv", cols)
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(bot_users)")}
            self.assertIn("chat_type", cols)
            tables = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for t in ("bot_variables", "bot_variable_state", "bot_templates", "bot_processes"):
                self.assertIn(t, tables)


class TestVariablesAndGroup(BaseFixTest):
    def setUp(self):
        super().setUp()
        self.bot_id = self.create_bot()
        self.rt = main.UserBotRuntime(self.bot_id, "TESTTOKEN", self.db_path)
        self.rt.api = FakeAPI()

    def _msg(self, uid, text, mid=1, ctype="group", chat_id=GROUP_ID):
        return {"message_id": mid, "chat": {"id": chat_id, "type": ctype},
                "from": {"id": uid, "first_name": "ادمین" if uid == ADMIN_USER else "کاربر"},
                "text": text}

    def test_06_group_variables_are_real(self):
        v = self.rt._get_all_variables(GROUP_ID, {"id": ADMIN_USER, "first_name": "ادمین"},
                                       {"type": "group", "id": GROUP_ID})
        self.assertEqual(v["GROUPNAME"], "گروه تست")
        self.assertEqual(v["GROUPTITLE"], "گروه تست")
        self.assertEqual(v["GROUPID"], str(GROUP_ID))
        self.assertEqual(v["GROUPMEMBERS"], "12")
        self.assertEqual(v["GROUPADMINS"], "2")
        self.assertIn("ادمین", v["ADMINS"])
        self.assertEqual(v["ISADMIN"], "بله")
        self.assertEqual(v["GROUPLINK"], "https://ble.ir/join/test")
        self.assertEqual(v["CHATTYPE"], "supergroup")
        self.assertTrue(v["RULES"])

    def test_07_custom_variable_command_zadlink_and_lock(self):
        self.add_user(self.bot_id, ADMIN_USER, "group", "ادمین")
        self.add_user(self.bot_id, NORMAL_USER, "group", "کاربر")
        # «قفل لینک» → متغیر zadlink فعال شود
        self.rt.handle_message(self._msg(ADMIN_USER, "قفل لینک", mid=1))
        st = self.db.get_var_state(self.bot_id, GROUP_ID, "zadlink")
        self.assertIsNotNone(st)
        self.assertEqual(st["is_active"], 1)
        v = self.rt._get_all_variables(GROUP_ID, {"id": ADMIN_USER, "first_name": "ادمین"},
                                       {"type": "group", "id": GROUP_ID})
        self.assertEqual(v["{zadlink}"], "فعال ✅")
        self.assertEqual(v["ZADLINK"], "فعال ✅")
        # لینک کاربر عادی حذف شود
        FakeAPI.deleted = []
        self.rt.handle_message(self._msg(NORMAL_USER, "نگا کن https://ble.ir/channel", mid=2))
        self.assertIn((GROUP_ID, 2), FakeAPI.deleted)
        # «بازکردن لینک» → قفل خاموش و پیام حذف نشود
        self.rt.handle_message(self._msg(ADMIN_USER, "بازکردن لینک", mid=3))
        st = self.db.get_var_state(self.bot_id, GROUP_ID, "zadlink")
        self.assertEqual(st["is_active"], 0)
        FakeAPI.deleted = []
        self.rt.handle_message(self._msg(NORMAL_USER, "https://ble.ir/channel", mid=4))
        self.assertNotIn((GROUP_ID, 4), FakeAPI.deleted)

    def test_08_builtin_group_commands_and_admin_only(self):
        self.add_user(self.bot_id, NORMAL_USER, "group")
        self.rt.handle_message(self._msg(NORMAL_USER, "بن", mid=10))
        # دستورات ادمینی فقط با ریپلای + ادمین؛ کاربر عادی نباید بن کند
        self.assertEqual(FakeAPI.banned, [])
        self.rt.handle_message(self._msg(ADMIN_USER, "آمار گروه", mid=11))
        self.assertTrue(any("آمار گروه" in m[1] for m in FakeAPI.sent))

    def test_09_pv_variables_are_not_wrong_hardcoded_values(self):
        v = self.rt._get_all_variables(1001, {"id": 1001, "first_name": "علی"},
                                       {"type": "private", "id": 1001})
        self.assertEqual(v["ISADMIN"], "خیر")
        self.assertEqual(v["ISOWNER"], "خیر")
        self.assertEqual(v["GROUPADMINS"], "0")
        self.assertEqual(v["GROUPMEMBERS"], "0")
        self.assertNotEqual(v["GROUPNAME"], "")
        self.assertEqual(v["TODAYMSG"], "0")


class TestTemplatesAndScopes(BaseFixTest):
    def setUp(self):
        super().setUp()
        self.bot_id = self.create_bot()

    def test_10_one_click_attach_and_customize(self):
        ok = self.builder.attach_template(OWNER, self.bot_id, "tools_01", silent=True)
        self.assertTrue(ok)
        row = self.db.fetchone("SELECT * FROM bot_templates WHERE bot_id=? AND template_key='tools_01'", (self.bot_id,))
        self.assertEqual(row["scope"], "pv")
        buttons = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=? AND template_key='tools_01'", (self.bot_id,))
        self.assertGreaterEqual(len(buttons), 4)
        self.assertTrue(all(b["scope"] == "pv" for b in buttons))
        # شخصیسازی عنوان دکمه
        self.db.set_user_step(OWNER, "await_library_custom", {"bot_id": self.bot_id, "key": "tools_01"})
        self.builder.handle_step(OWNER, {}, "عنوان|1|ابزار من", self.db.get_user_step(OWNER))
        first = self.db.fetchall("SELECT title FROM bot_buttons WHERE bot_id=? AND template_key='tools_01' ORDER BY position", (self.bot_id,))[0]
        self.assertEqual(first["title"], "ابزار من")

    def test_11_button_scope_group_vs_pv(self):
        self.builder.attach_template(OWNER, self.bot_id, "group_01", scope="group", silent=True)
        self.builder.attach_template(OWNER, self.bot_id, "tools_01", scope="pv", silent=True)
        buttons = [dict(b) for b in self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=?", (self.bot_id,))]
        def titles_for(ctype, cid):
            ext.set_runtime_context(chat_id=cid, chat_type=ctype, bot_id=self.bot_id, active_templates=None)
            inline, reply = main.build_user_bot_keyboard(buttons)
            titles = []
            if inline:
                titles += [b["text"] for row in inline["inline_keyboard"] for b in row]
            if reply:
                titles += [b["text"] for row in reply["keyboard"] for b in row]
            return titles
        self.assertFalse(any("قوانین" in t for t in titles_for("private", 1001)),
                         "دکمه گروهی نباید در پیوی باشد")
        self.assertTrue(any("قوانین" in t for t in titles_for("group", GROUP_ID)),
                        "دکمه گروهی باید در گروه باشد")
        self.assertTrue(any("ابزار" in t for t in titles_for("private", 1001)),
                        "دکمه پیوی باید در پیوی باشد")
        self.assertFalse(any("ابزار" in t for t in titles_for("group", GROUP_ID)),
                         "دکمه پیوی نباید در گروه باشد")

    def test_12_active_template_group_vs_pv(self):
        self.builder.attach_template(OWNER, self.bot_id, "group_01", scope="both", silent=True)
        self.builder.attach_template(OWNER, self.bot_id, "tools_01", scope="both", silent=True)
        ext.set_active_template(self.builder, OWNER, self.bot_id, "tools_01", "group")
        s = self.db.fetchone("SELECT * FROM bot_settings WHERE bot_id=?", (self.bot_id,))
        self.assertEqual(s["active_template_group"], "tools_01")
        rt = main.UserBotRuntime(self.bot_id, "TESTTOKEN", self.db_path)
        keys = rt.runtime_active_templates("group")
        self.assertEqual(keys, {"tools_01"})
        keys_pv = rt.runtime_active_templates("private")
        # فاز دوم: در هر دامنه حداکثر یک قالب فعال است → جلوگیری از دکمه/پاسخ تکراری
        self.assertEqual(len(keys_pv), 1)
        self.assertIn(next(iter(keys_pv)), {"group_01", "tools_01"})

    def test_13_scope_all_callback(self):
        self.builder.attach_template(OWNER, self.bot_id, "tools_01", silent=True)
        self.builder.handle_callback({"id": "q1", "data": f"scope_all_group_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        scopes = {r["scope"] for r in self.db.fetchall("SELECT scope FROM bot_buttons WHERE bot_id=?", (self.bot_id,))}
        self.assertEqual(scopes, {"group"})

    def test_14_btn_del_callback_not_swallowed(self):
        self.builder.attach_template(OWNER, self.bot_id, "tools_01", silent=True)
        FakeAPI.sent = []
        self.builder.handle_callback({"id": "q2", "data": f"btn_del_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        self.assertTrue(any("لیست دکمهها" in m[1] for m in FakeAPI.sent))


class TestBroadcast(BaseFixTest):
    def setUp(self):
        super().setUp()
        self.bot_id = self.create_bot()
        self.add_user(self.bot_id, 1001, "private", "علی")
        self.add_user(self.bot_id, 1002, "private", "سارا")
        self.add_user(self.bot_id, GROUP_ID, "group", "گروه")

    def test_15_broadcast_preview_confirm_send(self):
        # انتخاب نوع متن (روتینگ قدیمی) → FSM
        self.builder.handle_callback({"id": "c1", "data": f"bc_type_text_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        step = self.db.get_user_step(OWNER)
        self.assertEqual(step["step"], "await_broadcast_content")
        # متن حاوی «شارژ» قبلاً مسیر کیف پول میرفت؛ الان باید FSM اول باشد
        self.builder.handle_message({"chat": {"id": OWNER}, "from": {"id": OWNER},
                                     "message_id": 2, "text": "شارژ سلام FIRSTNAME"})
        step = self.db.get_user_step(OWNER)
        self.assertEqual(step["step"], "await_broadcast_preview")
        self.assertIn("شارژ", step["data"]["content"])
        # دکمه شیشهای
        self.builder.handle_callback({"id": "c2", "data": f"bc_addbtn_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        self.builder.handle_message({"chat": {"id": OWNER}, "from": {"id": OWNER},
                                     "message_id": 3, "text": "کانال|https://ble.ir/channel"})
        step = self.db.get_user_step(OWNER)
        self.assertIn("keyboard_json", step["data"])
        # تایید نهایی
        self.builder.handle_callback({"id": "c3", "data": f"bc_confirm_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        bc = self.db.fetchone("SELECT * FROM broadcasts WHERE bot_id=? ORDER BY id DESC LIMIT 1", (self.bot_id,))
        self.assertIsNotNone(bc)
        self.assertEqual(bc["total_count"], 3)
        # صبر تا اتمام ورکر
        for _ in range(100):
            row = self.db.fetchone("SELECT status, sent_count FROM broadcasts WHERE id=?", (bc["id"],))
            if row["status"] in ("completed", "cancelled", "failed"):
                break
            time.sleep(0.02)
        self.assertEqual(row["status"], "completed", f"status={row['status']}")
        self.assertEqual(row["sent_count"], 3)
        self.assertEqual(self.db.fetchone("SELECT COUNT(*) c FROM broadcast_queue WHERE broadcast_id=? AND status='sent'", (bc["id"],))["c"], 3)
        # متغیرها بهازای گیرنده رندر شدهاند
        sent_texts = [m[1] for m in FakeAPI.sent]
        self.assertTrue(any("علی" in t and "شارژ" in t for t in sent_texts), sent_texts[-5:])
        self.assertTrue(any("سارا" in t for t in sent_texts))

    def test_16_broadcast_target_scope(self):
        self.db.set_user_step(OWNER, "await_broadcast_preview",
                              {"bot_id": self.bot_id, "message_type": "text",
                               "content": "فقط پیوی", "target_scope": "all"})
        self.builder.handle_callback({"id": "c4", "data": f"bc_target_pv_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        self.assertEqual(self.db.get_user_step(OWNER)["data"]["target_scope"], "pv")
        self.builder.handle_callback({"id": "c5", "data": f"bc_confirm_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        bc = self.db.fetchone("SELECT * FROM broadcasts WHERE bot_id=? ORDER BY id DESC LIMIT 1", (self.bot_id,))
        self.assertEqual(bc["total_count"], 2)
        self.assertEqual(bc["target_scope"], "pv")
        for _ in range(100):
            row = self.db.fetchone("SELECT status FROM broadcasts WHERE id=?", (bc["id"],))
            if row["status"] in ("completed", "cancelled", "failed"):
                break
            time.sleep(0.02)

    def test_17_stop_broadcast(self):
        self.bcm.rate_limit = 1.0  # کندتر تا فرصت توقف داشته باشیم
        self.db.set_user_step(OWNER, "await_broadcast_preview",
                              {"bot_id": self.bot_id, "message_type": "text", "content": "تست"})
        self.builder.handle_callback({"id": "c6", "data": f"bc_confirm_{self.bot_id}",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        bc = self.db.fetchone("SELECT id FROM broadcasts WHERE bot_id=? ORDER BY id DESC LIMIT 1", (self.bot_id,))
        self.bcm.stop_broadcast(bc["id"])
        self.assertTrue(self.bcm.stop_flags.get(bc["id"]))
        for _ in range(100):
            row = self.db.fetchone("SELECT status FROM broadcasts WHERE id=?", (bc["id"],))
            if row["status"] == "cancelled":
                break
            time.sleep(0.03)
        self.assertEqual(row["status"], "cancelled")


class TestDeleteBot(BaseFixTest):
    def test_18_delete_bot_full_cleanup(self):
        bot_id = self.create_bot()
        self.add_user(bot_id, 1001, "private")
        self.builder.attach_template(OWNER, bot_id, "tools_01", silent=True)
        self.db.execute("INSERT INTO bot_buttons (bot_id,title,button_type,action_type) VALUES (?,?,?,?)",
                        (bot_id, "تست", "reply", "text"))
        # فایل و پروسه واقعی (شبیه دیپلوی قالب)
        workdir = os.path.join(ROOT, "bots", f"{bot_id}_testbot")
        os.makedirs(workdir, exist_ok=True)
        with open(os.path.join(workdir, "main.py"), "w", encoding="utf-8") as f:
            f.write("# test\n" * 500)
        proc = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                start_new_session=True)
        self.db.record_process(bot_id, proc.pid, workdir, "subprocess")
        self.db.execute("UPDATE bots SET workdir=? WHERE id=?", (workdir, bot_id))
        self.manager.bots[bot_id] = FakeRuntime()
        # همگانی در حال اجرا
        self.db.execute("""INSERT INTO broadcasts (bot_id,owner_id,content,status,total_count)
                           VALUES (?,?,?,'running',1)""", (bot_id, OWNER, "x"))
        bc_id = self.db.fetchone("SELECT id FROM broadcasts WHERE bot_id=?", (bot_id,))["id"]
        self.db.execute("INSERT INTO broadcast_queue (broadcast_id,chat_id) VALUES (?,?)", (bc_id, 1001))
        self.assertTrue(os.path.exists(workdir))
        self.assertTrue(self.manager.is_running(bot_id))

        self.builder.delete_bot(OWNER, bot_id, msg_id=None)

        self.assertIsNone(self.db.get_bot(bot_id))
        for table in ("bot_users", "bot_buttons", "bot_settings", "bot_variables",
                      "bot_templates", "bot_processes", "broadcasts", "broadcast_queue"):
            n = self.db.fetchone(f"SELECT COUNT(*) c FROM {table} WHERE {'broadcast_id' if table=='broadcast_queue' else 'bot_id'}=?",
                                 (bc_id if table == "broadcast_queue" else bot_id,))["c"]
            self.assertEqual(n, 0, f"جدول {table} پاک نشده")
        self.assertFalse(os.path.exists(workdir), "پوشه ربات پاک نشده / فضا آزاد نشده")
        self.assertFalse(self.manager.is_running(bot_id), "runtime همچنان فعال است")
        self.assertIn(bot_id, self.manager._deleted, "مانیتور ممکن است ربات را ریاستارت کند")
        try:
            proc.wait(timeout=3)
        except Exception:
            pass
        self.assertIsNotNone(proc.poll(), "پروسه subprocess همچنان زنده است")

    def test_19_deleted_bot_not_restarted_by_monitor(self):
        bot_id = self.create_bot()
        self.manager.remove_bot(bot_id)
        self.db.execute("UPDATE bots SET is_active=1, status='online' WHERE id=?", (bot_id,))
        # شبیهسازی یک چرخه مانیتور (بدون خواب ۶۰ ثانیهای)
        import sqlite3 as sq
        conn = sq.connect(self.db_path)
        conn.row_factory = sq.Row
        bots = conn.execute("SELECT * FROM bots WHERE is_active=1 AND status='online'").fetchall()
        conn.close()
        started = []
        orig_start = self.manager.start_bot
        self.manager.start_bot = lambda bid, tok: started.append(bid)
        try:
            for b in bots:
                bid = int(b["id"])
                if bid in getattr(self.manager, "_deleted", set()):
                    continue
                self.manager.start_bot(bid, b["token_encrypted"])
        finally:
            self.manager.start_bot = orig_start
        self.assertEqual(started, [])


class TestBaleAPI(BaseFixTest):
    def test_20_official_group_methods_and_get_updates(self):
        api = main.BaleAPI("123:ABC")
        fake = FakeSession()
        api.session = fake
        api.ban_chat_member(-100, 555)
        api.get_chat_members_count(-100)
        api.get_chat_administrators(-100)
        api.unpin_chat_message(-100, 12)
        api.delete_message(-100, 12)
        api.get_updates(offset=42, limit=50, timeout=3)
        posts = [c for c in fake.calls if c[0] == "POST"]
        gets = [c for c in fake.calls if c[0] == "GET"]
        self.assertTrue(any("banChatMember" in c[1] for c in posts))
        self.assertTrue(any("getChatMembersCount" in c[1] for c in posts))
        self.assertTrue(any("getChatAdministrators" in c[1] for c in posts))
        self.assertTrue(any("unPinChatMessage" in c[1] for c in posts))
        self.assertTrue(any("deleteMessage" in c[1] for c in posts))
        self.assertTrue(any("getUpdates" in c[1] for c in gets))
        ban_payload = next(c[2]["json"] for c in posts if "banChatMember" in c[1])
        self.assertEqual(ban_payload, {"chat_id": -100, "user_id": 555})
        gu = next(c[2]["params"] for c in gets if "getUpdates" in c[1])
        self.assertEqual(gu["offset"], 42)

    def test_21_rate_limit_429_retry(self):
        api = main.BaleAPI("123:ABC")
        fake = FakeSession()
        fake.script = [
            {"ok": False, "error_code": 429, "description": "Too Many Requests",
             "parameters": {"retry_after": 0}},
            {"ok": True, "result": {"message_id": 7}},
        ]
        api.session = fake
        res = api.send_message(123, "تست")
        self.assertEqual(res["message_id"], 7)
        self.assertEqual(len(fake.calls), 2)

    def test_22_send_message_accepts_protect_content(self):
        api = main.BaleAPI("123:ABC")
        fake = FakeSession()
        api.session = fake
        api.send_message(123, "PMGUARD", protect_content=True)
        payload = fake.calls[0][2]["json"]
        self.assertTrue(payload.get("protect_content"))


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TestCreationAndVariableFSM(BaseFixTest):
    def test_23_create_bot_with_library_template_one_click(self):
        self.builder.bot_manager.start_bot = lambda bid, tok: True
        self.db.set_user_step(OWNER, "await_template_choice", {
            "token_enc": "NEWTOKEN", "bot_username": "newbot",
            "bot_name": "ربات جدید", "bot_id_api": 777777})
        self.builder.handle_callback({"id": "q", "data": "use_template_tools_01",
                                      "from": {"id": OWNER},
                                      "message": {"message_id": 1, "chat": {"id": OWNER}}})
        bot = self.db.fetchone("SELECT * FROM bots WHERE bot_username='newbot'")
        self.assertIsNotNone(bot)
        tpl = self.db.fetchone("SELECT * FROM bot_templates WHERE bot_id=? AND template_key='tools_01'", (bot["id"],))
        self.assertIsNotNone(tpl)
        btns = self.db.fetchall("SELECT * FROM bot_buttons WHERE bot_id=? AND template_key='tools_01'", (bot["id"],))
        self.assertGreaterEqual(len(btns), 4)
        self.assertTrue(all(b["scope"] == tpl["scope"] for b in btns))
        self.assertGreaterEqual(self.db.fetchone("SELECT COUNT(*) c FROM bot_variables WHERE bot_id=?", (bot["id"],))["c"], 5)
        self.assertIsNone(self.db.get_user_step(OWNER))

    def test_24_add_custom_variable_with_commands(self):
        bot_id = self.create_bot()
        self.db.set_user_step(OWNER, "await_var_name", {"bot_id": bot_id})
        self.builder.handle_message({"chat": {"id": OWNER}, "from": {"id": OWNER},
                                     "message_id": 1, "text": "myvar"})
        step = self.db.get_user_step(OWNER)
        self.assertEqual(step["step"], "await_var_commands")
        self.builder.handle_message({"chat": {"id": OWNER}, "from": {"id": OWNER},
                                     "message_id": 2, "text": "روشن کن|خاموش کن"})
        v = self.db.fetchone("SELECT * FROM bot_variables WHERE bot_id=? AND name='myvar'", (bot_id,))
        self.assertIsNotNone(v)
        self.assertEqual(v["command_on"], "روشن کن")
        self.assertEqual(v["command_off"], "خاموش کن")
        self.assertIsNone(self.db.get_user_step(OWNER))
        rt = main.UserBotRuntime(bot_id, "TESTTOKEN", self.db_path)
        rt.api = FakeAPI()
        self.add_user(bot_id, 1001, "pv")
        rt.handle_message({"message_id": 3, "chat": {"id": 1001, "type": "group"},
                           "from": {"id": ADMIN_USER, "first_name": "ادمین"}, "text": "روشن کن"})
        st = self.db.get_var_state(bot_id, 1001, "myvar")
        # دامنه پیشفرض both ولی ادمین بودن بررسی میشود؛ در گروه ادمین است → فعال
        self.assertIsNotNone(st)
        self.assertEqual(st["is_active"], 1)

    def test_25_group_rules_variable(self):
        bot_id = self.create_bot()
        self.db.set_user_step(OWNER, "await_group_rules", {"bot_id": bot_id})
        self.builder.handle_message({"chat": {"id": OWNER}, "from": {"id": OWNER},
                                     "message_id": 1, "text": "احترام به یکدیگر الزامی است"})
        s = self.db.fetchone("SELECT group_config FROM bot_settings WHERE bot_id=?", (bot_id,))
        self.assertIn("احترام", s["group_config"])
        rt = main.UserBotRuntime(bot_id, "TESTTOKEN", self.db_path)
        rt.api = FakeAPI()
        v = rt._get_all_variables(GROUP_ID, {"id": 1001}, {"type": "group", "id": GROUP_ID})
        self.assertIn("احترام", v["RULES"])
