# -*- coding: utf-8 -*-
"""تستهای آفلاین سورس جداگانه «سلف تبلیغگر اکانت» (بدون نصب SDK)."""
import asyncio
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
_candidates = [HERE.parent, ROOT / "self_ad_bot", HERE]
SELF_DIR = next((p for p in _candidates if (p / "core.py").exists()), ROOT / "self_ad_bot")
sys.path.insert(0, str(SELF_DIR))

_SELF_AVAILABLE = (SELF_DIR / "core.py").exists() and (SELF_DIR / "main.py").exists()
if _SELF_AVAILABLE:
    import config  # noqa: E402
    import core  # noqa: E402
    # نام ماژول «main» ممکن است با main.py رباتساز (همان فرایند تست) تداخل کند؛
    # بنابراین با نام یکتا و از مسیر فایل بارگذاری میشود.
    import importlib.util  # noqa: E402
    _spec = importlib.util.spec_from_file_location("self_ad_bot_main", SELF_DIR / "main.py")
    self_main = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(self_main)
else:
    # وقتی فقط ZIP رباتساز استخراج شده، سورس سلف در SelfAdBot-FVG.zip جداگانه است
    config = core = self_main = None


class FakeChatType:
    PRIVATE = 1
    GROUP = 2


class FakeClient:
    def __init__(self):
        self.contacts = []
        self.messages = []
        self.gifts = []
        self.preview = None

    async def add_contact(self, user_id=None):
        self.contacts.append(user_id)
        return {"ok": True}

    async def send_message(self, text=None, chat_id=None, chat_type=None):
        self.messages.append((chat_id, chat_type, text))
        return {"ok": True}

    async def send_gift(self, **kw):
        self.gifts.append(kw)
        return {"ok": True}

    async def get_group_preview(self, link):
        return self.preview

    async def join_chat(self, link):
        return {"ok": True}

    async def get_me(self):
        return type("Me", (), {"id": 999})()


class FakeMsg:
    def __init__(self, chat_id=100, sender_id=55, mid=1, text="سلام"):
        self.chat = type("Chat", (), {"id": chat_id, "type": FakeChatType.GROUP})()
        self.sender_id = sender_id
        self.message_id = mid
        self.text = text
        self.client = None


def new_engine(tmp, **overrides):
    p = Path(tmp) / "panel.json"
    e = core.SelfAdEngine(p, chat_type=FakeChatType, banner_default="بنر تست")
    e.data.update(overrides)
    return e


class TestParsers(unittest.TestCase):
    def test_01_persian_numbers_and_parentheses(self):
        self.assertEqual(core.to_english_numbers("۱۲۳٤۵"), "12345")
        self.assertEqual(core.parse_int("ارسال پاکت (۵۰۰۰)"), 5000)
        self.assertEqual(core.parse_command("تنظیم بنر (سلام دنیا)", "تنظیم بنر"), "سلام دنیا")
        self.assertEqual(core.parse_command("تنظیم بنر سلام دنیا", "تنظیم بنر"), "سلام دنیا")

    def test_02_interval_units(self):
        self.assertEqual(core.parse_minutes("تنظیم تایم ارسال (1 دقیقه)"), 1)
        self.assertEqual(core.parse_minutes("(۵ دقیقه)"), 5)
        self.assertEqual(core.parse_minutes("1 ساعت"), 60)
        self.assertEqual(core.parse_minutes("30 ثانیه"), 1)

    def test_03_phone(self):
        self.assertEqual(core.valid_phone("۰۹۱۲۳۴۵۶۷۸۹"), "9123456789")
        self.assertEqual(core.valid_phone("989123456789"), "989123456789")
        self.assertIsNone(core.valid_phone("abc"))


class TestEngine(unittest.TestCase):
    def test_04_atomic_config_and_groups(self):
        with tempfile.TemporaryDirectory() as tmp:
            e = new_engine(tmp)
            e.set_banner("تبلیغ شماره ۱")
            e.add_group(-1001, "https://ble.ai/join/ABC", "گروه تست")
            e.add_group(-1002, "https://ble.ai/join/DEF", "گروه دوم")
            e.set_active_group(-1002)
            e.set_interval(1)
            self.assertEqual(len(e.target_groups()), 1)
            self.assertEqual(e.target_groups()[0]["id"], "-1002")
            self.assertTrue(e.is_target(-1002))
            self.assertFalse(e.is_target(-9999))
            e2 = core.SelfAdEngine(Path(tmp) / "panel.json", chat_type=FakeChatType)
            self.assertEqual(e2.banner, "تبلیغ شماره ۱")
            self.assertEqual(e2.interval_seconds, 60)
            raw = json.loads((Path(tmp) / "panel.json").read_text(encoding="utf-8"))
            self.assertEqual(len(raw["groups"]), 2)
            e.remove_group(-1002)
            self.assertEqual(e.data["groups"][0]["id"], "-1001")

    def test_05_auto_contact_and_pv_on_any_group_message(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp:
                e = new_engine(tmp, enabled=True)
                e.add_group(-1001, "", "target")
                cli = FakeClient()
                msg = FakeMsg(chat_id=-1001, sender_id=777, mid=10)
                ok = await e.on_group_message(cli, msg, "s1")
                self.assertTrue(ok)
                self.assertEqual(cli.contacts, [777])
                self.assertEqual(cli.messages[0][0], 777)
                self.assertEqual(cli.messages[0][1], FakeChatType.PRIVATE)
                self.assertEqual(cli.messages[0][2], "بنر تست")
                # کولداون: همان کاربر دوباره پاسخ نمیگیرد
                msg2 = FakeMsg(chat_id=-1001, sender_id=777, mid=11)
                self.assertFalse(await e.on_group_message(cli, msg2, "s1"))
                # پیام تکراری (همان message_id) دوباره پاسخ نمیگیرد
                self.assertFalse(await e.on_group_message(cli, FakeMsg(-1001, 888, 10), "s1"))
                # گروه غیرهدف → هیچ اقدامی
                self.assertFalse(await e.on_group_message(cli, FakeMsg(-9999, 999, 12), "s1"))
                # پیام خود سلف → هیچ اقدامی
                self.assertFalse(await e.on_group_message(cli, FakeMsg(-1001, 555, 13), "s1", [555]))
                # غیرفعال → هیچ اقدامی
                e.set_enabled(False)
                self.assertFalse(await e.on_group_message(cli, FakeMsg(-1001, 321, 14), "s1"))
                self.assertEqual(e.data["stats"]["auto_replies"], 1)
        asyncio.run(run())

    def test_06_group_ad_and_packet(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp:
                e = new_engine(tmp, enabled=True)
                e.add_group(-1001, "", "target")
                cli = FakeClient()
                self.assertEqual(await e.advertise(cli), 1)
                self.assertEqual(cli.messages[0][0], -1001)
                self.assertEqual(cli.messages[0][1], FakeChatType.GROUP)
                ok, info = await e.send_packet(cli, 5000)
                self.assertTrue(ok, info)
                self.assertEqual(cli.gifts[0]["amount"], 5000)
                self.assertEqual(cli.gifts[0]["chat_type"], FakeChatType.GROUP)
                ok2, _ = await e.send_packet(cli, 0)
                self.assertFalse(ok2)
        asyncio.run(run())

    def test_07_resolve_group_from_link(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp:
                e = new_engine(tmp)
                cli = FakeClient()
                cli.preview = type("P", (), {"id": 4242, "title": "گروه"})()
                gid = await e.resolve_group_id(cli, {"id": "https://ble.ai/join/X",
                                                     "link": "https://ble.ai/join/X"})
                self.assertEqual(gid, 4242)
                self.assertEqual(await e.resolve_group_id(cli, {"id": "-77"}), -77)
        asyncio.run(run())

    def test_08_cooldown_cap(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp:
                e = new_engine(tmp, enabled=True, max_pv_per_hour=2)
                cli = FakeClient()
                ok1 = await e.add_contact_and_send_pv(cli, 1, "s", force=True)
                ok2 = await e.add_contact_and_send_pv(cli, 2, "s", force=True)
                ok3 = await e.add_contact_and_send_pv(cli, 3, "s")
                self.assertTrue(ok1 and ok2)
                self.assertFalse(ok3)
        asyncio.run(run())


class DummyKeyboard:
    def __init__(self, *rows):
        self.rows = rows


class FakeReply:
    def __init__(self):
        self.sent = []

    async def reply(self, text, kb=None):
        self.sent.append(text)
        return self


class FakePanelMessage:
    def __init__(self, uid, text):
        self.author = type("A", (), {"id": uid})()
        self.text = text
        self.document = None
        self.out = []

    async def reply(self, text, kb=None):
        self.out.append(text)
        r = FakeReply()
        return r


class TestPanelAdminOnly(unittest.TestCase):
    def _app(self, tmp):
        # مقادیر ماژول را مستقیم عوض میکنیم ولی با addCleanup حتماً برمیگردانیم،
        # چون هندلرها بعد از خروج از with هم به config مراجعه میکنند.
        names = ("PANEL_FILE", "SESSIONS_DIR", "CHECK_DIR", "DATA_DIR",
                 "LOG_FILE", "MAIN_ADMIN_ID")
        orig = {n: getattr(config, n) for n in names}
        self.addCleanup(lambda: [setattr(config, n, v) for n, v in orig.items()])
        config.PANEL_FILE = Path(tmp) / "panel.json"
        config.SESSIONS_DIR = Path(tmp) / "sessions"
        config.CHECK_DIR = Path(tmp) / "check"
        config.DATA_DIR = Path(tmp) / "data"
        config.LOG_FILE = Path(tmp) / "log.txt"
        config.MAIN_ADMIN_ID = 424242
        for d in (config.SESSIONS_DIR, config.CHECK_DIR, config.DATA_DIR):
            d.mkdir(parents=True, exist_ok=True)
        sdk = (object, None, DummyKeyboard, object, object, FakeChatType, object)
        app = self_main.SelfAdApp(sdk)
        app.restart_scheduler = lambda: None
        app.start_sessions = lambda: asyncio.sleep(0)  # coroutine lambda
        return app

    def test_09_only_main_admin_gets_replies(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp:
                app = self._app(tmp)
                m = FakePanelMessage(999999, "/start")
                await app.handle(m)
                self.assertEqual(m.out, [], "غیرادمین نباید هیچ پاسخی بگیرد")
                m2 = FakePanelMessage(424242, "/start")
                await app.handle(m2)
                self.assertTrue(m2.out)
                m3 = FakePanelMessage(424242, "پیام کاملاً ناشناخته")
                await app.handle(m3)
                self.assertEqual(m3.out, [], "هیچ پیام پیشفرض/نامعتبر نباید ارسال شود")
        asyncio.run(run())

    def test_10_exact_commands(self):
        async def run():
            with tempfile.TemporaryDirectory() as tmp:
                app = self._app(tmp)
                m = FakePanelMessage(424242, "تنظیم بنر (تبلیغ ویژه)")
                await app.handle(m)
                self.assertEqual(app.engine.banner, "تبلیغ ویژه")
                m2 = FakePanelMessage(424242, "تنظیم تایم ارسال (1 دقیقه)")
                await app.handle(m2)
                self.assertEqual(app.engine.interval_seconds, 60)
                m3 = FakePanelMessage(424242, "ارسال پاکت (۵۰۰۰)")
                await app.handle(m3)
                self.assertTrue(m3.out)
                m4 = FakePanelMessage(424242, "📊 آمار")
                await app.handle(m4)
                self.assertIn("آمار سلف", m4.out[0])
        asyncio.run(run())

    def test_11_source_files_compile(self):
        import py_compile
        for f in SELF_DIR.glob("*.py"):
            py_compile.compile(str(f), doraise=True)
        self.assertTrue((SELF_DIR / "core.py").exists())


if not _SELF_AVAILABLE:
    # جلوگیری از شکستن سوئیت تست هنگام استخراج فقط ZIP رباتساز
    # (لیست صریح کلاسها، چون discovery هر TestCase موجود در namespace ماژول را میگیرد)
    for _cls in (TestParsers, TestEngine, TestPanelAdminOnly):
        _cls.__unittest_skip__ = True
        _cls.__unittest_skip_why__ = "سورس سلف فقط در SelfAdBot-FVG.zip است"
    del _cls   # discovery هر TestCase در namespace ماژول را بارگذاری میکند


if __name__ == "__main__":
    unittest.main()
