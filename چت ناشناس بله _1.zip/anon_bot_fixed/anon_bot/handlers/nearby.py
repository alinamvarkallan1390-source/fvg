from database.db import get_user, get_nearby_users, like_user, block_user, is_blocked, deduct_coins, add_coins, save_direct, get_setting
from utils.http_client import send_message, send_photo, answer_callback_query
from utils.states import set_state, update_data, STATES
from utils.helpers import format_other_profile, haversine, get_texts
from keyboards.builders import nearby_gender_inline, user_profile_view_inline, inline_kb
from utils.chat_manager import is_in_chat


async def handle_nearby(user_id: int, settings: dict):
    user = await get_user(user_id)
    if not user.get("latitude"):
        await send_message(user_id,
            "📍 <b>موقعیت مکانی ثبت نشده!</b>\n\n"
            "برای مشاهده افراد نزدیک، ابتدا موقعیت مکانی خود را در بخش پروفایل ثبت کنید.",
            inline_kb([[{"text": "📡 ثبت موقعیت", "callback_data": "edit:location"}]])
        )
        return
    await send_message(user_id,
        "📍 <b>افراد نزدیک به شما</b>\n\nکدام جنسیت را می‌خواهید ببینید؟",
        nearby_gender_inline()
    )


async def handle_nearby_callback(user_id: int, data: str, callback_id: str, settings: dict):
    from utils.http_client import answer_callback_query
    await answer_callback_query(callback_id)

    gender_map = {"girl": "دختر", "boy": "پسر"}
    gender = gender_map.get(data.split(":")[1])
    user = await get_user(user_id)

    if not user.get("latitude"):
        await send_message(user_id, "❌ موقعیت مکانی شما ثبت نشده است.")
        return

    nearby = await get_nearby_users(user["latitude"], user["longitude"],
                                     gender=gender, exclude_id=user_id, limit=20)

    if not nearby:
        emoji = "👧" if gender == "دختر" else "👦"
        await send_message(user_id,
            f"{emoji} در حال حاضر هیچ {'دختری' if gender == 'دختر' else 'پسری'} آنلاین در نزدیکی شما وجود ندارد."
        )
        return

    lines = [f"📍 <b>{'دختران' if gender == 'دختر' else 'پسران'} نزدیک به شما:</b>\n"]
    rows = []

    for u in nearby:
        dist = haversine(user["latitude"], user["longitude"],
                          u["latitude"], u["longitude"])
        if dist < 1000:
            dist_str = f"{int(dist)}m"
        else:
            dist_str = f"{dist/1000:.1f}km"

        uid = u.get("referral_code", "???")
        lines.append(
            f"• <b>{u['full_name']}</b> — {u.get('age', '؟')} ساله\n"
            f"  📏 {dist_str}  |  /user_{uid}"
        )

    await send_message(user_id, "\n".join(lines))


async def handle_view_user(user_id: int, ref_code: str, settings: dict):
    from database.db import get_user_by_referral, get_like_count
    target = await get_user_by_referral(ref_code)
    if not target:
        await send_message(user_id, "❌ کاربر مورد نظر یافت نشد.")
        return

    target_id = target["user_id"]
    if await is_blocked(target_id, user_id):
        await send_message(user_id, "❌ شما توسط این کاربر بلاک شده‌اید.")
        return

    likes = await get_like_count(target_id)
    in_chat = is_in_chat(target_id)

    user = await get_user(user_id)
    dist = None
    if user.get("latitude") and target.get("latitude"):
        dist = haversine(user["latitude"], user["longitude"],
                          target["latitude"], target["longitude"])

    text = format_other_profile(target, dist, in_chat)
    cost = int(await get_setting("cost_profile_request", "3"))
    markup = user_profile_view_inline(target_id, likes)

    if target.get("photo_file_id"):
        await send_photo(user_id, target["photo_file_id"], text, markup)
    else:
        await send_message(user_id, text, markup)


async def handle_like(user_id: int, target_id: int, callback_id: str):
    await answer_callback_query(callback_id)
    if user_id == target_id:
        await answer_callback_query(callback_id, "❌ نمی‌توانید به خودتان لایک بدهید!", True)
        return

    ok = await like_user(user_id, target_id)
    if ok:
        await answer_callback_query(callback_id, "❤️ لایک ثبت شد!", True)
        liker = await get_user(user_id)
        uid = liker.get("referral_code", "???") if liker else "???"
        target = await get_user(target_id)
        if target and not target.get("is_silent"):
            await send_message(target_id,
                f"❤️ <b>لایک جدید!</b>\n\n"
                f"کاربر /user_{uid} پروفایل شما را لایک کرد!"
            )
    else:
        await answer_callback_query(callback_id, "شما قبلاً این کاربر را لایک کرده‌اید", True)


async def handle_direct_message(user_id: int, target_id: int, callback_id: str, settings: dict):
    await answer_callback_query(callback_id)
    if await is_blocked(target_id, user_id):
        await send_message(user_id, "❌ امکان ارسال پیام دایرکت وجود ندارد.")
        return

    cost = 2
    ok = await deduct_coins(user_id, cost)
    if not ok:
        user = await get_user(user_id)
        await send_message(user_id,
            f"❌ <b>سکه کافی ندارید!</b>\n\n"
            f"ارسال پیام دایرکت: <b>{cost} سکه</b>\n"
            f"موجودی شما: <b>{user['coins']} سکه</b>"
        )
        return

    set_state(user_id, STATES["WAITING_DIRECT_MSG"], target_id=target_id)
    await send_message(user_id,
        "📨 <b>ارسال پیام دایرکت</b>\n\nپیام خود را بنویسید:",
        inline_kb([[{"text": "❌ انصراف", "callback_data": "cancel_direct"}]])
    )


async def handle_send_direct(user_id: int, text: str, settings: dict):
    from utils.states import get_data_key
    target_id = get_data_key(user_id, "target_id")
    if not target_id:
        return

    dm_id = await save_direct(user_id, target_id, text)
    sender = await get_user(user_id)
    uid = sender.get("referral_code", "???") if sender else "???"

    from keyboards.builders import direct_msg_inline
    target = await get_user(target_id)
    if target and not target.get("is_silent"):
        await send_message(target_id,
            f"📨 <b>پیام دایرکت جدید!</b>\n\n"
            f"از: /user_{uid}\n\n"
            f"『 {text} 』",
            direct_msg_inline(user_id, dm_id)
        )

    from utils.states import clear_state
    clear_state(user_id)
    await send_message(user_id, "✅ <b>پیام دایرکت ارسال شد!</b>")


async def handle_reply_direct(user_id: int, dm_id: int, target_id: int, callback_id: str):
    await answer_callback_query(callback_id)
    set_state(user_id, STATES["WAITING_DIRECT_MSG"], target_id=target_id, is_reply=True)
    await send_message(user_id,
        "↩️ <b>پاسخ به پیام دایرکت</b>\n\nپاسخ خود را بنویسید (رایگان):",
        inline_kb([[{"text": "❌ انصراف", "callback_data": "cancel_direct"}]])
    )
