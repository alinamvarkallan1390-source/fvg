import time
from database.db import (
    get_user, get_coins, deduct_coins, get_coin_packages,
    get_discount_code, create_order, update_order, get_order, get_setting,
)
from utils.http_client import send_message, answer_callback_query
from utils.states import set_state, clear_state, update_data, get_data_key, STATES
from keyboards.builders import coins_inline, payment_inline, back_keyboard
from config import BOT_USERNAME


async def handle_coins(user_id: int, settings: dict):
    coins    = await get_coins(user_id)
    packages = await get_coin_packages()
    text = (
        "🪙 <b>کیف سکه شما</b>\n\n"
        f"💰 موجودی فعلی: <b>{coins:,} سکه</b>\n\n"
        "برای افزایش سکه، یک بسته انتخاب کنید 👇"
    )
    await send_message(user_id, text, coins_inline(packages, settings))


async def handle_buy_package(user_id: int, package_id: int, cb_id: str, settings: dict):
    await answer_callback_query(cb_id)
    packages = await get_coin_packages()
    pkg = next((p for p in packages if p["id"] == package_id), None)
    if not pkg:
        await send_message(user_id, "❌ بسته مورد نظر یافت نشد.")
        return

    cards_raw = await get_setting("card_numbers", "")
    cards = []
    for line in (cards_raw or "").split("\n"):
        parts = line.strip().split("|")
        if len(parts) == 2:
            cards.append({"number": parts[0].strip(), "name": parts[1].strip()})

    if not cards:
        await send_message(user_id,
            "❌ در حال حاضر امکان خرید وجود ندارد.\nلطفاً بعداً امتحان کنید.")
        return

    card     = cards[0]
    order_id = await create_order(
        user_id, package_id, pkg["coins"], pkg["price"],
        None, 0, pkg["price"]
    )
    set_state(user_id, "order_pending",
              order_id=order_id, pkg_coins=pkg["coins"],
              amount=pkg["price"], final_amount=pkg["price"],
              card=card["number"], discount_applied=False)

    text = (
        f"💳 <b>پرداخت بسته سکه</b>\n\n"
        f"📦 بسته: <b>{pkg['title']}</b>\n"
        f"🪙 سکه: <b>{pkg['coins']:,} عدد</b>\n"
        f"💵 مبلغ: <b>{pkg['price']:,} تومان</b>\n\n"
        f"🏦 شماره کارت:\n<code>{card['number']}</code>\n"
        f"👤 به نام: <b>{card['name']}</b>\n\n"
        "پس از واریز، رسید را ارسال کنید 👇"
    )
    await send_message(user_id, text,
                       payment_inline(order_id, pkg["price"], card["number"]))


async def handle_apply_discount(user_id: int, order_id: int, cb_id: str):
    await answer_callback_query(cb_id)
    set_state(user_id, STATES["WAITING_DISCOUNT_CODE"], pending_order_id=order_id,
              order_id=get_data_key(user_id, "order_id") or order_id,
              amount=get_data_key(user_id, "amount"),
              card=get_data_key(user_id, "card"))
    await send_message(user_id,
        "🏷️ <b>کد تخفیف</b>\n\nکد تخفیف خود را وارد کنید:",
        back_keyboard(),
    )


async def handle_discount_code_input(user_id: int, code: str, settings: dict):
    order_id = get_data_key(user_id, "pending_order_id") or get_data_key(user_id, "order_id")
    if not order_id:
        clear_state(user_id)
        return

    order = await get_order(order_id)
    if not order:
        clear_state(user_id)
        return

    discount = await get_discount_code(code)
    if not discount:
        await send_message(user_id, "❌ کد تخفیف نامعتبر است.")
        return

    if discount["max_uses"] != -1 and discount["used_count"] >= discount["max_uses"]:
        await send_message(user_id, "❌ ظرفیت این کد تمام شده است.")
        return

    if time.time() > discount["created_at"] + discount["expires_days"] * 86400:
        await send_message(user_id, "❌ کد تخفیف منقضی شده است.")
        return

    percent  = discount["percent"]
    original = order["amount"]
    final    = int(original * (1 - percent / 100))

    await update_order(order_id,
                       discount_code=code,
                       discount_percent=percent,
                       final_amount=final)
    set_state(user_id, "order_pending",
              order_id=order_id,
              amount=original, final_amount=final,
              card=get_data_key(user_id, "card") or "",
              discount_applied=True)

    card = get_data_key(user_id, "card") or ""
    await send_message(user_id,
        f"✅ <b>کد تخفیف اعمال شد!</b>\n\n"
        f"🏷️ تخفیف: <b>{percent}%</b>\n"
        f"💵 مبلغ اصلی: <del>{original:,}</del> تومان\n"
        f"💵 مبلغ نهایی: <b>{final:,} تومان</b>",
        payment_inline(order_id, final, card, discount_applied=True),
    )


async def handle_confirm_payment(user_id: int, order_id: int, cb_id: str):
    await answer_callback_query(cb_id)
    set_state(user_id, STATES["WAITING_RECEIPT"], order_id=order_id)
    await send_message(user_id,
        "📸 <b>ارسال رسید</b>\n\nتصویر رسید پرداخت را ارسال کنید:",
        back_keyboard(),
    )


async def handle_receipt_photo(user_id: int, msg: dict, settings: dict):
    order_id = get_data_key(user_id, "order_id")
    photo    = msg.get("photo")
    if not photo:
        await send_message(user_id, "⚠️ لطفاً تصویر رسید را ارسال کنید.")
        return
    file_id = photo[-1]["file_id"]
    await update_order(order_id, receipt_file_id=file_id)
    set_state(user_id, STATES["WAITING_TRACKING"],
              order_id=order_id, receipt_file_id=file_id)
    await send_message(user_id,
        "✅ رسید دریافت شد!\n\n🔢 کد پیگیری روی رسید را وارد کنید:",
        back_keyboard(),
    )


async def handle_tracking_code(user_id: int, text: str, settings: dict):
    order_id = get_data_key(user_id, "order_id")
    await update_order(order_id, tracking_code=text)
    set_state(user_id, STATES["WAITING_TX_TIME"],
              order_id=order_id,
              receipt_file_id=get_data_key(user_id, "receipt_file_id"))
    await send_message(user_id,
        "⏰ ساعت دقیق تراکنش را وارد کنید (مثلاً ۱۴:۳۵):",
        back_keyboard(),
    )


async def handle_tx_time(user_id: int, text: str, settings: dict):
    from config import ADMIN_IDS
    from database.db import get_admins, get_user as _gu
    from utils.http_client import send_photo as _sp
    from keyboards.builders import order_admin_inline

    order_id        = get_data_key(user_id, "order_id")
    receipt_file_id = get_data_key(user_id, "receipt_file_id")
    await update_order(order_id, transaction_time=text)
    clear_state(user_id)

    order = await get_order(order_id)
    user  = await _gu(user_id)
    if not order or not user:
        return

    uname     = f"@{user['username']}" if user.get("username") else user.get("full_name", "ناشناس")
    disc_line = ""
    if order.get("discount_code"):
        disc_line = (
            f"\n🏷️ کد تخفیف: {order['discount_code']} ({order['discount_percent']}%)"
            f"\n💵 مبلغ نهایی: {order['final_amount']:,} تومان"
        )

    caption = (
        f"🔔 <b>سفارش جدید #{order_id}</b>\n\n"
        f"💵 مبلغ: {order['amount']:,} تومان\n"
        f"🪙 سکه: {order['coins']:,} عدد\n"
        f"👤 کاربر: {uname}\n"
        f"🆔 آیدی: {user['user_id']}\n"
        f"🔢 کد پیگیری: {order['tracking_code']}\n"
        f"⏰ ساعت: {text}"
        + disc_line
    )

    admins     = await get_admins()
    all_admins = list(set(ADMIN_IDS + admins))
    for admin_id in all_admins:
        try:
            await _sp(admin_id, receipt_file_id, caption, order_admin_inline(order_id))
        except Exception:
            pass

    await send_message(user_id,
        "✅ <b>سفارش شما ثبت شد!</b>\n\n"
        "⏳ تیم پشتیبانی در اسرع وقت بررسی می‌کند.\n"
        "🔔 پس از تأیید، سکه‌ها واریز می‌شوند.")


async def handle_free_coins(user_id: int, settings: dict):
    from database.db import get_user as _gu
    user     = await _gu(user_id)
    ref_code = user.get("referral_code", "") if user else ""
    bot_user = BOT_USERNAME.lstrip("@")
    link     = f"https://ble.ir/{bot_user}?start=ref_{ref_code}"

    await send_message(user_id,
        "🎯 <b>حوصلت سر رفته؟</b>\n\n"
        "بیا اینجا با افراد جدید آشنا بشی و لحظه‌های خوب بسازی! 💫\n\n"
        f"🔗 لینک ورود:\n{link}"
    )
    await send_message(user_id,
        f"🔗 <b>لینک اختصاصی شما:</b>\n\n"
        f"<code>{link}</code>\n\n"
        "👥 با دعوت دوستان سکه رایگان بگیرید!\n"
        "🪙 به ازای هر دعوت موفق سکه به حسابتان واریز می‌شود."
    )
