import asyncio
import time
from database.db import (
    get_user, update_user, get_all_settings, get_admins,
    is_blocked, block_user,
)
from utils.http_client import send_message, answer_callback_query
from utils.states import get_state, get_data_key, clear_state, set_state, STATES
from utils.chat_manager import is_in_chat, get_partner, remove_from_all_queues
from keyboards.builders import main_keyboard, back_keyboard, inline_kb, leave_confirm_inline
from config import ADMIN_IDS, DEFAULT_TEXTS
from handlers.admin import ADMIN_TEXT_STATES, _is_admin


async def _settings() -> dict:
    return await get_all_settings()


async def _main_kb(user_id: int, settings: dict) -> dict:
    admins    = await get_admins()
    all_admins = list(set(ADMIN_IDS + admins))
    return main_keyboard(user_id in all_admins, settings)


def _txt(settings: dict, key: str) -> str:
    return settings.get(key) or DEFAULT_TEXTS.get(key, key)


async def dispatch_message(msg: dict):
    if not msg:
        return

    user_id = msg.get("from", {}).get("id")
    if not user_id:
        return

    text     = msg.get("text", "") or ""
    settings = await _settings()

    user = await get_user(user_id)
    if not user:
        from handlers.start import handle_start
        await handle_start({"message": msg}, settings)
        return

    if user.get("is_banned"):
        await send_message(user_id, "⛔️ حساب شما مسدود شده است.")
        return

    await update_user(user_id, last_seen=int(time.time()), is_online=1)

    from handlers.start import check_channels, send_join_required
    joined, not_joined = await check_channels(user_id)
    if not joined:
        await send_join_required(user_id, not_joined, settings)
        return

    state = get_state(user_id)

    if text == "/exit" or text == "🔙 بازگشت به منو":
        if is_in_chat(user_id):
            pass
        else:
            remove_from_all_queues(user_id)
            clear_state(user_id)
            await send_message(user_id, "🏠 منوی اصلی:", await _main_kb(user_id, settings))
            return

    if text.startswith("/start"):
        from handlers.start import handle_start
        await handle_start({"message": msg}, settings)
        return

    if text == "/silent":
        new_val = 0 if user.get("is_silent") else 1
        await update_user(user_id, is_silent=new_val)
        await send_message(user_id,
            f"🔔 حالت سایلنت: <b>{'فعال ✅' if new_val else 'غیرفعال ❌'}</b>")
        return

    if text == "/delete_account":
        set_state(user_id, "confirm_delete")
        await send_message(user_id,
            "⚠️ <b>حذف اکانت</b>\n\nآیا مطمئن هستید؟",
            inline_kb([[
                {"text": "✅ بله، حذف شود", "callback_data": "del_acc:yes"},
                {"text": "❌ خیر",           "callback_data": "del_acc:no"},
            ]]))
        return

    if text.startswith("/user_"):
        ref_code = text.replace("/user_", "").strip()
        from handlers.nearby import handle_view_user
        await handle_view_user(user_id, ref_code, settings)
        return

    if text.startswith("/anon_msg_"):
        try:
            msg_id = int(text.replace("/anon_msg_", "").strip())
        except ValueError:
            return
        from database.db import get_anon_message
        m = await get_anon_message(msg_id)
        if m and m["owner_id"] == user_id:
            set_state(user_id, STATES["WAITING_ANON_REPLY"], anon_msg_id=msg_id)
            await send_message(user_id, "↩️ پاسخ را بنویسید:", back_keyboard())
        return

    if text.startswith("/addadmin ") and await _is_admin(user_id):
        parts = text.split()
        if len(parts) == 2 and parts[1].isdigit():
            from database.db import add_admin
            await add_admin(int(parts[1]))
            await send_message(user_id, f"✅ ادمین {parts[1]} اضافه شد.")
        return

    if text.startswith("/removeadmin ") and await _is_admin(user_id):
        parts = text.split()
        if len(parts) == 2 and parts[1].isdigit():
            from database.db import remove_admin
            await remove_admin(int(parts[1]))
            await send_message(user_id, f"✅ ادمین {parts[1]} حذف شد.")
        return

    if text.startswith("/ban ") and await _is_admin(user_id):
        parts = text.split()
        if len(parts) == 2 and parts[1].isdigit():
            await update_user(int(parts[1]), is_banned=1)
            await send_message(user_id, f"✅ کاربر {parts[1]} بن شد.")
        return

    if text.startswith("/unban ") and await _is_admin(user_id):
        parts = text.split()
        if len(parts) == 2 and parts[1].isdigit():
            await update_user(int(parts[1]), is_banned=0)
            await send_message(user_id, f"✅ بن کاربر {parts[1]} برداشته شد.")
        return

    btn_connect   = _txt(settings, "btn_connect")
    btn_nearby    = _txt(settings, "btn_nearby")
    btn_guide     = _txt(settings, "btn_guide")
    btn_profile   = _txt(settings, "btn_profile")
    btn_coins     = _txt(settings, "btn_coins")
    btn_anon_link = _txt(settings, "btn_anon_link")
    btn_referral  = _txt(settings, "btn_referral")
    btn_admin     = _txt(settings, "btn_admin")
    btn_vc        = _txt(settings, "btn_view_chat_profile")
    btn_lc        = _txt(settings, "btn_leave_chat")

    if is_in_chat(user_id):
        if text == btn_vc:
            from handlers.chat import handle_view_partner_profile
            await handle_view_partner_profile(user_id, "", settings)
            return
        if text == btn_lc:
            await send_message(user_id,
                "🚪 <b>ترک چت</b>\n\nآیا مطمئن هستید؟",
                leave_confirm_inline())
            return
        from handlers.chat import handle_chat_message
        await handle_chat_message(user_id, msg, settings)
        return

    if text in (btn_vc, btn_lc):
        await send_message(user_id, "⚠️ شما در حال چت نیستید!")
        return

    if text == btn_connect:
        from handlers.chat import handle_connect
        await handle_connect(user_id, settings)
        return

    if text == btn_nearby:
        from handlers.nearby import handle_nearby
        await handle_nearby(user_id, settings)
        return

    if text == btn_guide:
        await _send_guide(user_id)
        return

    if text == btn_profile:
        from handlers.profile import show_profile
        await show_profile(user_id, settings)
        return

    if text == btn_coins:
        from handlers.coins import handle_coins
        await handle_coins(user_id, settings)
        return

    if text == btn_anon_link:
        from handlers.anon_link import handle_anon_link_menu
        await handle_anon_link_menu(user_id, settings)
        return

    if text == btn_referral:
        from handlers.coins import handle_free_coins
        await handle_free_coins(user_id, settings)
        return

    if text == btn_admin and await _is_admin(user_id):
        from handlers.admin import handle_admin_panel
        await handle_admin_panel(user_id, settings)
        return

    if await _is_admin(user_id):
        from handlers.admin import handle_admin_keyboard_text
        if await handle_admin_keyboard_text(user_id, text, settings):
            return
        if state in ADMIN_TEXT_STATES:
            from handlers.admin import handle_admin_message
            await handle_admin_message(user_id, msg, settings)
            return

    if state == STATES["WAITING_ANON_MSG"]:
        link_code = get_data_key(user_id, "link_code")
        from handlers.anon_link import handle_anon_message_input
        await handle_anon_message_input(user_id, msg, link_code, settings)
        return

    if state == STATES["WAITING_ANON_REPLY"]:
        from handlers.anon_link import handle_anon_reply
        await handle_anon_reply(user_id, text, settings)
        return

    if state == STATES["WAITING_DIRECT_MSG"]:
        from handlers.nearby import handle_send_direct
        await handle_send_direct(user_id, text, settings)
        return

    if state == STATES["WAITING_DISCOUNT_CODE"]:
        from handlers.coins import handle_discount_code_input
        await handle_discount_code_input(user_id, text, settings)
        return

    if state == STATES["WAITING_RECEIPT"]:
        from handlers.coins import handle_receipt_photo
        await handle_receipt_photo(user_id, msg, settings)
        return

    if state == STATES["WAITING_TRACKING"]:
        from handlers.coins import handle_tracking_code
        await handle_tracking_code(user_id, text, settings)
        return

    if state == STATES["WAITING_TX_TIME"]:
        from handlers.coins import handle_tx_time
        await handle_tx_time(user_id, text, settings)
        return

    if state in {STATES["WAITING_NAME"], STATES["WAITING_AGE"],
                 STATES["WAITING_BIO"], STATES["WAITING_PHOTO"],
                 STATES["WAITING_LOCATION"]}:
        from handlers.profile import handle_edit_message
        await handle_edit_message(user_id, msg, settings)
        return


async def dispatch_callback(cb: dict):
    if not cb:
        return

    user_id  = cb.get("from", {}).get("id")
    data     = cb.get("data", "")
    cb_id    = cb.get("id", "")
    msg      = cb.get("message", {})
    msg_id   = msg.get("message_id", 0)
    settings = await _settings()

    if not user_id:
        return

    user = await get_user(user_id)
    if not user:
        await answer_callback_query(cb_id, "⚠️ ابتدا /start بزنید", True)
        return

    if user.get("is_banned"):
        await answer_callback_query(cb_id, "⛔️ حساب شما مسدود است", True)
        return

    await update_user(user_id, last_seen=int(time.time()), is_online=1)

    if data == "noop":
        await answer_callback_query(cb_id)
        return

    if data == "verify_join":
        from handlers.start import handle_verify_join
        await handle_verify_join(user_id, cb_id, settings)
        return

    if data.startswith("del_acc:"):
        await answer_callback_query(cb_id)
        if data.endswith("yes"):
            await update_user(user_id, is_banned=1)
            await send_message(user_id, "✅ اکانت شما حذف شد.")
        else:
            clear_state(user_id)
            await send_message(user_id, "❌ لغو شد.",
                               await _main_kb(user_id, settings))
        return

    if data.startswith("search:"):
        from handlers.chat import handle_search_callback
        await handle_search_callback(user_id, data, cb_id, settings)
        return

    if data == "cancel_search":
        await answer_callback_query(cb_id)
        remove_from_all_queues(user_id)
        clear_state(user_id)
        await send_message(user_id, "❌ جستجو لغو شد.",
                           await _main_kb(user_id, settings))
        return

    if data.startswith("leave:"):
        from handlers.chat import handle_leave_confirm
        await handle_leave_confirm(user_id, data, cb_id, settings)
        return

    if data.startswith("profile:") or data.startswith("unblock:"):
        from handlers.profile import handle_profile_callback
        await handle_profile_callback(user_id, data, cb_id, msg_id, settings)
        return

    if data.startswith("edit:") or data.startswith("set_gender:") or data.startswith("set_province:"):
        from handlers.profile import handle_edit_callback
        await handle_edit_callback(user_id, data, cb_id, msg_id, settings)
        return

    if data in ("cancel", "cancel_edit"):
        await answer_callback_query(cb_id)
        clear_state(user_id)
        await send_message(user_id, "❌ لغو شد.",
                           await _main_kb(user_id, settings))
        return

    if data.startswith("buy:"):
        pkg_id = int(data.split(":")[1])
        from handlers.coins import handle_buy_package
        await handle_buy_package(user_id, pkg_id, cb_id, settings)
        return

    if data == "coins:free":
        await answer_callback_query(cb_id)
        from handlers.coins import handle_free_coins
        await handle_free_coins(user_id, settings)
        return

    if data.startswith("discount:"):
        order_id = int(data.split(":")[1])
        from handlers.coins import handle_apply_discount
        await handle_apply_discount(user_id, order_id, cb_id)
        return

    if data.startswith("confirm_pay:"):
        order_id = int(data.split(":")[1])
        from handlers.coins import handle_confirm_payment
        await handle_confirm_payment(user_id, order_id, cb_id)
        return

    if data.startswith("copy_amount:"):
        await answer_callback_query(cb_id, f"مبلغ: {data.split(':')[1]} تومان", True)
        return

    if data.startswith("copy_card:"):
        await answer_callback_query(cb_id, f"کارت: {data.split(':')[1]}", True)
        return

    if data.startswith("nearby:"):
        from handlers.nearby import handle_nearby_callback
        await handle_nearby_callback(user_id, data, cb_id, settings)
        return

    if data.startswith("like:"):
        target_id = int(data.split(":")[1])
        from handlers.nearby import handle_like
        await handle_like(user_id, target_id, cb_id)
        return

    if data.startswith("block:"):
        target_id = int(data.split(":")[1])
        await answer_callback_query(cb_id)
        await block_user(user_id, target_id)
        await send_message(user_id, "🚫 کاربر بلاک شد.")
        return

    if data.startswith("direct:"):
        target_id = int(data.split(":")[1])
        from handlers.nearby import handle_direct_message
        await handle_direct_message(user_id, target_id, cb_id, settings)
        return

    if data == "cancel_direct":
        await answer_callback_query(cb_id)
        clear_state(user_id)
        await send_message(user_id, "❌ لغو شد.")
        return

    if data.startswith("reply_dm:"):
        parts     = data.split(":")
        dm_id     = int(parts[1])
        target_id = int(parts[2])
        from handlers.nearby import handle_reply_direct
        await handle_reply_direct(user_id, dm_id, target_id, cb_id)
        return

    if data.startswith("chat_req:"):
        target_id = int(data.split(":")[1])
        from handlers.chat import handle_chat_request
        await handle_chat_request(user_id, target_id, cb_id, settings)
        return

    if data.startswith("accept_chat:"):
        from_id = int(data.split(":")[1])
        from handlers.chat import handle_accept_chat
        await handle_accept_chat(user_id, from_id, cb_id, settings)
        return

    if data.startswith("reject_chat:"):
        from_id = int(data.split(":")[1])
        from handlers.chat import handle_reject_chat
        await handle_reject_chat(user_id, from_id, cb_id, settings)
        return

    if data.startswith("anon:") or data.startswith("anon_reply:") or data.startswith("anon_block:"):
        from handlers.anon_link import handle_anon_callback
        await handle_anon_callback(user_id, data, cb_id, settings)
        return

    if data in ("cancel_anon", "cancel_anon_reply"):
        await answer_callback_query(cb_id)
        clear_state(user_id)
        await send_message(user_id, "❌ لغو شد.",
                           await _main_kb(user_id, settings))
        return

    if data.startswith("ord_ok:") or data.startswith("ord_rej:") or data.startswith("ord_custom:"):
        from handlers.admin import handle_order_action
        await handle_order_action(user_id, data, cb_id, msg_id, settings)
        return

    if data.startswith("bc:"):
        from handlers.admin import handle_broadcast_callback
        await handle_broadcast_callback(user_id, data, cb_id, msg_id, settings)
        return

    if data.startswith("del_ch:"):
        ch_id = int(data.split(":")[1])
        from handlers.admin import handle_del_channel
        await handle_del_channel(user_id, ch_id, cb_id, msg_id)
        return

    if data.startswith("del_pkg:"):
        pkg_id = int(data.split(":")[1])
        await answer_callback_query(cb_id)
        import aiosqlite
        from config import DB_PATH
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE coin_packages SET is_active=0 WHERE id=?", (pkg_id,))
            await db.commit()
        await send_message(user_id, "✅ بسته حذف شد.")
        return

    if data.startswith("edit_btn:"):
        key = data.split(":", 1)[1]
        from handlers.admin import handle_edit_btn_callback
        await handle_edit_btn_callback(user_id, key, cb_id, msg_id, settings)
        return

    if data.startswith("del_admin:"):
        uid_to_del = int(data.split(":")[1])
        await answer_callback_query(cb_id)
        from database.db import remove_admin
        await remove_admin(uid_to_del)
        await send_message(user_id, f"✅ ادمین {uid_to_del} حذف شد.")
        return

    if data == "add_card" or data.startswith("del_card:"):
        from handlers.admin import handle_card_callback
        await handle_card_callback(user_id, data, cb_id, msg_id)
        return

    if data == "admin_cancel":
        await answer_callback_query(cb_id)
        clear_state(user_id)
        await send_message(user_id, "❌ لغو شد.")
        return

    await answer_callback_query(cb_id)


async def _send_guide(user_id: int):
    await send_message(user_id,
        "🤔 <b>راهنمای ربات</b>\n\n"
        "🔗 <b>وصل شدن به ناشناس:</b> چت کاملاً ناشناس\n\n"
        "📍 <b>افراد نزدیک:</b> کاربران آنلاین در نزدیکی شما\n\n"
        "👤 <b>پروفایل:</b> مشاهده و ویرایش اطلاعات\n\n"
        "💰 <b>سکه:</b> برای چت با جنسیت، درخواست چت، دایرکت و لینک ناشناس\n\n"
        "📩 <b>لینک ناشناس:</b> دریافت پیام ناشناس از دیگران\n\n"
        "🚶 <b>معرفی به دوستان:</b> سکه رایگان با دعوت دوستان\n\n"
        "💡 <b>در حین چت:</b>\n"
        "• عکس، فایل، صوت و استیکر ارسال کنید\n"
        "• «مشاهده پروفایل مخاطب» اطلاعات طرف مقابل را نشان می‌دهد\n"
        "• «ترک چت» برای پایان مکالمه\n"
        "• /exit برای خروج از هر مرحله‌ای"
    )
