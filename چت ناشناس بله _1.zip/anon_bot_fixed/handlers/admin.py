import time
import asyncio
import aiosqlite
from config import ADMIN_IDS, DB_PATH, DEFAULT_TEXTS
from database.db import (
    get_total_stats, get_all_users_ids, get_pending_orders, get_order,
    update_order, add_coins, get_setting, set_setting, get_admins,
    remove_admin, get_active_channels, get_coin_packages, get_user,
)
from utils.http_client import (
    send_message, send_photo, send_document,
    answer_callback_query, delete_message,
)
from utils.states import set_state, clear_state, get_data_key, update_data, get_state, STATES
from keyboards.builders import (
    order_admin_inline, inline_kb, broadcast_btn_inline,
    btn_list_inline, admin_main_keyboard, back_keyboard,
)

ADM_KEYBOARD_BTNS = {
    "📊 آمار آنلاین", "📣 پیام همگانی",
    "➕ افزودن کانال اجباری", "➖ حذف کانال اجباری",
    "⬇️ دانلود دیتابیس", "⬆️ آپلود دیتابیس",
    "👥 مدیریت ادمین‌ها", "🎁 هدیه زیرمجموعه‌گیری",
    "🏆 جایزه تکمیل پروفایل", "📦 افزودن بسته سکه",
    "🗑️ حذف بسته سکه", "💳 مدیریت شماره کارت‌ها",
    "⏳ پرداخت‌های تاییدنشده", "🪙 سکه همگانی",
    "🪙 سکه با آیدی", "🏷️ افزودن کد تخفیف",
    "✏️ تغییر متن دکمه‌ها", "💬 هزینه چت تصادفی",
    "💬 هزینه چت جنسیت", "💬 هزینه درخواست پروفایل",
    "🔗 هزینه لینک ناشناس",
}

ADMIN_TEXT_STATES = {
    STATES["WAITING_BROADCAST"],
    STATES["WAITING_BROADCAST_BTN_TEXT"],
    STATES["WAITING_BROADCAST_BTN_URL"],
    STATES["WAITING_CHANNEL_LINK"],
    STATES["WAITING_CHANNEL_BTN"],
    STATES["WAITING_REFERRAL_REWARD"],
    STATES["WAITING_PACKAGE_TITLE"],
    STATES["WAITING_PACKAGE_COINS"],
    STATES["WAITING_PACKAGE_PRICE"],
    STATES["WAITING_PROFILE_REWARD"],
    STATES["WAITING_CARD_NUMBER"],
    STATES["WAITING_REJECT_REASON"],
    STATES["WAITING_ADMIN_COINS"],
    STATES["WAITING_COINS_USER"],
    STATES["WAITING_CHAT_COST"],
    STATES["WAITING_BTN_TEXT_VALUE"],
    STATES["ADM_REF_CH_REWARD"],
    STATES["ADM_DISC_CODE"],
    STATES["ADM_DISC_PERCENT"],
    STATES["ADM_DISC_USES"],
    STATES["ADM_DISC_DAYS"],
    STATES["WAITING_DB_UPLOAD"],
    "adm_card_action",
    "adm_card_del_num",
    "adm_card_add_num",
    "adm_card_add_name",
}


async def _is_admin(user_id: int) -> bool:
    admins = await get_admins()
    return user_id in list(set(ADMIN_IDS + admins))


async def handle_admin_panel(user_id: int, settings: dict):
    if not await _is_admin(user_id):
        return
    await send_message(user_id,
        "⚙️ <b>پنل مدیریت</b>\n\nاز منوی پایین انتخاب کنید 👇",
        admin_main_keyboard(),
    )


async def _del(chat_id: int, msg_id: int):
    """حذف پیام قبلی بدون crash."""
    try:
        await delete_message(chat_id, msg_id)
    except Exception:
        pass


async def handle_admin_keyboard_text(user_id: int, text: str, settings: dict) -> bool:
    if not await _is_admin(user_id):
        return False
    if text not in ADM_KEYBOARD_BTNS:
        return False

    if text == "📊 آمار آنلاین":
        stats = await get_total_stats()
        growth_text = ""
        for row in stats.get("growth", []):
            growth_text += f"\n📅 {row[0]}: {row[1]:,} کاربر"
        await send_message(user_id,
            "📊 <b>آمار ربات</b>\n\n"
            f"👥 کاربران کل: <b>{stats['total_users']:,}</b>\n"
            f"💬 چت‌های کل: <b>{stats['total_chats']:,}</b>\n"
            f"🔄 چت‌های فعال: <b>{stats['active_chats']:,}</b>\n"
            f"🟢 آنلاین: <b>{stats['online_users']:,}</b>\n"
            f"🪙 مجموع سکه: <b>{stats['total_coins']:,}</b>"
            + (f"\n\n📈 رشد ۳ روز:{growth_text}" if growth_text else ""),
            admin_main_keyboard(),
        )

    elif text == "📣 پیام همگانی":
        set_state(user_id, STATES["WAITING_BROADCAST"])
        await send_message(user_id,
            "📣 <b>پیام همگانی</b>\n\nمتن یا عکس (با کپشن) ارسال کنید:",
            back_keyboard(),
        )

    elif text == "➕ افزودن کانال اجباری":
        set_state(user_id, STATES["WAITING_CHANNEL_LINK"])
        await send_message(user_id,
            "➕ <b>افزودن کانال اجباری</b>\n\n"
            "۱. ربات را ادمین کانال کنید.\n"
            "۲. لینک کانال را ارسال کنید:\n\n"
            "<code>https://ble.ir/channel_id</code>",
            back_keyboard(),
        )

    elif text == "➖ حذف کانال اجباری":
        channels = await get_active_channels()
        if not channels:
            await send_message(user_id, "📭 کانالی ثبت نشده.", admin_main_keyboard())
            return True
        rows = [[{"text": f"❌ {ch['button_text']} ({ch['channel_username']})",
                  "callback_data": f"del_ch:{ch['id']}"}] for ch in channels]
        await send_message(user_id, "🗑️ کانال مورد نظر را حذف کنید:", inline_kb(rows))

    elif text == "⬇️ دانلود دیتابیس":
        try:
            import io
            with open(DB_PATH, "rb") as f:
                bio = io.BytesIO(f.read())
            bio.name = "bot.db"
            await send_document(user_id, bio, "💾 دیتابیس ربات")
        except Exception as e:
            await send_message(user_id, f"❌ خطا: {e}", admin_main_keyboard())

    elif text == "⬆️ آپلود دیتابیس":
        set_state(user_id, STATES["WAITING_DB_UPLOAD"])
        await send_message(user_id, "⬆️ فایل دیتابیس را ارسال کنید:", back_keyboard())

    elif text == "👥 مدیریت ادمین‌ها":
        admins = await get_admins()
        lines = ["👥 <b>مدیریت ادمین‌ها</b>\n"]
        rows = []
        if admins:
            lines += [f"• <code>{a}</code>" for a in admins]
            rows = [[{"text": f"❌ حذف ادمین {a}", "callback_data": f"del_admin:{a}"}]
                    for a in admins]
        else:
            lines.append("ادمینی ثبت نشده.")
        lines += ["\n➕ افزودن: <code>/addadmin ID</code>"]
        markup = inline_kb(rows) if rows else None
        await send_message(user_id, "\n".join(lines), markup or admin_main_keyboard())

    elif text == "🎁 هدیه زیرمجموعه‌گیری":
        j = await get_setting("referral_join_reward", "10")
        c = await get_setting("referral_channel_reward", "5")
        set_state(user_id, STATES["WAITING_REFERRAL_REWARD"])
        await send_message(user_id,
            f"🎁 <b>هدیه زیرمجموعه‌گیری</b>\n\n"
            f"• ورود به ربات: <b>{j} سکه</b>\n"
            f"• عضویت کانال: <b>{c} سکه</b>\n\n"
            "مقدار جدید هدیه ورود (عدد) را وارد کنید:",
            back_keyboard(),
        )

    elif text == "🏆 جایزه تکمیل پروفایل":
        cur = await get_setting("profile_reward", "5")
        set_state(user_id, STATES["WAITING_PROFILE_REWARD"])
        await send_message(user_id,
            f"🏆 جایزه فعلی: <b>{cur} سکه</b>\n\nمقدار جدید را وارد کنید:",
            back_keyboard(),
        )

    elif text == "📦 افزودن بسته سکه":
        set_state(user_id, STATES["WAITING_PACKAGE_TITLE"])
        await send_message(user_id, "📦 عنوان بسته را وارد کنید:", back_keyboard())

    elif text == "🗑️ حذف بسته سکه":
        packages = await get_coin_packages()
        if not packages:
            await send_message(user_id, "📭 بسته‌ای ثبت نشده.", admin_main_keyboard())
            return True
        rows = [[{"text": f"🗑️ {p['title']} ({p['coins']} سکه | {p['price']:,} تومن)",
                  "callback_data": f"del_pkg:{p['id']}"}] for p in packages]
        await send_message(user_id, "بسته مورد نظر را حذف کنید:", inline_kb(rows))

    elif text == "💳 مدیریت شماره کارت‌ها":
        await _show_cards(user_id)

    elif text == "⏳ پرداخت‌های تاییدنشده":
        orders = await get_pending_orders()
        if not orders:
            await send_message(user_id, "✅ هیچ سفارش تاییدنشده‌ای نیست.", admin_main_keyboard())
            return True
        await send_message(user_id, f"⏳ <b>{len(orders)} سفارش در انتظار:</b>",
                           admin_main_keyboard())
        for o in orders[:10]:
            uname = f"@{o['username']}" if o.get("username") else o.get("full_name", "ناشناس")
            disc = ""
            if o.get("discount_code"):
                disc = (f"\n🏷️ تخفیف: {o['discount_code']} ({o['discount_percent']}%)"
                        f"\n💵 نهایی: {o['final_amount']:,} تومان")
            caption = (
                f"🧾 <b>سفارش #{o['id']}</b>\n\n"
                f"💵 مبلغ: {o['amount']:,} تومان\n"
                f"🪙 سکه: {o['coins']:,}\n"
                f"👤 کاربر: {uname}\n"
                f"🆔 آیدی: {o['user_id']}\n"
                f"🔢 کد پیگیری: {o.get('tracking_code') or '---'}\n"
                f"⏰ ساعت: {o.get('transaction_time') or '---'}" + disc
            )
            if o.get("receipt_file_id"):
                await send_photo(user_id, o["receipt_file_id"], caption,
                                 order_admin_inline(o["id"]))
            else:
                await send_message(user_id, caption, order_admin_inline(o["id"]))

    elif text == "🪙 سکه همگانی":
        set_state(user_id, STATES["WAITING_ADMIN_COINS"], broadcast_all=True)
        await send_message(user_id, "🪙 تعداد سکه برای همه کاربران:", back_keyboard())

    elif text == "🪙 سکه با آیدی":
        set_state(user_id, STATES["WAITING_COINS_USER"])
        await send_message(user_id, "🆔 آیدی عددی کاربر را وارد کنید:", back_keyboard())

    elif text == "🏷️ افزودن کد تخفیف":
        set_state(user_id, STATES["ADM_DISC_CODE"])
        await send_message(user_id, "🏷️ کد تخفیف را وارد کنید (مثلاً: SUMMER20):",
                           back_keyboard())

    elif text == "✏️ تغییر متن دکمه‌ها":
        await send_message(user_id, "✏️ دکمه مورد نظر را انتخاب کنید:",
                           btn_list_inline(settings))

    elif text == "💬 هزینه چت تصادفی":
        cur = await get_setting("cost_random", "0")
        set_state(user_id, STATES["WAITING_CHAT_COST"], cost_key="cost_random")
        await send_message(user_id,
            f"💬 هزینه فعلی: <b>{cur} سکه</b>\n\nمقدار جدید (۰=رایگان):",
            back_keyboard())

    elif text == "💬 هزینه چت جنسیت":
        cur = await get_setting("cost_gender", "2")
        set_state(user_id, STATES["WAITING_CHAT_COST"], cost_key="cost_gender")
        await send_message(user_id,
            f"💬 هزینه فعلی: <b>{cur} سکه</b>\n\nمقدار جدید:", back_keyboard())

    elif text == "💬 هزینه درخواست پروفایل":
        cur = await get_setting("cost_profile_request", "3")
        set_state(user_id, STATES["WAITING_CHAT_COST"], cost_key="cost_profile_request")
        await send_message(user_id,
            f"💬 هزینه فعلی: <b>{cur} سکه</b>\n\nمقدار جدید:", back_keyboard())

    elif text == "🔗 هزینه لینک ناشناس":
        cur = await get_setting("anon_link_cost", "3")
        set_state(user_id, STATES["WAITING_CHAT_COST"], cost_key="anon_link_cost")
        await send_message(user_id,
            f"🔗 هزینه فعلی: <b>{cur} سکه</b>\n\nمقدار جدید (۰=رایگان):",
            back_keyboard())

    return True


async def _show_cards(user_id: int):
    cur = await get_setting("card_numbers", "")
    cards = []
    for line in (cur or "").split("\n"):
        parts = line.strip().split("|")
        if len(parts) == 2:
            cards.append({"number": parts[0].strip(), "name": parts[1].strip()})

    lines = ["💳 <b>مدیریت شماره کارت‌ها</b>\n"]
    rows = []
    if cards:
        for i, c in enumerate(cards):
            lines.append(f"{i+1}. <code>{c['number']}</code> — {c['name']}")
            rows.append([{"text": f"🗑️ حذف {c['number'][-4:]}",
                          "callback_data": f"del_card:{i}"}])
    else:
        lines.append("کارتی ثبت نشده.")
    rows.append([{"text": "➕ افزودن کارت جدید", "callback_data": "add_card"}])
    await send_message(user_id, "\n".join(lines), inline_kb(rows))


async def handle_order_action(user_id: int, data: str, cb_id: str,
                               msg_id: int, settings: dict):
    if not await _is_admin(user_id):
        await answer_callback_query(cb_id, "❌ دسترسی ندارید!", True)
        return
    await answer_callback_query(cb_id)

    parts    = data.split(":")
    action   = parts[0]
    order_id = int(parts[1])
    order    = await get_order(order_id)
    if not order:
        await send_message(user_id, "❌ سفارش یافت نشد.")
        return

    # حذف پیام رسید قبلی
    await _del(user_id, msg_id)

    if action == "ord_ok":
        await update_order(order_id, status="confirmed")
        await add_coins(order["user_id"], order["coins"])
        from database.db import get_coins as _gc
        new_bal = await _gc(order["user_id"])
        if order.get("receipt_file_id"):
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute(
                    "UPDATE orders SET receipt_file_id=NULL WHERE id=?", (order_id,))
                await db.commit()
        await send_message(user_id,
            f"✅ <b>سفارش #{order_id} تأیید شد.</b>\n🪙 {order['coins']:,} سکه واریز شد.",
            admin_main_keyboard())
        await send_message(order["user_id"],
            f"✅ <b>پرداخت تأیید شد!</b>\n\n"
            f"🪙 <b>{order['coins']:,} سکه</b> واریز شد.\n"
            f"💰 موجودی جدید: <b>{new_bal:,} سکه</b>")

    elif action == "ord_rej":
        set_state(user_id, STATES["WAITING_REJECT_REASON"], order_id=order_id)
        await send_message(user_id, "✏️ دلیل رد سفارش را بنویسید:", back_keyboard())

    elif action == "ord_custom":
        set_state(user_id, STATES["WAITING_ADMIN_COINS"], order_id=order_id)
        await send_message(user_id, "🪙 تعداد سکه دریافتی کاربر:", back_keyboard())


async def handle_card_callback(user_id: int, data: str, cb_id: str, msg_id: int):
    if not await _is_admin(user_id):
        return
    await answer_callback_query(cb_id)
    await _del(user_id, msg_id)

    if data == "add_card":
        set_state(user_id, "adm_card_add_num")
        await send_message(user_id, "💳 شماره کارت جدید را وارد کنید:", back_keyboard())

    elif data.startswith("del_card:"):
        idx = int(data.split(":")[1])
        cur = await get_setting("card_numbers", "")
        lines = [l for l in cur.split("\n") if l.strip()]
        if 0 <= idx < len(lines):
            lines.pop(idx)
        await set_setting("card_numbers", "\n".join(lines))
        await send_message(user_id, "✅ کارت حذف شد.")
        await _show_cards(user_id)


async def handle_admin_message(user_id: int, msg: dict, settings: dict) -> bool:
    state = get_state(user_id)
    if state not in ADMIN_TEXT_STATES and state not in {
        "adm_card_action", "adm_card_del_num", "adm_card_add_num", "adm_card_add_name"
    }:
        return False
    if not await _is_admin(user_id):
        return False

    text  = msg.get("text", "")
    photo = msg.get("photo")
    doc   = msg.get("document")

    # ---- Card management ----
    if state == "adm_card_add_num":
        update_data(user_id, new_card_num=text)
        set_state(user_id, "adm_card_add_name", new_card_num=text)
        await send_message(user_id, "👤 نام صاحب کارت را وارد کنید:", back_keyboard())
        return True

    elif state == "adm_card_add_name":
        num = get_data_key(user_id, "new_card_num")
        cur = await get_setting("card_numbers", "")
        lines = [l for l in cur.split("\n") if l.strip()]
        lines.append(f"{num}|{text}")
        await set_setting("card_numbers", "\n".join(lines))
        clear_state(user_id)
        await send_message(user_id, f"✅ کارت <code>{num}</code> به نام {text} اضافه شد.",
                           admin_main_keyboard())
        return True

    # ---- Broadcast ----
    if state == STATES["WAITING_BROADCAST"]:
        bc_photo  = photo[-1]["file_id"] if photo else None
        bc_caption= msg.get("caption", "") if photo else ""
        bc_text   = text if not photo else None
        set_state(user_id, "bc_waiting_btn_choice",
                  bc_text=bc_text, bc_photo=bc_photo, bc_caption=bc_caption)
        await send_message(user_id,
            "✅ محتوا ذخیره شد.\n\nآیا دکمه شیشه‌ای می‌خواهید؟",
            broadcast_btn_inline(),
        )

    elif state == STATES["WAITING_BROADCAST_BTN_TEXT"]:
        update_data(user_id, bc_btn_text=text)
        set_state(user_id, STATES["WAITING_BROADCAST_BTN_URL"],
                  bc_text    = get_data_key(user_id, "bc_text"),
                  bc_photo   = get_data_key(user_id, "bc_photo"),
                  bc_caption = get_data_key(user_id, "bc_caption"),
                  bc_btn_text= text)
        await send_message(user_id, "🔗 لینک دکمه را وارد کنید:", back_keyboard())

    elif state == STATES["WAITING_BROADCAST_BTN_URL"]:
        bc_text    = get_data_key(user_id, "bc_text")
        bc_photo   = get_data_key(user_id, "bc_photo")
        bc_caption = get_data_key(user_id, "bc_caption")
        btn_text   = get_data_key(user_id, "bc_btn_text")
        btn_url    = text
        clear_state(user_id)
        await _do_broadcast(user_id, settings, bc_text, bc_photo, bc_caption,
                            btn_text=btn_text, btn_url=btn_url)

    elif state == STATES["WAITING_CHANNEL_LINK"]:
        link = text.strip()
        if not link.startswith("http"):
            await send_message(user_id, "❌ لینک نامعتبر است."); return True
        username = "@" + link.rstrip("/").split("/")[-1]
        set_state(user_id, STATES["WAITING_CHANNEL_BTN"], ch_link=link, ch_username=username)
        await send_message(user_id,
            f"✅ لینک: <b>{username}</b>\n\nمتن دکمه را وارد کنید:",
            back_keyboard())

    elif state == STATES["WAITING_CHANNEL_BTN"]:
        ch_link     = get_data_key(user_id, "ch_link")
        ch_username = get_data_key(user_id, "ch_username")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT INTO join_channels (channel_link, channel_username, button_text)"
                " VALUES (?,?,?)",
                (ch_link, ch_username, text),
            )
            await db.commit()
        clear_state(user_id)
        await send_message(user_id,
            f"✅ کانال <b>{ch_username}</b> اضافه شد! دکمه: «{text}»",
            admin_main_keyboard())

    elif state == STATES["WAITING_REFERRAL_REWARD"]:
        if not text.isdigit():
            await send_message(user_id, "⚠️ عدد وارد کنید."); return True
        await set_setting("referral_join_reward", text)
        set_state(user_id, STATES["ADM_REF_CH_REWARD"])
        await send_message(user_id,
            f"✅ هدیه ورود: <b>{text} سکه</b>\n\nهدیه عضویت کانال را وارد کنید:",
            back_keyboard())

    elif state == STATES["ADM_REF_CH_REWARD"]:
        if not text.isdigit():
            await send_message(user_id, "⚠️ عدد وارد کنید."); return True
        await set_setting("referral_channel_reward", text)
        j = await get_setting("referral_join_reward", "10")
        clear_state(user_id)
        await send_message(user_id,
            f"✅ ذخیره شد!\n• ورود ربات: {j} سکه\n• عضویت کانال: {text} سکه",
            admin_main_keyboard())

    elif state == STATES["WAITING_PACKAGE_TITLE"]:
        set_state(user_id, STATES["WAITING_PACKAGE_COINS"], pkg_title=text)
        await send_message(user_id, "🪙 تعداد سکه بسته:", back_keyboard())

    elif state == STATES["WAITING_PACKAGE_COINS"]:
        if not text.isdigit():
            await send_message(user_id, "⚠️ عدد وارد کنید."); return True
        set_state(user_id, STATES["WAITING_PACKAGE_PRICE"],
                  pkg_title=get_data_key(user_id, "pkg_title"), pkg_coins=int(text))
        await send_message(user_id, "💵 قیمت بسته (تومان):", back_keyboard())

    elif state == STATES["WAITING_PACKAGE_PRICE"]:
        if not text.isdigit():
            await send_message(user_id, "⚠️ عدد وارد کنید."); return True
        title = get_data_key(user_id, "pkg_title")
        coins = get_data_key(user_id, "pkg_coins")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT INTO coin_packages (title, coins, price) VALUES (?,?,?)",
                (title, coins, int(text)))
            await db.commit()
        clear_state(user_id)
        await send_message(user_id,
            f"✅ بسته «{title}» — {coins} سکه — {int(text):,} تومان اضافه شد!",
            admin_main_keyboard())

    elif state == STATES["WAITING_PROFILE_REWARD"]:
        if not text.isdigit():
            await send_message(user_id, "⚠️ عدد وارد کنید."); return True
        await set_setting("profile_reward", text)
        clear_state(user_id)
        await send_message(user_id, f"✅ جایزه تکمیل پروفایل: <b>{text} سکه</b>",
                           admin_main_keyboard())

    elif state == STATES["WAITING_CARD_NUMBER"]:
        await set_setting("card_numbers", text)
        clear_state(user_id)
        await send_message(user_id, "✅ کارت‌ها ذخیره شدند!", admin_main_keyboard())

    elif state == STATES["WAITING_REJECT_REASON"]:
        order_id = get_data_key(user_id, "order_id")
        order    = await get_order(order_id)
        await update_order(order_id, status="rejected", reject_reason=text)
        clear_state(user_id)
        await send_message(user_id, "✅ سفارش رد شد.", admin_main_keyboard())
        if order:
            await send_message(order["user_id"],
                f"❌ <b>پرداخت شما رد شد.</b>\n\n📝 دلیل: {text}")

    elif state == STATES["WAITING_ADMIN_COINS"]:
        if not text.isdigit():
            await send_message(user_id, "⚠️ عدد وارد کنید."); return True
        amount        = int(text)
        broadcast_all = get_data_key(user_id, "broadcast_all")
        order_id      = get_data_key(user_id, "order_id")
        target_uid    = get_data_key(user_id, "target_uid")
        if broadcast_all:
            users = await get_all_users_ids()
            for uid in users:
                await add_coins(uid, amount)
            clear_state(user_id)
            await send_message(user_id,
                f"✅ {amount:,} سکه به {len(users):,} کاربر واریز شد!",
                admin_main_keyboard())
        elif order_id:
            order = await get_order(order_id)
            await update_order(order_id, status="confirmed", coins=amount)
            await add_coins(order["user_id"], amount)
            clear_state(user_id)
            await send_message(user_id, f"✅ {amount:,} سکه واریز شد.",
                               admin_main_keyboard())
            await send_message(order["user_id"],
                f"🪙 <b>{amount:,} سکه</b> به حساب شما واریز شد!")
        elif target_uid:
            await add_coins(int(target_uid), amount)
            clear_state(user_id)
            await send_message(user_id,
                f"✅ {amount:,} سکه به کاربر {target_uid} واریز شد!",
                admin_main_keyboard())

    elif state == STATES["WAITING_COINS_USER"]:
        set_state(user_id, STATES["WAITING_ADMIN_COINS"], target_uid=text)
        await send_message(user_id, "🪙 تعداد سکه را وارد کنید:", back_keyboard())

    elif state == STATES["ADM_DISC_CODE"]:
        set_state(user_id, STATES["ADM_DISC_PERCENT"], new_disc_code=text)
        await send_message(user_id, "💯 درصد تخفیف (۱-۱۰۰):", back_keyboard())

    elif state == STATES["ADM_DISC_PERCENT"]:
        if not text.isdigit() or not (1 <= int(text) <= 100):
            await send_message(user_id, "⚠️ عدد ۱ تا ۱۰۰ وارد کنید."); return True
        set_state(user_id, STATES["ADM_DISC_USES"],
                  new_disc_code=get_data_key(user_id, "new_disc_code"),
                  disc_percent=int(text))
        await send_message(user_id,
            "👥 حداکثر استفاده:\n(-۱ یا «نامحدود» = بی‌نهایت)", back_keyboard())

    elif state == STATES["ADM_DISC_USES"]:
        max_uses = -1 if text.strip() in ("-1", "نامحدود") else (
            int(text) if text.isdigit() else -1)
        set_state(user_id, STATES["ADM_DISC_DAYS"],
                  new_disc_code=get_data_key(user_id, "new_disc_code"),
                  disc_percent=get_data_key(user_id, "disc_percent"),
                  disc_max_uses=max_uses)
        await send_message(user_id, "📅 مدت اعتبار (روز):", back_keyboard())

    elif state == STATES["ADM_DISC_DAYS"]:
        if not text.isdigit():
            await send_message(user_id, "⚠️ عدد وارد کنید."); return True
        code     = get_data_key(user_id, "new_disc_code")
        percent  = get_data_key(user_id, "disc_percent")
        max_uses = get_data_key(user_id, "disc_max_uses")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT OR REPLACE INTO discount_codes"
                " (code, percent, max_uses, expires_days, created_at, is_active)"
                " VALUES (?,?,?,?,?,1)",
                (code, percent, max_uses, int(text), int(time.time())))
            await db.commit()
        clear_state(user_id)
        await send_message(user_id,
            f"✅ کد تخفیف <b>{code}</b> ساخته شد!\n"
            f"💯 {percent}% | 👥 {'نامحدود' if max_uses==-1 else max_uses}"
            f" | 📅 {text} روز",
            admin_main_keyboard())

    elif state == STATES["WAITING_CHAT_COST"]:
        if not text.isdigit() and text != "رایگان":
            await send_message(user_id, "⚠️ عدد یا «رایگان» وارد کنید."); return True
        cost_key = get_data_key(user_id, "cost_key")
        val = "0" if text == "رایگان" else text
        await set_setting(cost_key, val)
        clear_state(user_id)
        await send_message(user_id,
            f"✅ هزینه تنظیم شد: <b>{'رایگان' if val=='0' else f'{val} سکه'}</b>",
            admin_main_keyboard())

    elif state == STATES["WAITING_BTN_TEXT_VALUE"]:
        key = get_data_key(user_id, "btn_key")
        await set_setting(key, text)
        clear_state(user_id)
        await send_message(user_id, f"✅ متن دکمه: <b>{text}</b>", admin_main_keyboard())

    elif state == STATES["WAITING_DB_UPLOAD"]:
        if doc:
            await set_setting("pending_db_file_id", doc["file_id"])
            clear_state(user_id)
            await send_message(user_id,
                "⚠️ دیتابیس دریافت شد. روی سرور جایگزین کنید و ربات را ریستارت کنید.",
                admin_main_keyboard())
        else:
            await send_message(user_id, "⚠️ فایل ارسال کنید.")

    return True


async def handle_broadcast_callback(user_id: int, data: str, cb_id: str,
                                     msg_id: int, settings: dict):
    await answer_callback_query(cb_id)
    await _del(user_id, msg_id)  # حذف پیام «آیا دکمه می‌خواهید»

    bc_text   = get_data_key(user_id, "bc_text")
    bc_photo  = get_data_key(user_id, "bc_photo")
    bc_caption= get_data_key(user_id, "bc_caption")

    if data == "bc:add_btn":
        set_state(user_id, STATES["WAITING_BROADCAST_BTN_TEXT"],
                  bc_text=bc_text, bc_photo=bc_photo, bc_caption=bc_caption)
        await send_message(user_id, "✏️ متن دکمه را وارد کنید:", back_keyboard())
    elif data == "bc:no_btn":
        clear_state(user_id)
        await _do_broadcast(user_id, settings, bc_text, bc_photo, bc_caption)


async def _do_broadcast(user_id: int, settings: dict,
                         bc_text: str, bc_photo: str, bc_caption: str,
                         btn_text: str = None, btn_url: str = None):
    markup = None
    if btn_text and btn_url:
        markup = inline_kb([[{"text": btn_text, "url": btn_url}]])

    users  = await get_all_users_ids()
    sent = failed = 0
    for i in range(0, len(users), 1000):
        batch = users[i:i+1000]
        tasks = []
        for uid in batch:
            if bc_photo:
                tasks.append(send_photo(uid, bc_photo, bc_caption or bc_text or "", markup))
            else:
                tasks.append(send_message(uid, bc_text or "", markup))
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for r in results:
            if isinstance(r, Exception):
                failed += 1
            else:
                ok = r.get("ok", False) if isinstance(r, dict) else False
                if ok:
                    sent += 1
                else:
                    failed += 1
        await asyncio.sleep(0.3)

    await send_message(user_id,
        f"✅ <b>پیام همگانی ارسال شد!</b>\n\n✔️ موفق: {sent:,}\n❌ ناموفق: {failed:,}",
        admin_main_keyboard())


async def handle_del_channel(user_id: int, ch_id: int, cb_id: str, msg_id: int):
    if not await _is_admin(user_id):
        return
    await answer_callback_query(cb_id)
    await _del(user_id, msg_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE join_channels SET is_active=0 WHERE id=?", (ch_id,))
        await db.commit()
    await send_message(user_id, "✅ کانال حذف شد.", admin_main_keyboard())


async def handle_edit_btn_callback(user_id: int, key: str, cb_id: str,
                                    msg_id: int, settings: dict):
    await answer_callback_query(cb_id)
    await _del(user_id, msg_id)
    current = settings.get(key) or DEFAULT_TEXTS.get(key, "")
    set_state(user_id, STATES["WAITING_BTN_TEXT_VALUE"], btn_key=key)
    await send_message(user_id,
        f"✏️ مقدار فعلی: <code>{current}</code>\n\nمتن جدید:",
        back_keyboard())
