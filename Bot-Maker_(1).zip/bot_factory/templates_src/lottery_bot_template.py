import requests
import sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import json
import sqlite3
import random
import datetime
import time
import threading
import re

# ======================== کانفیگ ========================
BOT_TOKEN = "{{BOT_TOKEN}}"
ADMIN_ID = "{{ADMIN_ID}}"  # آیدی عددی ادمین
ADMIN_CMD = "{{ADMIN_CMD}}"  # دستوری که پنل مدیریت رو باز می‌کنه
BASE_URL = f"https://tapi.bale.ai/bot{BOT_TOKEN}"

# تنظیمات پیش‌فرض
START_TIME = "12:00"
END_TIME = "22:00"
LOTTERY_TIME = "22:30"
PRIZE = "۱۰۰ هزار تومان"
SUPPORT_TEXT = "برای ارتباط با پشتیبانی به آیدی مدیسون مراجعه کنید."
# =====================================================

user_states = {}

# ======================== دیتابیس ========================
def init_db():
    conn = sqlite3.connect('lottery.db', check_same_thread=False)
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (user_id TEXT PRIMARY KEY,
                  username TEXT,
                  first_name TEXT,
                  shance INTEGER DEFAULT 0,
                  invited_by TEXT,
                  join_date TEXT,
                  is_banned INTEGER DEFAULT 0)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS participants
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id TEXT,
                  date TEXT,
                  shance_count INTEGER,
                  UNIQUE(user_id, date))''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS winners
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id TEXT,
                  prize TEXT,
                  win_date TEXT)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS settings
                 (key TEXT PRIMARY KEY,
                  value TEXT)''')
    
    settings = [
        ('start_time', START_TIME),
        ('end_time', END_TIME),
        ('lottery_time', LOTTERY_TIME),
        ('prize', PRIZE),
        ('support_text', SUPPORT_TEXT)
    ]
    for key, value in settings:
        c.execute('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', (key, value))
    
    conn.commit()
    return conn

db = init_db()

# ======================== توابع API بله ========================
def api_call(method, data=None):
    try:
        if data is None:
            data = {}
        response = requests.post(f"{BASE_URL}/{method}", json=data, timeout=15)
        result = response.json()
        if not result.get("ok"):
            print(f"API Error in {method}: {result}")
        return result
    except Exception as e:
        print(f"Exception in {method}: {e}")
        return {"ok": False, "description": str(e)}

def send_message(chat_id, text, reply_markup=None):
    data = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown"
    }
    if reply_markup:
        data["reply_markup"] = json.dumps(reply_markup)
    
    result = api_call("sendMessage", data)
    return result.get("ok", False)

def answer_callback(callback_id, text=""):
    data = {
        "callback_query_id": callback_id,
        "text": text
    }
    try:
        requests.post(f"{BASE_URL}/answerCallbackQuery", json=data, timeout=5)
    except:
        pass

def get_updates(offset=None, timeout=30):
    params = {"timeout": timeout}
    if offset:
        params["offset"] = offset
    try:
        response = requests.get(f"{BASE_URL}/getUpdates", params=params, timeout=timeout + 10)
        return response.json()
    except requests.exceptions.ReadTimeout:
        return {"ok": True, "result": []}
    except Exception as e:
        print(f"Error getting updates: {e}")
        return {"ok": False, "result": []}

def get_bot_username():
    result = api_call("getMe")
    if result.get("ok"):
        return result["result"]["username"]
    return None

# ======================== کیبوردها ========================
def main_menu():
    return {
        "inline_keyboard": [
            [{"text": "🎯 شرکت در قرعه‌کشی", "callback_data": "join_lottery"}],
            [{"text": "🎫 شانس‌های من", "callback_data": "my_shance"}],
            [{"text": "🔗 دعوت دوستان", "callback_data": "invite"}],
            [{"text": "🏆 برندگان قبلی", "callback_data": "winners"}],
            [{"text": "📖 راهنما", "callback_data": "help"}],
            [{"text": "🆘 پشتیبانی", "callback_data": "support"}]
        ]
    }

def admin_panel():
    return {
        "inline_keyboard": [
            [{"text": "⚙️ تنظیمات قرعه‌کشی", "callback_data": "admin_settings"}],
            [{"text": "🎁 تغییر جایزه", "callback_data": "change_prize"}],
            [{"text": "🆘 تغییر متن پشتیبانی", "callback_data": "change_support"}],
            [{"text": "📊 آمار", "callback_data": "admin_stats"}],
            [{"text": "🔧 مدیریت شانس کاربران", "callback_data": "manage_shance"}],
            [{"text": "🏆 لیست برندگان", "callback_data": "admin_winners"}],
            [{"text": "📢 ارسال همگانی", "callback_data": "broadcast"}],
            [{"text": "🎲 شروع دستی قرعه‌کشی", "callback_data": "manual_lottery"}],
            [{"text": "🔄 انتخاب مجدد برنده", "callback_data": "re_select"}]
        ]
    }

def settings_menu():
    c = db.cursor()
    c.execute("SELECT key, value FROM settings")
    settings = dict(c.fetchall())
    
    return {
        "inline_keyboard": [
            [{"text": f"🕛 ساعت شروع: {settings.get('start_time', '12:00')}", "callback_data": "set_start"}],
            [{"text": f"🕙 ساعت پایان: {settings.get('end_time', '22:00')}", "callback_data": "set_end"}],
            [{"text": f"🎰 ساعت قرعه‌کشی: {settings.get('lottery_time', '22:30')}", "callback_data": "set_lottery"}],
            [{"text": "🔙 بازگشت به پنل مدیریت", "callback_data": "back_admin"}]
        ]
    }

def back_to_admin():
    return {
        "inline_keyboard": [
            [{"text": "🔙 بازگشت", "callback_data": "back_admin"}]
        ]
    }

# ======================== توابع کمکی ========================
def get_setting(key):
    c = db.cursor()
    c.execute("SELECT value FROM settings WHERE key=?", (key,))
    result = c.fetchone()
    return result[0] if result else None

def set_setting(key, value):
    c = db.cursor()
    c.execute("UPDATE settings SET value=? WHERE key=?", (value, key))
    db.commit()
    print(f"✅ تنظیم {key} به {value} تغییر کرد")

def is_lottery_time():
    try:
        now = datetime.datetime.now()
        start_str = get_setting('start_time')
        end_str = get_setting('end_time')
        
        if not start_str or not end_str:
            return True
        
        start = datetime.datetime.strptime(start_str, "%H:%M").time()
        end = datetime.datetime.strptime(end_str, "%H:%M").time()
        return start <= now.time() <= end
    except Exception as e:
        print(f"Error in is_lottery_time: {e}")
        return True

def add_user(user_id, username, first_name, invited_by=None):
    c = db.cursor()
    c.execute("SELECT user_id, invited_by FROM users WHERE user_id=?", (str(user_id),))
    existing = c.fetchone()
    
    if existing is None:
        # کاربر جدید - ثبت نام
        c.execute("""INSERT INTO users (user_id, username, first_name, invited_by, join_date)
                     VALUES (?, ?, ?, ?, ?)""",
                  (str(user_id), username or "", first_name or "", invited_by, datetime.date.today().isoformat()))
        
        # اگر با لینک دعوت اومده، به دعوت‌کننده شانس بده
        if invited_by and invited_by != str(user_id):
            c.execute("UPDATE users SET shance = shance + 1 WHERE user_id=?", (str(invited_by),))
            print(f"✅ یک شانس به کاربر {invited_by} اضافه شد (دعوت از {user_id})")
    else:
        # کاربر قبلاً وجود داره
        existing_invited_by = existing[1]
        
        # اگر قبلاً invited_by نداشته و حالا داره، آپدیت کن
        if not existing_invited_by and invited_by and invited_by != str(user_id):
            c.execute("UPDATE users SET invited_by=? WHERE user_id=?", (invited_by, str(user_id)))
            c.execute("UPDATE users SET shance = shance + 1 WHERE user_id=?", (str(invited_by),))
            print(f"✅ کاربر {user_id} قبلاً ثبت‌نام کرده بود، حالا دعوت‌کننده {invited_by} ثبت شد و شانس گرفت")
    
    db.commit()

def get_user_shance(user_id):
    c = db.cursor()
    c.execute("SELECT shance FROM users WHERE user_id=?", (str(user_id),))
    result = c.fetchone()
    return result[0] if result else 0

def get_today_participants():
    today = datetime.date.today().isoformat()
    c = db.cursor()
    c.execute("SELECT user_id, shance_count FROM participants WHERE date=?", (today,))
    return c.fetchall()

def do_lottery():
    participants = get_today_participants()
    if not participants:
        print("❌ هیچ شرکت‌کننده‌ای برای امروز نیست")
        return None
    
    users = []
    weights = []
    for user_id, shance in participants:
        users.append(user_id)
        weights.append(max(1, shance))
    
    winner_id = random.choices(users, weights=weights, k=1)[0]
    prize = get_setting('prize') or "جایزه"
    
    c = db.cursor()
    c.execute("INSERT INTO winners (user_id, prize, win_date) VALUES (?, ?, ?)",
              (winner_id, prize, datetime.date.today().isoformat()))
    db.commit()
    
    print(f"🎉 برنده: {winner_id} | جایزه: {prize}")
    return winner_id, prize

def notify_users(winner_id, prize):
    participants = get_today_participants()
    
    send_message(winner_id,
        f"🎉🎉🎉 **تبریک!**\n\n"
        f"شما برنده قرعه‌کشی امروز شدید!\n"
        f"🎁 جایزه: **{prize}**\n\n"
        f"برای دریافت جایزه با پشتیبانی تماس بگیرید.",
        reply_markup=main_menu())
    
    for user_id, _ in participants:
        if str(user_id) != str(winner_id):
            send_message(user_id,
                "😔 متاسفانه در قرعه‌کشی امروز برنده نشدید.\n"
                "فردا دوباره شانس خودتون رو امتحان کنید!",
                reply_markup=main_menu())

# ======================== مدیریت پیام‌ها ========================
def handle_start(message):
    user_id = str(message["from"]["id"])
    first_name = message["from"].get("first_name", "")
    username = message["from"].get("username", "")
    
    invited_by = None
    text = message.get("text", "")
    
    # روش ۱: پترن ref_USERID
    match = re.search(r'ref_(\d+)', text)
    if match:
        invited_by = match.group(1)
        print(f"🔗 کد دعوت (ref): {invited_by}")
    
    # روش ۲: عدد تنها بعد از start
    if not invited_by:
        parts = text.split()
        if len(parts) > 1:
            # حذف کاراکترهای اضافی
            code = parts[1].strip()
            if code.isdigit():
                invited_by = code
                print(f"🔗 کد دعوت (عددی): {invited_by}")
    
    # ثبت‌نام کاربر
    add_user(user_id, username, first_name, invited_by)
    
    send_message(user_id,
        f"🎲 سلام {first_name}!\n"
        f"به ربات قرعه‌کشی خوش اومدی!\n\n"
        f"🎁 جایزه امروز: {get_setting('prize')}\n"
        f"⏰ زمان شرکت: {get_setting('start_time')} تا {get_setting('end_time')}\n"
        f"🎰 زمان قرعه‌کشی: {get_setting('lottery_time')}",
        reply_markup=main_menu())

def handle_admin_command(message):
    user_id = str(message["from"]["id"])
    chat_id = message["chat"]["id"]
    
    if user_id == ADMIN_ID:
        send_message(chat_id, "👑 پنل مدیریت:", reply_markup=admin_panel())
    else:
        send_message(chat_id, "⛔ شما ادمین نیستید!")

def handle_callback(callback):
    callback_id = callback["id"]
    user_id = str(callback["from"]["id"])
    data = callback["data"]
    message = callback.get("message", {})
    chat_id = message.get("chat", {}).get("id")
    message_id = message.get("message_id")
    
    answer_callback(callback_id)
    
    print(f"📥 کالبک از {user_id}: {data}")
    
    # ========== منوهای کاربر ==========
    if data == "join_lottery":
        if not is_lottery_time():
            send_message(chat_id,
                f"⏰ زمان شرکت در قرعه‌کشی تمام شده!\n"
                f"زمان مجاز: {get_setting('start_time')} تا {get_setting('end_time')}",
                reply_markup=main_menu())
            return
        
        today = datetime.date.today().isoformat()
        c = db.cursor()
        c.execute("SELECT id FROM participants WHERE user_id=? AND date=?", (user_id, today))
        exists = c.fetchone()
        
        if exists:
            send_message(chat_id, "⚠️ شما امروز قبلاً شرکت کرده‌اید!", reply_markup=main_menu())
            return
        
        shance = get_user_shance(user_id)
        if shance < 1:
            shance = 1
        
        c.execute("INSERT INTO participants (user_id, date, shance_count) VALUES (?, ?, ?)",
                  (user_id, today, shance))
        c.execute("UPDATE users SET shance = shance - 1 WHERE user_id=?", (user_id,))
        db.commit()
        
        send_message(chat_id,
            f"✅ با موفقیت در قرعه‌کشی امروز شرکت کردید!\n"
            f"🎫 شانس‌های شما: {shance} عدد\n"
            f"🎁 جایزه: {get_setting('prize')}\n\n"
            f"برنده ساعت {get_setting('lottery_time')} مشخص می‌شود.",
            reply_markup=main_menu())
    
    elif data == "my_shance":
        shance = get_user_shance(user_id)
        send_message(chat_id,
            f"🎫 تعداد شانس‌های شما: {shance} عدد\n\n"
            f"💡 با دعوت دوستان شانس بیشتری کسب کنید!",
            reply_markup=main_menu())
    
    elif data == "invite":
        bot_username = get_bot_username()
        if bot_username:
            invite_link = f"https://ble.ir/{bot_username}?start=ref_{user_id}"
            send_message(chat_id,
                f"🔗 لینک دعوت اختصاصی شما:\n\n"
                f"{invite_link}\n\n"
                f"💡 با این لینک دوستات رو دعوت کن!\n"
                f"به ازای هر دعوت موفق ۱ شانس می‌گیری.",
                reply_markup=main_menu())
        else:
            send_message(chat_id, "❌ خطا در دریافت اطلاعات ربات!", reply_markup=main_menu())
    
    elif data == "winners":
        c = db.cursor()
        c.execute("""
            SELECT w.user_id, w.prize, w.win_date, u.first_name, u.username
            FROM winners w
            LEFT JOIN users u ON w.user_id = u.user_id
            ORDER BY w.id DESC
            LIMIT 10
        """)
        winners = c.fetchall()
        
        if not winners:
            text = "🏆 هنوز برنده‌ای وجود ندارد!"
        else:
            text = "🏆 آخرین برندگان:\n\n"
            for i, (uid, prize, date, name, username) in enumerate(winners, 1):
                display_name = name or username or uid
                text += f"{i}. {display_name}\n   🎁 {prize} | 📅 {date}\n\n"
        
        send_message(chat_id, text, reply_markup=main_menu())
    
    elif data == "help":
        send_message(chat_id,
            "📖 **راهنمای ربات:**\n\n"
            "1️⃣ هر روز می‌تونید با شانس‌هاتون شرکت کنید.\n"
            "2️⃣ شانس بیشتر = احتمال برد بیشتر!\n"
            "3️⃣ با دعوت دوستان شانس بگیرید.\n"
            "4️⃣ قرعه‌کشی هر شب رأس ساعت مقرر انجام میشه.\n"
            "5️⃣ برنده از طریق ربات مطلع میشه.\n\n"
            "❓ سوالی دارید؟ از دکمه پشتیبانی استفاده کنید.",
            reply_markup=main_menu())
    
    elif data == "support":
        support_text = get_setting('support_text') or SUPPORT_TEXT
        send_message(chat_id, f"🆘 **پشتیبانی**\n\n{support_text}", reply_markup=main_menu())
    
    # ========== پنل ادمین ==========
    elif data == "admin_settings":
        if user_id != ADMIN_ID:
            send_message(chat_id, "⛔ دسترسی غیرمجاز!", reply_markup=main_menu())
            return
        send_message(chat_id, "⚙️ تنظیمات قرعه‌کشی:", reply_markup=settings_menu())
    
    elif data == "back_admin":
        if user_id != ADMIN_ID:
            return
        send_message(chat_id, "👑 پنل مدیریت:", reply_markup=admin_panel())
    
    elif data == "back_main":
        send_message(chat_id, "📱 منوی اصلی:", reply_markup=main_menu())
    
    elif data == "admin_stats":
        if user_id != ADMIN_ID:
            send_message(chat_id, "⛔ دسترسی غیرمجاز!", reply_markup=main_menu())
            return
        c = db.cursor()
        c.execute("SELECT COUNT(*) FROM users")
        total_users = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM participants WHERE date=?", (datetime.date.today().isoformat(),))
        today_parts = c.fetchone()[0]
        c.execute("SELECT SUM(shance) FROM users")
        total_shance = c.fetchone()[0] or 0
        
        send_message(chat_id,
            f"📊 آمار ربات:\n\n"
            f"👥 کل کاربران: {total_users}\n"
            f"🎯 شرکت‌کنندگان امروز: {today_parts}\n"
            f"🎫 کل شانس‌های موجود: {total_shance}",
            reply_markup=admin_panel())
    
    elif data == "admin_winners":
        if user_id != ADMIN_ID:
            send_message(chat_id, "⛔ دسترسی غیرمجاز!", reply_markup=main_menu())
            return
        c = db.cursor()
        c.execute("""
            SELECT w.user_id, w.prize, w.win_date, u.first_name, u.username
            FROM winners w
            LEFT JOIN users u ON w.user_id = u.user_id
            ORDER BY w.id DESC
            LIMIT 20
        """)
        winners = c.fetchall()
        
        if not winners:
            text = "🏆 هنوز برنده‌ای ثبت نشده!"
        else:
            text = "🏆 لیست برندگان:\n\n"
            for i, (uid, prize, date, name, username) in enumerate(winners, 1):
                display_name = name or username or uid
                text += f"{i}. {display_name} | {prize} | {date}\n"
        
        send_message(chat_id, text, reply_markup=admin_panel())
    
    elif data == "manual_lottery":
        if user_id != ADMIN_ID:
            send_message(chat_id, "⛔ دسترسی غیرمجاز!", reply_markup=main_menu())
            return
        result = do_lottery()
        if result:
            winner_id, prize = result
            notify_users(winner_id, prize)
            send_message(chat_id,
                f"✅ قرعه‌کشی دستی انجام شد!\nبرنده: `{winner_id}`\nجایزه: {prize}",
                reply_markup=admin_panel())
        else:
            send_message(chat_id, "❌ هیچ شرکت‌کننده‌ای برای امروز نیست!", reply_markup=admin_panel())
    
    elif data == "re_select":
        if user_id != ADMIN_ID:
            send_message(chat_id, "⛔ دسترسی غیرمجاز!", reply_markup=main_menu())
            return
        participants = get_today_participants()
        if not participants:
            send_message(chat_id, "❌ هیچ شرکت‌کننده‌ای وجود ندارد!", reply_markup=admin_panel())
            return
        
        users = []
        weights = []
        for uid, shance in participants:
            users.append(uid)
            weights.append(max(1, shance))
        
        winner_id = random.choices(users, weights=weights, k=1)[0]
        prize = get_setting('prize') or "جایزه"
        
        c = db.cursor()
        c.execute("DELETE FROM winners WHERE win_date=?", (datetime.date.today().isoformat(),))
        c.execute("INSERT INTO winners (user_id, prize, win_date) VALUES (?, ?, ?)",
                  (winner_id, prize, datetime.date.today().isoformat()))
        db.commit()
        
        notify_users(winner_id, prize)
        send_message(chat_id,
            f"✅ برنده جدید با موفقیت انتخاب شد!\nکاربر: `{winner_id}`",
            reply_markup=admin_panel())
    
    # ========== تنظیمات (FSM) ==========
    elif data in ["set_start", "set_end", "set_lottery", "change_prize", "change_support", "manage_shance", "broadcast"]:
        if user_id != ADMIN_ID:
            send_message(chat_id, "⛔ دسترسی غیرمجاز!", reply_markup=main_menu())
            return
        
        user_states[user_id] = {"state": data}
        
        messages = {
            "set_start": "⏰ ساعت **شروع** جدید را وارد کنید (مثال: 14:30):",
            "set_end": "⏰ ساعت **پایان** جدید را وارد کنید (مثال: 23:00):",
            "set_lottery": "🎰 ساعت **قرعه‌کشی** جدید را وارد کنید (مثال: 23:30):",
            "change_prize": "🎁 متن جایزه جدید را وارد کنید:",
            "change_support": "🆘 متن پشتیبانی جدید را وارد کنید:",
            "manage_shance": "🔧 آیدی کاربر و مقدار تغییر را وارد کنید:\nفرمت: `USER_ID +5` یا `USER_ID -2`",
            "broadcast": "📢 متن پیام همگانی را وارد کنید:"
        }
        
        send_message(chat_id, messages[data], reply_markup=back_to_admin())

def handle_text_message(message):
    user_id = str(message["from"]["id"])
    chat_id = message["chat"]["id"]
    text = message.get("text", "")
    
    print(f"📩 پیام از {user_id}: {text}")
    
    if user_id in user_states and user_id == ADMIN_ID:
        state = user_states[user_id]["state"]
        
        if state == "set_start":
            if re.match(r'^\d{1,2}:\d{2}$', text):
                set_setting('start_time', text)
                del user_states[user_id]
                send_message(chat_id, f"✅ ساعت شروع با موفقیت به **{text}** تغییر کرد.", reply_markup=admin_panel())
            else:
                send_message(chat_id, "❌ فرمت اشتباه! مثال: 14:30", reply_markup=back_to_admin())
        
        elif state == "set_end":
            if re.match(r'^\d{1,2}:\d{2}$', text):
                set_setting('end_time', text)
                del user_states[user_id]
                send_message(chat_id, f"✅ ساعت پایان با موفقیت به **{text}** تغییر کرد.", reply_markup=admin_panel())
            else:
                send_message(chat_id, "❌ فرمت اشتباه! مثال: 23:00", reply_markup=back_to_admin())
        
        elif state == "set_lottery":
            if re.match(r'^\d{1,2}:\d{2}$', text):
                set_setting('lottery_time', text)
                del user_states[user_id]
                send_message(chat_id, f"✅ ساعت قرعه‌کشی با موفقیت به **{text}** تغییر کرد.", reply_markup=admin_panel())
            else:
                send_message(chat_id, "❌ فرمت اشتباه! مثال: 23:30", reply_markup=back_to_admin())
        
        elif state == "change_prize":
            set_setting('prize', text)
            del user_states[user_id]
            send_message(chat_id, f"✅ جایزه با موفقیت به «**{text}**» تغییر کرد.", reply_markup=admin_panel())
        
        elif state == "change_support":
            set_setting('support_text', text)
            del user_states[user_id]
            send_message(chat_id, f"✅ متن پشتیبانی با موفقیت به:\n«**{text}**»\nتغییر کرد.", reply_markup=admin_panel())
        
        elif state == "manage_shance":
            match = re.match(r'(\d+)\s*([+-]\d+)', text)
            if match:
                target_user = match.group(1)
                amount = int(match.group(2))
                
                c = db.cursor()
                c.execute("UPDATE users SET shance = shance + ? WHERE user_id=?", (amount, target_user))
                db.commit()
                
                new_shance = get_user_shance(target_user)
                del user_states[user_id]
                send_message(chat_id,
                    f"✅ شانس کاربر `{target_user}` به مقدار {amount} تغییر کرد.\n"
                    f"شانس فعلی: {new_shance}",
                    reply_markup=admin_panel())
            else:
                send_message(chat_id,
                    "❌ فرمت اشتباه!\n"
                    "مثال صحیح: `1024517436 +5`",
                    reply_markup=back_to_admin())
        
        elif state == "broadcast":
            c = db.cursor()
            c.execute("SELECT user_id FROM users")
            users = c.fetchall()
            
            success = 0
            fail = 0
            for (uid,) in users:
                result = send_message(uid, text)
                if result:
                    success += 1
                else:
                    fail += 1
                time.sleep(0.05)
            
            del user_states[user_id]
            send_message(chat_id,
                f"✅ پیام همگانی ارسال شد!\n"
                f"موفق: {success} | ناموفق: {fail}",
                reply_markup=admin_panel())
    else:
        send_message(chat_id, "👋 لطفاً از دکمه‌های منو استفاده کنید.", reply_markup=main_menu())

# ======================== زمان‌بند خودکار ========================
def lottery_scheduler():
    """چک کردن زمان قرعه‌کشی هر ۳۰ ثانیه"""
    last_lottery_date = None
    
    while True:
        try:
            now = datetime.datetime.now()
            today = now.date()
            
            if last_lottery_date == today:
                time.sleep(30)
                continue
            
            lottery_time_str = get_setting('lottery_time')
            if not lottery_time_str:
                time.sleep(30)
                continue
            
            try:
                lottery_time = datetime.datetime.strptime(lottery_time_str, "%H:%M").time()
            except:
                time.sleep(30)
                continue
            
            if now.time() >= lottery_time:
                print(f"[{now}] 🎰 شروع قرعه‌کشی خودکار...")
                result = do_lottery()
                if result:
                    winner_id, prize = result
                    notify_users(winner_id, prize)
                    print(f"✅ برنده: {winner_id} | جایزه: {prize}")
                last_lottery_date = today
            
            time.sleep(30)
            
        except Exception as e:
            print(f"Error in scheduler: {e}")
            time.sleep(30)

# ======================== حلقه اصلی ========================
def main():
    print("🚀 ربات قرعه‌کشی بله راه‌اندازی شد!")
    print(f"⏰ زمان شروع: {get_setting('start_time')}")
    print(f"⏰ زمان پایان: {get_setting('end_time')}")
    print(f"🎰 زمان قرعه‌کشی: {get_setting('lottery_time')}")
    print(f"🎁 جایزه: {get_setting('prize')}")
    print(f"🆘 متن پشتیبانی: {get_setting('support_text')}")
    print(f"👑 ادمین: {ADMIN_ID}")
    print("-" * 40)
    
    scheduler_thread = threading.Thread(target=lottery_scheduler, daemon=True)
    scheduler_thread.start()
    
    offset = None
    
    while True:
        try:
            updates = get_updates(offset, timeout=30)
            
            if updates.get("ok") and updates.get("result"):
                for update in updates["result"]:
                    offset = update["update_id"] + 1
                    
                    if "message" in update and "text" in update["message"]:
                        message = update["message"]
                        text = message.get("text", "")
                        
                        if text.startswith("/start"):
                            handle_start(message)
                        elif text.startswith(ADMIN_CMD):
                            handle_admin_command(message)
                        else:
                            handle_text_message(message)
                    
                    elif "callback_query" in update:
                        handle_callback(update["callback_query"])
            
            time.sleep(0.3)
            
        except KeyboardInterrupt:
            print("\n\n❌ ربات خاموش شد.")
            db.close()
            break
        except Exception as e:
            print(f"⚠️ خطا در حلقه اصلی: {e}")
            time.sleep(3)

if __name__ == "__main__":
    main()