import requests
import json
import time
import os
import sys

# محافظت در برابر کرش روی ویندوز موقع پرینت فارسی/ایموجی وقتی خروجی به فایل ریدایرکت می‌شه
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import random
import math
from datetime import datetime, timedelta

# ==================== تنظیمات ====================
TOKEN = "{{BOT_TOKEN}}"
BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
ADMIN_ID = {{ADMIN_ID}}
DATA_FILE = "Matrix_data.json"
BOT_LINK = ""

# توکن‌های پرداخت
WALLET_TOKEN_REAL = "ولت توکن خود را اینجا بزارید"
WALLET_TOKEN_TEST = "WALLET-TEST-1111111111111111"

CARD_TO_GOLD_RATE = 5
TRANSFER_FEE = 0.05
SPY_COST_TOMAN = 15000
SPY_COST_RIAL = 150000
BATTLE_COOLDOWN = 120  # ثانیه
TRANSFER_COOLDOWN = 120

# قیمت‌ها
PRICES = {
    "vikings": 10,
    "knights": 20,
    "archers": 15,
    "catapult": 50,
    "war_elephant": 80,
    "alchemist": 40,
    "sword": 30,
    "lance": 50,
    "longbow": 40,
    "siege_tower": 100,
    "war_drum": 60,
    "shield": 25,
    "armor": 45,
    "wall": 70,
    "tower": 120,
    "moat": 90,
    "house": 30,
    "farm": 25,
    "workshop": 50,
    "hospital": 100,
    "tavern": 80,
    "market": 120,
    "barracks": 200,
    "gold_mine": 500,
    "oil_rig": 400,
    "trade_post": 300,
    "create_alliance": 2000,
    "change_name": 500,
    "change_alliance_name": 1000
}

UNIT_POWER = {
    "vikings": 5,
    "knights": 10,
    "archers": 7,
    "catapult": 20,
    "war_elephant": 50,
    "alchemist": 15
}

EQUIPMENT_EFFECT = {
    "sword": {"vikings": 1.5, "type": "offensive"},
    "lance": {"knights": 1.5, "type": "offensive"},
    "longbow": {"archers": 1.5, "type": "offensive"},
    "siege_tower": {"catapult": 1.8, "type": "offensive"},
    "war_drum": {"all": 1.2, "type": "offensive"},
    "shield": {"defense": 0.8, "type": "defensive"},
    "armor": {"defense": 0.7, "type": "defensive"},
    "wall": {"defense": 0.6, "type": "defensive"},
    "tower": {"defense": 1.3, "type": "defensive"},
    "moat": {"enemy": 0.7, "type": "defensive"}
}

BUILDING_INCOME = {
    "gold_mine": {"gold": 50, "food": 0},
    "oil_rig": {"gold": 0, "food": 100},
    "trade_post": {"gold": 30, "food": 30},
    "market": {"gold": 20, "food": 0},
    "farm": {"gold": 0, "food": 10},
    "workshop": {"gold": 15, "food": 0}
}

PACKAGES = {
    "starter": {
        "name": "🌟 پکیج شروع",
        "price_toman": 5000,
        "price_rial": 50000,
        "items": {"gold": 10000, "vikings": 20, "knights": 10, "archers": 15, "sword": 2, "shield": 2}
    },
    "offensive": {
        "name": "⚔️ پکیج تهاجمی",
        "price_toman": 15000,
        "price_rial": 150000,
        "items": {"gold": 30000, "catapult": 5, "war_elephant": 2, "alchemist": 8, "siege_tower": 3, "war_drum": 2}
    },
    "defensive": {
        "name": "🛡️ پکیج دفاعی",
        "price_toman": 15000,
        "price_rial": 150000,
        "items": {"gold": 30000, "wall": 3, "tower": 2, "moat": 2, "armor": 5, "shield": 5}
    },
    "gold": {
        "name": "💰 پکیج طلا",
        "price_toman": 10000,
        "price_rial": 100000,
        "items": {"gold": 50000}
    },
    "ultimate": {
        "name": "👑 پکیج نهایی",
        "price_toman": 50000,
        "price_rial": 500000,
        "items": {
            "gold": 150000,
            "vikings": 50,
            "knights": 30,
            "archers": 40,
            "catapult": 10,
            "war_elephant": 5,
            "alchemist": 15,
            "sword": 10,
            "shield": 10,
            "armor": 8,
            "war_drum": 5,
            "gold_mine": 2,
            "oil_rig": 2
        }
    }
}

# ==================== ساختار داده‌ها ====================
game_state = {
    "players": {},
    "alliances": {},
    "wars": [],  # جنگ‌های فعال بین کشورها
    "active_wars": {},  # {war_key: {"attacker": id, "defender": id, "start": time, "duration": 120}}
    "battles": [],
    "news": [],
    "statements": [],
    "waiting_for": {},
    "bot_start_time": time.time(),
    "online_users": set(),
    "banned_kingdoms": [],
    "card_requests": [],
    "referrals": {},
    "last_tax_collection": {},
    "transfers": [],
    "spy_requests": [],
    "admin_username": None,
    "payment_mode": "test"  # "test" or "real"
}

# ==================== توابع کمکی ====================
def save_data():
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            data = game_state.copy()
            data["online_users"] = list(game_state["online_users"])
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"خطا در ذخیره: {e}")

def load_data():
    global game_state
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
                if "online_users" in loaded:
                    loaded["online_users"] = set(loaded["online_users"])
                
                loaded.setdefault("statements", [])
                loaded.setdefault("waiting_for", {})
                loaded.setdefault("last_tax_collection", {})
                loaded.setdefault("transfers", [])
                loaded.setdefault("alliances", {})
                loaded.setdefault("battles", [])
                loaded.setdefault("news", [])
                loaded.setdefault("card_requests", [])
                loaded.setdefault("banned_kingdoms", [])
                loaded.setdefault("spy_requests", [])
                loaded.setdefault("active_wars", {})
                loaded.setdefault("admin_username", None)
                loaded.setdefault("payment_mode", "test")
                
                for pid, p in loaded.get("players", {}).items():
                    p.setdefault("catapult", 0)
                    p.setdefault("war_elephant", 0)
                    p.setdefault("alchemist", 0)
                    p.setdefault("sword", 0)
                    p.setdefault("lance", 0)
                    p.setdefault("longbow", 0)
                    p.setdefault("siege_tower", 0)
                    p.setdefault("war_drum", 0)
                    p.setdefault("shield", 0)
                    p.setdefault("armor", 0)
                    p.setdefault("wall", 0)
                    p.setdefault("tower", 0)
                    p.setdefault("moat", 0)
                    p.setdefault("gold_mine", 0)
                    p.setdefault("oil_rig", 0)
                    p.setdefault("trade_post", 0)
                    p.setdefault("happiness", 75)
                    p.setdefault("spy_quota", 0)  # سهمیه جاسوسی رایگان
                    p.setdefault("last_transfer_time", 0)  # آخرین زمان انتقال
                    p.setdefault("last_attack_time", 0)  # آخرین زمان حمله
                    
                game_state.update(loaded)
    except Exception as e:
        print(f"خطا در بارگذاری: {e}")
        save_data()

def calculate_happiness(player):
    happiness = 50
    happiness += player.get("taverns", 0) * 3
    happiness += player.get("hospitals", 0) * 2
    happiness += player.get("markets", 0) * 1
    happiness += player.get("trade_post", 0) * 2
    
    food_per_person = player["food"] / max(1, player["population"])
    if food_per_person > 2:
        happiness += 10
    elif food_per_person < 1:
        happiness -= 10
    
    gold_per_person = player["gold"] / max(1, player["population"])
    if gold_per_person > 100:
        happiness += 5
    elif gold_per_person < 10:
        happiness -= 5
    
    return max(0, min(100, happiness))

def calculate_power(player, units=None, is_attacker=True):
    if units is None:
        units = player
    
    base_power = 0
    for unit, count in units.items():
        if unit in UNIT_POWER and count:
            base_power += UNIT_POWER[unit] * count
    
    if is_attacker:
        if player.get("war_drum", 0) > 0:
            base_power *= (1 + 0.2 * player["war_drum"])
        
        for unit in ["vikings", "knights", "archers", "catapult"]:
            if unit == "vikings" and player.get("sword", 0) > 0:
                base_power += UNIT_POWER[unit] * units.get(unit, 0) * 0.5 * player["sword"]
            elif unit == "knights" and player.get("lance", 0) > 0:
                base_power += UNIT_POWER[unit] * units.get(unit, 0) * 0.5 * player["lance"]
            elif unit == "archers" and player.get("longbow", 0) > 0:
                base_power += UNIT_POWER[unit] * units.get(unit, 0) * 0.5 * player["longbow"]
            elif unit == "catapult" and player.get("siege_tower", 0) > 0:
                base_power += UNIT_POWER[unit] * units.get(unit, 0) * 0.8 * player["siege_tower"]
    
    return int(base_power)

def calculate_defense_power(player):
    base_power = calculate_power(player, is_attacker=False)
    
    defense_bonus = 1.0
    if player.get("wall", 0) > 0:
        defense_bonus += 0.2 * player["wall"]
    if player.get("tower", 0) > 0:
        defense_bonus += 0.3 * player["tower"]
    
    damage_reduction = 1.0
    if player.get("shield", 0) > 0:
        damage_reduction -= 0.1 * player["shield"]
    if player.get("armor", 0) > 0:
        damage_reduction -= 0.15 * player["armor"]
    
    damage_reduction = max(0.3, min(1.0, damage_reduction))
    
    return int(base_power * defense_bonus), damage_reduction

def get_player_alliance(player_id):
    for aid, alliance in game_state["alliances"].items():
        if str(player_id) in alliance["members"]:
            return aid, alliance
    return None, None

def calculate_income(player):
    gold_inc = 0
    food_inc = 0
    for building, income in BUILDING_INCOME.items():
        count = player.get(building, 0)
        gold_inc += income["gold"] * count
        food_inc += income["food"] * count
    return gold_inc, food_inc

def is_player_in_war(player_id):
    """بررسی اینکه آیا کشور در جنگی فعال شرکت دارد"""
    for key, war in game_state["active_wars"].items():
        if war["attacker"] == str(player_id) or war["defender"] == str(player_id):
            return True, war
    return False, None

def clean_expired_wars():
    """پاک کردن جنگ‌های منقضی شده"""
    now = time.time()
    expired = [key for key, war in game_state["active_wars"].items() if now - war["start"] > war["duration"]]
    for key in expired:
        del game_state["active_wars"][key]
    if expired:
        save_data()

def safe_send(chat_id, text, reply_markup=None):
    try:
        data = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
        if reply_markup:
            data["reply_markup"] = reply_markup
        response = requests.post(BASE_URL + "sendMessage", json=data, timeout=10)
        return response.json()
    except:
        return {"ok": False}

# ==================== کلاس اصلی ====================
class CrownCrossBot:
    def __init__(self):
        self.last_update_id = 0
        load_data()
        self.fetch_admin_username()
        print("⚔️ ماتریکس وار - نسخه نهایی")
        print(f"🔗 {BOT_LINK}")
        print(f"👥 {len(game_state['players'])} کشور")
        print(f"🏰 {len(game_state['alliances'])} اتحاد")
        print(f"💰 حالت پرداخت: {game_state['payment_mode']}")
    
    def fetch_admin_username(self):
        """دریافت یوزرنیم ادمین از طریق getChat"""
        try:
            result = self.api_request("getChat", {"chat_id": ADMIN_ID})
            if result.get("ok"):
                chat = result["result"]
                game_state["admin_username"] = chat.get("username")
                if game_state["admin_username"]:
                    print(f"👤 ادمین: @{game_state['admin_username']}")
                else:
                    print("⚠️ ادمین یوزرنیم ندارد!")
            else:
                print("⚠️ خطا در دریافت اطلاعات ادمین")
        except:
            print("⚠️ خطا در دریافت یوزرنیم ادمین")
    
    def api_request(self, method, data=None, max_retries=3):
        for attempt in range(max_retries):
            try:
                url = BASE_URL + method
                if data:
                    response = requests.post(url, json=data, timeout=20)
                else:
                    response = requests.get(url, timeout=20)
                return response.json()
            except:
                if attempt < max_retries - 1:
                    time.sleep(2)
        return {"ok": False}
    
    # ========== منوهای اصلی ==========
    def main_menu(self, user_id):
        if str(user_id) not in game_state["players"]:
            return None
        player = game_state["players"][str(user_id)]
        player["happiness"] = calculate_happiness(player)
        gold_inc, food_inc = calculate_income(player)
        offensive = calculate_power(player, is_attacker=True)
        defensive, _ = calculate_defense_power(player)
        aid, alliance = get_player_alliance(user_id)
        
        last_tax = game_state["last_tax_collection"].get(str(user_id), 0)
        tax_available = time.time() - last_tax >= 7 * 24 * 3600
        
        text = (
            f"✨ *{player['kingdom_name']}* ✨\n"
            f"👑 {player['player_name']}\n"
            f"🔹━━━━━━━━━━━━━━🔹\n"
            f"💰 طلا: {player['gold']:,}\n"
            f"🌾 غذا: {player['food']:,}\n"
            f"⚔️ قدرت تهاجمی: {offensive:,}\n"
            f"🛡️ قدرت دفاعی: {defensive:,}\n"
            f"😊 رضایت: {player['happiness']}%\n"
            f"🏰 اتحاد: {alliance['name'] if alliance else '⛔️ ندارد'}\n"
            f"👥 جمعیت: {player['population']:,}\n"
            f"📈 درآمد ساعتی: +{gold_inc} طلا, +{food_inc} غذا\n"
            f"🔸━━━━━━━━━━━━━━🔸\n"
            f"💰 مالیات: {'✅ قابل دریافت' if tax_available else '⏳ هفته آینده'}"
        )
        
        keyboard = [
            [{"text": "⚔️ ارتش", "callback_data": "menu_army"},
             {"text": "🏗️ ساختمان", "callback_data": "menu_build"}],
            [{"text": "🏰 اتحاد", "callback_data": "menu_alliance"},
             {"text": "🔥 نبرد", "callback_data": "menu_battle"}],
            [{"text": "💰 اقتصاد", "callback_data": "menu_economy"},
             {"text": "🏆 رتبه‌بندی", "callback_data": "menu_rank"}],
            [{"text": "💳 خرید", "callback_data": "menu_shop"},
             {"text": "📰 اخبار", "callback_data": "menu_news"}],
            [{"text": "📢 بیانیه", "callback_data": "menu_statement"},
             {"text": "🕵️ جاسوسی", "callback_data": "menu_spy"}],
            [{"text": "🤝 رفرال", "callback_data": "menu_referral"},
             {"text": "⚙️ تنظیمات", "callback_data": "menu_settings"}],
            [{"text": "🔄 تازه‌سازی", "callback_data": "refresh"}]
        ]
        if str(user_id) == str(ADMIN_ID):
            keyboard.append([{"text": "👑 پنل مدیریت", "callback_data": "menu_admin"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    # ========== ارتش و ساختمان (مشابه قبل) ==========
    def army_menu(self, user_id):
        player = game_state["players"][str(user_id)]
        text = (
            f"⚔️ *نیروهای نظامی* ⚔️\n"
            f"🔹━━━━━━━━━━━━━━🔹\n"
            f"🪓 وایکینگ: {player['vikings']} (قدرت {UNIT_POWER['vikings']})\n"
            f"🏇 شوالیه: {player['knights']} (قدرت {UNIT_POWER['knights']})\n"
            f"🏹 کماندار: {player['archers']} (قدرت {UNIT_POWER['archers']})\n"
            f"🏰 منجنیق: {player.get('catapult',0)} (قدرت {UNIT_POWER['catapult']})\n"
            f"🐘 فیل جنگی: {player.get('war_elephant',0)} (قدرت {UNIT_POWER['war_elephant']})\n"
            f"⚗️ کیمیاگر: {player.get('alchemist',0)} (قدرت {UNIT_POWER['alchemist']})\n"
            f"🔸━━━━━━━━━━━━━━🔸\n"
            f"⚔️ تجهیزات تهاجمی:\n"
            f"🗡️ شمشیر: {player.get('sword',0)}\n"
            f"🏇 نیزه: {player.get('lance',0)}\n"
            f"🏹 کمان بلند: {player.get('longbow',0)}\n"
            f"🏰 برج محاصره: {player.get('siege_tower',0)}\n"
            f"🥁 طبل جنگ: {player.get('war_drum',0)}\n"
            f"🔸━━━━━━━━━━━━━━🔸\n"
            f"🛡️ تجهیزات دفاعی:\n"
            f"🛡️ سپر: {player.get('shield',0)}\n"
            f"🛡️ زره: {player.get('armor',0)}\n"
            f"🧱 دیوار: {player.get('wall',0)}\n"
            f"🏯 برج دیدبانی: {player.get('tower',0)}\n"
            f"🌊 خندق: {player.get('moat',0)}"
        )
        keyboard = [
            [{"text": "🪓 آموزش وایکینگ", "callback_data": "train_units_vikings"}],
            [{"text": "🏇 آموزش شوالیه", "callback_data": "train_units_knights"}],
            [{"text": "🏹 آموزش کماندار", "callback_data": "train_units_archers"}],
            [{"text": "🏰 آموزش منجنیق", "callback_data": "train_units_catapult"}],
            [{"text": "🐘 آموزش فیل جنگی", "callback_data": "train_units_war_elephant"}],
            [{"text": "⚗️ آموزش کیمیاگر", "callback_data": "train_units_alchemist"}],
            [{"text": "⚔️ تجهیزات تهاجمی", "callback_data": "equipment_offensive"}],
            [{"text": "🛡️ تجهیزات دفاعی", "callback_data": "equipment_defensive"}],
            [{"text": "🔙 بازگشت", "callback_data": "back_main"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def equipment_offensive_menu(self, user_id):
        text = "⚔️ *تجهیزات تهاجمی* ⚔️"
        keyboard = [
            [{"text": f"🗡️ شمشیر ({PRICES['sword']} طلا)", "callback_data": "buy_equipment_sword"}],
            [{"text": f"🏇 نیزه ({PRICES['lance']} طلا)", "callback_data": "buy_equipment_lance"}],
            [{"text": f"🏹 کمان بلند ({PRICES['longbow']} طلا)", "callback_data": "buy_equipment_longbow"}],
            [{"text": f"🏰 برج محاصره ({PRICES['siege_tower']} طلا)", "callback_data": "buy_equipment_siege_tower"}],
            [{"text": f"🥁 طبل جنگ ({PRICES['war_drum']} طلا)", "callback_data": "buy_equipment_war_drum"}],
            [{"text": "🔙 بازگشت", "callback_data": "menu_army"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def equipment_defensive_menu(self, user_id):
        text = "🛡️ *تجهیزات دفاعی* 🛡️"
        keyboard = [
            [{"text": f"🛡️ سپر ({PRICES['shield']} طلا)", "callback_data": "buy_equipment_shield"}],
            [{"text": f"🛡️ زره ({PRICES['armor']} طلا)", "callback_data": "buy_equipment_armor"}],
            [{"text": f"🧱 دیوار ({PRICES['wall']} طلا)", "callback_data": "buy_equipment_wall"}],
            [{"text": f"🏯 برج دیدبانی ({PRICES['tower']} طلا)", "callback_data": "buy_equipment_tower"}],
            [{"text": f"🌊 خندق ({PRICES['moat']} طلا)", "callback_data": "buy_equipment_moat"}],
            [{"text": "🔙 بازگشت", "callback_data": "menu_army"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def build_menu(self, user_id):
        player = game_state["players"][str(user_id)]
        text = (
            f"🏗️ *ساختمان‌ها* 🏗️\n"
            f"🔹━━━━━━━━━━━━━━🔹\n"
            f"🏠 خانه: {player.get('houses',0)} (+۵۰ نفر)\n"
            f"🌾 مزرعه: {player.get('farms',0)} (+۱۰۰ غذا/ساعت)\n"
            f"⚒️ کارگاه: {player.get('workshops',0)} (+۱۵ طلا/ساعت)\n"
            f"🏥 بیمارستان: {player.get('hospitals',0)}\n"
            f"🍺 میخانه: {player.get('taverns',0)}\n"
            f"🏪 بازار: {player.get('markets',0)} (+۲۰ طلا/ساعت)\n"
            f"🏛️ پادگان: {player.get('barracks',0)}\n"
            f"⛏️ معدن طلا: {player.get('gold_mine',0)} (+۵۰ طلا/ساعت)\n"
            f"🛢️ دکل نفتی: {player.get('oil_rig',0)} (+۱۰۰ غذا/ساعت)\n"
            f"🏪 پست تجاری: {player.get('trade_post',0)} (+۳۰ طلا, +۳۰ غذا/ساعت)\n"
            f"🔸━━━━━━━━━━━━━━🔸"
        )
        keyboard = [
            [{"text": f"🏠 خانه ({PRICES['house']} طلا)", "callback_data": "build_house"}],
            [{"text": f"🌾 مزرعه ({PRICES['farm']} طلا)", "callback_data": "build_farm"}],
            [{"text": f"⚒️ کارگاه ({PRICES['workshop']} طلا)", "callback_data": "build_workshop"}],
            [{"text": f"🏥 بیمارستان ({PRICES['hospital']} طلا)", "callback_data": "build_hospital"}],
            [{"text": f"🍺 میخانه ({PRICES['tavern']} طلا)", "callback_data": "build_tavern"}],
            [{"text": f"🏪 بازار ({PRICES['market']} طلا)", "callback_data": "build_market"}],
            [{"text": f"🏛️ پادگان ({PRICES['barracks']} طلا)", "callback_data": "build_barracks"}],
            [{"text": f"⛏️ معدن طلا ({PRICES['gold_mine']} طلا)", "callback_data": "build_gold_mine"}],
            [{"text": f"🛢️ دکل نفتی ({PRICES['oil_rig']} طلا)", "callback_data": "build_oil_rig"}],
            [{"text": f"🏪 پست تجاری ({PRICES['trade_post']} طلا)", "callback_data": "build_trade_post"}],
            [{"text": "🔙 بازگشت", "callback_data": "back_main"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    # ========== اتحاد ==========
    def alliance_menu(self, user_id):
        aid, alliance = get_player_alliance(user_id)
        if not alliance:
            text = "🏰 شما عضو هیچ اتحادی نیستید."
            keyboard = [
                [{"text": "🏰 ایجاد اتحاد", "callback_data": "create_alliance"}],
                [{"text": "🔍 جستجوی اتحاد", "callback_data": "search_alliance"}],
                [{"text": "🔙 بازگشت", "callback_data": "back_main"}]
            ]
            return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
        
        is_leader = (alliance["leader_id"] == str(user_id))
        total_power = 0
        for member in alliance["members"]:
            if member in game_state["players"]:
                total_power += calculate_power(game_state["players"][member])
        
        text = (
            f"🏰 *{alliance['name']}*\n"
            f"🔹━━━━━━━━━━━━━━🔹\n"
            f"👥 اعضا: {len(alliance['members'])}\n"
            f"⚔️ قدرت کل: {total_power:,}\n"
            f"📅 تأسیس: {datetime.fromtimestamp(alliance['created_at']).strftime('%Y/%m/%d')}\n"
            f"🔸━━━━━━━━━━━━━━🔸"
        )
        
        keyboard = [
            [{"text": "👥 لیست اعضا", "callback_data": f"alliance_members_{aid}"}],
            [{"text": "💰 انتقال منابع", "callback_data": f"alliance_transfer_{aid}"}],
            [{"text": "⚔️ اعلان جنگ", "callback_data": f"alliance_war_{aid}"}]
        ]
        
        if is_leader:
            pending_count = len(alliance.get("pending_requests", []))
            keyboard.append([{"text": f"📨 درخواست‌ها ({pending_count})", "callback_data": f"alliance_requests_{aid}"}])
            keyboard.append([{"text": "✏️ تغییر نام", "callback_data": f"alliance_rename_{aid}"}])
        
        keyboard.append([{"text": "🚪 ترک اتحاد", "callback_data": f"alliance_leave_{aid}"}])
        keyboard.append([{"text": "🔙 بازگشت", "callback_data": "back_main"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def alliance_members_menu(self, user_id, aid):
        if aid not in game_state["alliances"]:
            return self.alliance_menu(user_id)
        alliance = game_state["alliances"][aid]
        text = "👥 *لیست اعضا*\n🔹━━━━━━━━━━━━━━🔹\n"
        for member in alliance["members"]:
            if member in game_state["players"]:
                p = game_state["players"][member]
                role = "👑" if member == alliance["leader_id"] else "👤"
                power = calculate_power(p)
                text += f"{role} {p['kingdom_name']} - قدرت {power}\n"
        keyboard = [[{"text": "🔙 بازگشت", "callback_data": f"alliance_back_{aid}"}]]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def alliance_requests_menu(self, user_id, aid):
        if aid not in game_state["alliances"]:
            return self.alliance_menu(user_id)
        alliance = game_state["alliances"][aid]
        if alliance["leader_id"] != str(user_id):
            return self.alliance_menu(user_id)
        
        pending = alliance.get("pending_requests", [])
        if not pending:
            text = "📨 هیچ درخواست عضویتی وجود ندارد."
            keyboard = [[{"text": "🔙 بازگشت", "callback_data": f"alliance_back_{aid}"}]]
            return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
        
        text = "📨 *درخواست‌های عضویت*"
        keyboard = []
        for req in pending:
            if req in game_state["players"]:
                p = game_state["players"][req]
                keyboard.append([
                    {"text": f"✅ {p['kingdom_name']}", "callback_data": f"alliance_accept_{aid}_{req}"},
                    {"text": f"❌ رد", "callback_data": f"alliance_reject_{aid}_{req}"}
                ])
        keyboard.append([{"text": "🔙 بازگشت", "callback_data": f"alliance_back_{aid}"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def alliance_war_menu(self, user_id, aid):
        if aid not in game_state["alliances"]:
            return self.alliance_menu(user_id)
        alliance = game_state["alliances"][aid]
        if alliance["leader_id"] != str(user_id):
            return self.alliance_menu(user_id)
        
        other_alliances = []
        for oaid, oalliance in game_state["alliances"].items():
            if oaid != aid:
                other_alliances.append((oaid, oalliance["name"], len(oalliance["members"])))
        
        if not other_alliances:
            text = "⚔️ هیچ اتحاد دیگری برای اعلان جنگ وجود ندارد."
            keyboard = [[{"text": "🔙 بازگشت", "callback_data": f"alliance_back_{aid}"}]]
            return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
        
        text = "⚔️ *اعلان جنگ*\nاتحاد مورد نظر را انتخاب کنید:"
        keyboard = []
        for oaid, name, members in other_alliances[:10]:
            keyboard.append([{"text": f"⚔️ {name} ({members} عضو)", "callback_data": f"alliance_declare_{aid}_{oaid}"}])
        keyboard.append([{"text": "🔙 بازگشت", "callback_data": f"alliance_back_{aid}"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def search_alliance_menu(self, user_id):
        alliances = []
        for aid, alliance in game_state["alliances"].items():
            if str(user_id) not in alliance["members"]:
                alliances.append((aid, alliance["name"], len(alliance["members"])))
        
        if not alliances:
            text = "🔍 هیچ اتحاد دیگری یافت نشد."
            keyboard = [[{"text": "🔙 بازگشت", "callback_data": "menu_alliance"}]]
            return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
        
        text = "🔍 *اتحادهای موجود*"
        keyboard = []
        for aid, name, members in alliances[:10]:
            keyboard.append([{"text": f"🏰 {name} ({members} عضو)", "callback_data": f"alliance_join_{aid}"}])
        keyboard.append([{"text": "🔙 بازگشت", "callback_data": "menu_alliance"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    # ========== نبرد با زمان‌بندی ==========
    def battle_menu(self, user_id):
        clean_expired_wars()
        in_war, war = is_player_in_war(user_id)
        if in_war:
            remaining = int(war["duration"] - (time.time() - war["start"]))
            other = war["attacker"] if war["defender"] == str(user_id) else war["defender"]
            other_name = game_state["players"].get(other, {}).get("kingdom_name", "نامشخص")
            text = (
                f"🔥 شما در جنگ با {other_name} هستید!\n"
                f"⏳ زمان باقی‌مانده: {remaining} ثانیه\n"
                f"تا پایان جنگ نمی‌توانید به کسی حمله کنید یا مورد حمله قرار بگیرید."
            )
            keyboard = [[{"text": "🔙 بازگشت", "callback_data": "back_main"}]]
            return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
        
        text = (
            "🔥 *میدان نبرد* 🔥\n"
            "برای حمله، کشور هدف را انتخاب کنید.\n"
            "پس از حمله، به مدت ۲ دقیقه در وضعیت جنگی قرار می‌گیرید و نمی‌توانید حمله جدیدی کنید."
        )
        
        players = []
        aid, _ = get_player_alliance(user_id)
        for pid, p in game_state["players"].items():
            if pid == str(user_id) or pid in game_state.get("banned_kingdoms", []):
                continue
            # بررسی اینکه کشور هدف در جنگ نباشد
            target_in_war, _ = is_player_in_war(pid)
            if target_in_war:
                continue
            p_aid, _ = get_player_alliance(pid)
            if aid and p_aid == aid:
                continue
            players.append((pid, p["kingdom_name"]))
        
        if not players:
            return {"text": "❌ هیچ کشور قابل حمله‌ای یافت نشد.", "reply_markup": {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": "back_main"}]]}}
        
        keyboard = []
        for pid, name in players[:5]:
            keyboard.append([{"text": f"⚔️ {name}", "callback_data": f"attack_select_{pid}"}])
        keyboard.append([{"text": "🔙 بازگشت", "callback_data": "back_main"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def attack_select_menu(self, user_id, target_id):
        player = game_state["players"][str(user_id)]
        target = game_state["players"][target_id]
        
        key = f"attack_{user_id}_{target_id}"
        if key not in game_state["waiting_for"]:
            game_state["waiting_for"][key] = {
                "vikings": 0, "knights": 0, "archers": 0,
                "catapult": 0, "war_elephant": 0, "alchemist": 0,
                "cancelable": True
            }
        selected = game_state["waiting_for"][key]
        
        selected_power = 0
        for unit, count in selected.items():
            if unit in UNIT_POWER and count:
                selected_power += UNIT_POWER[unit] * count
        
        def_power, _ = calculate_defense_power(target)
        
        if selected_power + def_power > 0:
            win_chance = (selected_power / (selected_power + def_power)) * 100
            win_chance = min(95, max(5, int(win_chance)))
        else:
            win_chance = 50
        
        text = (
            f"⚔️ *حمله به {target['kingdom_name']}*\n"
            f"🛡️ قدرت مدافع: {def_power:,}\n"
            f"🎲 شانس پیروزی تقریبی: {win_chance}%\n"
            f"🔹━━━━━━━━━━━━━━🔹\n"
            f"نیروهای انتخاب شده:\n"
            f"🪓 وایکینگ: {selected['vikings']}/{player['vikings']}\n"
            f"🏇 شوالیه: {selected['knights']}/{player['knights']}\n"
            f"🏹 کماندار: {selected['archers']}/{player['archers']}\n"
            f"🏰 منجنیق: {selected['catapult']}/{player.get('catapult',0)}\n"
            f"🐘 فیل جنگی: {selected['war_elephant']}/{player.get('war_elephant',0)}\n"
            f"⚗️ کیمیاگر: {selected['alchemist']}/{player.get('alchemist',0)}\n"
            f"🔸━━━━━━━━━━━━━━🔸\n"
            f"⚔️ قدرت انتخاب شده: {selected_power:,}"
        )
        
        keyboard = [
            [{"text": "🪓 وایکینگ", "callback_data": "noop"}],
            [{"text": "➖ ۵", "callback_data": f"adj_vikings_minus_{target_id}"},
             {"text": "➕ ۵", "callback_data": f"adj_vikings_plus_{target_id}"},
             {"text": "🔝 حداکثر", "callback_data": f"adj_vikings_max_{target_id}"}],
            
            [{"text": "🏇 شوالیه", "callback_data": "noop"}],
            [{"text": "➖ ۲", "callback_data": f"adj_knights_minus_{target_id}"},
             {"text": "➕ ۲", "callback_data": f"adj_knights_plus_{target_id}"},
             {"text": "🔝 حداکثر", "callback_data": f"adj_knights_max_{target_id}"}],
            
            [{"text": "🏹 کماندار", "callback_data": "noop"}],
            [{"text": "➖ ۳", "callback_data": f"adj_archers_minus_{target_id}"},
             {"text": "➕ ۳", "callback_data": f"adj_archers_plus_{target_id}"},
             {"text": "🔝 حداکثر", "callback_data": f"adj_archers_max_{target_id}"}],
            
            [{"text": "🏰 منجنیق", "callback_data": "noop"}],
            [{"text": "➖ ۱", "callback_data": f"adj_catapult_minus_{target_id}"},
             {"text": "➕ ۱", "callback_data": f"adj_catapult_plus_{target_id}"},
             {"text": "🔝 حداکثر", "callback_data": f"adj_catapult_max_{target_id}"}],
            
            [{"text": "🐘 فیل جنگی", "callback_data": "noop"}],
            [{"text": "➖ ۱", "callback_data": f"adj_elephant_minus_{target_id}"},
             {"text": "➕ ۱", "callback_data": f"adj_elephant_plus_{target_id}"},
             {"text": "🔝 حداکثر", "callback_data": f"adj_elephant_max_{target_id}"}],
            
            [{"text": "⚗️ کیمیاگر", "callback_data": "noop"}],
            [{"text": "➖ ۱", "callback_data": f"adj_alchemist_minus_{target_id}"},
             {"text": "➕ ۱", "callback_data": f"adj_alchemist_plus_{target_id}"},
             {"text": "🔝 حداکثر", "callback_data": f"adj_alchemist_max_{target_id}"}],
            
            [{"text": "✅ شروع نبرد", "callback_data": f"attack_confirm_{target_id}"}],
            [{"text": "❌ لغو و بازگشت", "callback_data": "menu_battle"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def execute_attack(self, attacker_id, defender_id, selected_units):
        attacker = game_state["players"][attacker_id]
        defender = game_state["players"][defender_id]
        
        # محاسبه قدرت
        attacker_power = 0
        for unit, count in selected_units.items():
            if unit in UNIT_POWER and count:
                base = UNIT_POWER[unit] * count
                if unit == "vikings":
                    base *= (1 + 0.5 * attacker.get("sword", 0))
                elif unit == "knights":
                    base *= (1 + 0.5 * attacker.get("lance", 0))
                elif unit == "archers":
                    base *= (1 + 0.5 * attacker.get("longbow", 0))
                elif unit == "catapult":
                    base *= (1 + 0.8 * attacker.get("siege_tower", 0))
                attacker_power += base
        attacker_power *= (1 + 0.2 * attacker.get("war_drum", 0))
        
        defender_power, damage_reduction = calculate_defense_power(defender)
        if defender.get("moat", 0) > 0:
            attacker_power = int(attacker_power * (1 - 0.3 * defender["moat"]))
        
        total_power = attacker_power + defender_power
        if total_power == 0:
            return "draw", 0, 0, 0, 0
        
        # شانس با کمی تصادفی
        attacker_chance = (attacker_power / total_power) * 0.7 + 0.15 + random.uniform(-0.1, 0.1)
        attacker_chance = max(0.1, min(0.9, attacker_chance))
        
        if random.random() < attacker_chance:
            winner = "attacker"
            winner_power = attacker_power
            loser_power = defender_power
        else:
            winner = "defender"
            winner_power = defender_power
            loser_power = attacker_power
        
        damage_ratio = min(0.8, loser_power / max(1, winner_power))
        
        # تلفات مدافع
        for unit in UNIT_POWER.keys():
            defender[unit] = max(0, defender.get(unit, 0) - int(defender.get(unit, 0) * damage_ratio * damage_reduction))
        
        # تلفات مهاجم
        for unit in selected_units:
            attacker[unit] = max(0, attacker.get(unit, 0) - int(selected_units[unit] * damage_ratio * 0.8))
        
        gold_loot = food_loot = 0
        if winner == "attacker":
            gold_loot = int(defender['gold'] * 0.15)
            food_loot = int(defender['food'] * 0.15)
            attacker['gold'] += gold_loot
            attacker['food'] += food_loot
            defender['gold'] -= gold_loot
            defender['food'] -= food_loot
        
        # ثبت جنگ فعال (مدت ۲ دقیقه)
        war_key = f"{min(attacker_id, defender_id)}_{max(attacker_id, defender_id)}"
        game_state["active_wars"][war_key] = {
            "attacker": attacker_id,
            "defender": defender_id,
            "start": time.time(),
            "duration": BATTLE_COOLDOWN
        }
        
        # ثبت نبرد
        battle = {
            "id": str(int(time.time())),
            "attacker": attacker_id,
            "defender": defender_id,
            "winner": winner,
            "attacker_power": int(attacker_power),
            "defender_power": int(defender_power),
            "gold_loot": gold_loot,
            "food_loot": food_loot,
            "time": time.time()
        }
        game_state["battles"].append(battle)
        if len(game_state["battles"]) > 100:
            game_state["battles"] = game_state["battles"][-100:]
        
        save_data()
        return winner, attacker_power, defender_power, gold_loot, food_loot
    
    # ========== جاسوسی ==========
    def spy_menu(self, user_id):
        text = (
            "🕵️ *جاسوسی*\n"
            f"با پرداخت {SPY_COST_TOMAN} تومان می‌توانید اطلاعاتی از یک کشور به دست آورید.\n"
            "اگر سهمیه جاسوسی رایگان دارید، می‌توانید بدون پرداخت استفاده کنید.\n"
            "کشور مورد نظر را انتخاب کنید:"
        )
        
        players = []
        for pid, p in game_state["players"].items():
            if pid != str(user_id) and pid not in game_state.get("banned_kingdoms", []):
                players.append((pid, p["kingdom_name"]))
        
        if not players:
            return {"text": "❌ هیچ کشوری برای جاسوسی وجود ندارد.", "reply_markup": {"inline_keyboard": [[{"text": "🔙 بازگشت", "callback_data": "back_main"}]]}}
        
        keyboard = []
        for pid, name in players[:5]:
            keyboard.append([{"text": f"🕵️ {name}", "callback_data": f"spy_select_{pid}"}])
        keyboard.append([{"text": "🔙 بازگشت", "callback_data": "back_main"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def spy_payment(self, user_id, target_id):
        player = game_state["players"][str(user_id)]
        # اگر سهمیه دارد
        if player.get("spy_quota", 0) > 0:
            player["spy_quota"] -= 1
            save_data()
            return "quota"
        
        # در غیر این صورت پرداخت
        target = game_state["players"][target_id]
        invoice = {
            "chat_id": user_id,
            "title": f"جاسوسی از {target['kingdom_name']}",
            "description": f"دریافت اطلاعات محرمانه از {target['kingdom_name']}",
            "payload": f"spy_{target_id}_{time.time()}",
            "provider_token": WALLET_TOKEN_REAL if game_state["payment_mode"] == "real" else WALLET_TOKEN_TEST,
            "start_parameter": "pay",
            "currency": "IRR",
            "prices": [{"label": "جاسوسی", "amount": SPY_COST_RIAL}]
        }
        result = self.api_request("sendInvoice", invoice)
        if result.get("ok"):
            return "invoice"
        return None
    
    def get_spy_info(self, target_id):
        """دریافت اطلاعات جاسوسی به صورت تصادفی و ناقص"""
        target = game_state["players"][target_id]
        info_parts = []
        
        # لیست بخش‌های اطلاعاتی
        sections = [
            ("💰 طلا", f"{target['gold']:,}"),
            ("🌾 غذا", f"{target['food']:,}"),
            ("⚔️ قدرت تهاجمی", f"{calculate_power(target, is_attacker=True):,}"),
            ("🛡️ قدرت دفاعی", f"{calculate_defense_power(target)[0]:,}"),
            ("😊 رضایت", f"{target['happiness']}%"),
            ("👥 جمعیت", f"{target['population']:,}"),
            ("🪓 وایکینگ", str(target['vikings'])),
            ("🏇 شوالیه", str(target['knights'])),
            ("🏹 کماندار", str(target['archers'])),
            ("🏰 منجنیق", str(target.get('catapult',0))),
            ("🐘 فیل جنگی", str(target.get('war_elephant',0))),
            ("⚗️ کیمیاگر", str(target.get('alchemist',0))),
        ]
        
        # انتخاب تصادفی ۴ تا ۶ بخش
        num = random.randint(4, 6)
        selected = random.sample(sections, num)
        
        info = f"🕵️ *اطلاعات جاسوسی از {target['kingdom_name']}*\n"
        info += "🔹━━━━━━━━━━━━━━🔹\n"
        for label, value in selected:
            info += f"{label}: {value}\n"
        info += "🔸━━━━━━━━━━━━━━🔸\n"
        info += "_بقیه اطلاعات توسط جاسوسان قابل شناسایی نبود._"
        
        return info
    
    # ========== رفرال ==========
    def referral_menu(self, user_id):
        ref_data = game_state["referrals"].get(str(user_id), {"count": 0, "bonus": 0})
        text = (
            f"🤝 *سیستم رفرال*\n"
            f"با دعوت دوستان خود پاداش بگیرید!\n"
            f"🔹━━━━━━━━━━━━━━🔹\n"
            f"👥 تعداد دعوت‌ها: {ref_data['count']}\n"
            f"💰 پاداش جمع‌آوری شده: {ref_data['bonus']}\n"
            f"🔸━━━━━━━━━━━━━━🔸\n"
            f"🔗 لینک دعوت شما:\n"
            f"{BOT_LINK}?start={user_id}"
        )
        keyboard = [
            [{"text": "💰 دریافت پاداش", "callback_data": "claim_referral_bonus"}],
            [{"text": "🔙 بازگشت", "callback_data": "back_main"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    # ========== انتقال منابع با زمان‌بندی ==========
    def transfer_outside_menu(self, user_id):
        player = game_state["players"][str(user_id)]
        now = time.time()
        last = player.get("last_transfer_time", 0)
        if now - last < TRANSFER_COOLDOWN:
            remaining = int(TRANSFER_COOLDOWN - (now - last))
            text = f"⏳ شما باید {remaining} ثانیه صبر کنید تا بتوانید دوباره انتقال دهید."
            keyboard = [[{"text": "🔙 بازگشت", "callback_data": "back_main"}]]
            return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
        
        text = "💰 *انتقال منابع به کشور دیگر*\nنام کشور مقصد را وارد کنید:"
        game_state["waiting_for"][str(user_id)] = {"type": "transfer_outside_name", "cancelable": True}
        save_data()
        keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def search_country_by_name(self, name):
        for pid, p in game_state["players"].items():
            if p["kingdom_name"].lower() == name.lower():
                return pid, p
        return None, None
    
    # ========== منوهای دیگر ==========
    def statement_menu(self, user_id):
        text = "📢 *ارسال بیانیه*\nمتن بیانیه خود را بنویسید:"
        game_state["waiting_for"][str(user_id)] = {"type": "statement", "cancelable": True}
        save_data()
        keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def news_menu(self, user_id):
        if not game_state.get("news", []):
            text = "📰 خبری منتشر نشده است."
        else:
            text = "📰 *آخرین اخبار* 📰\n🔹━━━━━━━━━━━━━━🔹\n"
            for news in game_state["news"][-5:]:
                text += f"*{news['title']}*\n{news['content']}\n📝 {news['author']} - {datetime.fromtimestamp(news['time']).strftime('%Y/%m/%d %H:%M')}\n🔸━━━━━━━━━━━━━━🔸\n"
        keyboard = [[{"text": "🔙 بازگشت", "callback_data": "back_main"}]]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def rank_menu(self, user_id):
        rankings = []
        for pid, p in game_state["players"].items():
            if pid not in game_state.get("banned_kingdoms", []):
                total_power = calculate_power(p) + calculate_defense_power(p)[0]
                rankings.append((p["kingdom_name"], total_power, p.get("gold", 0)))
        rankings.sort(key=lambda x: x[1], reverse=True)
        
        text = "🏆 *۱۰ کشور برتر* 🏆\n🔹━━━━━━━━━━━━━━🔹\n"
        for i, (name, power, gold) in enumerate(rankings[:10], 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            text += f"{medal} {name}\n   ⚔️ {power:,} | 💰 {gold:,}\n"
        keyboard = [[{"text": "🔙 بازگشت", "callback_data": "back_main"}]]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def economy_menu(self, user_id):
        player = game_state["players"][str(user_id)]
        last_tax = game_state["last_tax_collection"].get(str(user_id), 0)
        tax_available = time.time() - last_tax >= 7 * 24 * 3600
        tax_time = "✅ قابل دریافت" if tax_available else f"⏳ {7 - int((time.time() - last_tax) / 86400)} روز دیگر"
        gold_inc, food_inc = calculate_income(player)
        
        text = (
            f"💰 *اقتصاد* 💰\n"
            f"🔹━━━━━━━━━━━━━━🔹\n"
            f"طلای موجود: {player['gold']:,}\n"
            f"غذا: {player['food']:,}\n"
            f"جمعیت: {player['population']:,}\n"
            f"📈 درآمد ساعتی: +{gold_inc} طلا, +{food_inc} غذا\n"
            f"🔸━━━━━━━━━━━━━━🔸\n"
            f"💰 مالیات: {tax_time}"
        )
        keyboard = [
            [{"text": "💰 دریافت مالیات", "callback_data": "collect_tax"}],
            [{"text": "🌾 برداشت محصول", "callback_data": "harvest"}],
            [{"text": "💳 خرید طلا", "callback_data": "menu_shop"}],
            [{"text": "🌍 انتقال به کشور دیگر", "callback_data": "transfer_outside"}],
            [{"text": "🔙 بازگشت", "callback_data": "back_main"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def shop_menu(self, user_id):
        text = "💳 *فروشگاه* 💳\nپکیج‌های ویژه با پول واقعی:"
        keyboard = []
        for pid, pkg in PACKAGES.items():
            keyboard.append([{"text": f"{pkg['name']} - {pkg['price_toman']} تومان", "callback_data": f"buy_package_{pid}"}])
        keyboard.append([{"text": "💳 کارت به کارت", "callback_data": "card_payment"}])
        keyboard.append([{"text": "🔙 بازگشت", "callback_data": "back_main"}])
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def settings_menu(self, user_id):
        text = "⚙️ *تنظیمات* ⚙️"
        keyboard = [
            [{"text": "✏️ تغییر نام کشور", "callback_data": "rename_kingdom"}],
            [{"text": "🔙 بازگشت", "callback_data": "back_main"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    def admin_menu(self):
        war_status = "⚔️ روشن" if game_state.get("war_enabled", False) else "🕊️ خاموش"
        payment_status = "💰 واقعی" if game_state["payment_mode"] == "real" else "🧪 آزمایشی"
        text = f"👑 *پنل مدیریت* 👑\nوضعیت جنگ: {war_status}\nپرداخت: {payment_status}"
        keyboard = [
            [{"text": "⚔️ تغییر وضعیت جنگ", "callback_data": "admin_toggle_war"}],
            [{"text": "💳 تغییر حالت پرداخت", "callback_data": "admin_toggle_payment"}],
            [{"text": "📊 آمار کلی", "callback_data": "admin_stats"}],
            [{"text": "💰 کمک به همه", "callback_data": "admin_give_gold"}],
            [{"text": "🎁 پاداش ویژه", "callback_data": "admin_give_all"}],
            [{"text": "📰 ارسال خبر", "callback_data": "admin_news"}],
            [{"text": "🚫 بن کشور", "callback_data": "admin_ban"}],
            [{"text": "🕵️ افزودن سهمیه جاسوسی", "callback_data": "admin_add_spy"}],
            [{"text": "🔙 بازگشت", "callback_data": "back_main"}]
        ]
        return {"text": text, "reply_markup": {"inline_keyboard": keyboard}}
    
    # ========== هندلر Callback ==========
    def handle_callback(self, cb):
        data = cb["data"]
        user_id = cb["from"]["id"]
        callback_id = cb["id"]
        msg = cb["message"]
        chat_id = msg["chat"]["id"]
        msg_id = msg["message_id"]
        
        if str(user_id) in game_state.get("banned_kingdoms", []) and not data.startswith("admin_"):
            self.answer_callback(callback_id, "⛔️ شما از بازی بن شده‌اید.", True)
            return
        
        clean_expired_wars()
        
        # بازگشت به اصلی
        if data == "back_main":
            if str(user_id) in game_state["waiting_for"]:
                del game_state["waiting_for"][str(user_id)]
            to_delete = [k for k in game_state["waiting_for"] if k.startswith(f"attack_{user_id}_")]
            for k in to_delete:
                del game_state["waiting_for"][k]
            save_data()
            
            menu = self.main_menu(user_id)
            if menu:
                self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            else:
                self.send_message(chat_id, "ابتدا /start را بزنید.")
            self.answer_callback(callback_id)
            return
        
        if data == "refresh":
            menu = self.main_menu(user_id)
            if menu:
                self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id, "✅ تازه شد")
            return
        
        # منوهای اصلی
        menu_actions = {
            "menu_army": self.army_menu,
            "menu_build": self.build_menu,
            "menu_alliance": self.alliance_menu,
            "menu_battle": self.battle_menu,
            "menu_economy": self.economy_menu,
            "menu_rank": self.rank_menu,
            "menu_shop": self.shop_menu,
            "menu_news": self.news_menu,
            "menu_statement": self.statement_menu,
            "menu_spy": self.spy_menu,
            "menu_referral": self.referral_menu,
            "menu_settings": self.settings_menu,
        }
        if data in menu_actions:
            menu = menu_actions[data](user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data == "menu_admin":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            menu = self.admin_menu()
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data == "equipment_offensive":
            menu = self.equipment_offensive_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        if data == "equipment_defensive":
            menu = self.equipment_defensive_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        # آموزش نیروها
        if data.startswith("train_units_"):
            unit = data.split("_")[2]
            player = game_state["players"][str(user_id)]
            price = PRICES.get(unit, 0)
            if player["gold"] < price:
                self.answer_callback(callback_id, "❌ طلا کافی نیست", True)
                return
            player["gold"] -= price
            player[unit] = player.get(unit, 0) + 1
            save_data()
            self.answer_callback(callback_id, f"✅ یک {unit} آموزش داده شد")
            menu = self.army_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        # خرید تجهیزات
        if data.startswith("buy_equipment_"):
            equip = data.split("_")[2]
            player = game_state["players"][str(user_id)]
            price = PRICES.get(equip, 0)
            if player["gold"] < price:
                self.answer_callback(callback_id, "❌ طلا کافی نیست", True)
                return
            player["gold"] -= price
            player[equip] = player.get(equip, 0) + 1
            save_data()
            self.answer_callback(callback_id, f"✅ {equip} خریداری شد")
            menu = self.army_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        # ساخت ساختمان
        if data.startswith("build_"):
            building = data.split("_")[1]
            player = game_state["players"][str(user_id)]
            price = PRICES.get(building, 0)
            if player["gold"] < price:
                self.answer_callback(callback_id, "❌ طلا کافی نیست", True)
                return
            player["gold"] -= price
            player[building] = player.get(building, 0) + 1
            if building == "house":
                player["population"] += 50
            save_data()
            self.answer_callback(callback_id, f"✅ {building} ساخته شد")
            menu = self.build_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        # ========== اتحاد ==========
        if data == "search_alliance":
            menu = self.search_alliance_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("alliance_join_"):
            aid = data.split("_")[2]
            if aid not in game_state["alliances"]:
                self.answer_callback(callback_id, "❌ اتحاد وجود ندارد", True)
                return
            alliance = game_state["alliances"][aid]
            if str(user_id) in alliance["members"]:
                self.answer_callback(callback_id, "❌ شما عضو هستید", True)
                return
            
            if "pending_requests" not in alliance:
                alliance["pending_requests"] = []
            if str(user_id) in alliance["pending_requests"]:
                self.answer_callback(callback_id, "❌ قبلاً درخواست داده‌اید", True)
                return
            
            alliance["pending_requests"].append(str(user_id))
            save_data()
            leader_id = alliance["leader_id"]
            safe_send(int(leader_id), f"📨 درخواست عضویت جدید از {game_state['players'][str(user_id)]['kingdom_name']}")
            self.answer_callback(callback_id, "✅ درخواست شما ارسال شد")
            menu = self.alliance_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        if data.startswith("alliance_members_"):
            aid = data.split("_")[2]
            menu = self.alliance_members_menu(user_id, aid)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("alliance_back_"):
            aid = data.split("_")[2]
            menu = self.alliance_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("alliance_requests_"):
            aid = data.split("_")[2]
            menu = self.alliance_requests_menu(user_id, aid)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("alliance_accept_"):
            parts = data.split("_")
            aid = parts[2]
            req_id = parts[3]
            if aid not in game_state["alliances"]:
                self.answer_callback(callback_id, "❌ خطا", True)
                return
            alliance = game_state["alliances"][aid]
            if alliance["leader_id"] != str(user_id):
                self.answer_callback(callback_id, "❌ فقط رهبر", True)
                return
            if req_id not in alliance.get("pending_requests", []):
                self.answer_callback(callback_id, "❌ درخواست وجود ندارد", True)
                return
            
            alliance["pending_requests"].remove(req_id)
            alliance["members"].append(req_id)
            save_data()
            safe_send(int(req_id), f"✅ درخواست عضویت شما در {alliance['name']} پذیرفته شد.")
            self.answer_callback(callback_id, "✅ پذیرفته شد")
            menu = self.alliance_requests_menu(user_id, aid)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        if data.startswith("alliance_reject_"):
            parts = data.split("_")
            aid = parts[2]
            req_id = parts[3]
            if aid not in game_state["alliances"]:
                self.answer_callback(callback_id, "❌ خطا", True)
                return
            alliance = game_state["alliances"][aid]
            if alliance["leader_id"] != str(user_id):
                self.answer_callback(callback_id, "❌ فقط رهبر", True)
                return
            if req_id not in alliance.get("pending_requests", []):
                self.answer_callback(callback_id, "❌ درخواست وجود ندارد", True)
                return
            
            alliance["pending_requests"].remove(req_id)
            save_data()
            safe_send(int(req_id), f"❌ درخواست عضویت شما در {alliance['name']} رد شد.")
            self.answer_callback(callback_id, "❌ رد شد")
            menu = self.alliance_requests_menu(user_id, aid)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        if data.startswith("alliance_war_"):
            aid = data.split("_")[2]
            menu = self.alliance_war_menu(user_id, aid)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("alliance_declare_"):
            parts = data.split("_")
            aid = parts[2]
            oaid = parts[3]
            if aid not in game_state["alliances"] or oaid not in game_state["alliances"]:
                self.answer_callback(callback_id, "❌ خطا", True)
                return
            alliance = game_state["alliances"][aid]
            if alliance["leader_id"] != str(user_id):
                self.answer_callback(callback_id, "❌ فقط رهبر", True)
                return
            
            war_id = str(int(time.time()))
            war = {
                "id": war_id,
                "attacker_alliance": aid,
                "defender_alliance": oaid,
                "status": "active",
                "start_time": time.time(),
                "battles": []
            }
            game_state.setdefault("wars", []).append(war)
            save_data()
            
            for member in alliance["members"]:
                safe_send(int(member), f"⚔️ اتحاد شما به {game_state['alliances'][oaid]['name']} اعلان جنگ داد!")
            for member in game_state["alliances"][oaid]["members"]:
                safe_send(int(member), f"⚠️ اتحاد {game_state['alliances'][aid]['name']} به شما اعلان جنگ داد!")
            
            self.answer_callback(callback_id, "✅ جنگ اعلام شد")
            menu = self.alliance_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        if data.startswith("alliance_leave_"):
            aid = data.split("_")[2]
            if aid not in game_state["alliances"]:
                self.answer_callback(callback_id, "❌ خطا", True)
                return
            alliance = game_state["alliances"][aid]
            if str(user_id) not in alliance["members"]:
                self.answer_callback(callback_id, "❌ شما عضو نیستید", True)
                return
            
            if alliance["leader_id"] == str(user_id):
                for member in alliance["members"]:
                    safe_send(int(member), f"⚠️ اتحاد {alliance['name']} توسط رهبر منحل شد.")
                del game_state["alliances"][aid]
            else:
                alliance["members"].remove(str(user_id))
                safe_send(int(alliance["leader_id"]), f"👤 {game_state['players'][str(user_id)]['kingdom_name']} اتحاد را ترک کرد.")
            
            save_data()
            self.answer_callback(callback_id, "✅ شما از اتحاد خارج شدید")
            menu = self.alliance_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        # ========== نبرد ==========
        if data.startswith("attack_select_"):
            target_id = data.split("_")[2]
            menu = self.attack_select_menu(user_id, target_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("adj_"):
            parts = data.split("_")
            unit = parts[1]
            op = parts[2]
            target_id = parts[3]
            
            key = f"attack_{user_id}_{target_id}"
            if key not in game_state["waiting_for"]:
                self.answer_callback(callback_id, "❌ خطا", True)
                return
            selected = game_state["waiting_for"][key]
            player = game_state["players"][str(user_id)]
            
            max_available = player.get(unit, 0)
            current = selected.get(unit, 0)
            
            if op == "plus":
                selected[unit] = min(current + 1, max_available)
            elif op == "minus":
                selected[unit] = max(current - 1, 0)
            elif op == "max":
                selected[unit] = max_available
            
            game_state["waiting_for"][key] = selected
            save_data()
            
            menu = self.attack_select_menu(user_id, target_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("attack_confirm_"):
            target_id = data.split("_")[2]
            key = f"attack_{user_id}_{target_id}"
            if key not in game_state["waiting_for"]:
                self.answer_callback(callback_id, "❌ خطا: نیرویی انتخاب نشده", True)
                return
            
            selected = {k: v for k, v in game_state["waiting_for"][key].items() if k != "cancelable"}
            player = game_state["players"][str(user_id)]
            for unit, count in selected.items():
                if player.get(unit, 0) < count:
                    self.answer_callback(callback_id, f"❌ {unit} کافی نیست", True)
                    return
            
            winner, ap, dp, gold_loot, food_loot = self.execute_attack(str(user_id), target_id, selected)
            
            del game_state["waiting_for"][key]
            
            # پیام‌های جذاب
            attacker_name = player['kingdom_name']
            defender_name = game_state["players"][target_id]['kingdom_name']
            
            if winner == "attacker":
                result_text = (
                    f"🏆 *پیروزی شکوهمندانه!*\n\n"
                    f"⚔️ ارتش {attacker_name} با رشادت تمام، {defender_name} را در هم کوبید!\n"
                    f"📊 آمار نبرد:\n"
                    f"• قدرت مهاجم: {int(ap):,}\n"
                    f"• قدرت مدافع: {int(dp):,}\n"
                    f"💰 غنائم: {gold_loot} طلا و {food_loot} غذا\n\n"
                    f"🔥 نام {attacker_name} برای همیشه در تاریخ ثبت شد!"
                )
            elif winner == "defender":
                result_text = (
                    f"💔 *شکست در نبرد!*\n\n"
                    f"⚔️ ارتش {attacker_name} با وجود دلیری، در برابر مدافعان دلیر {defender_name} تاب نیاورد.\n"
                    f"📊 آمار نبرد:\n"
                    f"• قدرت مهاجم: {int(ap):,}\n"
                    f"• قدرت مدافع: {int(dp):,}\n"
                    f"🕊️ جنگجویان بسیاری جان باختند...\n\n"
                    f"اما هنوز فردا روز دیگریست!"
                )
            else:
                result_text = (
                    f"🤝 *نبرد مساوی!*\n\n"
                    f"⚔️ دو ارتش {attacker_name} و {defender_name} چنان جنگیدند که هیچ‌کس برتر نبود.\n"
                    f"📊 آمار نبرد:\n"
                    f"• قدرت مهاجم: {int(ap):,}\n"
                    f"• قدرت مدافع: {int(dp):,}\n"
                    f"🌫️ میدان جنگ پر از کشته‌شدگان است...\n\n"
                    f"شاید روزی دیگر..."
                )
            
            # اطلاع به مدافع
            safe_send(int(target_id), f"⚠️ *حمله به کشور شما!*\n\n{result_text}")
            
            self.send_message(user_id, result_text)
            menu = self.main_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        # ========== جاسوسی ==========
        if data.startswith("spy_select_"):
            target_id = data.split("_")[2]
            result = self.spy_payment(user_id, target_id)
            if result == "quota":
                info = self.get_spy_info(target_id)
                self.send_message(user_id, info)
                self.answer_callback(callback_id, "✅ از سهمیه شما استفاده شد")
            elif result == "invoice":
                self.answer_callback(callback_id, "✅ فاکتور جاسوسی ارسال شد")
            else:
                self.answer_callback(callback_id, "❌ خطا در ایجاد فاکتور", True)
            return
        
        # ========== رفرال ==========
        if data == "claim_referral_bonus":
            ref_data = game_state["referrals"].get(str(user_id), {"count": 0, "bonus": 0})
            bonus = ref_data["bonus"]
            if bonus <= 0:
                self.answer_callback(callback_id, "❌ پاداشی وجود ندارد", True)
                return
            game_state["players"][str(user_id)]["gold"] += bonus
            ref_data["bonus"] = 0
            save_data()
            self.answer_callback(callback_id, f"✅ {bonus} طلا دریافت شد")
            menu = self.referral_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        # ========== انتقال منابع خارج از اتحاد ==========
        if data == "transfer_outside":
            menu = self.transfer_outside_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            self.answer_callback(callback_id)
            return
        
        if data.startswith("transfer_confirm_"):
            parts = data.split("_")
            target_id = parts[2]
            amount = int(parts[3])
            key = f"transfer_{user_id}_{target_id}"
            if key in game_state["waiting_for"]:
                del game_state["waiting_for"][key]
            
            player = game_state["players"][str(user_id)]
            if player["gold"] < amount:
                self.answer_callback(callback_id, "❌ طلا کافی نیست", True)
                return
            
            now = time.time()
            last = player.get("last_transfer_time", 0)
            if now - last < TRANSFER_COOLDOWN:
                remaining = int(TRANSFER_COOLDOWN - (now - last))
                self.answer_callback(callback_id, f"⏳ {remaining} ثانیه دیگر صبر کنید", True)
                return
            
            fee = int(amount * TRANSFER_FEE)
            net = amount - fee
            player["gold"] -= amount
            game_state["players"][target_id]["gold"] += net
            player["last_transfer_time"] = now
            
            transfer = {
                "from": str(user_id),
                "to": target_id,
                "amount": amount,
                "net": net,
                "fee": fee,
                "time": now
            }
            game_state.setdefault("transfers", []).append(transfer)
            save_data()
            
            safe_send(int(target_id), f"💰 {net} طلا از طرف {player['kingdom_name']} به شما منتقل شد (کارمزد {fee})")
            self.answer_callback(callback_id, f"✅ {amount} طلا منتقل شد")
            menu = self.economy_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        # ========== خرید پکیج ==========
        if data.startswith("buy_package_"):
            pkg_id = data.split("_")[2]
            if pkg_id not in PACKAGES:
                self.answer_callback(callback_id, "❌ پکیج نامعتبر", True)
                return
            pkg = PACKAGES[pkg_id]
            token = WALLET_TOKEN_REAL if game_state["payment_mode"] == "real" else WALLET_TOKEN_TEST
            invoice = {
                "chat_id": user_id,
                "title": pkg["name"],
                "description": f"خرید پکیج {pkg['name']}",
                "payload": f"package_{pkg_id}_{time.time()}",
                "provider_token": token,
                "start_parameter": "pay",
                "currency": "IRR",
                "prices": [{"label": pkg["name"], "amount": pkg["price_rial"]}]
            }
            result = self.api_request("sendInvoice", invoice)
            if result.get("ok"):
                self.answer_callback(callback_id, "✅ فاکتور ارسال شد")
            else:
                self.answer_callback(callback_id, "❌ خطا", True)
            return
        
        # ========== کارت به کارت با لینک مستقیم به ادمین ==========
        if data == "card_payment":
            if game_state["admin_username"]:
                contact_link = f"https://t.me/{game_state['admin_username']}"
                text = f"💳 برای کارت به کارت، لطفاً به ادمین پیام دهید:\n{contact_link}"
                keyboard = [[{"text": "📨 پیام به ادمین", "url": contact_link}],
                            [{"text": "🔙 بازگشت", "callback_data": "back_main"}]]
                self.edit_message(chat_id, msg_id, text, {"inline_keyboard": keyboard})
            else:
                text = "💳 اطلاعات ادمین در دسترس نیست. لطفاً بعداً تلاش کنید."
                keyboard = [[{"text": "🔙 بازگشت", "callback_data": "back_main"}]]
                self.edit_message(chat_id, msg_id, text, {"inline_keyboard": keyboard})
            self.answer_callback(callback_id)
            return
        
        # ========== تغییر نام ==========
        if data == "rename_kingdom":
            player = game_state["players"][str(user_id)]
            if player["gold"] < PRICES["change_name"]:
                self.answer_callback(callback_id, "❌ طلا کافی نیست", True)
                return
            game_state["waiting_for"][str(user_id)] = {"type": "new_kingdom_name", "cancelable": True}
            save_data()
            keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
            self.send_message(user_id, "📝 نام جدید کشور را وارد کنید:", keyboard)
            self.answer_callback(callback_id)
            return
        
        # ========== ایجاد اتحاد ==========
        if data == "create_alliance":
            player = game_state["players"][str(user_id)]
            if player["gold"] < PRICES["create_alliance"]:
                self.answer_callback(callback_id, "❌ طلا کافی نیست", True)
                return
            game_state["waiting_for"][str(user_id)] = {"type": "alliance_name", "cancelable": True}
            save_data()
            keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
            self.send_message(user_id, "📝 نام اتحاد را وارد کنید:", keyboard)
            self.answer_callback(callback_id)
            return
        
        # ========== انتقال منابع درون اتحاد ==========
        if data.startswith("alliance_transfer_"):
            aid = data.split("_")[2]
            alliance = game_state["alliances"][aid]
            keyboard = []
            for member in alliance["members"]:
                if member != str(user_id):
                    name = game_state["players"][member]["kingdom_name"]
                    keyboard.append([{"text": f"👤 {name}", "callback_data": f"alliance_transfer_to_{member}_{aid}"}])
            keyboard.append([{"text": "❌ لغو", "callback_data": "back_main"}])
            self.edit_message(chat_id, msg_id, "💰 انتخاب کشور مقصد:", {"inline_keyboard": keyboard})
            self.answer_callback(callback_id)
            return
        
        if data.startswith("alliance_transfer_to_"):
            parts = data.split("_")
            target_id = parts[3]
            aid = parts[4]
            game_state["waiting_for"][str(user_id)] = {"type": "alliance_transfer_amount", "target_id": target_id, "alliance_id": aid, "cancelable": True}
            save_data()
            keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
            self.send_message(user_id, "💰 مقدار طلا برای انتقال را وارد کنید:", keyboard)
            self.answer_callback(callback_id)
            return
        
        # ========== اقتصاد ==========
        if data == "collect_tax":
            player = game_state["players"][str(user_id)]
            last_tax = game_state["last_tax_collection"].get(str(user_id), 0)
            if time.time() - last_tax < 7 * 24 * 3600:
                remaining = 7 - int((time.time() - last_tax) / 86400)
                self.answer_callback(callback_id, f"⏳ {remaining} روز دیگر", True)
                return
            
            tax = player["population"] * 10
            player["gold"] += tax
            game_state["last_tax_collection"][str(user_id)] = time.time()
            save_data()
            self.answer_callback(callback_id, f"💰 {tax} طلا مالیات هفتگی دریافت شد")
            menu = self.economy_menu(user_id)
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        if data == "harvest":
            player = game_state["players"][str(user_id)]
            harvest = player.get("farms", 0) * 150
            player["food"] += harvest
            save_data()
            self.answer_callback(callback_id, f"🌾 {harvest} غذا برداشت شد")
            return
        
        # ========== ادمین ==========
        if data == "admin_toggle_war":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            game_state["war_enabled"] = not game_state.get("war_enabled", False)
            save_data()
            self.answer_callback(callback_id, f"جنگ {'روشن' if game_state['war_enabled'] else 'خاموش'} شد")
            menu = self.admin_menu()
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        if data == "admin_toggle_payment":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            game_state["payment_mode"] = "real" if game_state["payment_mode"] == "test" else "test"
            save_data()
            self.answer_callback(callback_id, f"✅ حالت پرداخت: {game_state['payment_mode']}")
            menu = self.admin_menu()
            self.edit_message(chat_id, msg_id, menu["text"], menu["reply_markup"])
            return
        
        if data == "admin_stats":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            total_players = len(game_state["players"])
            total_gold = sum(p["gold"] for p in game_state["players"].values())
            total_power = sum(calculate_power(p) for p in game_state["players"].values())
            total_alliances = len(game_state.get("alliances", {}))
            text = (
                f"📊 *آمار کلی*\n"
                f"👥 کشورها: {total_players}\n"
                f"💰 کل طلا: {total_gold:,}\n"
                f"⚔️ کل قدرت: {total_power:,}\n"
                f"🏰 اتحادها: {total_alliances}\n"
                f"⚔️ نبردها: {len(game_state.get('battles', []))}\n"
                f"📰 اخبار: {len(game_state.get('news', []))}\n"
                f"🚫 بن شده‌ها: {len(game_state.get('banned_kingdoms', []))}"
            )
            self.send_message(chat_id, text)
            self.answer_callback(callback_id)
            return
        
        if data == "admin_give_gold":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            for p in game_state["players"].values():
                p["gold"] += 500
            save_data()
            self.answer_callback(callback_id, "✅ ۵۰۰ طلا به همه داده شد")
            return
        
        if data == "admin_give_all":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            for p in game_state["players"].values():
                p["gold"] += 1000
                p["food"] += 2000
            save_data()
            self.answer_callback(callback_id, "✅ پاداش همگانی داده شد")
            return
        
        if data == "admin_news":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            game_state["waiting_for"][str(user_id)] = {"type": "admin_news_title", "cancelable": True}
            save_data()
            keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
            self.send_message(chat_id, "📰 عنوان خبر را وارد کنید:", keyboard)
            self.answer_callback(callback_id)
            return
        
        if data == "admin_ban":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            game_state["waiting_for"][str(user_id)] = {"type": "admin_ban_name", "cancelable": True}
            save_data()
            keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
            self.send_message(chat_id, "🚫 نام کشور مورد نظر را وارد کنید:", keyboard)
            self.answer_callback(callback_id)
            return
        
        if data == "admin_add_spy":
            if user_id != ADMIN_ID:
                self.answer_callback(callback_id, "⛔️ دسترسی ندارید", True)
                return
            game_state["waiting_for"][str(user_id)] = {"type": "admin_spy_name", "cancelable": True}
            save_data()
            keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
            self.send_message(chat_id, "🕵️ نام کشور را برای افزودن سهمیه جاسوسی وارد کنید:")
            self.answer_callback(callback_id)
            return
        
        self.answer_callback(callback_id)
    
    def handle_message(self, msg):
        if "text" not in msg:
            if "successful_payment" in msg:
                user_id = msg["from"]["id"]
                payment = msg["successful_payment"]
                payload = payment.get("invoice_payload", "")
                
                if str(user_id) in game_state["players"]:
                    if payload.startswith("package_"):
                        pkg_id = payload.split("_")[1]
                        if pkg_id in PACKAGES:
                            pkg = PACKAGES[pkg_id]
                            for item, amount in pkg["items"].items():
                                if item == "gold":
                                    game_state["players"][str(user_id)]["gold"] += amount
                                else:
                                    game_state["players"][str(user_id)][item] = game_state["players"][str(user_id)].get(item, 0) + amount
                            self.send_message(user_id, f"✅ پکیج {pkg['name']} با موفقیت فعال شد!")
                    elif payload.startswith("spy_"):
                        target_id = payload.split("_")[1]
                        info = self.get_spy_info(target_id)
                        self.send_message(user_id, info)
                    else:
                        amount = payment["total_amount"] // 10
                        game_state["players"][str(user_id)]["gold"] += amount
                        self.send_message(user_id, f"✅ {amount} طلا به حساب شما اضافه شد.")
                    
                    save_data()
            return
        
        text = msg["text"]
        user_id = msg["from"]["id"]
        user_name = msg["from"].get("first_name", "کاربر")
        
        game_state["online_users"].add(user_id)
        
        if str(user_id) in game_state.get("waiting_for", {}):
            wait = game_state["waiting_for"][str(user_id)]
            
            if wait["type"] == "kingdom_name":
                if len(text) < 3:
                    self.send_message(user_id, "❌ حداقل ۳ حرف")
                    return
                
                game_state["players"][str(user_id)] = {
                    "player_name": user_name,
                    "kingdom_name": text,
                    "gold": 2000,
                    "food": 3000,
                    "vikings": 10,
                    "knights": 2,
                    "archers": 8,
                    "catapult": 0,
                    "war_elephant": 0,
                    "alchemist": 0,
                    "sword": 0,
                    "lance": 0,
                    "longbow": 0,
                    "siege_tower": 0,
                    "war_drum": 0,
                    "shield": 0,
                    "armor": 0,
                    "wall": 0,
                    "tower": 0,
                    "moat": 0,
                    "gold_mine": 0,
                    "oil_rig": 0,
                    "trade_post": 0,
                    "houses": 3,
                    "farms": 2,
                    "workshops": 0,
                    "hospitals": 0,
                    "taverns": 0,
                    "markets": 0,
                    "barracks": 0,
                    "population": 300,
                    "happiness": 75,
                    "spy_quota": 0,
                    "last_transfer_time": 0,
                    "last_attack_time": 0
                }
                
                welcome_msg = (
                    f"🎉 *به امپراتوری {text} خوش آمدید، شهریار {user_name}!*\n\n"
                    f"🌟 سرزمین شما با ۲۰۰۰ طلا و ۳۰۰۰ غذا کار خود را آغاز می‌کند.\n"
                    f"⚔️ ارتشی کوچک اما مصمم در اختیار دارید.\n"
                    f"🏗️ با ساختن بناها، اقتصاد خود را تقویت کنید.\n"
                    f"🔥 آماده نبرد با همسایگان شوید!\n\n"
                    f"باشد که نام شما در تاریخ جاودانه بماند..."
                )
                self.send_message(user_id, welcome_msg)
                
                if wait.get("referrer"):
                    ref = wait["referrer"]
                    if ref in game_state["players"]:
                        game_state["players"][ref]["gold"] += 500
                        game_state["players"][str(user_id)]["gold"] += 500
                        ref_data = game_state["referrals"].setdefault(ref, {"count": 0, "bonus": 0})
                        ref_data["count"] += 1
                        ref_data["bonus"] += 500
                        safe_send(int(ref), f"🎁 ۵۰۰ طلا پاداش دعوت + یک زیرمجموعه جدید به نام {text}")
                
                del game_state["waiting_for"][str(user_id)]
                save_data()
                
                menu = self.main_menu(user_id)
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                return
            
            elif wait["type"] == "new_kingdom_name":
                player = game_state["players"][str(user_id)]
                if player["gold"] < PRICES["change_name"]:
                    self.send_message(user_id, "❌ طلا کافی نیست")
                    return
                player["gold"] -= PRICES["change_name"]
                old_name = player["kingdom_name"]
                player["kingdom_name"] = text
                del game_state["waiting_for"][str(user_id)]
                save_data()
                self.send_message(user_id, f"✅ نام کشور شما از {old_name} به {text} تغییر یافت.")
                menu = self.main_menu(user_id)
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                return
            
            elif wait["type"] == "alliance_name":
                player = game_state["players"][str(user_id)]
                if player["gold"] < PRICES["create_alliance"]:
                    self.send_message(user_id, "❌ طلا کافی نیست")
                    return
                
                aid = str(int(time.time()))
                game_state["alliances"][aid] = {
                    "id": aid,
                    "name": text,
                    "leader_id": str(user_id),
                    "members": [str(user_id)],
                    "power": calculate_power(player),
                    "created_at": time.time(),
                    "pending_requests": []
                }
                player["gold"] -= PRICES["create_alliance"]
                del game_state["waiting_for"][str(user_id)]
                save_data()
                self.send_message(user_id, f"✅ اتحاد {text} با شکوه تمام ایجاد شد!")
                menu = self.alliance_menu(user_id)
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                return
            
            elif wait["type"] == "card_amount":
                try:
                    amount = int(text)
                    if amount < 1000:
                        self.send_message(user_id, "❌ حداقل ۱۰۰۰ تومان")
                        return
                    gold = amount * CARD_TO_GOLD_RATE
                    req = {
                        "user_id": str(user_id),
                        "name": game_state["players"][str(user_id)]["kingdom_name"],
                        "amount_toman": amount,
                        "amount_gold": gold,
                        "time": time.time()
                    }
                    game_state["card_requests"].append(req)
                    # به ادمین اطلاع داده می‌شود اما کاربر به پیوی ادمین هدایت می‌شود
                    if game_state["admin_username"]:
                        admin_link = f"https://t.me/{game_state['admin_username']}"
                        text = f"✅ درخواست شما ثبت شد. لطفاً برای ادامه به ادمین پیام دهید:\n{admin_link}"
                        keyboard = [[{"text": "📨 پیام به ادمین", "url": admin_link}],
                                    [{"text": "🔙 بازگشت", "callback_data": "back_main"}]]
                        self.send_message(user_id, text, {"inline_keyboard": keyboard})
                    else:
                        self.send_message(user_id, "✅ درخواست شما ثبت شد. ادمین به زودی با شما تماس می‌گیرد.")
                    
                    del game_state["waiting_for"][str(user_id)]
                    save_data()
                except:
                    self.send_message(user_id, "❌ لطفاً عدد وارد کنید")
                return
            
            elif wait["type"] == "alliance_transfer_amount":
                try:
                    amount = int(text)
                    if amount <= 0:
                        self.send_message(user_id, "❌ عدد مثبت وارد کنید")
                        return
                    player = game_state["players"][str(user_id)]
                    if player["gold"] < amount:
                        self.send_message(user_id, "❌ طلا کافی نیست")
                        return
                    
                    target_id = wait["target_id"]
                    aid = wait["alliance_id"]
                    
                    if target_id not in game_state["players"]:
                        return
                    
                    now = time.time()
                    last = player.get("last_transfer_time", 0)
                    if now - last < TRANSFER_COOLDOWN:
                        remaining = int(TRANSFER_COOLDOWN - (now - last))
                        self.send_message(user_id, f"⏳ {remaining} ثانیه دیگر صبر کنید")
                        return
                    
                    fee = int(amount * TRANSFER_FEE)
                    net = amount - fee
                    
                    player["gold"] -= amount
                    player["last_transfer_time"] = now
                    game_state["players"][target_id]["gold"] += net
                    
                    transfer = {
                        "from": str(user_id),
                        "to": target_id,
                        "amount": amount,
                        "net": net,
                        "fee": fee,
                        "time": now
                    }
                    game_state.setdefault("transfers", []).append(transfer)
                    
                    safe_send(int(target_id), f"💰 {net} طلا از طرف {player['kingdom_name']} در اتحاد به شما منتقل شد (کارمزد {fee})")
                    
                    del game_state["waiting_for"][str(user_id)]
                    save_data()
                    self.send_message(user_id, f"✅ {amount} طلا به {game_state['players'][target_id]['kingdom_name']} منتقل شد (کارمزد {fee})")
                    menu = self.alliance_menu(user_id)
                    self.send_message(user_id, menu["text"], menu["reply_markup"])
                except:
                    self.send_message(user_id, "❌ عدد وارد کنید")
                return
            
            elif wait["type"] == "transfer_outside_name":
                target_id, target = self.search_country_by_name(text)
                if not target_id:
                    self.send_message(user_id, "❌ کشوری با این نام یافت نشد.")
                    return
                
                if target_id == str(user_id):
                    self.send_message(user_id, "❌ نمی‌توانید به خودتان انتقال دهید.")
                    return
                
                key = f"transfer_{user_id}_{target_id}"
                game_state["waiting_for"][key] = {"target": target_id, "step": "amount", "cancelable": True}
                del game_state["waiting_for"][str(user_id)]
                save_data()
                
                keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
                self.send_message(user_id, f"💰 مقدار طلا برای انتقال به {target['kingdom_name']} را وارد کنید (حداکثر {game_state['players'][str(user_id)]['gold']}):", keyboard)
                return
            
            elif wait.get("step") == "amount" and wait.get("target"):
                try:
                    amount = int(text)
                    if amount <= 0:
                        self.send_message(user_id, "❌ عدد مثبت وارد کنید")
                        return
                    player = game_state["players"][str(user_id)]
                    if player["gold"] < amount:
                        self.send_message(user_id, "❌ طلا کافی نیست")
                        return
                    
                    target_id = wait["target"]
                    
                    now = time.time()
                    last = player.get("last_transfer_time", 0)
                    if now - last < TRANSFER_COOLDOWN:
                        remaining = int(TRANSFER_COOLDOWN - (now - last))
                        self.send_message(user_id, f"⏳ {remaining} ثانیه دیگر صبر کنید")
                        return
                    
                    fee = int(amount * TRANSFER_FEE)
                    net = amount - fee
                    
                    player["gold"] -= amount
                    player["last_transfer_time"] = now
                    game_state["players"][target_id]["gold"] += net
                    
                    transfer = {
                        "from": str(user_id),
                        "to": target_id,
                        "amount": amount,
                        "net": net,
                        "fee": fee,
                        "time": now
                    }
                    game_state.setdefault("transfers", []).append(transfer)
                    
                    safe_send(int(target_id), f"💰 {net} طلا از طرف {player['kingdom_name']} به شما منتقل شد (کارمزد {fee})")
                    
                    key = f"transfer_{user_id}_{target_id}"
                    if key in game_state["waiting_for"]:
                        del game_state["waiting_for"][key]
                    save_data()
                    self.send_message(user_id, f"✅ {amount} طلا به {game_state['players'][target_id]['kingdom_name']} منتقل شد (کارمزد {fee})")
                    menu = self.economy_menu(user_id)
                    self.send_message(user_id, menu["text"], menu["reply_markup"])
                except:
                    self.send_message(user_id, "❌ عدد وارد کنید")
                return
            
            elif wait["type"] == "statement":
                statement = {
                    "id": str(int(time.time())),
                    "author": game_state["players"][str(user_id)]["kingdom_name"],
                    "content": text,
                    "time": time.time()
                }
                game_state.setdefault("statements", []).append(statement)
                
                for pid in game_state["players"]:
                    safe_send(int(pid), f"📢 *بیانیه از {statement['author']}*\n\n{text}")
                
                del game_state["waiting_for"][str(user_id)]
                save_data()
                self.send_message(user_id, "✅ بیانیه شما برای همه ارسال شد.")
                menu = self.main_menu(user_id)
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                return
            
            elif wait["type"] == "admin_news_title":
                game_state["waiting_for"][str(user_id)] = {"type": "admin_news_content", "title": text, "cancelable": True}
                save_data()
                keyboard = [[{"text": "❌ لغو", "callback_data": "back_main"}]]
                self.send_message(user_id, "📝 متن خبر را وارد کنید:", keyboard)
                return
            
            elif wait["type"] == "admin_news_content":
                title = wait["title"]
                content = text
                news = {
                    "id": str(int(time.time())),
                    "title": title,
                    "content": content,
                    "author": "مدیریت",
                    "time": time.time()
                }
                game_state.setdefault("news", []).append(news)
                
                for pid in game_state["players"]:
                    safe_send(int(pid), f"📰 *{title}*\n\n{content}\n- مدیریت")
                
                del game_state["waiting_for"][str(user_id)]
                save_data()
                self.send_message(user_id, "✅ خبر منتشر شد.")
                menu = self.admin_menu()
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                return
            
            elif wait["type"] == "admin_ban_name":
                target_name = text
                target_id = None
                for pid, p in game_state["players"].items():
                    if p["kingdom_name"].lower() == target_name.lower():
                        target_id = pid
                        break
                if not target_id:
                    self.send_message(user_id, "❌ کشور یافت نشد")
                    return
                
                game_state.setdefault("banned_kingdoms", []).append(target_id)
                safe_send(int(target_id), "🚫 شما از بازی بن شده‌اید.")
                
                del game_state["waiting_for"][str(user_id)]
                save_data()
                self.send_message(user_id, f"✅ کشور {target_name} بن شد.")
                menu = self.admin_menu()
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                return
            
            elif wait["type"] == "admin_spy_name":
                target_name = text
                target_id = None
                for pid, p in game_state["players"].items():
                    if p["kingdom_name"].lower() == target_name.lower():
                        target_id = pid
                        break
                if not target_id:
                    self.send_message(user_id, "❌ کشور یافت نشد")
                    return
                
                game_state["players"][target_id]["spy_quota"] = game_state["players"][target_id].get("spy_quota", 0) + 1
                save_data()
                self.send_message(user_id, f"✅ یک سهمیه جاسوسی به {target_name} اضافه شد.")
                menu = self.admin_menu()
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                del game_state["waiting_for"][str(user_id)]
                return
        
        if text.startswith("/start"):
            if str(user_id) in game_state["players"]:
                if str(user_id) in game_state.get("banned_kingdoms", []):
                    self.send_message(user_id, "🚫 شما از بازی بن شده‌اید.")
                    return
                menu = self.main_menu(user_id)
                self.send_message(user_id, menu["text"], menu["reply_markup"])
                return
            
            parts = text.split()
            referrer = parts[1] if len(parts) > 1 and parts[1].isdigit() else None
            game_state["waiting_for"][str(user_id)] = {"type": "kingdom_name", "referrer": referrer, "cancelable": False}
            save_data()
            self.send_message(user_id, "⚔️ به جنگ ماتریکس خوش آمدید!\n📝 نام کشور خود را وارد کنید:")
    
    def edit_message(self, chat_id, message_id, text, reply_markup=None):
        data = {"chat_id": chat_id, "message_id": message_id, "text": text, "parse_mode": "HTML"}
        if reply_markup:
            data["reply_markup"] = reply_markup
        return self.api_request("editMessageText", data)
    
    def answer_callback(self, callback_id, text="", alert=False):
        return self.api_request("answerCallbackQuery", {
            "callback_query_id": callback_id,
            "text": text,
            "show_alert": alert
        })
    
    def send_message(self, chat_id, text, reply_markup=None):
        data = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
        if reply_markup:
            data["reply_markup"] = reply_markup
        return self.api_request("sendMessage", data)
    
    def apply_hourly_income(self):
        for pid, p in game_state["players"].items():
            gold_inc, food_inc = calculate_income(p)
            p["gold"] += gold_inc
            p["food"] += food_inc
        save_data()
        print(f"💰 درآمد ساعتی به {len(game_state['players'])} کشور اعمال شد.")

    def income_ticker_thread(self):
        while True:
            time.sleep(3600)
            try:
                self.apply_hourly_income()
            except Exception as e:
                print(f"⚠️ خطا در درآمد ساعتی: {e}")

    def run(self):
        print("🤖 بات در حال اجراست...")
        last_income_time = time.time()
        
        while True:
            try:
                if time.time() - last_income_time >= 3600:
                    self.apply_hourly_income()
                    last_income_time = time.time()
                
                updates = self.api_request("getUpdates", {
                    "offset": self.last_update_id + 1,
                    "timeout": 60
                })
                if updates.get("ok"):
                    for update in updates.get("result", []):
                        self.last_update_id = update["update_id"]
                        if "message" in update:
                            self.handle_message(update["message"])
                        elif "callback_query" in update:
                            self.handle_callback(update["callback_query"])
                        elif "pre_checkout_query" in update:
                            self.api_request("answerPreCheckoutQuery", {
                                "pre_checkout_query_id": update["pre_checkout_query"]["id"],
                                "ok": True
                            })
                time.sleep(0.1)
            except KeyboardInterrupt:
                print("\n🛑 بات متوقف شد")
                save_data()
                break
            except Exception as e:
                print(f"⚠️ خطا: {e}")
                time.sleep(5)

if __name__ == "__main__":
    bot = CrownCrossBot()
    bot.run()