import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import time
import sqlite3
import requests
from datetime import datetime

TOKEN = "{{BOT_TOKEN}}"
BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
ADMIN_ID = {{ADMIN_ID}}
ADMIN_CMD = "{{ADMIN_CMD}}"
DB_NAME = "custom_bot.db"

# ==================== دیتابیس ====================
def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("""CREATE TABLE IF NOT EXISTS buttons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        label TEXT, response_text TEXT DEFAULT '',
        photo_file_id TEXT DEFAULT '', position INTEGER DEFAULT 0)""")
    conn.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('welcome_text', 'به بات خوش اومدی 🌹')")
    conn.commit()
    conn.close()

def get_setting(key, default=""):
    r = db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r and r["value"] else default

def set_setting(key, value):
    conn = db()
    conn.execute("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    conn.commit()
    conn.close()

def get_buttons():
    return db().execute("SELECT * FROM buttons ORDER BY position, id").fetchall()

def get_button_by_label(label):
    return db().execute("SELECT * FROM buttons WHERE label=?", (label,)).fetchone()

def get_button_by_id(bid):
    return db().execute("SELECT * FROM buttons WHERE id=?", (bid,)).fetchone()

def add_button(label, response_text, photo_file_id=""):
    conn = db()
    pos = db().execute("SELECT COALESCE(MAX(position),0)+1 p FROM buttons").fetchone()["p"]
    conn.execute("INSERT INTO buttons (label, response_text, photo_file_id, position) VALUES (?,?,?,?)", (label, response_text, photo_file_id, pos))
    conn.commit()
    conn.close()

def update_button_response(bid, response_text, photo_file_id=""):
    conn = db()
    conn.execute("UPDATE buttons SET response_text=?, photo_file_id=? WHERE id=?", (response_text, photo_file_id, bid))
    conn.commit()
    conn.close()

def delete_button(bid):
    conn = db()
    conn.execute("DELETE FROM buttons WHERE id=?", (bid,))
    conn.commit()
    conn.close()

# ==================== API بله ====================
def api_request(method, data=None, max_retries=3):
    for attempt in range(max_retries):
        try:
            url = BASE_URL + method
            r = requests.post(url, json=data, timeout=20) if data else requests.get(url, timeout=20)
            return r.json()
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(2)
    return {"ok": False}

def send_message(chat_id, text, keyboard=None):
    data = {"chat_id": chat_id, "text": text}
    if keyboard:
        data["reply_markup"] = keyboard
    return api_request("sendMessage", data)

def send_photo(chat_id, file_id, caption=None, keyboard=None):
    data = {"chat_id": chat_id, "photo": file_id}
    if caption:
        data["caption"] = caption
    if keyboard:
        data["reply_markup"] = keyboard
    return api_request("sendPhoto", data)

def is_admin(user_id):
    return int(user_id) == int(ADMIN_ID)

# ==================== کیبوردها ====================
CANCEL_KB = {"keyboard": [[{"text": "❌ انصراف"}]], "resize_keyboard": True}

def user_keyboard():
    btns = get_buttons()
    rows, row = [], []
    for b in btns:
        row.append({"text": b["label"]})
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    if not rows:
        rows = [[{"text": "هنوز دکمه‌ای تنظیم نشده"}]]
    return {"keyboard": rows, "resize_keyboard": True}

def admin_keyboard():
    return {"keyboard": [
        [{"text": "➕ افزودن دکمه"}],
        [{"text": "📋 لیست دکمه‌ها"}],
        [{"text": "✏️ ویرایش دکمه"}, {"text": "🗑 حذف دکمه"}],
        [{"text": "✏️ تنظیم پیام خوش‌آمد"}],
        [{"text": "🔙 بازگشت به منوی کاربر"}],
    ], "resize_keyboard": True}

# ==================== حالت‌های در انتظار ====================
waiting_for = {}

def buttons_list_text():
    btns = get_buttons()
    if not btns:
        return "📭 هنوز هیچ دکمه‌ای اضافه نشده."
    out = "📋 لیست دکمه‌ها:\n"
    for b in btns:
        has_photo = "🖼" if b["photo_file_id"] else ""
        out += f"\n#{b['id']} {b['label']} {has_photo}"
    return out

def handle_admin_flow(chat_id, text, msg):
    key = str(chat_id)
    wait = waiting_for.get(key)

    if text == "❌ انصراف" and wait:
        del waiting_for[key]
        send_message(chat_id, "لغو شد.", admin_keyboard())
        return True

    if not wait:
        return False
    wtype = wait["type"]

    if wtype == "add_label":
        if get_button_by_label(text):
            send_message(chat_id, "❌ دکمه‌ای با این متن از قبل هست. یه متن دیگه بفرست:", CANCEL_KB)
            return True
        wait["label"] = text
        wait["type"] = "add_response"
        send_message(chat_id, "📝 متن پاسخ این دکمه رو بفرست:", CANCEL_KB)
        return True

    if wtype == "add_response":
        wait["response"] = text
        wait["type"] = "add_photo"
        send_message(chat_id, "🖼 اگه می‌خوای عکس هم به پاسخ اضافه بشه بفرستش، وگرنه بفرست: -", CANCEL_KB)
        return True

    if wtype == "add_photo":
        photo_id = ""
        if msg.get("photo"):
            photo_id = msg["photo"][-1]["file_id"]
        elif text.strip() != "-":
            send_message(chat_id, "❌ یا عکس بفرست یا فقط علامت - رو بفرست:", CANCEL_KB)
            return True
        add_button(wait["label"], wait["response"], photo_id)
        del waiting_for[key]
        send_message(chat_id, f"✅ دکمه «{wait['label']}» اضافه شد.", admin_keyboard())
        return True

    if wtype == "edit_id":
        if not text.isdigit() or not get_button_by_id(int(text)):
            send_message(chat_id, "❌ شماره دکمه معتبر نیست:", CANCEL_KB)
            return True
        wait["bid"] = int(text)
        wait["type"] = "edit_response"
        send_message(chat_id, "📝 متن پاسخ جدید رو بفرست:", CANCEL_KB)
        return True

    if wtype == "edit_response":
        wait["response"] = text
        wait["type"] = "edit_photo"
        send_message(chat_id, "🖼 عکس جدید بفرست، یا برای بدون‌عکس بفرست: -", CANCEL_KB)
        return True

    if wtype == "edit_photo":
        photo_id = ""
        if msg.get("photo"):
            photo_id = msg["photo"][-1]["file_id"]
        elif text.strip() != "-":
            send_message(chat_id, "❌ یا عکس بفرست یا فقط علامت - رو بفرست:", CANCEL_KB)
            return True
        update_button_response(wait["bid"], wait["response"], photo_id)
        del waiting_for[key]
        send_message(chat_id, "✅ دکمه ویرایش شد.", admin_keyboard())
        return True

    if wtype == "delete_id":
        del waiting_for[key]
        if not text.isdigit() or not get_button_by_id(int(text)):
            send_message(chat_id, "❌ شماره دکمه معتبر نیست.", admin_keyboard())
            return True
        delete_button(int(text))
        send_message(chat_id, "✅ دکمه حذف شد.", admin_keyboard())
        return True

    if wtype == "set_welcome":
        set_setting("welcome_text", text)
        del waiting_for[key]
        send_message(chat_id, "✅ پیام خوش‌آمد ذخیره شد.", admin_keyboard())
        return True

    return False


def handle_admin_menu(chat_id, text):
    key = str(chat_id)

    if text == ADMIN_CMD:
        send_message(chat_id, "👑 پنل مدیریت بات سفارشی", admin_keyboard())
        return True
    if text == "🔙 بازگشت به منوی کاربر":
        send_message(chat_id, "برگشتی به منوی کاربر.", user_keyboard())
        return True
    if text == "➕ افزودن دکمه":
        waiting_for[key] = {"type": "add_label"}
        send_message(chat_id, "📝 متن (لیبل) دکمه‌ی جدید رو بفرست:", CANCEL_KB)
        return True
    if text == "📋 لیست دکمه‌ها":
        send_message(chat_id, buttons_list_text(), admin_keyboard())
        return True
    if text == "✏️ ویرایش دکمه":
        waiting_for[key] = {"type": "edit_id"}
        send_message(chat_id, "شماره دکمه (#) رو بفرست:\n\n" + buttons_list_text(), CANCEL_KB)
        return True
    if text == "🗑 حذف دکمه":
        waiting_for[key] = {"type": "delete_id"}
        send_message(chat_id, "شماره دکمه (#) که می‌خوای حذف بشه رو بفرست:\n\n" + buttons_list_text(), CANCEL_KB)
        return True
    if text == "✏️ تنظیم پیام خوش‌آمد":
        waiting_for[key] = {"type": "set_welcome"}
        send_message(chat_id, f"متن فعلی:\n\n{get_setting('welcome_text')}\n\nمتن جدید رو بفرست:", CANCEL_KB)
        return True
    return False


def handle_message(msg):
    chat_id = msg["chat"]["id"]
    text = msg.get("text", "") or ""

    if is_admin(chat_id):
        if handle_admin_flow(chat_id, text, msg):
            return
        if handle_admin_menu(chat_id, text):
            return

    if text == "/start":
        send_message(chat_id, get_setting("welcome_text"), user_keyboard())
        if is_admin(chat_id):
            send_message(chat_id, f"👑 برای پنل مدیریت دستور {ADMIN_CMD} رو بفرست.")
        return

    btn = get_button_by_label(text)
    if btn:
        if btn["photo_file_id"]:
            send_photo(chat_id, btn["photo_file_id"], caption=btn["response_text"] or None, keyboard=user_keyboard())
        else:
            send_message(chat_id, btn["response_text"] or "(پاسخی تنظیم نشده)", user_keyboard())
        return

    send_message(chat_id, get_setting("welcome_text"), user_keyboard())


def run():
    last_update_id = 0
    while True:
        try:
            updates = api_request("getUpdates", {"offset": last_update_id + 1, "timeout": 30})
            if updates.get("ok"):
                for update in updates.get("result", []):
                    last_update_id = update["update_id"]
                    try:
                        if "message" in update:
                            handle_message(update["message"])
                    except Exception as e:
                        print(f"⚠️ خطا: {e}")
            time.sleep(0.3)
        except KeyboardInterrupt:
            print("\n🛑 بات متوقف شد")
            break
        except Exception as e:
            print(f"⚠️ خطا: {e}")
            time.sleep(2)


if __name__ == "__main__":
    init_db()
    print("🚀 بات سفارشی آماده شد")
    print(f"👑 دستور پنل مدیریت: {ADMIN_CMD}")
    run()
