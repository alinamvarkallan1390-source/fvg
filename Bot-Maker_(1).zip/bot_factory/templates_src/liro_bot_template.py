import os
import requests
import json
import time
import re
import random
import sys

# محافظت در برابر کرش روی ویندوز موقع پرینت فارسی/ایموجی وقتی خروجی به فایل ریدایرکت می‌شه
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass



TOKEN = "{{BOT_TOKEN}}"  # Robot token


PROVIDER_TOKEN = "WALLET-TEST-1111111111111111"  # توکن پرداخت بله - برای فعال‌سازی پرداخت واقعی جایگزین کن

ADMIN_IDS = [{{ADMIN_ID}}]  # Robot admin IDs
ADMIN_CMD = "{{ADMIN_CMD}}"  # دستوری که پنل مدیریت رو باز می‌کنه

BAD_WORDS = ["کص" , "کیر" , "کصننت" , "خارکصه" , "اوبی" , "حرومزاده" , "کصننت" , "حرومی" , "مادرتو" , "کص ننت" , "گاییدم" , "asshole" , "fuck you" , "بیناموس" , "بی ناموس"]  #Words to lock fosh

#Set secret answers
#Account information variables : #{name} , #{username} , #{id}
HIDDEN_TAGS = {
    "مشخصات من": "*مشخصات کاربری شما : \n شناسه عددی → {id} \n یوزرنیم → @{username} \n نام اکانت → {name}*",
    "درود": "درود برشما [{name}](uid:{id}) خوشحال شدم از ديدنت🥰",
    "خوبی": "ممنون من خوبم شما چطوريد🥰؟" , 
    "خوبی؟" : "ممنون من خوبم شما چطوريد🥰؟" , 
    "سلام" : "سلام [{name}](uid:{id}) عزيز😇",
    "hi" : "Helo [{name}](uid:{id})",
    "Hi" : "Hi [{name}](uid:{id}) baby😇",
    "ربات" : "جونم [{name}](uid:{id})",
    "دلام" : "سلام عزيزم🫰",
    "سيلام" : "عليک سلام😈",
    "سلامم" : "سلام خوبي؟"
}

BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/" #Basic URL bale
DATA_FILE = "data.json" #Database name (in json format)

#short term memory
spam_tracker = {}
admin_states = {}
user_states = {} 
active_games = {} 


def load_data():
    if not os.path.exists(DATA_FILE):
        return {
            "users": [],
            "groups": [],
            "settings": {
                "support_channel": "", 
                "support_id": "",
                "fsub_channels": [],
                "fsub_text": "❌ برای استفاده از امکانات ربات، ابتدا باید در کانال‌های زیر عضو شوید و سپس دکمه بررسی عضویت را بزنید!"
            },
            "groups_data": {},
            "daily_leaderboard": {"date": time.strftime("%Y-%m-%d"), "groups": {}}
        }
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    if "settings" not in data: data["settings"] = {}
    data["settings"].setdefault("support_channel", "")
    data["settings"].setdefault("support_id", "")
    data["settings"].setdefault("fsub_channels", [])
    data["settings"].setdefault("fsub_text", "❌ برای استفاده از امکانات ربات، ابتدا باید در کانال‌های زیر عضو شوید و سپس دکمه بررسی عضویت را بزنید!")
    data.setdefault("daily_leaderboard", {"date": time.strftime("%Y-%m-%d"), "groups": {}})
    return data

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


def send_request(method, payload=None):
    try:
        response = requests.post(BASE_URL + method, json=payload)
        return response.json()
    except Exception as e:
        print(f"Error in {method}: {e}")
        return {}

def send_message(chat_id, text, reply_markup=None, reply_to=None):
    payload = {"chat_id": chat_id, "text": text}
    if reply_markup: payload["reply_markup"] = reply_markup
    if reply_to: payload["reply_to_message_id"] = reply_to
    return send_request("sendMessage", payload)

def edit_message(chat_id, message_id, text, reply_markup=None):
    payload = {"chat_id": chat_id, "message_id": message_id, "text": text}
    if reply_markup: payload["reply_markup"] = reply_markup
    return send_request("editMessageText", payload)

def delete_message(chat_id, message_id):
    return send_request("deleteMessage", {"chat_id": chat_id, "message_id": message_id})

def kick_user(chat_id, user_id):
    return send_request("banChatMember", {"chat_id": chat_id, "user_id": user_id})

def restrict_user(chat_id, user_id):
    permissions = {"can_send_messages": False}
    return send_request("restrictChatMember", {"chat_id": chat_id, "user_id": user_id, "permissions": permissions})

def unrestrict_user(chat_id, user_id):
    permissions = {"can_send_messages": True}
    return send_request("restrictChatMember", {"chat_id": chat_id, "user_id": user_id, "permissions": permissions})

def pin_message(chat_id, message_id):
    return send_request("pinChatMessage", {"chat_id": chat_id, "message_id": message_id})

def unpin_message(chat_id):
    return send_request("unpinChatMessage", {"chat_id": chat_id})


def send_invoice(chat_id, title, description, payload, provider_token, start_parameter, currency, prices):
    params = {
        "chat_id": chat_id,
        "title": title,
        "description": description,
        "payload": payload,
        "provider_token": provider_token,
        "start_parameter": start_parameter,
        "currency": currency,
        "prices": prices
    }
    return send_request("sendInvoice", params)

def get_chat_admins(chat_id):
    res = send_request("getChatAdministrators", {"chat_id": chat_id})
    if res.get("ok"):
        return [admin["user"]["id"] for admin in res["result"]]
    return []

def export_group_link(chat_id):
    res = send_request("exportChatInviteLink", {"chat_id": chat_id})
    if res.get("ok"): return res["result"]
    return None

def check_membership(chat_id, user_id):
    res = send_request("getChatMember", {"chat_id": chat_id, "user_id": user_id})
    if res.get("ok"):
        status = res["result"].get("status")
        if status in ["creator", "administrator", "member"]: return True
    return False

def is_joined_all(user_id, data):
    channels = data["settings"].get("fsub_channels", [])
    if not channels: return True, []
    
    not_joined = []
    for chan in channels:
        formatted_chat_id = f"@{chan}"
        if not check_membership(formatted_chat_id, user_id):
            not_joined.append(chan)
            
    if not_joined: return False, not_joined
    return True, []

def get_fsub_keyboard(channels):
    keyboard = []
    for idx, chan in enumerate(channels, 1):
        keyboard.append([{"text": f"📢 عضویت در کانال ({idx})", "url": f"https://ble.ir/{chan}"}])
    keyboard.append([{"text": "🔄 بررسی عضویت", "callback_data": "check_fsub"}])
    return {"inline_keyboard": keyboard}


def build_xo_keyboard(board):
    keyboard = []
    for i in range(0, 9, 3):
        row = []
        for j in range(3):
            idx = i + j
            val = board[idx]
            display = "⬜" if val == " " else ("❌" if val == "X" else "⭕")
            row.append({"text": display, "callback_data": f"xo_click_{idx}"})
        keyboard.append(row)
    keyboard.append([{"text": "🏳️ انصراف و تسلیم", "callback_data": "forfeit_game"}])
    return {"inline_keyboard": keyboard}

def check_xo_winner(b):
    lines = [(0,1,2), (3,4,5), (6,7,8), (0,3,6), (1,4,7), (2,5,8), (0,4,8), (2,4,6)]
    for l in lines:
        if b[l[0]] == b[l[1]] == b[l[2]] and b[l[0]] != " ": return b[l[0]]
    if " " not in b: return "draw"
    return None


def get_guide_text():
    return """📚 **راهنمای خفن ربات (نسخه سوپر پیشرفته + آمار و پرداخت)**
        
🔒 **قفل‌ها و مجازات خودکار:**
قفل/بازکردن 〔 ⛓لینک/ 🔀فوروارد/ #⃣ هشتگ/ 🌪اسپم/ 🎞فیلم/ 🌉عکس/ 🤬فحش/ 🗣صدا/ 👤مخاطب/ 💾فایل〕

تنظیم مجازات 〔 ⛓لینک / 🔀فوروارد/ 🎞فیلم/ 🌉عکس/ 🤬فحش/ 🗣صدا/ 👤مخاطب/ 💾فایل... .〕〔اخطار/ریم/سکوت〕

غیرفعال مجازات 〔 ⛓لینک/ 🔀فوروارد/ 🎞فیلم/ 🌉عکس/ 🤬فحش/ 🗣صدا/ 👤مخاطب/ 💾فایل... .〕

📊 **آمار روزانه:**
امار روزانه 📊 -> نمایش ۱۰ نفر برتر و فعال امروز گروه

🎮 **بخش سرگرمی و بازی چت گروه:**
سرگرمی فعال 👾 / سرگرمی غیرفعال -> مدیریت توسط مدیران
دوز یا xo | سنگ کاغذ قیچی یا rsp | گل یا پوچ

📢 **قفل جوین اجباری اختصاصی گروه:**
تنظیم کانال 〔یوزرنیم کانال〕 | لغو کانال گروه

🔗 دریافت لینک گروه (برای همه):
بفرستید: لینک

🚷 **فیلترینگ کلمات اختصاصی:**
فیلتر 〔کلمه〕 / حذف فیلتر 〔کلمه〕
لیست فیلتر
تنظیم مجازات فیلتر 〔اخطار/ریم/سکوت〕
غیرفعال مجازات فیلتر

🧹 **پاکسازی گروه:**
پاکسازی 〔تعداد〕 (مثال: پاکسازی 50)

🏷 **سیستم تگ و قوانین:**
تنظیم تگ 〔کلمه〕 〔جواب〕
حذف تگ 〔کلمه〕 / لیست تگ
ثبت قوانین 〔متن〕 / قوانین یا مشاهده قوانین

🛠 **برخورد دستی (ریپلای روی پیام):**
اخراج / سکوت / حذف سکوت
اخطار / حذف اخطار
پین / برداشتن سنجاق

⚠️ **تنظیمات کلی اخطار:**
حداکثر اخطار 〔عدد〕
تنظیم مجازات اخطار 〔ریم/سکوت〕

👋 **خوشامدگویی:**
تنظیم خوشامد 〔متن〕 / لغو خوشامد / ریست خوشامد"""


def apply_penalty(chat_id, user_id, user_name, penalty, group_settings, data):
    if not penalty: return
    if penalty == "ریم":
        kick_user(chat_id, user_id)
        send_message(chat_id, f"🚀 بوم! [{name}](uid:{id}) به خاطر تخلف مستقیم شوت شد بیرون! 🥾")
    elif penalty == "سکوت":
        restrict_user(chat_id, user_id)
        send_message(chat_id, f"🤐 [{name}](uid:{id}) به خاطر تخلف رفت تو قرنطینه سکوت! 🤫")
    elif penalty == "اخطار":
        warnings = group_settings["warnings"]
        current_warn = warnings.get(str(user_id), 0) + 1
        max_warn = group_settings["max_warnings"]
        main_penalty = group_settings["warning_penalty"]

        if current_warn >= max_warn:
            if main_penalty == "ریم":
                kick_user(chat_id, user_id)
                action_done = "شوت شد بیرون 🥾"
            else:
                restrict_user(chat_id, user_id)
                action_done = "رفت تو قرنطینه سکوت 🤐"
            warnings[str(user_id)] = 0
            send_message(chat_id, f"🚨 دیگه کاسه صبرم لبریز شد! [{name}](uid:{id}) تو انجام تخلف به سقف اخطارها ({max_warn}) رسید و {action_done}! 💀")
        else:
            warnings[str(user_id)] = current_warn
            send_message(chat_id, f"⚠️ هوی [{name}](uid:{id})! یه کارت زرد به خاطر تخلف گرفتی! 🟨 حواستو جمع کن.\nتعداد اخطار: {current_warn}/{max_warn}")
        save_data(data)


main_menu_keyboard = {
    "inline_keyboard": [
        [{"text": "📜 راهنمای خفن ربات", "callback_data": "guide"}],
        [{"text": "☎️ پشتیبانی", "callback_data": "support_team"}, {"text": "❤️ حمایت از ما", "callback_data": "support_us"}]
    ]
}

admin_panel_keyboard = {
    "inline_keyboard": [
        [{"text": "🚀 ارسال همگانی (بمب‌باران)", "callback_data": "admin_broadcast"}],
        [{"text": "⚙️ تنظیمات موتور ربات", "callback_data": "admin_settings"}],
        [{"text": "📢 تنظیمات جوین اجباری ربات", "callback_data": "admin_fsub"}],
        [{"text": "📊 آمار و ارقام تشکیلات", "callback_data": "admin_stats"}]
    ]
}

fsub_menu_keyboard = {
    "inline_keyboard": [
        [{"text": "✍️ تنظیم متن دسترسی محدود", "callback_data": "fsub_set_text"}],
        [{"text": "➕ اضافه کردن کانال", "callback_data": "fsub_add_chan"}, {"text": "❌ حذف کانال", "callback_data": "fsub_del_chan"}],
        [{"text": "📋 لیست کانال‌های اجباری", "callback_data": "fsub_list"}],
        [{"text": "🔙 بازگشت به پنل اصلی", "callback_data": "back_to_panel"}]
    ]
}

broadcast_menu_keyboard = {
    "inline_keyboard": [
        [{"text": "👤 شلیک به پی‌وی‌ها", "callback_data": "bc_users"}, {"text": "👥 شلیک به گروه‌ها", "callback_data": "bc_groups"}],
        [{"text": "💣 شلیک به کل دنیا!", "callback_data": "bc_all"}]
    ]
}

support_menu_keyboard = {
    "inline_keyboard": [
        [{"text": "📢 کانال ما", "callback_data": "sup_channel"}],
        [{"text": "👤 یقه ادمین رو بگیر!", "callback_data": "sup_admin"}]
    ]
}

rps_keyboard = {
    "inline_keyboard": [
        [{"text": "🪨 سنگ", "callback_data": "rps_sank"}, {"text": "📄 کاغذ", "callback_data": "rps_kaghaz"}, {"text": "✂️ قیچی", "callback_data": "rps_gheichi"}],
        [{"text": "🏳️ انصراف و تسلیم", "callback_data": "forfeit_game"}]
    ]
}

gol_keyboard = {
    "inline_keyboard": [
        [{"text": "✋ دست راست", "callback_data": "gol_rast"}, {"text": "🤚 دست چپ", "callback_data": "gol_chap"}],
        [{"text": "🏳️ انصراف و تسلیم", "callback_data": "forfeit_game"}]
    ]
}

def handle_message(message, data):
    chat_id = message["chat"]["id"]
    chat_type = message["chat"]["type"]
    user_id = message["from"]["id"]
    user_name = message["from"].get("first_name", "کاربر")
    user_username = message["from"].get("username", "ندارد")
    text = message.get("text", "").strip()
    msg_id = message["message_id"]

    # 📊 موتور ثبت آمار روزانه پیام‌ها در گروه
    if chat_type in ["group", "supergroup"]:
        current_date = time.strftime("%Y-%m-%d")
        if data["daily_leaderboard"]["date"] != current_date:
            data["daily_leaderboard"]["date"] = current_date
            data["daily_leaderboard"]["groups"] = {}
        
        group_id_str = str(chat_id)
        user_id_str = str(user_id)
        
        group_lb = data["daily_leaderboard"]["groups"].setdefault(group_id_str, {})
        user_stat = group_lb.setdefault(user_id_str, {"name": user_name, "count": 0})
        user_stat["count"] += 1
        user_stat["name"] = user_name 

    if chat_type == "private" and user_id not in data["users"]:
        data["users"].append(user_id)
        save_data(data)
    elif chat_type in ["group", "supergroup"]:
        if chat_id not in data["groups"]:
            data["groups"].append(chat_id)
            save_data(data)

    if chat_type in ["group", "supergroup"]:
        group_settings = data["groups_data"].get(str(chat_id), {})
        group_settings.setdefault("welcome_text", "خوش اومدی رفیق! 🥳 صفا آوردی، فقط حواست به قوانین باشه که با من در نیفتی! 🤖⚔️")
        group_settings.setdefault("welcome_enabled", True)
        group_settings.setdefault("locks", {"link": False, "forward": False, "hashtag": False, "spam": False, "video": False, "photo": False, "profanity": False, "audio": False, "contact": False, "document": False})
        group_settings.setdefault("lock_penalties", {"link": None, "forward": None, "hashtag": None, "spam": None, "video": None, "photo": None, "profanity": None, "audio": None, "contact": None, "document": None})
        group_settings.setdefault("warnings", {})
        group_settings.setdefault("max_warnings", 3)
        group_settings.setdefault("warning_penalty", "ریم")
        group_settings.setdefault("tags", {})
        group_settings.setdefault("filters", [])
        group_settings.setdefault("filter_penalty", None)
        group_settings.setdefault("rules", "قوانین هنوز توسط رئیس ثبت نشده! 📜")
        group_settings.setdefault("fsub_channel", "")
        group_settings.setdefault("entertainment_enabled", True)
        data["groups_data"][str(chat_id)] = group_settings

    new_members = message.get("new_chat_members", [])
    if new_members and chat_type in ["group", "supergroup"]:
        group_settings = data["groups_data"].get(str(chat_id), {})
        if group_settings.get("welcome_enabled", True):
            welcome_text = group_settings.get("welcome_text", "خوش اومدی!")
            for member in new_members:
                send_message(chat_id, f"سلااام {member.get('first_name', 'مهمون')} عزیز! 👋\n{welcome_text}")
        return


    if chat_type == "private" and user_id in user_states and user_states[user_id] == "waiting_for_support_amount":
        if not text.isdigit():
            send_message(chat_id, "❌ رئیس! لطفاً فقط عدد انگلیسی وارد کن. فرآیند لغو شد. دوباره دکمه حمایت رو بزن.")
            del user_states[user_id]
            return
        
        amount_toman = int(text)
        if amount_toman < 5000 or amount_toman > 1000000:
            send_message(chat_id, f"❌ مبلغ خارج از محدوده است!\nحداقل: ۵,۰۰۰ تومان\nحداکثر: ۱,۰۰۰,۰۰۰ تومان\n\nمبلغ وارد شده شما: {amount_toman:,} تومان\nفرآیند لغو شد. مجدداً تلاش کنید.")
            del user_states[user_id]
            return
        

        amount_rial = amount_toman * 10
        prices = [{"label": f"حمایت مالی از ربات", "amount": amount_rial}]
        
        send_message(chat_id, "⏳ در حال صدور فاکتور پرداخت رسمی بله... لطفاً کمی منتظر بمانید.")
        
        res = send_invoice(
            chat_id=chat_id,
            title="❤️ حمایت مالی از ربات",
            description=f"مبلغ حمایت: {amount_toman:,} تومان\nدمت گرم رفیق! انرژی دادی بهمون. 🚀",
            payload=f"support_{user_id}_{int(time.time())}",
            provider_token=PROVIDER_TOKEN,
            start_parameter="support_bot",
            currency="IRR",
            prices=prices
        )
        
        if not res.get("ok"):
            send_message(chat_id, "❌ خطایی در ارتباط با درگاه پرداخت بله رخ داد! مطمئن شو توکن پرداخت (PROVIDER_TOKEN) خط اول کد رو درست ست کردی رئیس.")
        
        del user_states[user_id]
        return

    if chat_type == "private" and user_id not in ADMIN_IDS:
        joined, not_joined = is_joined_all(user_id, data)
        if not joined:
            fsub_text = data["settings"].get("fsub_text")
            send_message(chat_id, fsub_text, reply_markup=get_fsub_keyboard(not_joined))
            return

    if chat_type == "private":
        if text == "/start":
            send_message(chat_id, "درود, به ربات مدیریت گروه خوش آمدید🤩", reply_markup=main_menu_keyboard)
            if user_id in ADMIN_IDS:
                send_message(chat_id, f"👑 برای پنل مدیریت دستور {ADMIN_CMD} رو بفرست.")
        elif text == ADMIN_CMD and user_id in ADMIN_IDS:
            send_message(chat_id, "🎩 پنل مدیریت شما:", reply_markup=admin_panel_keyboard)
        elif user_id in ADMIN_IDS and user_id in admin_states:
            state = admin_states[user_id]
            if state.startswith("bc_"):
                targets = []
                if state == "bc_users": targets = data["users"]
                elif state == "bc_groups": targets = data["groups"]
                elif state == "bc_all": targets = data["users"] + data["groups"]
                
                sent_count = 0
                for target in targets:
                    res = send_message(target, text)
                    if res.get("ok"): sent_count += 1
                send_message(chat_id, f"✅ با موفقیت به {sent_count} جا شلیک شد! 🔫😎")
                del admin_states[user_id]
            elif state == "set_sup_channel":
                data["settings"]["support_channel"] = text
                save_data(data)
                send_message(chat_id, "✅ لینک کانال با موفقیت رفت تو سیستم!")
                del admin_states[user_id]
            elif state == "set_sup_admin":
                data["settings"]["support_id"] = text
                save_data(data)
                send_message(chat_id, "✅ آیدی ادمین ثبت شد. منبعد میان یقه تو رو میگیرن! 😂")
                del admin_states[user_id]
            elif state == "fsub_set_text":
                data["settings"]["fsub_text"] = text
                save_data(data)
                send_message(chat_id, "✅ متن دسترسی محدود با موفقیت آپدیت شد، رئیس!", reply_markup=fsub_menu_keyboard)
                del admin_states[user_id]
            elif state == "fsub_add_chan":
                chan = text.strip().replace("https://ble.ir/", "").replace("@", "")
                if chan:
                    if chan not in data["settings"]["fsub_channels"]:
                        data["settings"]["fsub_channels"].append(chan)
                        save_data(data)
                        send_message(chat_id, f"✅ کانال @{chan} با موفقیت به لیست جوین اجباری ربات اضافه شد.", reply_markup=fsub_menu_keyboard)
                    else:
                        send_message(chat_id, "❌ این کانال که از قبل توی لیست ادمین بود!", reply_markup=fsub_menu_keyboard)
                del admin_states[user_id]
            elif state == "fsub_del_chan":
                chan = text.strip().replace("https://ble.ir/", "").replace("@", "")
                if chan in data["settings"]["fsub_channels"]:
                    data["settings"]["fsub_channels"].remove(chan)
                    save_data(data)
                    send_message(chat_id, f"🗑 کانال @{chan} با موفقیت از لیست جوین اجباری ربات خط خورد.", reply_markup=fsub_menu_keyboard)
                else:
                    send_message(chat_id, "❌ همچین کانالی توی لیست پیدا نشد!", reply_markup=fsub_menu_keyboard)
                del admin_states[user_id]
        return

    if chat_type in ["group", "supergroup"]:
        group_settings = data["groups_data"][str(chat_id)]
        locks = group_settings.get("locks", {})
        lock_penalties = group_settings.get("lock_penalties", {})
        admins = get_chat_admins(chat_id)
        is_admin = user_id in admins or user_id in ADMIN_IDS

        if text in HIDDEN_TAGS:
            reply_template = HIDDEN_TAGS[text]
            final_reply = reply_template.replace("{name}", str(user_name)).replace("{username}", str(user_username)).replace("{id}", str(user_id))
            send_message(chat_id, final_reply, reply_to=msg_id)
            return

        if text == "لینک":
            g_link = export_group_link(chat_id)
            if g_link: send_message(chat_id, f"🔗 **لینک گروه:**\n{g_link}", reply_to=msg_id)
            else: send_message(chat_id, "❌ خطا! ربات دسترسی ساخت لینک ندارد یا ادمین گروه نیست.", reply_to=msg_id)
            return

        if text in group_settings["tags"]:
            send_message(chat_id, group_settings["tags"][text], reply_to=msg_id)
            
        if text in ["قوانین", "مشاهده قوانین"]:
            send_message(chat_id, f"⚖️ **طومار قوانین گروه:**\n\n{group_settings['rules']}")

        if text == "راهنما":
            send_message(chat_id, get_guide_text(), reply_to=msg_id)

   
        if text in ["لیدربرد", "امار روزانه"]:
            group_id_str = str(chat_id)
            group_lb = data["daily_leaderboard"]["groups"].get(group_id_str, {})
            
            if not group_lb:
                send_message(chat_id, "📊 هنوز هیچ آماری برای امروز ثبت نشده! اولین نفری باش که چت میکنه.", reply_to=msg_id)
                return
            

            sorted_users = sorted(group_lb.items(), key=lambda x: x[1]["count"], reverse=True)[:10]
            
            lb_text = f"📊 **۱۰ کاربر فعال و برتر امروز گروه**\n📅 تاریخ: {data['daily_leaderboard']['date']}\n\n"
            medal_map = {0: "🥇", 1: "🥈", 2: "🥉"}
            
            for idx, (u_id, u_info) in enumerate(sorted_users):
                medal = medal_map.get(idx, "🔹")
                lb_text += f"{medal} {idx+1}. **{u_info['name']}** ➜ `{u_info['count']}` پیام\n"
            
            lb_text += "\n🏁 مسابقه تا آخر امشب ادامه داره، چت کنید و بیاید بالا! 🔥"
            send_message(chat_id, lb_text, reply_to=msg_id)
            return


        if text in ["دوز", "xo", "ایجاد بازی دوز", "rsp", "سنگ کاغذ قیچی", "ایجاد بازی سنگ کاغذ قیچی", "ایجاد بازی گل یا پوچ", "گل یا پوچ"]:
            if not group_settings.get("entertainment_enabled", True):
                send_message(chat_id, "❌ بخش سرگرمی در این گروه توسط مدیران غیرفعال شده است!", reply_to=msg_id)
                return
            
            game_type = "xo" if text in ["دوز", "xo", "ایجاد بازی دوز"] else ("rps" if text in ["rsp", "سنگ کاغذ قیچی", "ایجاد بازی سنگ کاغذ قیچی"] else "gol")
            game_names = {"xo": "دوز ❌⭕", "rps": "سنگ کاغذ قیچی 🪨📄✂️", "gol": "گل یا پوچ 🎭"}
            
            join_kb = {"inline_keyboard": [[{"text": "🤝 ورود به مسابقه (عضو شدم)", "callback_data": "join_entertainment_game"}]]}
            res = send_message(chat_id, f"🎮 **رقابت جدید شلیک شد!**\n\n🏆 نوع چالش: **{game_names[game_type]}**\n👤 طراح چالش: {user_name}\n⏳ در انتظار حریف... رفقا سریع‌تر روی دکمه زیر بزنید تا بازی شروع بشه!", reply_markup=join_kb, reply_to=msg_id)
            
            if res.get("ok"):
                game_msg_id = res["result"]["message_id"]
                active_games[game_msg_id] = {
                    "type": game_type,
                    "chat_id": chat_id,
                    "creator": user_id,
                    "creator_name": user_name,
                    "opponent": None,
                    "opponent_name": None,
                    "status": "waiting"
                }
            return

        if not is_admin:
            group_chan = group_settings.get("fsub_channel", "")
            if group_chan:
                formatted_chan_id = f"@{group_chan}"
                if not check_membership(formatted_chan_id, user_id):
                    delete_message(chat_id, msg_id)
                    fsub_group_kb = {"inline_keyboard": [[{"text": "📢 عضویت در کانال گروه", "url": f"https://ble.ir/{group_chan}"}]]}
                    send_message(chat_id, f"⚠️ کاربر {user_name} عزیز، لطفا در کانال @{group_chan} جوین شوید تا بتوانید در گروه پیام ارسال کنید.", reply_markup=fsub_group_kb)
                    return

            must_delete = False
            triggered_penalty = None
            
            if locks.get("profanity") and any(word in text for word in BAD_WORDS):
                must_delete = True
                triggered_penalty = lock_penalties.get("profanity")
            elif locks.get("photo") and "photo" in message:
                must_delete = True
                triggered_penalty = lock_penalties.get("photo")
            elif locks.get("video") and "video" in message:
                must_delete = True
                triggered_penalty = lock_penalties.get("video")
            elif locks.get("audio") and ("voice" in message or "audio" in message):
                must_delete = True
                triggered_penalty = lock_penalties.get("audio")
            elif locks.get("contact") and "contact" in message:
                must_delete = True
                triggered_penalty = lock_penalties.get("contact")
            elif locks.get("document") and "document" in message:
                must_delete = True
                triggered_penalty = lock_penalties.get("document")

            if not must_delete:
                for word in group_settings["filters"]:
                    if word in text:
                        must_delete = True
                        triggered_penalty = group_settings["filter_penalty"]
                        break
            
            if not must_delete:
                if locks.get("link") and re.search(r'(https?://|ble\.ir|t\.me|@\w+)', text): 
                    must_delete = True
                    triggered_penalty = lock_penalties.get("link")
                elif locks.get("forward") and ("forward_from" in message or "forward_from_chat" in message): 
                    must_delete = True
                    triggered_penalty = lock_penalties.get("forward")
                elif locks.get("hashtag") and "#" in text: 
                    must_delete = True
                    triggered_penalty = lock_penalties.get("hashtag")

            if must_delete:
                delete_message(chat_id, msg_id)
                apply_penalty(chat_id, user_id, user_name, triggered_penalty, group_settings, data)
                return

            if locks.get("spam"):
                current_time = time.time()
                if chat_id not in spam_tracker: spam_tracker[chat_id] = {}
                if user_id not in spam_tracker[chat_id]: spam_tracker[chat_id][user_id] = []
                user_times = spam_tracker[chat_id][user_id]
                user_times.append(current_time)
                user_times = [t for t in user_times if current_time - t < 3]
                spam_tracker[chat_id][user_id] = user_times
                if len(user_times) >= 4:
                    delete_message(chat_id, msg_id)
                    apply_penalty(chat_id, user_id, user_name, lock_penalties.get("spam"), group_settings, data)
                    return

        if is_admin:
            if ent_match := re.match(r"^سرگرمی (فعال|غیرفعال)$", text):
                status = ent_match.group(1) == "فعال"
                group_settings["entertainment_enabled"] = status
                save_data(data)
                status_text = "🟢 فعال" if status else "🔴 غیرفعال"
                send_message(chat_id, f"⚙️ وضعیت موتور سرگرمی و بازی‌های گروه به [{status_text}] تغییر یافت.", reply_to=msg_id)
                return

            if group_fsub_match := re.match(r"^تنظیم کانال (\S+)$", text):
                chan = group_fsub_match.group(1).strip().replace("https://ble.ir/", "").replace("@", "")
                group_settings["fsub_channel"] = chan
                save_data(data)
                send_message(chat_id, f"✅ کانال @{chan} به عنوان کانال جوین اجباری این گروه ثبت شد.", reply_to=msg_id)
                return
            elif text in ["لغو کانال گروه", "لغو کانال اجباری", "حذف کانال"]:
                group_settings["fsub_channel"] = ""
                save_data(data)
                send_message(chat_id, "🔓 قفل کانال اجباری گروه برداشته شد.", reply_to=msg_id)
                return

            if "reply_to_message" in message:
                target_msg = message["reply_to_message"]
                target_user = target_msg["from"]["id"]
                target_name = target_msg["from"].get("first_name", "کاربر")
                target_msg_id = target_msg["message_id"]

                if re.match(r"^(ریم|کیک|سیک|اخراج)$", text):
                    kick_user(chat_id, target_user)
                    send_message(chat_id, f"🚀 بوم! [{name}](uid:{id}) با اردنگی شوت شد بیرون! 👋")
                elif re.match(r"^(سکوت|خفه)$", text):
                    restrict_user(chat_id, target_user)
                    send_message(chat_id, f"🤐 زیپ دهان [{name}](uid:{id}) کشیده شد! 🤫")
                elif re.match(r"^(حذف سکوت|رفع سکوت)$", text):
                    unrestrict_user(chat_id, target_user)
                    send_message(chat_id, f"🎤 [{name}](uid:{id}) از قرنطینه درومد! 🦜")
                elif re.match(r"^(پین|سنجاق)$", text):
                    pin_message(chat_id, target_msg_id)
                    send_message(chat_id, "📌 پیام با یه میخ طویله محکم کوبیده شد اون بالا! 🔨")
                elif text == "اخطار":
                    apply_penalty(chat_id, target_user, target_name, "اخطار", group_settings, data)
                elif text == "حذف اخطار":
                    warnings = group_settings["warnings"]
                    current_warn = warnings.get(str(target_user), 0)
                    if current_warn > 0:
                        warnings[str(target_user)] = current_warn - 1
                        save_data(data)
                        send_message(chat_id, f"😇 شانس آوردی [{name}](uid:{id})! یه دونه از اخطارات پاک شد.")
                    else:
                        send_message(chat_id, f"🤷‍♂️ این بیچاره [{name}](uid:{id}) که اصلا اخطاری نداره!")

            purge_match = re.match(r"^پاکسازی (\d+)$", text)
            if purge_match:
                count = int(purge_match.group(1))
                if count > 100: count = 100
                for i in range(count): delete_message(chat_id, msg_id - i)
                return

            tag_match = re.match(r"^تنظیم تگ (\S+) ([\s\S]+)$", text)
            if tag_match:
                keyword, reply_text = tag_match.groups()
                group_settings["tags"][keyword] = reply_text
                save_data(data)
                send_message(chat_id, f"🎯 تگ '{keyword}' قفل شد رو هدف! 🤖💬")
            elif text == "لیست تگ":
                tags = group_settings.get("tags", {})
                msg = "🏷 **لیست تگ‌های تنظیم شده:**\n\n" + "\n".join([f"🔸 {k}" for k in tags]) if tags else "📭 هیچ تگی ثبت نشده!"
                send_message(chat_id, msg)
            elif del_tag_match := re.match(r"^حذف تگ (\S+)$", text):
                keyword = del_tag_match.group(1)
                if keyword in group_settings["tags"]:
                    del group_settings["tags"][keyword]
                    save_data(data)
                    send_message(chat_id, f"🗑 تگ '{keyword}' پودر شد!")
                else:
                    send_message(chat_id, "🤔 همچین تگی اصلا نداشتیم!")

            elif filter_match := re.match(r"^فیلتر(?: کردن)? (\S+)$", text):
                word = filter_match.group(1)
                if word not in group_settings["filters"]:
                    group_settings["filters"].append(word)
                    save_data(data)
                    send_message(chat_id, f"🚫 کلمه '{word}' رفت تو لیست سیاه! 🤬")
            elif text in ["لیست فیلتر", "لیست فیلتر ها"]:
                filters = group_settings.get("filters", [])
                msg = "🚷 **لیست کلمات ممنوعه:**\n\n" + "\n".join([f"⛔️ {w}" for w in filters]) if filters else "🕊 کلمه فیلتر شده‌ای نداریم!"
                send_message(chat_id, msg)
            elif del_filter_match := re.match(r"^(?:حذف|حذف کردن) فیلتر (\S+)$", text):
                word = del_filter_match.group(1)
                if word in group_settings["filters"]:
                    group_settings["filters"].remove(word)
                    save_data(data)
                    send_message(chat_id, f"✅ کلمه '{word}' آزاد شد! 🕊")

            elif lp_match := re.match(r"^تنظیم مجازات (اسپم|لینک|فوروارد|هشتگ|فیلم|عکس|فحش|صدا|مخاطب|فایل) (اخطار|ریم|سکوت)$", text):
                lock_name_map = {"لینک": "link", "فوروارد": "forward", "هشتگ": "hashtag", "اسپم": "spam", "فیلم": "video", "عکس": "photo", "فحش": "profanity", "صدا": "audio", "مخاطب": "contact", "فایل": "document"}
                group_settings["lock_penalties"][lock_name_map[lp_match.group(1)]] = lp_match.group(2)
                save_data(data)
                send_message(chat_id, f"⚔️ هر کی قفل {lp_match.group(1)} رو بشکنه، مجازاتش میشه: [{lp_match.group(2)}] 😈")
            elif lock_match := re.match(r"^قفل (لینک|فوروارد|هشتگ|اسپم|فیلم|عکس|فحش|صدا|مخاطب|فایل)$", text):
                lock_name_map = {"لینک": "link", "فوروارد": "forward", "هشتگ": "hashtag", "اسپم": "spam", "فیلم": "video", "عکس": "photo", "فحش": "profanity", "صدا": "audio", "مخاطب": "contact", "فایل": "document"}
                group_settings["locks"][lock_name_map[lock_match.group(1)]] = True
                save_data(data)
                send_message(chat_id, f"🔒 قفل {lock_match.group(1)} محکم بسته شد! 🥷")
            elif unlock_match := re.match(r"^بازکردن (لینک|فوروارد|هشتگ|اسپم|فیلم|عکس|فحش|صدا|مخاطب|فایل)$", text):
                lock_name_map = {"لینک": "link", "فوروارد": "forward", "هشتگ": "hashtag", "اسپم": "spam", "فیلم": "video", "عکس": "photo", "فحش": "profanity", "صدا": "audio", "مخاطب": "contact", "فایل": "document"}
                group_settings["locks"][lock_name_map[unlock_match.group(1)]] = False
                save_data(data)
                send_message(chat_id, f"🔓 قفل {unlock_match.group(1)} شکسته شد! 🕊️")

            elif rule_match := re.match(r"^ثبت قوانین ([\s\S]+)$", text):
                group_settings["rules"] = rule_match.group(1)
                save_data(data)
                send_message(chat_id, "📜 قوانین گروه با موفقیت ثبت شد! ⚖️")

            elif re.match(r"^(برداشتن سنجاق)$", text):
                unpin_message(chat_id)
                send_message(chat_id, "✅ پیام از اون بالا کنده شد!")
            elif text.startswith("تنظیم خوشامد "):
                group_settings["welcome_text"] = text.replace("تنظیم خوشامد ", "")
                save_data(data)
                send_message(chat_id, "🤵 متن خوشامدگویی با موفقیت آپدیت شد!")
            elif max_warn_match := re.match(r"^(?:تنظیم حداکثر اخطار|حداکثر اخطار) (\d+)$", text):
                group_settings["max_warnings"] = int(max_warn_match.group(1))
                save_data(data)
                send_message(chat_id, f"📏 حداکثر ظرفیت اخطار روی {max_warn_match.group(1)} تنظیم شد.")


def handle_callback(callback, data):
    call_id = callback["id"]
    user_id = callback["from"]["id"]
    user_name = callback["from"].get("first_name", "کاربر")
    chat_id = callback["message"]["chat"]["id"]
    cb_data = callback["data"]
    msg_id = callback["message"]["message_id"]

    def answer_callback(text="", show_alert=False):
        send_request("answerCallbackQuery", {"callback_query_id": call_id, "text": text, "show_alert": show_alert})

    if cb_data == "check_fsub":
        joined, not_joined = is_joined_all(user_id, data)
        if joined:
            answer_callback("✅ عضویت شما تایید شد! به ربات خوش آمدید.", show_alert=True)
            delete_message(chat_id, msg_id)
            send_message(chat_id, "درود, به ربات مدیریت گروه خوش آمدید🤩", reply_markup=main_menu_keyboard)
        else:
            answer_callback("❌ هنوز در تمامی کانال‌ها عضو نشده‌اید!", show_alert=True)
        return


    if cb_data == "support_us":
        user_states[user_id] = "waiting_for_support_amount"
        send_message(user_id, "❤️ **به بخش حمایت مالی خوش آمدید رفیق!**\n\nلطفاً مبلغ مورد نظر خود را به **تومان (عدد انگلیسی)** وارد و ارسال کنید:\n\n🔹 حداقل مبلغ: `5,000` تومان\n🔸 حداکثر مبلغ: `1,000,000` تومان")
        answer_callback("لطفاً چت خصوصی خود را چک کنید 💬")
        return


    if cb_data == "forfeit_game":
        if msg_id in active_games:
            game = active_games[msg_id]
            if user_id in [game["creator"], game["opponent"]]:
                winner_name = game["opponent_name"] if user_id == game["creator"] else game["creator_name"]
                edit_message(chat_id, msg_id, f"🏳️ **پایان مسابقه به دلیل تسلیم!**\n\n👤 بازیکن {user_name} پرچم سفید بالا آورد و تسلیم شد!\n🏆 برنده نهایی این نبرد جذاب: **{winner_name}**")
                del active_games[msg_id]
                answer_callback("پرچم سفید بالا بردی داداش!🏳️")
            else:
                answer_callback("❌ شما بازیکن این مسابقه نیستی!", show_alert=True)
        else:
            answer_callback("❌ این بازی به پایان رسیده است!")
        return


    if cb_data == "join_entertainment_game":
        if msg_id in active_games:
            game = active_games[msg_id]
            if user_id == game["creator"]:
                answer_callback("❌ شما خودت موسس بازی هستی پهلوان!", show_alert=True)
                return
            if game["opponent"] is not None:
                answer_callback("❌ متاسفانه ظرفیت این مسابقه تکمیله!", show_alert=True)
                return
            
            game["opponent"] = user_id
            game["opponent_name"] = user_name
            game["status"] = "playing"
            
            if game["type"] == "xo":
                game["board"] = [" "] * 9
                game["turn"] = game["creator"]
                edit_message(chat_id, msg_id, f"🎮 **نبرد دوز شروع شد!**\n\n❌ بازیکن اول: {game['creator_name']}\n⭕ بازیکن دوم: {game['opponent_name']}\n\n👉 نوبت حرکت: **{game['creator_name']} (❌)**", reply_markup=build_xo_keyboard(game["board"]))
            elif game["type"] == "rps":
                game["creator_choice"] = None
                game["opponent_choice"] = None
                edit_message(chat_id, msg_id, f"🎮 **نبرد سنگ کاغذ قیچی آغاز شد!**\n\n💥 رفقا {game['creator_name']} و {game['opponent_name']} سریعاً انتخاب مخفیانه‌تون رو انجام بدین:", reply_markup=rps_keyboard)
            elif game["type"] == "gol":
                game["round"] = 1
                game["scores"] = {game["creator"]: 0, game["opponent"]: 0}
                game["hider"] = random.choice([game["creator"], game["opponent"]])
                game["guesser"] = game["opponent"] if game["hider"] == game["creator"] else game["creator"]
                hider_name = game["creator_name"] if game["hider"] == game["creator"] else game["opponent_name"]
                edit_message(chat_id, msg_id, f"🎮 **مسابقه جذاب گل یا پوچ کلید خورد! (۴ رانده)**\n\n راند شماره: **1 از 4**\n🎭 قرعه به نامت افتاد! کاربر **{hider_name}**، گل رو تو کدوم دستت قایم می‌کنی؟ 🫣", reply_markup=gol_keyboard)
            answer_callback("🤝 با موفقیت وارد مسابقه شدی!")
        else:
            answer_callback("❌ این بازی منقضی شده است!", show_alert=True)
        return


    if cb_data.startswith("xo_click_"):
        if msg_id in active_games:
            game = active_games[msg_id]
            idx = int(cb_data.split("_")[2])
            if game["status"] != "playing": return
            if user_id != game["turn"]:
                answer_callback("❌ الان نوبت شما نیست.", show_alert=True)
                return
            if game["board"][idx] != " ":
                answer_callback("❌ این خونه قبلاً پر شده!", show_alert=True)
                return
            
            current_sign = "X" if user_id == game["creator"] else "O"
            game["board"][idx] = current_sign
            win_result = check_xo_winner(game["board"])
            
            if win_result:
                if win_result == "draw":
                    edit_message(chat_id, msg_id, f"🤝 **پایان مسابقه دوز!**\n\n💥 نبرد بین {game['creator_name']} و {game['opponent_name']} با نتیجه **مساوی** به پایان رسید!", reply_markup=build_xo_keyboard(game["board"]))
                else:
                    winner_name = game["creator_name"] if win_result == "X" else game["opponent_name"]
                    edit_message(chat_id, msg_id, f"🏆 **پایان مسابقه دوز!**\n\n🎉 کاربر **{winner_name}** برنده نهایی این راند دوز شد! 👑", reply_markup=build_xo_keyboard(game["board"]))
                del active_games[msg_id]
            else:
                game["turn"] = game["opponent"] if game["turn"] == game["creator"] else game["creator"]
                next_player_name = game["creator_name"] if game["turn"] == game["creator"] else game["opponent_name"]
                next_sign = "❌" if game["turn"] == game["creator"] else "⭕"
                edit_message(chat_id, msg_id, f"🎮 **نبرد دوز در جریان است...**\n\n❌ اول: {game['creator_name']} | ⭕ دوم: {game['opponent_name']}\n\n👉 نوبت حرکت: **{next_player_name} ({next_sign})**", reply_markup=build_xo_keyboard(game["board"]))
            answer_callback()
        return


    if cb_data.startswith("rps_"):
        if msg_id in active_games:
            game = active_games[msg_id]
            choice = cb_data.split("_")[1]
            if user_id == game["creator"]:
                if game["creator_choice"] is not None: return
                game["creator_choice"] = choice
                answer_callback("✅ انتخاب شما مخفیانه ثبت شد!")
            elif user_id == game["opponent"]:
                if game["opponent_choice"] is not None: return
                game["opponent_choice"] = choice
                answer_callback("✅ انتخاب شما مخفیانه ثبت شد!")
            else:
                answer_callback("❌ شما بازیکن نیستی!", show_alert=True)
                return
                
            if game["creator_choice"] and game["opponent_choice"]:
                c1 = game["creator_choice"]
                c2 = game["opponent_choice"]
                emoji_map = {"sank": "🪨 سنگ", "kaghaz": "📄 کاغذ", "gheichi": "✂️ قیچی"}
                result_text = f"📊 **نتیجه چالش سنگ کاغذ قیچی:**\n\n👤 {game['creator_name']}: {emoji_map[c1]}\n👤 {game['opponent_name']}: {emoji_map[c2]}\n\n"
                if c1 == c2: result_text += "🤝 نتیجه نهایی: **مساوی!**"
                elif (c1 == "sank" and c2 == "gheichi") or (c1 == "kaghaz" and c2 == "sank") or (c1 == "gheichi" and c2 == "kaghaz"):
                    result_text += f"🏆 برنده مسابقه: **{game['creator_name']}** 🎉"
                else:
                    result_text += f"🏆 برنده مسابقه: **{game['opponent_name']}** 🎉"
                edit_message(chat_id, msg_id, result_text)
                del active_games[msg_id]
            else:
                status_msg = f"🎮 **نبرد سنگ کاغذ قیچی...**\n\n"
                status_msg += f"{'✅ ثبت شد' if game['creator_choice'] else '⏳ در انتظار انتخاب'} ➜ {game['creator_name']}\n"
                status_msg += f"{'✅ ثبت شد' if game['opponent_choice'] else '⏳ در انتظار انتخاب'} ➜ {game['opponent_name']}\n"
                edit_message(chat_id, msg_id, status_msg, reply_markup=rps_keyboard)
        return

 
    if cb_data.startswith("gol_"):
        if msg_id in active_games:
            game = active_games[msg_id]
            hand_choice = cb_data.split("_")[1]
            hand_names = {"rast": "✋ دست راست", "chap": "🤚 دست چپ"}
            
            if "hidden_hand" not in game or game["hidden_hand"] is None:
                if user_id != game["hider"]:
                    answer_callback("❌ شما الان باید چشم بذاری!", show_alert=True)
                    return
                game["hidden_hand"] = hand_choice
                guesser_name = game["creator_name"] if game["guesser"] == game["creator"] else game["opponent_name"]
                edit_message(chat_id, msg_id, f"🎮 **گل یا پوچ (راند {game['round']} از 4)**\n\n🔒 گل قایم شد!\n🧐 حالا **{guesser_name}** بگو ببینم حدس می‌زنی گل تو کدوم دسته؟", reply_markup=gol_keyboard)
                answer_callback("گل رو قایم کردی!")
            else:
                if user_id != game["guesser"]:
                    answer_callback("❌ اجازه بده حریفت حدس بزنه.", show_alert=True)
                    return
                hider_name = game["creator_name"] if game["hider"] == game["creator"] else game["opponent_name"]
                guesser_name = game["creator_name"] if game["guesser"] == game["creator"] else game["opponent_name"]
                
                if hand_choice == game["hidden_hand"]:
                    game["scores"][game["guesser"]] += 1
                    round_res = f"🎉 **حدس درست بود!** {guesser_name} گل رو در {hand_names[game['hidden_hand']]} پیدا کرد و ۱ امتیاز گرفت."
                else:
                    game["scores"][game["hider"]] += 1
                    round_res = f"😜 **حدس غلط!** {hider_name} رودست زد! گل در {hand_names[game['hidden_hand']]} بود. ۱ امتیاز برای مخفی‌کننده."
                
                game["round"] += 1
                if game["round"] > 4:
                    s1 = game["scores"][game["creator"]]
                    s2 = game["scores"][game["opponent"]]
                    final_text = f"🏁 **پایان مسابقه ماراتن گل یا پوچ!**\n\n📊 امتیازات نهایی:\n👤 {game['creator_name']}: {s1}\n👤 {game['opponent_name']}: {s2}\n\n"
                    if s1 == s2: final_text += "👑 مسابقه مساوی شد! هر دو پادشاه گل یا پوچ هستید."
                    else: final_text += f"🏆 قهرمان نهایی مسابقه: **{game['creator_name'] if s1 > s2 else game['opponent_name']}** 👑🔥"
                    edit_message(chat_id, msg_id, final_text)
                    del active_games[msg_id]
                else:
                    game["hider"], game["guesser"] = game["guesser"], game["hider"]
                    game["hidden_hand"] = None
                    next_hider_name = game["creator_name"] if game["hider"] == game["creator"] else game["opponent_name"]
                    edit_message(chat_id, msg_id, f"🎮 **گل یا پوچ (راند جدید)**\n\n راند شماره: **{game['round']} از 4**\n{round_res}\n\n📊 امتیازات: {game['creator_name']}: {game['scores'][game['creator']]} | {game['opponent_name']}: {game['scores'][game['opponent']]}\n\n🎭 حالا نوبت **{next_hider_name}** هست که گل رو قایم کنه!", reply_markup=gol_keyboard)
                answer_callback()
        return

    if cb_data == "guide":
        send_message(chat_id, get_guide_text())
        answer_callback()
    elif cb_data == "support_team":
        send_message(chat_id, "📞 با کی کار داشتی عزیزم؟", reply_markup=support_menu_keyboard)
        answer_callback()
    elif cb_data == "sup_channel":
        channel = data["settings"].get("support_channel")
        if channel: send_message(chat_id, f"📢 بیا اینم کانال ما: {channel}")
        else: send_message(chat_id, "❌ رئیس هنوز کانالی ثبت نکرده!")
        answer_callback()
    elif cb_data == "sup_admin":
        admin_id_sup = data["settings"].get("support_id")
        if admin_id_sup: send_message(chat_id, f"👤 بفرما، اینم آیدی رئیس: {admin_id_sup}")
        else: send_message(chat_id, "❌ آیدی ادمین ثبت نشده!")
        answer_callback()
    
    elif user_id in ADMIN_IDS:
        if cb_data == "admin_broadcast":
            send_message(chat_id, "خب رئیس، میخوای به کیا پیام بفرستی؟ 😎", reply_markup=broadcast_menu_keyboard)
            answer_callback()
        elif cb_data in ["bc_users", "bc_groups", "bc_all"]:
            admin_states[user_id] = cb_data
            send_message(chat_id, "متن پیامت رو بفرست تا شلیکش کنم:")
            answer_callback()
        elif cb_data == "admin_settings":
            settings_kb = {"inline_keyboard": [[{"text": "تنظیم کانال", "callback_data": "set_sup_channel"}], [{"text": "تنظیم آیدی", "callback_data": "set_sup_admin"}]]}
            send_message(chat_id, "⚙️ منوی تنظیمات موتور ربات:", reply_markup=settings_kb)
            answer_callback()
        elif cb_data == "set_sup_channel":
            admin_states[user_id] = "set_sup_channel"
            send_message(chat_id, "لینک کانال رو بفرست ببینم:")
            answer_callback()
        elif cb_data == "set_sup_admin":
            admin_states[user_id] = "set_sup_admin"
            send_message(chat_id, "آیدی پشتیبان رو بفرست:")
            answer_callback()
        elif cb_data == "admin_fsub":
            send_message(chat_id, "📢 **منوی تنظیمات جوین اجباری:**", reply_markup=fsub_menu_keyboard)
            answer_callback()
        elif cb_data == "fsub_set_text":
            admin_states[user_id] = "fsub_set_text"
            send_message(chat_id, "✍️ متن جدید دسترسی محدود را ارسال کنید:")
            answer_callback()
        elif cb_data == "fsub_add_chan":
            admin_states[user_id] = "fsub_add_chan"
            send_message(chat_id, "➕ یوزرنیم کانال جدید را بدون @ ارسال کنید:")
            answer_callback()
        elif cb_data == "fsub_del_chan":
            admin_states[user_id] = "fsub_del_chan"
            send_message(chat_id, "❌ یوزرنیم کانالی که میخواهید حذف کنید را بدون @ ارسال کنید:")
            answer_callback()
        elif cb_data == "fsub_list":
            chans = data["settings"].get("fsub_channels", [])
            msg = "📋 **لیست کانال‌های فعال:**\n\n" + "\n".join([f"🔹 @{c}" for c in chans]) if chans else "📭 لیست خالی است رئیس!"
            send_message(chat_id, msg, reply_markup=fsub_menu_keyboard)
            answer_callback()
        elif cb_data == "back_to_panel":
            send_message(chat_id, "بفرمایید پنل مدیریت شما:", reply_markup=admin_panel_keyboard)
            answer_callback()
        elif cb_data == "admin_stats":
            users_count = len(data["users"])
            groups_count = len(data["groups"])
            send_message(chat_id, f"📊 **آمار تشکیلات ما** 🕵️‍♂️\n\n👤 رفقای ربات: {users_count}\n🏢 گروه‌های تحت سلطه: {groups_count}")
            answer_callback()
    else:
        answer_callback(".", True)

def main():
    print("Bot is running...")
    data = load_data()
    offset = 0
    while True:
        try:
            response = requests.get(BASE_URL + "getUpdates", params={"offset": offset, "timeout": 10})
            updates = response.json()
            if updates.get("ok"):
                for update in updates["result"]:
                    offset = update["update_id"] + 1
                    if "message" in update: handle_message(update["message"], data)
                    elif "callback_query" in update: handle_callback(update["callback_query"], data)
        except Exception as e:
            time.sleep(2)

if __name__ == "__main__":
    main()
