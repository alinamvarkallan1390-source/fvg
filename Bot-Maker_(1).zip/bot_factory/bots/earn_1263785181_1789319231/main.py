import os
import sys

# محافظت در برابر کرش روی ویندوز موقع پرینت فارسی/ایموجی وقتی خروجی به فایل ریدایرکت می‌شه
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import json
import time
import random
import sqlite3
import requests
from datetime import datetime

# ==================== تنظیمات ====================
TOKEN = "124718614:FamHpHFVp2MrsRJaf347fV6go3rQHdLvN1U"
BASE_URL = f"https://tapi.bale.ai/bot{TOKEN}/"
ADMIN_IDS = [1263785181]
ADMIN_CMD = "/panel"  # دستوری که پنل مدیریت رو باز می‌کنه (پیش‌فرض: /admin)
BOT_USERNAME = ""  # با getMe در ابتدای اجرا خودکار پر می‌شه
DB_FILE = "earn.db"
DEFAULT_SCREENSHOT_PROMPT = "📸 لطفاً اسکرین‌شات پرداخت رو ارسال کنید"

# ==================== دیتابیس ====================
def db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        chat_id INTEGER PRIMARY KEY,
        username TEXT DEFAULT '',
        balance INTEGER DEFAULT 0,
        step TEXT DEFAULT 'home',
        is_banned INTEGER DEFAULT 0,
        created_at TEXT DEFAULT '')""")
    try:
        conn.execute("ALTER TABLE users ADD COLUMN username TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass
    conn.execute("""CREATE TABLE IF NOT EXISTS referrals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        referrer_id INTEGER,
        referee_id INTEGER,
        is_verified INTEGER DEFAULT 0,
        created_at TEXT DEFAULT '')""")
    conn.execute("""CREATE TABLE IF NOT EXISTS withdrawal_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id INTEGER,
        amount INTEGER,
        card TEXT,
        type TEXT DEFAULT 'card',
        reject_reason TEXT DEFAULT '',
        track_id INTEGER,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT '')""")
    try:
        conn.execute("ALTER TABLE withdrawal_requests ADD COLUMN type TEXT DEFAULT 'card'")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE withdrawal_requests ADD COLUMN reject_reason TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE withdrawal_requests ADD COLUMN review_chat_id TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE withdrawal_requests ADD COLUMN review_msg_id INTEGER")
    except sqlite3.OperationalError:
        pass
    conn.execute("""CREATE TABLE IF NOT EXISTS force_channels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        channel_username TEXT UNIQUE)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT)""")

    defaults = {
        "bannerText": "💎 با دعوت دوستانت پول دربیار!\n\nلینک اختصاصی تو:\nLINK\n\nبه‌ازای هر دعوت موفق: TOMAN تومان",
        "earningsDescription": "دوستانت رو با لینک بالا دعوت کن. وقتی وارد بات بشن، TOMAN تومان به حسابت اضافه می‌شه!",
        "startText": "به ربات خوش آمدید 🌹",
        "rulesText": "قوانین ربات هنوز تنظیم نشده.",
        "supportText": "برای ارتباط با پشتیبانی به ادمین پیام بدید.",
        "guideText": "راهنمای استفاده هنوز تنظیم نشده.",
        "inviteBonus": "1000",
        "minimumWithdrawal": "5000",
        "withdrawalChannelId": "",
        "withdrawalLogChannelId": "",
        "requireScreenshot": "yes",
        "screenshotPromptText": DEFAULT_SCREENSHOT_PROMPT,
        "joinBotUrl": "",
        "confirmedLogTemplate": DEFAULT_CONFIRMED_TEMPLATE,
        "depositProofChannelId": "",
        "bannerImage": "",
    }
    for k, v in defaults.items():
        conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
    conn.commit()
    conn.close()

def get_setting(key, default=None):
    r = db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    val = r["value"] if r else None
    return val if val not in (None, "") else default

def set_setting(key, value):
    conn = db()
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )
    conn.commit()
    conn.close()

def is_admin(user_id):
    return int(user_id) in ADMIN_IDS

def get_user(chat_id):
    return db().execute("SELECT * FROM users WHERE chat_id=?", (chat_id,)).fetchone()

def get_user_by_username(username):
    return db().execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()

def ensure_user(chat_id, username=None):
    conn = db()
    row = conn.execute("SELECT * FROM users WHERE chat_id=?", (chat_id,)).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO users (chat_id, username, created_at) VALUES (?, ?, ?)",
            (chat_id, username or "", datetime.now().isoformat()),
        )
        conn.commit()
        conn.close()
        return True  # کاربر جدید بود
    elif username and username != row["username"]:
        conn.execute("UPDATE users SET username=? WHERE chat_id=?", (username, chat_id))
        conn.commit()
    conn.close()
    return False

def set_step(chat_id, step):
    conn = db()
    conn.execute("UPDATE users SET step=? WHERE chat_id=?", (step, chat_id))
    conn.commit()
    conn.close()

def add_balance(chat_id, amount):
    conn = db()
    conn.execute("UPDATE users SET balance = balance + ? WHERE chat_id=?", (amount, chat_id))
    conn.commit()
    conn.close()

def sub_balance(chat_id, amount):
    conn = db()
    conn.execute("UPDATE users SET balance = balance - ? WHERE chat_id=?", (amount, chat_id))
    conn.commit()
    conn.close()

# ==================== کیبوردها ====================
USER_KEYBOARD = {
    "keyboard": [
        [{"text": "💎 شروع کسب درآمد 💎"}],
        [{"text": "🏠 حساب کاربری"}, {"text": "🌟 برترین کاربران"}],
        [{"text": "💸 برداشت از حساب"}, {"text": "📊 تاریخچه برداشت"}],
        [{"text": "📚 راهنما"}, {"text": "📞 پشتیبانی"}, {"text": "📜 قوانین"}],
    ]
}
ADMIN_KEYBOARD = {
    "keyboard": [
        [{"text": "📊 آمار ربات"}],
        [{"text": "✏️ متن بنر"}, {"text": "🔘 توضیحات کسب درآمد"}],
        [{"text": "🚫 مسدود کردن کاربر"}, {"text": "✅ رفع مسدود کاربر"}],
        [{"text": "🔍 جستجوی کاربر"}],
        [{"text": "📢 ارسال همگانی"}],
        [{"text": "🎁 تنظیم هدیه دعوت"}, {"text": "💰 تنظیم حداقل برداشت"}],
        [{"text": "✏️ تنظیم متن شروع"}, {"text": "📜 تنظیم متن قوانین"}],
        [{"text": "🧑‍💻 تنظیم متن پشتیبانی"}, {"text": "📚 تنظیم متن راهنما"}],
        [{"text": "➕ افزودن جوین اجباری"}, {"text": "➖ حذف جوین اجباری"}],
        [{"text": "🔧 تنظیم کانال بررسی برداشت"}, {"text": "📋 تنظیم کانال لاگ تایید‌شده‌ها"}],
        [{"text": "📸 نیاز به اسکرین‌شات: روشن/خاموش"}, {"text": "✏️ متن درخواست اسکرین‌شات"}],
        [{"text": "🔗 لینک دکمه ورود به ربات"}, {"text": "📝 ویرایش فرم تاییدشده"}],
        [{"text": "🔙 بازگشت به منو اصلی"}],
    ]
}
BACK_ADMIN_KEYBOARD = {"keyboard": [[{"text": "🔙 بازگشت به مدیریت"}]]}
BACK_USER_KEYBOARD = {"keyboard": [[{"text": "🔙 بازگشت به منو اصلی"}]]}
WITHDRAW_TYPE_KEYBOARD = {"keyboard": [[{"text": "💳 کارت به کارت"}, {"text": "🎁 پاکت هدیه"}], [{"text": "🔙 بازگشت به منو اصلی"}]]}

# ==================== API بله ====================
def api_request(method, data=None, max_retries=3):
    for attempt in range(max_retries):
        try:
            url = BASE_URL + method
            if data:
                r = requests.post(url, json=data, timeout=20)
            else:
                r = requests.get(url, timeout=20)
            return r.json()
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(2)
    return {"ok": False}

def send_message(chat_id, text, keyboard=None, parse_mode=None):
    data = {"chat_id": chat_id, "text": text}
    if keyboard:
        data["reply_markup"] = keyboard
    if parse_mode:
        data["parse_mode"] = parse_mode
    return api_request("sendMessage", data)

def send_photo(chat_id, file_id, caption=None, keyboard=None, parse_mode=None):
    data = {"chat_id": chat_id, "photo": file_id}
    if caption:
        data["caption"] = caption
    if keyboard:
        data["reply_markup"] = keyboard
    if parse_mode:
        data["parse_mode"] = parse_mode
    return api_request("sendPhoto", data)

def mask_card(card):
    """شماره کارت رو برای نمایش عمومی می‌پوشونه، فقط ابتدا/انتهاش معلومه."""
    c = card.strip()
    if len(c) <= 8:
        return "*" * len(c)
    return f"{c[:6]}****{c[-4:]}"

def join_button_keyboard():
    url = get_setting("joinBotUrl", "") or (f"https://ble.ir/{BOT_USERNAME}" if BOT_USERNAME else "")
    if not url:
        return None
    return {"inline_keyboard": [[{"text": "ورود به ربات و کسب درآمد", "url": url}]]}

def edit_message(chat_id, message_id, text, keyboard=None):
    data = {"chat_id": chat_id, "message_id": message_id, "text": text}
    if keyboard:
        data["reply_markup"] = keyboard
    return api_request("editMessageText", data)

def answer_callback(callback_id, text="", alert=False):
    return api_request("answerCallbackQuery", {"callback_query_id": callback_id, "text": text, "show_alert": alert})

def get_chat_member(chat_id, user_id):
    return api_request("getChatMember", {"chat_id": chat_id, "user_id": user_id})

def fetch_bot_username():
    global BOT_USERNAME
    r = api_request("getMe")
    if r.get("ok"):
        BOT_USERNAME = r["result"].get("username", "")

# ==================== توابع کمکی ====================
def jnow_date():
    return time.strftime("%Y/%m/%d")

def jnow_time():
    return time.strftime("%H:%M:%S")

def fmt_dt(iso_str):
    try:
        dt = datetime.fromisoformat(iso_str)
        return dt.strftime("%H:%M - %Y/%m/%d")
    except Exception:
        return iso_str or "-"

def render_placeholders(text, user_id):
    link = f"https://ble.ir/{BOT_USERNAME}?start={user_id}" if BOT_USERNAME else "(لینک بعد از تنظیم توکن آماده می‌شه)"
    bonus = get_setting("inviteBonus", "1000")
    return text.replace("LINK", link).replace("TOMAN", str(bonus))

# ==================== پردازش پیام‌ها ====================
def handle_start_referral(chat_id, text):
    """اگه کاربر جدید با /start ref_id وارد شده، رفرال رو ثبت می‌کنه (پاداش موقع تایید عضویت پرداخت می‌شه)."""
    parts = text.split(" ", 1)
    if len(parts) < 2:
        return
    referrer_raw = parts[1].strip()
    if not referrer_raw.isdigit():
        return
    referrer_id = int(referrer_raw)
    if referrer_id == chat_id:
        return
    ref = get_user(referrer_id)
    if ref is None:
        return
    conn = db()
    conn.execute(
        "INSERT INTO referrals (referrer_id, referee_id, created_at) VALUES (?,?,?)",
        (referrer_id, chat_id, datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()


def check_force_join(chat_id):
    """لیست کانال‌هایی که کاربر عضو نیست رو برمی‌گردونه؛ اگه خالی بود یعنی همه‌جا عضوعه."""
    channels = [r["channel_username"] for r in db().execute("SELECT channel_username FROM force_channels").fetchall()]
    if not channels:
        return []
    not_joined = []
    for ch in channels:
        res = get_chat_member(f"@{ch}", chat_id)
        status = (res.get("result") or {}).get("status")
        if status not in ("member", "administrator", "creator"):
            not_joined.append(ch)
    return not_joined


def handle_start(chat_id, text, username=""):
    is_new = ensure_user(chat_id, username)
    if is_new:
        handle_start_referral(chat_id, text)

    not_joined = check_force_join(chat_id) if not is_admin(chat_id) else []
    if not_joined:
        msg = "🔔 برای ادامه، ابتدا در کانال‌های زیر عضو شوید:\n\n"
        buttons = []
        for ch in not_joined:
            msg += f"کانال: @{ch}\n"
            buttons.append([{"text": f"عضویت در کانال {ch}", "url": f"https://ble.ir/{ch}"}])
        buttons.append([{"text": "بررسی عضویت", "callback_data": "joined_all"}])
        send_message(chat_id, msg, {"inline_keyboard": buttons})
        return

    finalize_join(chat_id)


def finalize_join(chat_id):
    ensure_user(chat_id)
    pending = db().execute(
        "SELECT * FROM referrals WHERE referee_id=? AND is_verified=0", (chat_id,)
    ).fetchone()
    if pending:
        conn = db()
        conn.execute("UPDATE referrals SET is_verified=1 WHERE referee_id=?", (chat_id,))
        conn.commit()
        conn.close()
        referrer_id = pending["referrer_id"]
        bonus = int(get_setting("inviteBonus", "1000"))
        add_balance(referrer_id, bonus)
        send_message(referrer_id, f"🎉 تبریک! زیرمجموعه شما با موفقیت تایید شد.\n\n💰 به حساب شما {bonus:,} تومان اضافه گردید.")

    text = get_setting("startText", "به ربات خوش آمدید 🌹")
    send_message(chat_id, text, USER_KEYBOARD)
    set_step(chat_id, "home")


def handle_message(msg):
    chat_id = msg["chat"]["id"]
    user_id = msg.get("from", {}).get("id", chat_id)
    text = msg.get("text", "") or ""
    message_id = msg["message_id"]
    username = msg.get("from", {}).get("username", "")

    # توجه: اینجا عمداً ensure_user صدا زده نمی‌شه؛ چون تشخیص «کاربر تازه‌وارد» (برای رفرال)
    # داخل handle_start انجام می‌شه و باید همون اولین جایی باشه که کاربر رو می‌سازه.
    user = get_user(chat_id)
    step = user["step"] if user else "home"

    if user and user["is_banned"] and not is_admin(chat_id):
        send_message(chat_id, "⚠️ شما از ربات مسدود شده‌اید!\n\nبرای رفع مشکل به پشتیبانی مراجعه کنید")
        return

    # ---------- عکس اسکرین‌شات پرداخت (ادمین) ----------
    if step.startswith("await-screenshot-") and is_admin(chat_id):
        track_id = int(step.split("-")[2])
        photos = msg.get("photo")
        if not photos:
            send_message(chat_id, "❌ باید عکس (اسکرین‌شات) بفرستی، نه متن. یا برای انصراف /admin رو بزن.")
            return
        file_id = photos[-1]["file_id"]  # بزرگ‌ترین سایز
        set_step(chat_id, "panel")
        ok, err = finalize_confirm(track_id, chat_id, screenshot_file_id=file_id)
        send_message(chat_id, "✅ تایید نهایی انجام شد." if ok else err, ADMIN_KEYBOARD)
        return

    # ---------- شروع ----------
    if text.startswith("/start") or text == "🔙 بازگشت به منو اصلی":
        handle_start(chat_id, text, username)
        return

    ensure_user(chat_id, username)  # برای بقیه‌ی پیام‌ها (غیر از /start) اینجا مطمئن می‌شیم کاربر توی دیتابیسه

    # ---------- منوی کاربر ----------
    if text == "💎 شروع کسب درآمد 💎":
        banner = render_placeholders(get_setting("bannerText", ""), chat_id)
        desc = render_placeholders(get_setting("earningsDescription", ""), chat_id)
        send_message(chat_id, banner)
        send_message(chat_id, desc)
        return

    if text == "🏠 حساب کاربری":
        total = db().execute("SELECT COUNT(*) c FROM referrals WHERE referrer_id=?", (chat_id,)).fetchone()["c"]
        verified = db().execute("SELECT COUNT(*) c FROM referrals WHERE referrer_id=? AND is_verified=1", (chat_id,)).fetchone()["c"]
        unverified = total - verified
        join_time = fmt_dt(user["created_at"]) if user else "-"
        info = (
            f"جزئیات حساب کاربری ({chat_id}) 👇\n\n"
            f"💼 موجودی کیف پول شما: {user['balance']:,} تومان\n"
            f"🗓 تاریخ ثبت‌نام: {join_time}\n\n"
            f"👥 تعداد زیرمجموعه‌های شما: {total}\n"
            f"✅ زیرمجموعه‌های تایید شده: {verified}\n"
            f"❌ زیرمجموعه‌های تایید نشده: {unverified}"
        )
        send_message(chat_id, info)
        return

    if text == "🌟 برترین کاربران":
        rows = db().execute(
            "SELECT referrer_id, COUNT(*) c FROM referrals WHERE referrer_id != 0 "
            "GROUP BY referrer_id ORDER BY c DESC LIMIT 10"
        ).fetchall()
        out = "🌟 برترین کاربران\n\n"
        medals = {1: "🥇", 2: "🥈", 3: "🥉"}
        for i, r in enumerate(rows, start=1):
            medal = medals.get(i, "🎖️")
            out += f"{medal} - {r['referrer_id']} | {r['c']} زیرمجموعه\n\n"
        send_message(chat_id, out)
        return

    if text in ("📚 راهنما",):
        send_message(chat_id, get_setting("guideText", "تنظیم نشده"))
        return
    if text == "📞 پشتیبانی":
        send_message(chat_id, get_setting("supportText", "تنظیم نشده"))
        return
    if text == "📜 قوانین":
        send_message(chat_id, get_setting("rulesText", "تنظیم نشده"))
        return

    if text == "📊 تاریخچه برداشت":
        rows = db().execute(
            "SELECT * FROM withdrawal_requests WHERE chat_id=? ORDER BY id DESC LIMIT 5", (chat_id,)
        ).fetchall()
        out = "📊 تاریخچه برداشت‌ها\n\n"
        if not rows:
            out += "❌ هیچ برداشت اخیری یافت نشد."
        else:
            status_map = {"confirme": "✅ تایید شده", "rejected": "❌ رد شده", "pending": "⏳ در صف انتظار"}
            type_map = {"card": "💳 کارت به کارت", "gift": "🎁 پاکت هدیه"}
            for w in rows:
                type_label = type_map.get(w["type"] or "card", "💳 کارت به کارت")
                detail_label = "شماره کارت" if (w["type"] or "card") == "card" else "آیدی گیرنده"
                out += (
                    f"🔹 برداشت ({type_label})\n💰 مبلغ: {w['amount']:,} تومان\n"
                    f"📅 تاریخ: {fmt_dt(w['created_at'])}\n"
                    f"🎟 کد رهگیری: {w['track_id']}\n"
                    f"📌 {detail_label}: {w['card']}\n"
                    f"📍 وضعیت: {status_map.get(w['status'], w['status'])}\n"
                )
                if w["status"] == "rejected" and w["reject_reason"]:
                    out += f"📝 دلیل رد: {w['reject_reason']}\n"
                out += "\n"
        send_message(chat_id, out)
        return

    # ---------- برداشت ----------
    if text == "💸 برداشت از حساب":
        send_message(chat_id, "لطفاً روش برداشت رو انتخاب کنید:", WITHDRAW_TYPE_KEYBOARD)
        set_step(chat_id, "enter-type-withdrawal")
        return

    if text == "💳 کارت به کارت":
        send_message(chat_id, f"💸 لطفاً مبلغ برداشت رو وارد کنید:\n\n💰 موجودی شما: {user['balance']:,} تومان", BACK_USER_KEYBOARD)
        set_step(chat_id, "enter-amount-card")
        return

    if text == "🎁 پاکت هدیه":
        send_message(chat_id, f"💸 لطفاً مبلغ پاکت هدیه رو وارد کنید:\n\n💰 موجودی شما: {user['balance']:,} تومان", BACK_USER_KEYBOARD)
        set_step(chat_id, "enter-amount-gift")
        return

    if step in ("enter-amount-card", "enter-amount-gift"):
        withdraw_type = "card" if step == "enter-amount-card" else "gift"
        if not text.replace(".", "", 1).isdigit():
            send_message(chat_id, "⚠️ مبلغ نامعتبره. یه عدد صحیح بفرست:")
            return
        amount = int(float(text))
        if amount <= 0:
            send_message(chat_id, "⚠️ مبلغ نامعتبره. یه عدد صحیح بفرست:")
            return
        if amount > user["balance"]:
            send_message(chat_id, f"⚠️ موجودی کافی برای برداشت {amount:,} تومان نداری.")
            return
        min_w = int(get_setting("minimumWithdrawal", "5000"))
        if amount < min_w:
            send_message(chat_id, f"⚠️ مبلغ کمتر از حداقل برداشت ({min_w:,} تومان) هست.")
            return
        if withdraw_type == "card":
            send_message(chat_id, "💳 لطفاً شماره کارت ۱۶ رقمی بانکی خودتو بفرست:")
        else:
            send_message(chat_id, "🎁 لطفاً یوزرنیم کسی که باید پاکت هدیه بهش داده بشه رو بفرست (با یا بدون @):")
        set_step(chat_id, f"enter-detail-{withdraw_type}-{amount}")
        return

    if step.startswith("enter-detail-"):
        _, _, withdraw_type, amount_s = step.split("-", 3)
        amount = int(amount_s)
        if withdraw_type == "gift":
            uname = text.strip().lstrip("@")
            recipient_row = get_user_by_username(uname)
            if not recipient_row:
                send_message(chat_id, f"⚠️ کاربری با یوزرنیم @{uname} تو ربات پیدا نشد.\nاول باید طرف مقابل حداقل یه‌بار /start رو به ربات زده باشه. یوزرنیم رو دوباره بفرست:")
                return
            if recipient_row["chat_id"] == chat_id:
                send_message(chat_id, "⚠️ نمی‌تونی به خودت پاکت هدیه بدی. یوزرنیم دیگه‌ای بفرست:")
                return
            detail_value = uname
        else:
            detail_value = text.strip()
        if withdraw_type == "card":
            invoice = (
                f"🔹 فاکتور درخواست برداشت (💳 کارت به کارت)\n💰 مبلغ: {amount:,} تومان\n"
                f"🏦 شماره کارت: {detail_value}\n⏰ {jnow_date()} {jnow_time()}"
            )
        else:
            invoice = (
                f"🔹 فاکتور درخواست پاکت هدیه (🎁)\n💰 مبلغ: {amount:,} تومان\n"
                f"🎯 گیرنده: @{detail_value}\n⏰ {jnow_date()} {jnow_time()}"
            )
        kb = {"inline_keyboard": [[
            {"text": "✅ تایید برداشت", "callback_data": f"confirm_withdrawal-{withdraw_type}-{amount}-{detail_value}"},
            {"text": "❌ انصراف", "callback_data": "cancel_withdrawal"},
        ]]}
        send_message(chat_id, invoice, kb)
        set_step(chat_id, "confirm-or-cancel-withdrawal")
        return

    # ---------- منوی ادمین ----------
    if is_admin(chat_id):
        if handle_admin_message(chat_id, text, step, message_id):
            return

    # پیش‌فرض: منوی اصلی
    send_message(chat_id, get_setting("startText", "به ربات خوش آمدید 🌹"), USER_KEYBOARD)
    set_step(chat_id, "home")


def handle_admin_message(chat_id, text, step, message_id):
    if text in (ADMIN_CMD, "🔙 بازگشت به مدیریت"):
        send_message(chat_id, "👋 به پنل مدیریت خوش اومدی!", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "📊 آمار ربات":
        total_users = db().execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
        total_wd = db().execute("SELECT COALESCE(SUM(amount),0) s FROM withdrawal_requests WHERE status='confirme'").fetchone()["s"]
        today = time.strftime("%Y-%m-%d")
        today_wd = db().execute(
            "SELECT COALESCE(SUM(amount),0) s FROM withdrawal_requests WHERE status='confirme' AND date(created_at)=?", (today,)
        ).fetchone()["s"]
        new_today = db().execute("SELECT COUNT(*) c FROM users WHERE date(created_at)=?", (today,)).fetchone()["c"]
        out = (
            f"📊 آمار ربات\n\n👥 تعداد کل اعضا: {total_users}\n🆕 اعضای جدید امروز: {new_today}\n"
            f"💸 مجموع برداشت‌های تایید شده: {total_wd:,} تومان\n💰 برداشت‌های تایید شده امروز: {today_wd:,} تومان"
        )
        send_message(chat_id, out)
        return True

    if text == "✏️ متن بنر":
        send_message(chat_id, "لطفاً متن جدید بنر رو بفرست. برای لینک از LINK و برای مبلغ از TOMAN استفاده کن:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-banner-text")
        return True
    if step == "set-banner-text":
        set_setting("bannerText", text)
        send_message(chat_id, "✅ متن بنر ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "🔘 توضیحات کسب درآمد":
        send_message(chat_id, "لطفاً توضیحات جدید رو بفرست (LINK و TOMAN قابل استفاده‌ست):", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-earnings-description")
        return True
    if step == "set-earnings-description":
        set_setting("earningsDescription", text)
        send_message(chat_id, "✅ توضیحات ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "🚫 مسدود کردن کاربر":
        send_message(chat_id, "آیدی عددی کاربر رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "block-user")
        return True
    if step == "block-user":
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر بفرست.", BACK_ADMIN_KEYBOARD)
            return True
        target = int(text)
        u = get_user(target)
        if u:
            conn = db()
            conn.execute("UPDATE users SET is_banned=1 WHERE chat_id=?", (target,))
            conn.commit()
            conn.close()
            send_message(chat_id, f"✅ کاربر {target} مسدود شد.", ADMIN_KEYBOARD)
        else:
            send_message(chat_id, "❌ کاربری با این آیدی وجود ندارد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "✅ رفع مسدود کاربر":
        send_message(chat_id, "آیدی عددی کاربر رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "unblock-user")
        return True
    if step == "unblock-user":
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر بفرست.", BACK_ADMIN_KEYBOARD)
            return True
        target = int(text)
        u = get_user(target)
        if u:
            conn = db()
            conn.execute("UPDATE users SET is_banned=0 WHERE chat_id=?", (target,))
            conn.commit()
            conn.close()
            send_message(chat_id, f"✅ کاربر {target} آزاد شد.", ADMIN_KEYBOARD)
        else:
            send_message(chat_id, "❌ کاربری با این آیدی وجود ندارد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "🔍 جستجوی کاربر":
        send_message(chat_id, "آیدی عددی کاربر رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "search-user")
        return True
    if step == "search-user":
        if not text.isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر بفرست.", BACK_ADMIN_KEYBOARD)
            return True
        target = int(text)
        u = get_user(target)
        if u:
            refs = db().execute(
                "SELECT * FROM referrals WHERE referrer_id=? ORDER BY id DESC LIMIT 5", (target,)
            ).fetchall()
            recent = "".join(f"🧑‍💻 کاربر: {r['referee_id']} | {fmt_dt(r['created_at'])}\n" for r in refs) or "❌ زیرمجموعه‌ای ثبت نشده."
            out = (
                f"🔍 اطلاعات کاربر {target}:\n\n💳 موجودی: {u['balance']:,}\n"
                f"🚫 وضعیت: {'مسدود' if u['is_banned'] else 'آزاد'}\n👥 تعداد زیرمجموعه: {len(refs)}\n\n📋 آخرین‌ها:\n{recent}"
            )
            send_message(chat_id, out, ADMIN_KEYBOARD)
        else:
            send_message(chat_id, "❌ کاربری با این آیدی یافت نشد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "📢 ارسال همگانی":
        send_message(chat_id, "پیامی که می‌خوای همگانی ارسال بشه رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "send-all")
        return True
    if step == "send-all":
        users = db().execute("SELECT chat_id FROM users").fetchall()
        count = 0
        for u in users:
            send_message(u["chat_id"], text)
            count += 1
            time.sleep(0.3)
        send_message(chat_id, f"✅ پیام به {count} نفر ارسال شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "🎁 تنظیم هدیه دعوت":
        send_message(chat_id, "مبلغ هدیه دعوت رو به تومان بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-invite-bonus")
        return True
    if step == "set-invite-bonus":
        if not text.isdigit() or int(text) <= 0:
            send_message(chat_id, "❌ مبلغ معتبر بفرست.", BACK_ADMIN_KEYBOARD)
            return True
        set_setting("inviteBonus", text)
        send_message(chat_id, f"✅ هدیه دعوت تنظیم شد: {int(text):,} تومان", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "💰 تنظیم حداقل برداشت":
        send_message(chat_id, "حداقل مبلغ برداشت رو به تومان بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-min-withdrawal")
        return True
    if step == "set-min-withdrawal":
        if not text.isdigit() or int(text) <= 0:
            send_message(chat_id, "❌ مبلغ معتبر بفرست.", BACK_ADMIN_KEYBOARD)
            return True
        set_setting("minimumWithdrawal", text)
        send_message(chat_id, f"✅ حداقل برداشت تنظیم شد: {int(text):,} تومان", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "✏️ تنظیم متن شروع":
        send_message(chat_id, "متن شروع جدید رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-start-text")
        return True
    if step == "set-start-text":
        set_setting("startText", text)
        send_message(chat_id, "✅ متن شروع ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "📜 تنظیم متن قوانین":
        send_message(chat_id, "متن قوانین جدید رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-rules-text")
        return True
    if step == "set-rules-text":
        set_setting("rulesText", text)
        send_message(chat_id, "✅ متن قوانین ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "🧑‍💻 تنظیم متن پشتیبانی":
        send_message(chat_id, "متن پشتیبانی جدید رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-support-text")
        return True
    if step == "set-support-text":
        set_setting("supportText", text)
        send_message(chat_id, "✅ متن پشتیبانی ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "📚 تنظیم متن راهنما":
        send_message(chat_id, "متن راهنمای جدید رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-guide-text")
        return True
    if step == "set-guide-text":
        set_setting("guideText", text)
        send_message(chat_id, "✅ متن راهنما ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "➕ افزودن جوین اجباری":
        send_message(chat_id, "یوزرنیم کانال (بدون @) رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "add-force-channel")
        return True
    if step == "add-force-channel":
        ch = text.strip().lstrip("@")
        conn = db()
        conn.execute("INSERT OR IGNORE INTO force_channels (channel_username) VALUES (?)", (ch,))
        conn.commit()
        conn.close()
        send_message(chat_id, f"✅ کانال {ch} به جوین اجباری اضافه شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "➖ حذف جوین اجباری":
        rows = db().execute("SELECT channel_username FROM force_channels").fetchall()
        if not rows:
            send_message(chat_id, "⚠️ کانالی ثبت نشده.", ADMIN_KEYBOARD)
            set_step(chat_id, "panel")
            return True
        out = "یوزرنیم کانالی که می‌خوای حذف بشه رو بفرست:\n\n"
        out += "\n".join(f"{i+1}. {r['channel_username']}" for i, r in enumerate(rows))
        send_message(chat_id, out, BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "remove-force-channel")
        return True
    if step == "remove-force-channel":
        ch = text.strip().lstrip("@")
        conn = db()
        cur = conn.execute("DELETE FROM force_channels WHERE channel_username=?", (ch,))
        conn.commit()
        conn.close()
        if cur.rowcount:
            send_message(chat_id, f"✅ کانال {ch} حذف شد.", ADMIN_KEYBOARD)
        else:
            send_message(chat_id, f"⚠️ کانال {ch} پیدا نشد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "🔧 تنظیم کانال بررسی برداشت":
        send_message(chat_id, "آیدی عددی کانالی که درخواست‌های برداشت برای بررسی/تایید اونجا پست بشن رو بفرست:\n(بات باید ادمین اون کانال باشه)", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-withdrawal-channel")
        return True
    if step == "set-withdrawal-channel":
        if not text.lstrip("-").isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر بفرست.", BACK_ADMIN_KEYBOARD)
            return True
        set_setting("withdrawalChannelId", text)
        send_message(chat_id, "✅ کانال بررسی برداشت ثبت شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "📋 تنظیم کانال لاگ تایید‌شده‌ها":
        send_message(chat_id, "آیدی عددی کانالی که بعد از تایید نهایی، لاگ برداشت‌های تایید‌شده اونجا پست بشه رو بفرست:\n(بات باید ادمین اون کانال باشه)", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-withdrawal-log-channel")
        return True
    if step == "set-withdrawal-log-channel":
        if not text.lstrip("-").isdigit():
            send_message(chat_id, "❌ آیدی عددی معتبر بفرست.", BACK_ADMIN_KEYBOARD)
            return True
        set_setting("withdrawalLogChannelId", text)
        send_message(chat_id, "✅ کانال لاگ تایید‌شده‌ها ثبت شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "📸 نیاز به اسکرین‌شات: روشن/خاموش":
        current = get_setting("requireScreenshot", "yes")
        new_val = "no" if current == "yes" else "yes"
        set_setting("requireScreenshot", new_val)
        state_fa = "روشنه (موقع تایید برداشت کارتی، اسکرین‌شات پرداخت می‌خواد)" if new_val == "yes" else "خاموشه (تایید بدون نیاز به اسکرین‌شات انجام می‌شه)"
        send_message(chat_id, f"✅ الان {state_fa}", ADMIN_KEYBOARD)
        return True

    if text == "✏️ متن درخواست اسکرین‌شات":
        send_message(chat_id, f"متن فعلی:\n\n{get_setting('screenshotPromptText', DEFAULT_SCREENSHOT_PROMPT)}\n\nمتن جدید رو بفرست:", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-screenshot-prompt")
        return True
    if step == "set-screenshot-prompt":
        set_setting("screenshotPromptText", text)
        send_message(chat_id, "✅ ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if text == "🔗 لینک دکمه ورود به ربات":
        current = get_setting("joinBotUrl", "")
        send_message(chat_id, f"لینک فعلی: {current or '(تنظیم نشده - فعلاً دکمه نمایش داده نمی‌شه)'}\n\nلینک جدید (باید با http شروع بشه) رو بفرست، یا برای حذف دکمه بفرست: -", BACK_ADMIN_KEYBOARD)
        set_step(chat_id, "set-join-url")
        return True
    if step == "set-join-url":
        val = text.strip()
        if val == "-":
            set_setting("joinBotUrl", "")
            send_message(chat_id, "✅ دکمه حذف شد.", ADMIN_KEYBOARD)
        elif val.startswith("http://") or val.startswith("https://"):
            set_setting("joinBotUrl", val)
            send_message(chat_id, "✅ لینک ذخیره شد.", ADMIN_KEYBOARD)
        else:
            send_message(chat_id, "❌ لینک باید با http:// یا https:// شروع بشه.", BACK_ADMIN_KEYBOARD)
            return True
        set_step(chat_id, "panel")
        return True

    if text == "📝 ویرایش فرم تاییدشده":
        current = get_setting("confirmedLogTemplate", DEFAULT_CONFIRMED_TEMPLATE)
        send_message(
            chat_id,
            f"فرم فعلی (که موقع تایید برداشت به کانال لاگ ارسال می‌شه):\n\n{current}\n\n"
            "می‌تونی از جای‌گزین‌های {recipient} (نام/یوزرنیم گیرنده)، {amount} (مبلغ) و {track_id} (کد پیگیری) استفاده کنی.\n"
            "برای *بولد* از ستاره دور کلمه استفاده کن.\n\nمتن جدید رو بفرست:",
            BACK_ADMIN_KEYBOARD,
        )
        set_step(chat_id, "set-confirmed-template")
        return True
    if step == "set-confirmed-template":
        if "{recipient}" not in text or "{amount}" not in text or "{track_id}" not in text:
            send_message(chat_id, "❌ متن باید حتماً شامل {recipient} و {amount} و {track_id} باشه. دوباره بفرست:", BACK_ADMIN_KEYBOARD)
            return True
        set_setting("confirmedLogTemplate", text)
        send_message(chat_id, "✅ فرم ذخیره شد.", ADMIN_KEYBOARD)
        set_step(chat_id, "panel")
        return True

    if step.startswith("reject-reason-"):
        track_id = int(step.split("-")[2])
        reason = text.strip()
        w = db().execute("SELECT * FROM withdrawal_requests WHERE track_id=?", (track_id,)).fetchone()
        set_step(chat_id, "panel")
        if not w or w["status"] != "pending":
            send_message(chat_id, "⚠️ این درخواست دیگه معتبر نیست (شاید قبلاً پردازش شده).", ADMIN_KEYBOARD)
            return True
        finalize_reject(track_id, reason, chat_id)
        send_message(chat_id, "✅ رد درخواست با دلیل ثبت شد.", ADMIN_KEYBOARD)
        return True

    return False


def notify_admins_or_channel(text, keyboard):
    """پیام رو به کانال بررسی برداشت می‌فرسته (اگه تنظیم شده)، وگرنه به همه‌ی ادمین‌ها. message_id رو برمی‌گردونه."""
    review_channel = get_setting("withdrawalChannelId")
    target = review_channel if review_channel else None
    if target:
        res = send_message(target, text, keyboard)
        if res.get("ok"):
            return target, res["result"]["message_id"]
        return None, None
    else:
        last = (None, None)
        for admin_id in ADMIN_IDS:
            res = send_message(admin_id, text, keyboard)
            if res.get("ok"):
                last = (str(admin_id), res["result"]["message_id"])
        return last


def display_name(chat_id):
    u = get_user(chat_id)
    if u and u["username"]:
        return f"@{u['username']}"
    return str(chat_id)


DEFAULT_CONFIRMED_TEMPLATE = (
    "📢 *تراکنش جدید تایید شده:*\n"
    "🎁 *دریافت‌کننده:* {recipient}\n"
    "💰 *مبلغ:* {amount} تومان\n"
    "🎟 *کد پیگیری:* {track_id}"
)

def build_confirmed_log_text(w):
    requester, amount, wtype, detail, track_id = w["chat_id"], w["amount"], w["type"], w["card"], w["track_id"]
    recipient_name = f"@{detail}" if wtype == "gift" else display_name(requester)
    tmpl = get_setting("confirmedLogTemplate", DEFAULT_CONFIRMED_TEMPLATE)
    return tmpl.format(recipient=recipient_name, amount=f"{amount:,}", track_id=track_id)


def finalize_confirm(track_id, chat_id_acted_by, screenshot_file_id=None):
    w = db().execute("SELECT * FROM withdrawal_requests WHERE track_id=?", (track_id,)).fetchone()
    if not w or w["status"] != "pending":
        return False, "این درخواست دیگه معتبر نیست (شاید قبلاً پردازش شده)."

    requester, amount, wtype, detail = w["chat_id"], w["amount"], w["type"], w["card"]

    recipient_chat_id = None
    if wtype == "gift":
        recipient_row = get_user_by_username(detail)
        if not recipient_row:
            return False, f"⚠️ کاربری با یوزرنیم @{detail} پیدا نشد (شاید یوزرنیمش رو عوض کرده). درخواست هنوز pending موند."
        recipient_chat_id = recipient_row["chat_id"]

    conn = db()
    conn.execute("UPDATE withdrawal_requests SET status='confirme' WHERE track_id=?", (track_id,))
    conn.commit()
    conn.close()

    if wtype == "gift":
        ensure_user(recipient_chat_id)
        add_balance(recipient_chat_id, amount)
        recipient_balance = get_user(recipient_chat_id)["balance"]
        send_message(recipient_chat_id, f"🎁 یه پاکت هدیه به مبلغ {amount:,} تومان براتون واریز شد!\n💰 موجودی فعلی: {recipient_balance:,}")
        send_message(requester, f"✅ پاکت هدیه‌ی شما به مبلغ {amount:,} تومان با موفقیت برای @{detail} ارسال شد.\n🎟 کد: {track_id}")
    else:
        send_message(requester, f"✅ درخواست برداشت کارت‌به‌کارت شما تایید شد.\n\n💰 مبلغ: {amount:,} تومان\n🏦 کارت: {mask_card(detail)}\n🎟 کد: {track_id}")

    # ادیت پیام کانال بررسی (حذف دکمه‌ها)
    review_summary = f"✅ تایید شد (کد {track_id})"
    if w["review_chat_id"] and w["review_msg_id"]:
        edit_message(w["review_chat_id"], w["review_msg_id"], review_summary)

    # پست به کانال لاگ تایید‌شده‌ها (کانال دوم)، اگه تنظیم شده باشه
    log_channel = get_setting("withdrawalLogChannelId")
    if log_channel:
        log_text = build_confirmed_log_text(w)
        kb = join_button_keyboard()
        if screenshot_file_id:
            send_photo(log_channel, screenshot_file_id, caption=log_text, keyboard=kb, parse_mode="Markdown")
        else:
            send_message(log_channel, log_text, keyboard=kb, parse_mode="Markdown")

    return True, None


def finalize_reject(track_id, reason, acted_by_chat_id):
    w = db().execute("SELECT * FROM withdrawal_requests WHERE track_id=?", (track_id,)).fetchone()
    if not w or w["status"] != "pending":
        return False, "این درخواست دیگه معتبر نیست (شاید قبلاً پردازش شده)."

    conn = db()
    conn.execute("UPDATE withdrawal_requests SET status='rejected', reject_reason=? WHERE track_id=?", (reason, track_id))
    conn.commit()
    conn.close()

    requester, amount, wtype = w["chat_id"], w["amount"], w["type"]
    add_balance(requester, amount)  # برگردوندن مبلغ به حساب کاربر

    kind_fa = "پاکت هدیه" if wtype == "gift" else "برداشت کارت‌به‌کارت"
    send_message(
        requester,
        f"❌ درخواست {kind_fa} شما رد شد و مبلغ به حسابتون برگشت.\n\n"
        f"💰 مبلغ: {amount:,} تومان\n📝 دلیل رد: {reason}\n🎟 کد: {track_id}",
    )

    if w["review_chat_id"] and w["review_msg_id"]:
        edit_message(w["review_chat_id"], w["review_msg_id"], f"❌ رد شد (کد {track_id})\n📝 دلیل: {reason}")

    return True, None


def handle_callback(cb):
    cb_id = cb["id"]
    data = cb.get("data", "")
    message = cb.get("message", {})
    chat_id = message.get("chat", {}).get("id")
    message_id = message.get("message_id")
    user_id = cb.get("from", {}).get("id", chat_id)

    answer_callback(cb_id)

    if data == "joined_all":
        not_joined = check_force_join(chat_id)
        if not_joined:
            answer_callback(cb_id, "هنوز عضو همه کانال‌ها نشدی!", True)
            return
        finalize_join(chat_id)
        return

    if data == "cancel_withdrawal":
        edit_message(chat_id, message_id, "❌ درخواست برداشت لغو شد")
        send_message(chat_id, "به منوی اصلی برگشتی", USER_KEYBOARD)
        set_step(chat_id, "home")
        return

    if data.startswith("confirm_withdrawal-"):
        _, wtype, amount_s, detail = data.split("-", 3)
        amount = int(amount_s)
        user = get_user(chat_id)
        if not user or amount > user["balance"]:
            edit_message(chat_id, message_id, "⚠️ موجودی کافی برای این برداشت نداری.")
            return

        for _ in range(20):
            track_id = random.randint(1000000, 9999999)
            exists = db().execute("SELECT COUNT(*) c FROM withdrawal_requests WHERE track_id=?", (track_id,)).fetchone()["c"]
            if not exists:
                break

        sub_balance(chat_id, amount)

        review_chat_id, review_msg_id = None, None
        kind_fa = "🎁 پاکت هدیه" if wtype == "gift" else "💳 کارت به کارت"
        detail_line = f"🎯 آیدی گیرنده: {detail}" if wtype == "gift" else f"🏦 شماره کارت: {detail}"
        admin_text = (
            f"📤 درخواست برداشت جدید ({kind_fa})\n\n👤 کاربر: {chat_id}\n💰 مبلغ: {amount:,} تومان\n"
            f"{detail_line}\n🎟 کد پیگیری: {track_id}\n⏰ {jnow_date()} {jnow_time()}"
        )
        kb = {"inline_keyboard": [[
            {"text": "✅ تایید برداشت", "callback_data": f"confirme_withdraw-{track_id}"},
            {"text": "❌ رد برداشت", "callback_data": f"reject_withdraw-{track_id}"},
        ]]}
        review_chat_id, review_msg_id = notify_admins_or_channel(admin_text, kb)

        conn = db()
        conn.execute(
            "INSERT INTO withdrawal_requests (chat_id, amount, card, type, track_id, review_chat_id, review_msg_id, created_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (chat_id, amount, detail, wtype, track_id, review_chat_id or "", review_msg_id, datetime.now().isoformat()),
        )
        conn.commit()
        conn.close()

        edit_message(chat_id, message_id, f"✅ درخواست شما با کد {track_id} ثبت شد.\n\n⏳ ممکنه تا ۲۴ ساعت طول بکشه.")
        send_message(chat_id, "به منوی اصلی برگشتی", USER_KEYBOARD)
        set_step(chat_id, "home")
        return

    if data.startswith("confirme_withdraw-"):
        if not is_admin(user_id):
            answer_callback(cb_id, "⛔ فقط ادمین می‌تونه این کارو بکنه.", True)
            return
        track_id = int(data.split("-")[1])
        w = db().execute("SELECT * FROM withdrawal_requests WHERE track_id=?", (track_id,)).fetchone()
        if not w or w["status"] != "pending":
            answer_callback(cb_id, "این درخواست دیگه معتبر نیست.", True)
            return
        if w["type"] == "card" and get_setting("requireScreenshot", "yes") == "yes":
            ensure_user(user_id)
            set_step(user_id, f"await-screenshot-{track_id}")
            send_message(user_id, get_setting("screenshotPromptText", DEFAULT_SCREENSHOT_PROMPT))
            return
        ok, err = finalize_confirm(track_id, user_id)
        if not ok:
            answer_callback(cb_id, err, True)
        return

    if data.startswith("reject_withdraw-"):
        if not is_admin(user_id):
            answer_callback(cb_id, "⛔ فقط ادمین می‌تونه این کارو بکنه.", True)
            return
        track_id = int(data.split("-")[1])
        w = db().execute("SELECT * FROM withdrawal_requests WHERE track_id=?", (track_id,)).fetchone()
        if not w or w["status"] != "pending":
            answer_callback(cb_id, "این درخواست دیگه معتبر نیست.", True)
            return
        ensure_user(user_id)
        set_step(user_id, f"reject-reason-{track_id}")
        send_message(user_id, f"📝 دلیل رد درخواست برداشت (کد {track_id}) رو بنویس:\n\nاین دلیل عیناً برای کاربر ارسال می‌شه.")
        return


# ==================== اجرا ====================
def run():
    last_update_id = 0
    while True:
        try:
            updates = api_request("getUpdates", {"offset": last_update_id + 1, "timeout": 30})
            if updates.get("ok"):
                for update in updates.get("result", []):
                    last_update_id = update["update_id"]
                    try:
                        if "message" in update:
                            handle_message(update["message"])
                        elif "callback_query" in update:
                            handle_callback(update["callback_query"])
                    except Exception as e:
                        print(f"⚠️ خطا در پردازش آپدیت: {e}")
            time.sleep(0.3)
        except KeyboardInterrupt:
            print("\n🛑 بات متوقف شد")
            break
        except Exception as e:
            print(f"⚠️ خطا: {e}")
            time.sleep(2)


if __name__ == "__main__":
    init_db()
    fetch_bot_username()
    print("🚀 ربات کسب درآمد آماده شد")
    print(f"✅ یوزرنیم بات: @{BOT_USERNAME}" if BOT_USERNAME else "⚠️ یوزرنیم بات گرفته نشد")
    print("=" * 40)
    run()
