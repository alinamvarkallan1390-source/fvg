# -*- coding: utf-8 -*-
"""پیکربندی سورس «سلف تبلیغگر اکانت» — فقط ادمین اصلی ربات مجاز است."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SESSIONS_DIR = BASE_DIR / "sessions"
CHECK_DIR = BASE_DIR / "check"
DATA_DIR = BASE_DIR / "data"
PANEL_FILE = DATA_DIR / "panel.json"
LOG_FILE = BASE_DIR / "self_ad.log"

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
MAIN_ADMIN_ID = int(os.getenv("MAIN_ADMIN_ID", "0") or 0)
# لیست اضافی (اختیاری) — اما «فقط فقط» ادمین اصلی به سلف دسترسی دارد
EXTRA_ADMINS = {int(x) for x in os.getenv("EXTRA_ADMINS", "").split(",") if x.strip().isdigit()}

DEFAULT_BANNER = (
    "✨ سلام! این پیام از طرف تیم تبلیغات ارسال شد.\n"
    "برای اطلاعات بیشتر با ما در تماس باشید 🙏"
)
DEFAULT_DELAY = 2          # ثانیه، بین عملیاتهای دستهجمعی (از سورس اصلی)
DEFAULT_INTERVAL_MINUTES = 0   # ۰ = غیرفعال
DEFAULT_PV_COOLDOWN_HOURS = 6
DEFAULT_MAX_PV_PER_HOUR = 60
SESSION_EXTENSION = ".bale"    # رفع باگ سورس اصلی: .id ساخته میشد ولی .bale اسکن میشد


def is_main_admin(user_id) -> bool:
    """دروازه امنیتی تکخط: فقط ادمین ربات اصلی."""
    try:
        return int(user_id) == int(MAIN_ADMIN_ID) and MAIN_ADMIN_ID > 0
    except (TypeError, ValueError):
        return False


def ensure_dirs():
    for d in (SESSIONS_DIR, CHECK_DIR, DATA_DIR):
        d.mkdir(parents=True, exist_ok=True)
