# -*- coding: utf-8 -*-
# =====================================================================
# سورس جداگانه: «سلف تبلیغ گر اکانت» (Self Advertiser)
# برگرفته از main-3_2.py ریپوی اول (کامیت 3837569) — خط به خط بازبینی و
# تمام باگهای شناختهشدهاش رفع شد؛ فقط و فقط ادمین اصلی ربات به آن دسترسی دارد.
#
#  • ورود به اکانت (سشن) و انتخاب گروه هدف از پنل مدیریت
#  • ۱) تبلیغ در گروه هدف   ۲) هر پیام در گروه ⇒ افزودن به مخاطبین + بنر پیوی
#  • ارسال پاکت / تنظیم بنر / ارسال بنر / تنظیم تایم ارسال (۱ دقیقه)
# =====================================================================
from __future__ import annotations

import asyncio
import gc
import json
import os
import shutil
import sys
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

import config
from core import (SelfAdEngine, parse_command, parse_int, parse_minutes,
                  to_english_numbers, valid_phone)

BASE = Path(__file__).resolve().parent

MAIN_KEYBOARD = [
    ["🎯 انتخاب گروه هدف", "📋 لیست گروهها"],
    ["➕ افزودن گروه", "➖ حذف گروه"],
    ["📝 تنظیم بنر", "📢 ارسال تبلیغ به گروه"],
    ["⏱ تنظیم تایم ارسال", "🎁 ارسال پاکت"],
    ["▶️ شروع تبلیغات", "⏹ توقف تبلیغات"],
    ["💻 مدیریت سشن", "🔍 بررسی سشنها"],
    ["📊 آمار", "📦 دریافت بکاپ"],
    ["📚 راهنما"],
]
SESSION_KEYBOARD = [
    ["✨ ساخت سشن", "🔐 دریافت کد ورود"],
    ["📥 افزودن سشن (فایل)", "📋 لیست سشنها"],
    ["🔙 بازگشت"],
]

HELP_TEXT = """📚 **راهنمای سلف تبلیغگر** (فقط ادمین اصلی)

🔹 **دستورات دقیق:**
• `تنظیم بنر (بنر)` یا `تنظیم بنر متن تبلیغ` → ذخیره بنر
• `ارسال بنر (بنر)` → ارسال همان بنر به گروه هدف
• `ارسال پاکت (مبلغ)` → پاکت هدیه با مبلغ (ریال)
• `تنظیم تایم ارسال (1 دقیقه)` → ارسال دورهای هر ۱ دقیقه

🔸 **گروه هدف:** «➕ افزودن گروه» ← لینک دعوت یا آیدی عددی بفرست؛
سپس «🎯 انتخاب گروه هدف» و انتخاب از لیست.

🔹 **رفتار خودکار:** به محض اینکه «هرکسی» در گروه هدف پیام داد،
سلف او را به مخاطبین اضافه کرده و بنر را در پیویش ارسال میکند
(کولداون ۶ ساعت + سقف ساعتی برای جلوگیری از بن شدن).

🔸 **سشن:** «✨ ساخت سشن» ← شماره (مثلاً 989123456789) ← کد ← در صورت
نیاز رمز دو مرحلهای. فایلهای `.bale` و `.zip` هم پذیرفته میشوند.

⚠️ هیچ پیام ناشناخته/پیشفرض پاسخ داده نمیشود."""

WELCOME = ("✨ **پنل مدیریت سلف تبلیغگر اکانت**\n\n"
           "🔐 دسترسی فقط برای ادمین اصلی ربات\n"
           "🎯 اول گروه هدف را انتخاب کن، بعد بنر و تایم ارسال را تنظیم کن.\n"
           "📚 «راهنما» دستورات دقیق را نشان میدهد.")


class SelfAdApp:
    def __init__(self, sdk):
        # sdk = (Bc, private_condition, ReplyKeyboard, Client, Dispatcher, ChatType, AuthErrors)
        (self.Bc, self.private, self.ReplyKeyboard, self.AiobaleClient,
         self.Dispatcher, self.ChatType, self.AuthErrors) = sdk
        config.ensure_dirs()
        self.engine = SelfAdEngine(config.PANEL_FILE, chat_type=self.ChatType,
                                   banner_default=config.DEFAULT_BANNER)
        if not self.engine.data.get("admin_id"):
            self.engine.data["admin_id"] = config.MAIN_ADMIN_ID
        if not self.engine.data.get("delay"):
            self.engine.data["delay"] = config.DEFAULT_DELAY
        self.engine.save()
        self.bot = None
        self.user_state = {}          # FSM ادمین
        self.clients = {}             # session_key -> client
        self.dispatchers = {}
        self.tasks = []
        self.self_ids = set()
        self._scheduler_task = None

    # ---------------- ابزارهای ارسال امن ----------------
    async def reply(self, message, text, keyboard=None):
        if keyboard:
            try:
                return await message.reply(text, self.ReplyKeyboard(*keyboard))
            except Exception:
                pass
        try:
            return await message.reply(text)
        except Exception:
            return None

    async def notify(self, text):
        if self.bot and config.MAIN_ADMIN_ID:
            try:
                await self.bot.send_message(config.MAIN_ADMIN_ID, text)
            except Exception:
                pass

    async def send_document(self, message, path: Path, caption=""):
        """رفع باگ reply_document تاییدنشده سورس اصلی."""
        try:
            if hasattr(message, "reply_document"):
                return await message.reply_document(str(path), caption)
        except Exception:
            pass
        try:
            if hasattr(message, "reply"):
                return await message.reply(caption + f"\n📁 `{path}`")
        except Exception:
            pass
        return None

    # ---------------- سشنها ----------------
    def session_files(self):
        config.ensure_dirs()
        return sorted(f.name for f in config.SESSIONS_DIR.glob("*" + config.SESSION_EXTENSION))

    def make_client(self, session_name: str, dispatcher=None):
        dp = dispatcher or self.Dispatcher()
        path = config.SESSIONS_DIR / session_name
        # رفع باگ: همیشه session_file= (کلمهدار) و همان پسوند .bale
        return dp, self.AiobaleClient(dp, session_file=str(path))

    async def start_sessions(self):
        """یک Dispatcher/Client برای هر سشن؛ پیامهای گروه هدف رهگیری میشوند."""
        for name in self.session_files():
            key = name
            if key in self.clients:
                continue
            dp = self.Dispatcher()

            @dp.message()
            async def _on_message(msg, _key=key):
                try:
                    cli = self.clients.get(_key) or getattr(msg, "client", None)
                    await self.engine.on_group_message(cli, msg, _key, self.self_ids)
                except Exception as e:
                    self.log(f"on_group_message: {e}")

            try:
                dp2, client = self.make_client(name, dp)
                self.dispatchers[key] = dp2
                self.clients[key] = client
                t = asyncio.create_task(client.start())
                self.tasks.append(t)
                try:
                    me = await client.get_me()
                    if getattr(me, "id", None):
                        self.self_ids.add(int(me.id))
                except Exception:
                    pass
            except Exception as e:
                self.log(f"start session {name}: {e}")
        self.restart_scheduler()
        return len(self.clients)

    def restart_scheduler(self):
        if self._scheduler_task:
            try:
                self._scheduler_task.cancel()
            except Exception:
                pass
        try:
            self._scheduler_task = asyncio.create_task(
                self.engine.scheduler_loop(lambda: list(self.clients.items())))
            self.tasks.append(self._scheduler_task)
        except RuntimeError:
            pass   # خارج از event loop (تستها)

    def log(self, msg):
        try:
            with open(config.LOG_FILE, "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().isoformat()} {msg}\n")
        except Exception:
            pass

    # ---------------- گروه هدف ----------------
    async def add_group_from_link(self, message, raw):
        raw = (raw or "").strip()
        if raw.lstrip("-").isdigit():
            g = self.engine.add_group(raw, "", f"گروه {raw}")
            await self.reply(message, f"✅ گروه `{raw}` به عنوان هدف تنظیم شد.")
            return
        if not ("/" in raw or "@" in raw):
            await self.reply(message, "❌ لینک دعوت یا آیدی عددی معتبر بفرست.")
            return
        gid, title, joined = raw, f"گروه {raw[-8:]}", False
        for cli in list(self.clients.values()):
            try:
                preview = await cli.get_group_preview(raw)
                gid = str(int(getattr(preview, "id", None) or preview["id"]))
                title = str(getattr(preview, "title", "") or title)
            except Exception:
                pass
            try:
                await cli.join_chat(raw)
                joined = True
            except Exception:
                pass
            break
        g = self.engine.add_group(gid, raw, title)
        await self.reply(message,
            f"✅ گروه هدف تنظیم شد:\n🏷 {title}\n🆔 `{gid}`\n"
            f"🔗 {raw}\n📥 عضویت سشن: {'انجام شد' if joined else 'نیاز به جوین دستی'}",
            MAIN_KEYBOARD)

    def groups_keyboard(self):
        rows = [[f"🎯 {g.get('title') or g.get('id')} | {str(g.get('id'))[:18]}"]
                for g in self.engine.data.get("groups", [])]
        rows.append(["🔙 بازگشت"])
        return rows

    # ---------------- هندلر اصلی پنل ----------------
    async def handle(self, message):
        # 🚪 دروازه امنیتی: «فقط فقط برای ادمین ربات اصلی»
        try:
            uid = int(message.author.id)
        except Exception:
            return
        if not config.is_main_admin(uid):
            return
        text = (getattr(message, "text", None) or "").strip()
        state = self.user_state.get(uid)

        # ---------- FSM ----------
        if text in ("/cancel", "❌ انصراف"):
            self.user_state.pop(uid, None)
            await self.reply(message, "❌ عملیات لغو شد.", MAIN_KEYBOARD)
            return
        if state:
            handled = await self.handle_state(message, uid, state, text)
            if handled:
                return

        # ---------- دستورات دقیق (هیچ پاسخ پیشفرض وجود ندارد) ----------
        if text in ("/start", "🔙 بازگشت", "بازگشت"):
            await self.reply(message, WELCOME, MAIN_KEYBOARD)
            return
        if text == "📚 راهنما":
            await self.reply(message, HELP_TEXT, MAIN_KEYBOARD)
            return
        if text == "📊 آمار":
            await self.reply(message, self.engine.stats_text(), MAIN_KEYBOARD)
            return
        if text == "📋 لیست گروهها":
            gs = self.engine.data.get("groups", [])
            txt = "📋 **گروههای ذخیرهشده**\n\n" + (
                "\n".join(f"• {g.get('title')} — `{g.get('id')}`"
                          f"{' ✅ هدف' if str(g.get('id')) == str(self.engine.data.get('active_group')) else ''}"
                          for g in gs) if gs else "هنوز گروهی اضافه نشده.")
            await self.reply(message, txt, MAIN_KEYBOARD)
            return
        if text == "🎯 انتخاب گروه هدف":
            if not self.engine.data.get("groups"):
                await self.reply(message, "⚠️ اول «➕ افزودن گروه» را بزن.", MAIN_KEYBOARD)
                return
            await self.reply(message, "گروه هدف تبلیغ را انتخاب کن:", self.groups_keyboard())
            return
        if text.startswith("🎯 "):
            gid = text.split("|")[-1].strip()
            if self.engine.set_active_group(gid):
                await self.reply(message, f"✅ گروه هدف تنظیم شد: `{gid}`", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ گروه یافت نشد.", MAIN_KEYBOARD)
            return
        if text == "➕ افزودن گروه":
            self.user_state[uid] = {"step": "await_group"}
            await self.reply(message, "🔗 لینک دعوت گروه یا آیدی عددی آن را بفرست:\n(لغو: /cancel)")
            return
        if text == "➖ حذف گروه":
            self.user_state[uid] = {"step": "await_remove_group"}
            await self.reply(message, "🆔 آیدی گروهی که باید حذف شود را بفرست:")
            return
        if text == "📝 تنظیم بنر":
            self.user_state[uid] = {"step": "await_banner"}
            await self.reply(message, "📝 متن بنر را بفرست (یا `تنظیم بنر (متن)`):")
            return
        if text == "⏱ تنظیم تایم ارسال":
            self.user_state[uid] = {"step": "await_interval"}
            await self.reply(message, "⏱ دوره ارسال را بفرست، مثال: `1 دقیقه` / `5 دقیقه` / `1 ساعت`")
            return
        if text == "🎁 ارسال پاکت":
            self.user_state[uid] = {"step": "await_packet"}
            await self.reply(message, "💰 مبلغ پاکت (ریال) را بفرست، مثال: `ارسال پاکت (۵۰۰۰)`")
            return
        if text == "📢 ارسال تبلیغ به گروه":
            n = await self.advertise_now()
            await self.reply(message, f"📢 بنر به {n} گروه هدف ارسال شد.", MAIN_KEYBOARD)
            return
        if text == "▶️ شروع تبلیغات":
            self.engine.set_enabled(True)
            await self.start_sessions()
            await self.reply(message, "🟢 سلف فعال شد.\nهر پیام در گروه هدف ⇒ مخاطب + بنر پیوی.", MAIN_KEYBOARD)
            return
        if text == "⏹ توقف تبلیغات":
            self.engine.set_enabled(False)
            await self.reply(message, "🔴 سلف متوقف شد (هیچ پیام خودکاری ارسال نمیشود).", MAIN_KEYBOARD)
            return
        if text == "💻 مدیریت سشن":
            await self.reply(message, "💻 **مدیریت سشنها**", SESSION_KEYBOARD)
            return
        if text == "📋 لیست سشنها":
            files = self.session_files()
            await self.reply(message, "📋 سشنها:\n" + ("\n".join("• " + f for f in files) if files else "— خالی —"),
                             SESSION_KEYBOARD)
            return
        if text == "✨ ساخت سشن":
            self.user_state[uid] = {"step": "await_phone"}
            await self.reply(message, "📱 شماره اکانت را بفرست (مثلاً 989123456789):\nلغو: /cancel")
            return
        if text == "🔐 دریافت کد ورود":
            self.user_state[uid] = {"step": "await_session_name"}
            await self.reply(message, "📄 نام فایل سشن را بفرست (مثلاً 98912….bale):")
            return
        if text == "📥 افزودن سشن (فایل)":
            await self.reply(message, "📥 فایل `.bale` یا فایل `.zip` حاوی سشنها را ارسال کنید.")
            return
        if text == "🔍 بررسی سشنها":
            report = await self.check_sessions()
            await self.reply(message, report, SESSION_KEYBOARD)
            return
        if text == "📦 دریافت بکاپ":
            await self.backup(message)
            return
        if text == "🧹 پاکسازی گروهها":
            n = await self.cleanup_groups()
            await self.reply(message, f"🧹 {n} گروه پاکسازی شد.", MAIN_KEYBOARD)
            return

        # --- دستورات متنی با پارامتر (پرانتز دار/بدون پرانتز) ---
        rest = parse_command(text, "تنظیم بنر")
        if rest is not None:
            if self.engine.set_banner(rest):
                await self.reply(message, f"✅ بنر ذخیره شد:\n\n{self.engine.banner[:500]}", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ بنر خالی یا خیلی طولانی است.")
            return
        rest = parse_command(text, "ارسال بنر")
        if rest is not None:
            banner = rest or self.engine.banner
            n = await self.advertise_now(banner)
            await self.reply(message, f"📢 ارسال بنر به {n} گروه انجام شد.", MAIN_KEYBOARD)
            return
        rest = parse_command(text, "ارسال پاکت")
        if rest is not None:
            amount = parse_int(rest)
            if not amount:
                await self.reply(message, "❌ مبلغ نامعتبر. مثال: `ارسال پاکت (۵۰۰۰)`")
                return
            ok, info = await self.send_packet(amount)
            await self.reply(message, ("🎁 " if ok else "❌ ") + info, MAIN_KEYBOARD)
            return
        rest = parse_command(text, "تنظیم تایم ارسال")
        if rest is not None:
            minutes = parse_minutes(rest)
            if not minutes:
                await self.reply(message, "❌ فرمت نامعتبر. مثال: `تنظیم تایم ارسال (1 دقیقه)`")
                return
            self.engine.set_interval(minutes)
            self.engine.set_enabled(True)
            self.restart_scheduler()
            await self.reply(message,
                f"⏱ ارسال دورهای هر **{minutes} دقیقه** تنظیم و فعال شد.\n"
                "سشنها بهصورت خودکار استارت میشوند.", MAIN_KEYBOARD)
            await self.start_sessions()
            return
        if text.startswith("عضو شو"):
            await self.bulk_join(message, text)
            return

        # 📄 آپلود سشن (از سورس اصلی، ایمنشده)
        doc = getattr(message, "document", None)
        if doc is not None:
            await self.handle_document(message, doc)
            return
        # 🚫 قانون: فقط دستورات تنظیمشده پاسخ میگیرند — هیچ پیام «نامعتبر» ارسال نمیشود

    # ---------------- FSM ----------------
    async def handle_state(self, message, uid, state, text):
        step = state.get("step")
        if step == "await_group":
            self.user_state.pop(uid, None)
            await self.add_group_from_link(message, text)
            return True
        if step == "await_remove_group":
            self.user_state.pop(uid, None)
            self.engine.remove_group(to_english_numbers(text).strip())
            await self.reply(message, "🗑 گروه حذف شد.", MAIN_KEYBOARD)
            return True
        if step == "await_banner":
            self.user_state.pop(uid, None)
            if self.engine.set_banner(text):
                await self.reply(message, "✅ بنر ذخیره شد.", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ متن نامعتبر.")
            return True
        if step == "await_interval":
            self.user_state.pop(uid, None)
            minutes = parse_minutes(text)
            if minutes:
                self.engine.set_interval(minutes)
                self.engine.set_enabled(True)
                self.restart_scheduler()
                await self.reply(message, f"⏱ هر {minutes} دقیقه ارسال میشود.", MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ مثال: `1 دقیقه`")
            return True
        if step == "await_packet":
            self.user_state.pop(uid, None)
            amount = parse_int(text)
            if amount:
                ok, info = await self.send_packet(amount)
                await self.reply(message, ("🎁 " if ok else "❌ ") + info, MAIN_KEYBOARD)
            else:
                await self.reply(message, "❌ مبلغ نامعتبر.")
            return True
        if step == "await_phone":
            phone = valid_phone(text)
            if not phone:
                await self.reply(message, "❌ شماره نامعتبر. مثال: 989123456789")
                return True
            name = phone + config.SESSION_EXTENSION
            if (config.SESSIONS_DIR / name).exists():
                self.user_state.pop(uid, None)
                await self.reply(message, "✅ این سشن از قبل وجود دارد.", SESSION_KEYBOARD)
                return True
            try:
                dp, cli = self.make_client(name)
                t = await cli.start_phone_auth(phone_number=int(phone))
                if not hasattr(t, "transaction_hash"):
                    await self.reply(message, "⚠️ ارسال کد ناموفق بود. شماره را دوباره بررسی کن.")
                    return True
                self.user_state[uid] = {
                    "step": "await_code", "phone": phone,
                    "transaction_hash": t.transaction_hash,
                    "send_time": datetime.now(), "code_attempts": 0,
                    "password_attempts": 0,
                }
                await self.reply(message, "📨 کد ارسال شد (۹۰ ثانیه فرصت داری). کد را بفرست:")
            except Exception as e:
                self.user_state.pop(uid, None)
                await self.reply(message, f"❌ خطا در ارسال کد: {e}")
            return True
        if step in ("await_code", "await_password"):
            if datetime.now() - state.get("send_time", datetime.now()) > timedelta(seconds=90):
                self.user_state.pop(uid, None)
                await self.reply(message, "⏰ مهلت تمام شد.", SESSION_KEYBOARD)
                return True
            name = state["phone"] + config.SESSION_EXTENSION
            try:
                dp, cli = self.make_client(name)
                if step == "await_code":
                    code = to_english_numbers(text).strip()
                    if not code.isdigit():
                        await self.reply(message, "🔢 فقط عدد بفرست.")
                        return True
                    t = await cli.validate_code(code=code,
                                                transaction_hash=state["transaction_hash"])
                    if t == self.AuthErrors.WRONG_CODE:
                        state["code_attempts"] += 1
                        if state["code_attempts"] >= 2:
                            self.user_state.pop(uid, None)
                            await self.reply(message, "🚫 کد اشتباه؛ تلاشها تمام شد.")
                        else:
                            await self.reply(message, "❌ کد اشتباه، یک بار دیگر بفرست.")
                        return True
                    if t == self.AuthErrors.PASSWORD_NEEDED:
                        state["step"] = "await_password"
                        await self.reply(message, "🔐 رمز دو مرحلهای را بفرست:")
                        return True
                    if t == self.AuthErrors.UNKNOWN:
                        self.user_state.pop(uid, None)
                        await self.reply(message, "❌ خطای ناشناخته.")
                        return True
                else:
                    t = await cli.validate_password(text, state["transaction_hash"])
                    if t == self.AuthErrors.WRONG_PASSWORD:
                        state["password_attempts"] += 1
                        if state["password_attempts"] >= 2:
                            self.user_state.pop(uid, None)
                            await self.reply(message, "🚫 رمز اشتباه؛ تلاشها تمام شد.")
                        else:
                            await self.reply(message, "❌ رمز اشتباه، دوباره بفرست.")
                        return True
                    if t == self.AuthErrors.UNKNOWN:
                        self.user_state.pop(uid, None)
                        await self.reply(message, "❌ خطای ناشناخته.")
                        return True
                self.user_state.pop(uid, None)
                await self.reply(message, "🎉 لاگین موفق؛ سشن ذخیره شد.", SESSION_KEYBOARD)
                await self.start_sessions()
            except Exception as e:
                await self.reply(message, f"⚠️ خطا: {e}")
            return True
        if step == "await_session_name":
            self.user_state.pop(uid, None)
            name = os.path.basename((text or "").strip())
            path = config.SESSIONS_DIR / name
            if not path.exists() or not name.endswith(config.SESSION_EXTENSION):
                await self.reply(message, "❌ فایل پیدا نشد.", SESSION_KEYBOARD)
                return True
            await self.reply(message, "⏳ تا ۶۰ ثانیه پیامهای حاوی کد برایتان فوروارد میشود.")
            asyncio.create_task(self.forward_codes(name))
            return True
        return False

    async def forward_codes(self, session_name):
        """نسخه امن get_coder سورس اصلی (client همیشه تعریفشده + cancel امن)."""
        client = None
        task = None
        try:
            dp = self.Dispatcher()

            @dp.message()
            async def _code(msg):
                txt = getattr(msg, "text", "") or ""
                if "Code" in txt or "کد" in txt:
                    await self.notify(f"🔐 کد از {session_name}:\n{txt}")

            dp, client = self.make_client(session_name, dp)
            task = asyncio.create_task(client.start())
            await asyncio.sleep(60)
        except Exception as e:
            self.log(f"forward_codes: {e}")
        finally:
            if task:
                task.cancel()
            if client:
                try:
                    await client.stop()
                except Exception:
                    pass
            await self.notify("⏱ دریافت کد به پایان رسید.")

    # ---------------- عملیات ----------------
    async def advertise_now(self, banner=None):
        if not self.clients:
            await self.start_sessions()
        n = 0
        for key, cli in list(self.clients.items()):
            if cli is None:
                continue
            try:
                n += await self.engine.advertise(cli, banner)
            except Exception as e:
                self.log(f"advertise {key}: {e}")
        self.engine.save()
        return n

    async def send_packet(self, amount):
        if not self.clients:
            await self.start_sessions()
        for cli in list(self.clients.values()):
            if cli is None:
                continue
            return await self.engine.send_packet(cli, amount)
        return False, "هیچ سشن فعالی وجود ندارد"

    async def bulk_join(self, message, text):
        """`عضو شو\\n[تعداد]\\n[لینک]` — نسخه بدون except خالی/متغیر تعریفنشده."""
        parts = [p.strip() for p in text.split("\n") if p.strip()]
        if len(parts) < 3:
            await self.reply(message, "فرمت: `عضو شو` \\n تعداد \\n لینک")
            return
        count = parse_int(parts[1]) or 0
        link = parts[2]
        if count <= 0:
            await self.reply(message, "❌ تعداد نامعتبر.")
            return
        if not self.clients:
            await self.start_sessions()
        done = 0
        for key, cli in list(self.clients.items())[:count]:
            try:
                await cli.join_chat(link)
                done += 1
            except Exception as e:
                self.log(f"join {key}: {e}")
            await asyncio.sleep(float(self.engine.data.get("delay") or 2))
        await self.add_group_from_link(message, link)
        await self.reply(message, f"✅ {done} سشن به گروه جوین شدند.", MAIN_KEYBOARD)

    async def check_sessions(self):
        ok = bad = 0
        seen = set()
        for name in self.session_files():
            client = None
            try:
                dp, client = self.make_client(name)
                me = await client.get_me()
                mid = int(getattr(me, "id", 0) or 0)
                if mid and mid in seen:
                    (config.SESSIONS_DIR / name).unlink(missing_ok=True)
                    continue
                seen.add(mid)
                ok += 1
            except Exception:
                (config.SESSIONS_DIR / name).unlink(missing_ok=True)
                bad += 1
            finally:
                if client is not None:
                    try:
                        await client.stop()
                    except Exception:
                        pass
        return f"🔍 بررسی سشنها\n✅ سالم: {ok}\n❌ خراب/تکراری حذفشده: {bad}"

    async def cleanup_groups(self):
        n = 0
        for g in list(self.engine.data.get("groups", [])):
            gid = await self._resolve_id(g)
            for cli in list(self.clients.values()):
                try:
                    await cli.leave_group(gid)
                except Exception:
                    pass
            self.engine.remove_group(g.get("id"))
            n += 1
        return n

    async def _resolve_id(self, g):
        for cli in list(self.clients.values()):
            try:
                v = await self.engine.resolve_group_id(cli, g)
                if v is not None:
                    return v
            except Exception:
                pass
        try:
            return int(str(g.get("id")))
        except Exception:
            return 0

    async def handle_document(self, message, doc):
        name = os.path.basename(str(getattr(doc, "name", "") or ""))
        if not (name.endswith(".bale") or name.endswith(".zip")):
            return
        try:
            raw = await self.bot.download(doc.id)
        except Exception as e:
            await self.reply(message, f"❌ دانلود فایل ناموفق: {e}")
            return
        config.ensure_dirs()
        tmp = config.CHECK_DIR / name
        tmp.write_bytes(raw)
        if name.endswith(".zip"):
            good = bad = 0
            with zipfile.ZipFile(tmp, "r") as zf:
                for member in zf.namelist():
                    if not member.endswith(config.SESSION_EXTENSION):
                        continue
                    target = config.SESSIONS_DIR / os.path.basename(member)
                    client = None
                    try:
                        target.write_bytes(zf.read(member))
                        dp, client = self.make_client(target.name)
                        await client.get_me()
                        good += 1
                    except Exception:
                        target.unlink(missing_ok=True)
                        bad += 1
                    finally:
                        if client:
                            try:
                                await client.stop()
                            except Exception:
                                pass
            await self.reply(message, f"📦 سشنهای سالم: {good} | خراب: {bad}", SESSION_KEYBOARD)
        else:
            client = None
            try:
                dp, client = self.make_client(name)
                await client.get_me()
                (config.SESSIONS_DIR / name).write_bytes(raw)
                await self.reply(message, "✅ فایل سشن تایید و ذخیره شد.", SESSION_KEYBOARD)
            except Exception:
                await self.reply(message, "❌ فایل سشن خراب یا نامعتبر است.")
            finally:
                if client:
                    try:
                        await client.stop()
                    except Exception:
                        pass
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        gc.collect()

    async def backup(self, message):
        out = config.CHECK_DIR / "sessions_backup"
        shutil.make_archive(str(out), "zip", str(config.SESSIONS_DIR))
        zip_path = Path(str(out) + ".zip")
        await self.send_document(message, zip_path,
                                 "📦 بکاپ سشنها — " + datetime.now().strftime("%Y/%m/%d %H:%M"))
        try:
            zip_path.unlink(missing_ok=True)
        except Exception:
            pass

    # ---------------- register ----------------
    def register(self, bot):
        self.bot = bot
        cond = self.private

        @bot.on_message(cond)
        async def _handler(message):
            try:
                await self.handle(message)
            except Exception as e:
                self.log(f"handler: {e}")
                try:
                    await self.reply(message, f"⚠️ خطای کنترلشده: {e}")
                except Exception:
                    pass
        return bot


def load_sdk():
    """واردات تنبل — امکان اجرای تستهای آفلاین بدون نصب SDK."""
    from balethon import Client as Bc
    from balethon.conditions import private
    from balethon.objects import ReplyKeyboard
    from aiobale import Client, Dispatcher
    from aiobale.enums import ChatType, AuthErrors
    return Bc, private, ReplyKeyboard, Client, Dispatcher, ChatType, AuthErrors


def run():
    if not config.BOT_TOKEN:
        print("❌ خطا: متغیر محیطی BOT_TOKEN تنظیم نشده است.", file=sys.stderr)
        return 1
    if config.MAIN_ADMIN_ID <= 0:
        print("❌ خطا: MAIN_ADMIN_ID تنظیم نشده — سلف فقط برای ادمین اصلی فعال است.", file=sys.stderr)
        return 1
    sdk = load_sdk()
    app = SelfAdApp(sdk)
    bot = sdk[0](config.BOT_TOKEN)
    app.register(bot)
    bot.run()
    return 0


if __name__ == "__main__":
    sys.exit(run())
