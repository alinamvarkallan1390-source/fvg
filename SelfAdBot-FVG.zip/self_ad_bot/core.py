# -*- coding: utf-8 -*-
"""هسته منطقی سلف تبلیغگر — بدون وابستگی خارجی (کاملاً قابلتست آفلاین).

منطقها:
 ۱) تبلیغ در گروه(های) هدف انتخابشده از پنل مدیریت
 ۲) به محض پیام هرکس در گروه هدف ← افزودن به مخاطبین + ارسال بنر به پیوی او
 ۳) ارسال پاکت هدیه (send_gift)، تنظیم/ارسال بنر و ارسال دورهای
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

PERSIAN_DIGITS = {
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
    "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
    "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
}

DEFAULT_CONFIG = {
    "admin_id": 0,
    "banner": "",
    "interval_minutes": 0,
    "delay": 2,
    "pv_cooldown_hours": 6,
    "max_pv_per_hour": 60,
    "enabled": False,
    "groups": [],          # [{id, link, title}]
    "active_group": "",    # شناسه گروه هدف فعلی
    "group": [],           # لینکهای سازگار با data/panel.json سورس اصلی
    "stats": {"group_ads": 0, "pv_sent": 0, "contacts": 0,
              "packets": 0, "errors": 0, "auto_replies": 0},
}


def to_english_numbers(text: str) -> str:
    return "".join(PERSIAN_DIGITS.get(ch, ch) for ch in str(text or ""))


def parse_int(text: str) -> Optional[int]:
    """استخراج اولین عدد (فارسی/عربی/انگلیسی) از متن داخل/خارج پرانتز."""
    t = to_english_numbers(str(text or ""))
    m = re.search(r"\d+", t)
    return int(m.group(0)) if m else None


def parse_minutes(text: str) -> Optional[int]:
    """`تنظیم تایم ارسال (1 دقیقه)` → ۱ دقیقه؛ پشتیبانی ثانیه/دقیقه/ساعت."""
    t = to_english_numbers(str(text or "")).lower()
    m = re.search(r"(\d+)", t)
    if not m:
        return None
    n = int(m.group(1))
    if "ثانیه" in t or "second" in t or "sec" in t:
        return max(1, round(n / 60))
    if "ساعت" in t or "hour" in t:
        return n * 60
    return n  # پیشفرض دقیقه


def parse_command(text: str, prefix: str) -> Optional[str]:
    """`تنظیم بنر (متن)` و `تنظیم بنر متن` هر دو برگردانده میشوند."""
    t = (text or "").strip()
    if not t.startswith(prefix):
        return None
    rest = t[len(prefix):].strip()
    if rest.startswith("(") and rest.endswith(")") and len(rest) >= 2:
        rest = rest[1:-1].strip()
    return rest


def valid_phone(text: str) -> Optional[str]:
    phone = re.sub(r"\D", "", to_english_numbers(text))
    if len(phone) == 10 and not phone.startswith("9"):
        phone = "9" + phone
    elif len(phone) == 11 and phone.startswith("09"):
        phone = phone[1:]
    return phone if phone.isdigit() and len(phone) >= 10 else None


class SelfAdEngine:
    """موتور بدون I/O خارجی — تمام تعاملات از طریق آبجکت client تزریق میشود."""

    def __init__(self, config_path: Optional[Path] = None, chat_type=None, banner_default: str = ""):
        self.config_path = Path(config_path) if config_path else None
        self.ChatType = chat_type
        self.banner_default = banner_default
        self.data = self._load()
        self._pv_last: Dict[Tuple[str, int], float] = {}
        self._pv_hour: Dict[str, List[float]] = {}
        self._seen_messages: set = set()
        self._scheduler_task = None
        self._clients: Dict[str, Any] = {}
        self._lock = asyncio.Lock()

    # ---------------- پیکربندی ----------------
    def _load(self) -> Dict[str, Any]:
        cfg = json.loads(json.dumps(DEFAULT_CONFIG))
        if self.config_path and self.config_path.exists():
            try:
                saved = json.loads(self.config_path.read_text(encoding="utf-8"))
                if isinstance(saved, dict):
                    for k, v in saved.items():
                        if k in cfg:
                            cfg[k] = v
            except Exception:
                pass
        cfg.setdefault("stats", dict(DEFAULT_CONFIG["stats"]))
        if not cfg.get("banner"):
            cfg["banner"] = self.banner_default
        return cfg

    def save(self):
        if not self.config_path:
            return
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.config_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.config_path)   # نوشتن اتمیک → پنل نیمهنوشته نمیماند
        except Exception:
            pass

    @property
    def banner(self) -> str:
        return self.data.get("banner") or self.banner_default

    def set_banner(self, text: str) -> bool:
        text = (text or "").strip()
        if not text or len(text) > 3500:
            return False
        self.data["banner"] = text
        self.save()
        return True

    def set_interval(self, minutes: int) -> int:
        minutes = max(0, min(int(minutes), 24 * 60))
        self.data["interval_minutes"] = minutes
        self.save()
        return minutes

    @property
    def interval_seconds(self) -> int:
        return int(self.data.get("interval_minutes") or 0) * 60

    def set_enabled(self, value: bool):
        self.data["enabled"] = bool(value)
        self.save()

    # ---------------- گروههای هدف ----------------
    def target_groups(self) -> List[Dict[str, Any]]:
        active = str(self.data.get("active_group") or "").strip()
        groups = [g for g in self.data.get("groups", []) if isinstance(g, dict)]
        if active:
            chosen = [g for g in groups if str(g.get("id")) == active]
            if chosen:
                return chosen
        return groups[:1]   # پیشفرض: فقط یک گروه هدف → جلوگیری از ارسال ناخواسته

    def add_group(self, group_id, link: str = "", title: str = "") -> Dict[str, Any]:
        gid = str(group_id).strip()
        for g in list(self.data.get("groups", [])):
            if str(g.get("id")) == gid or (link and str(g.get("link")) == link):
                g["link"] = link or g.get("link", "")
                g["title"] = title or g.get("title", "")
                self.data["active_group"] = gid
                self.save()
                return g
        g = {"id": gid, "link": link, "title": title or gid}
        self.data.setdefault("groups", []).append(g)
        if link and link not in self.data.get("group", []):
            self.data.setdefault("group", []).append(link)
        self.data["active_group"] = gid
        self.save()
        return g

    def remove_group(self, group_id):
        gid = str(group_id)
        self.data["groups"] = [g for g in self.data.get("groups", []) if str(g.get("id")) != gid]
        if str(self.data.get("active_group")) == gid:
            self.data["active_group"] = str(self.data["groups"][0]["id"]) if self.data["groups"] else ""
        self.save()

    def set_active_group(self, group_id) -> bool:
        gid = str(group_id)
        if any(str(g.get("id")) == gid for g in self.data.get("groups", [])):
            self.data["active_group"] = gid
            self.save()
            return True
        return False

    def is_target(self, chat_id) -> bool:
        cid = str(chat_id)
        return any(str(g.get("id")) == cid for g in self.target_groups())

    # ---------------- تعامل با aiobale ----------------
    async def resolve_group_id(self, client, group: Dict[str, Any]):
        """لینک → شناسه عددی گروه (get_group_preview)؛ عدد → همان عدد."""
        gid = str(group.get("id") or "").strip()
        if gid.lstrip("-").isdigit():
            return int(gid)
        link = str(group.get("link") or "").strip()
        if not link:
            return None
        try:
            preview = await client.get_group_preview(link)
            if preview is None:
                return None
            return int(getattr(preview, "id", None) or preview["id"])
        except Exception:
            return None

    async def send_group_ad(self, client, group: Dict[str, Any], banner: Optional[str] = None) -> bool:
        gid = await self.resolve_group_id(client, group)
        if gid is None:
            self.data["stats"]["errors"] += 1
            return False
        try:
            await client.send_message(text=banner or self.banner, chat_id=gid,
                                      chat_type=self.ChatType.GROUP)
            self.data["stats"]["group_ads"] += 1
            return True
        except Exception:
            # fallback شناسه آفستدار گروههای بله (مطابق سورس اصلی: id + 2**32)
            try:
                await client.send_message(text=banner or self.banner, chat_id=gid + (2 ** 32),
                                          chat_type=self.ChatType.GROUP)
                self.data["stats"]["group_ads"] += 1
                return True
            except Exception:
                self.data["stats"]["errors"] += 1
                return False

    async def advertise(self, client, banner: Optional[str] = None) -> int:
        """۱) تبلیغ در گروه(های) هدف."""
        n = 0
        for g in self.target_groups():
            if await self.send_group_ad(client, g, banner):
                n += 1
        self.save()
        return n

    async def add_contact_and_send_pv(self, client, user_id: int, session_key: str = "default",
                                      force: bool = False, banner: Optional[str] = None) -> bool:
        """۲) افزودن به مخاطبین + ارسال بنر به پیوی (با کولداون و سقف ساعتی)."""
        if not user_id:
            return False
        uid = int(user_id)
        now = time.time()
        cooldown = float(self.data.get("pv_cooldown_hours") or 6) * 3600
        if not force and now - self._pv_last.get((session_key, uid), 0) < cooldown:
            return False
        hour = [t for t in self._pv_hour.get(session_key, []) if now - t < 3600]
        cap = int(self.data.get("max_pv_per_hour") or 60)
        if not force and len(hour) >= cap:
            return False
        try:
            await client.add_contact(user_id=uid)
            self.data["stats"]["contacts"] += 1
        except Exception:
            # حتی اگر add_contact خطا داد (مثلاً از قبل مخاطب است)، پیام ارسال شود
            pass
        try:
            await client.send_message(text=banner or self.banner, chat_id=uid,
                                      chat_type=self.ChatType.PRIVATE)
        except Exception:
            self.data["stats"]["errors"] += 1
            return False
        self._pv_last[(session_key, uid)] = now
        hour.append(now)
        self._pv_hour[session_key] = hour
        self.data["stats"]["pv_sent"] += 1
        self.save()
        return True

    async def on_group_message(self, client, msg, session_key: str = "default",
                               self_ids: Iterable[int] = ()) -> bool:
        """به محض «هر پیامی» در گروه هدف → مخاطب + بنر پیوی."""
        if not self.data.get("enabled", False):
            return False
        chat = getattr(msg, "chat", None)
        cid = getattr(chat, "id", None) if chat is not None else None
        if cid is None:
            return False
        if not self.is_target(cid):
            return False
        uid = getattr(msg, "sender_id", None)
        if uid is None:
            return False
        if int(uid) in {int(x) for x in (self_ids or [])}:
            return False
        mid = getattr(msg, "message_id", None)
        dedup_key = (session_key, cid, mid)
        if mid is not None and dedup_key in self._seen_messages:
            return False
        if mid is not None:
            self._seen_messages.add(dedup_key)
            if len(self._seen_messages) > 20000:      # محافظ حافظه
                self._seen_messages = set(list(self._seen_messages)[-10000:])
        target_client = client or getattr(msg, "client", None)
        if target_client is None:
            return False
        ok = await self.add_contact_and_send_pv(target_client, uid, session_key)
        if ok:
            self.data["stats"]["auto_replies"] += 1
        return ok

    async def send_packet(self, client, amount: int, banner: Optional[str] = None,
                          gift_count: int = 1) -> Tuple[bool, str]:
        """ارسال پاکت هدیه (send_gift) به گروه هدف."""
        amount = int(amount or 0)
        if amount <= 0:
            return False, "مبلغ نامعتبر است"
        if not self.data.get("groups"):
            return False, "اول گروه هدف را از پنل مدیریت انتخاب کن"
        gid = await self.resolve_group_id(client, self.target_groups()[0])
        if gid is None:
            return False, "شناسه گروه قابل حل نیست"
        try:
            await client.send_gift(chat_id=gid, chat_type=self.ChatType.GROUP,
                                   amount=amount, message=banner or self.banner,
                                   gift_count=max(1, int(gift_count)))
            self.data["stats"]["packets"] += 1
            self.save()
            return True, f"پاکت {amount:,} ریال ارسال شد"
        except Exception:
            try:
                await client.send_gift(chat_id=gid + (2 ** 32), chat_type=self.ChatType.GROUP,
                                       amount=amount, message=banner or self.banner,
                                       gift_count=max(1, int(gift_count)))
                self.data["stats"]["packets"] += 1
                self.save()
                return True, f"پاکت {amount:,} ریال ارسال شد"
            except Exception as e:
                self.data["stats"]["errors"] += 1
                return False, f"خطا در ارسال پاکت: {e}"

    # ---------------- ارسال دورهای ----------------
    async def scheduler_loop(self, get_clients):
        """`تنظیم تایم ارسال (1 دقیقه)` ⇒ هر دقیقه بنر به گروه هدف."""
        while True:
            await asyncio.sleep(max(5, self.interval_seconds or 60))
            if not self.data.get("enabled", False) or not self.interval_seconds:
                continue
            try:
                clients = list(get_clients() or [])
            except Exception:
                clients = []
            for key, cli in clients:
                if cli is None:
                    continue
                try:
                    await self.advertise(cli)
                except Exception:
                    self.data["stats"]["errors"] += 1
                await asyncio.sleep(float(self.data.get("delay") or 2))
            self.save()

    def stats_text(self) -> str:
        s = self.data.get("stats", {})
        return (
            "📊 **آمار سلف تبلیغگر**\n\n"
            f"📢 تبلیغ در گروه: {s.get('group_ads', 0)}\n"
            f"📩 بنر پیوی: {s.get('pv_sent', 0)}\n"
            f"👥 افزوده به مخاطبین: {s.get('contacts', 0)}\n"
            f"🤖 پاسخ خودکار به پیام گروه: {s.get('auto_replies', 0)}\n"
            f"🎁 پاکتها: {s.get('packets', 0)}\n"
            f"❌ خطاها: {s.get('errors', 0)}\n\n"
            f"🎯 گروه هدف: `{self.data.get('active_group') or '---'}`\n"
            f"⏱ دوره ارسال: {self.data.get('interval_minutes') or 0} دقیقه\n"
            f"🟢 وضعیت: {'فعال' if self.data.get('enabled') else 'غیرفعال'}"
        )

    def status_text(self) -> str:
        return (
            "🤖 **سلف تبلیغگر اکانت**\n"
            f"📝 بنر فعلی:\n{self.banner[:400]}\n\n"
            f"{self.stats_text()}"
        )
